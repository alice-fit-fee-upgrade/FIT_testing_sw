open_checkpoint gate_phase_route.dcp
source hdmi-timing.tcl
report_timing_summary -check_timing_verbose -report_unconstrained -file qualification-timing.rpt
report_drc -file qualification-drc.rpt
report_cdc -details -file qualification-cdc.rpt
report_utilization -file qualification-utilization.rpt
set wns [get_property SLACK [get_timing_paths -delay_type max -max_paths 1]]
set whs [get_property SLACK [get_timing_paths -delay_type min -max_paths 1]]
set errors [get_drc_violations -filter {SEVERITY == Error}]
set iserdes [llength [get_cells -hier -filter {REF_NAME == ISERDESE2}]]
set diffout [llength [get_cells -hier -filter {REF_NAME =~ OBUFDS* || REF_NAME =~ OBUFTDS* || REF_NAME =~ IOBUFDS*}]]
if {[llength [get_cells -hier -filter {REF_NAME == GTPE2_COMMON}]] != 1 || [llength [get_cells -hier -filter {REF_NAME == GTPE2_CHANNEL}]] != 3} {error "Expected one dual-PLL common and two SFP channels"}
set f [open qualification-values.json w]
puts $f "{\"wns_ns\": $wns, \"whs_ns\": $whs, \"drc_errors\": [llength $errors], \"iserdes_count\": $iserdes, \"differential_output_buffers\": $diffout}"
close $f
if {$wns<0 || $whs<0 || [llength $errors] || $iserdes!=18 || $diffout!=10} {error "RX gate-phase implementation does not qualify"}

write_checkpoint -force gate_phase_qualified.dcp
set_property BITSTREAM.CONFIG.OVERTEMPPOWERDOWN Enable [current_design]
set_property BITSTREAM.GENERAL.COMPRESS True [current_design]
set_property BITSTREAM.CONFIG.CONFIGRATE 16 [current_design]
set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 1 [current_design]
set_property BITSTREAM.CONFIG.USR_ACCESS TIMESTAMP [current_design]
set_property BITSTREAM.CONFIG.USERID "0x52504831" [current_design]
set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 2.5 [current_design]
write_bitstream -force gate_phase_qualified.bit 
exit