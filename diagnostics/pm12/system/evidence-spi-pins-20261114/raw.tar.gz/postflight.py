import sys,contextlib,json,datetime
from pathlib import Path
sys.path.insert(0,'/home/codex-hil/fit-testing-publish/diagnostics/pm12/system')
from hold_spi import *
from client import save_capture
root=Path(__file__).parent;out=root/'postflight';out.mkdir(exist_ok=False);r={}
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console(dict(uart='/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port0')));d=system.GatePhaseIPbusDevice();st.callback(d.close);c=system.Client();st.callback(c.close)
 r['identity']=c.read(0,3);r['enable']=d.read(0x144);r['state']=d.read(0x150);r['tdc_frontend']=c.read(0x205)[0];r['pgood']=require_power_good(u,capture);r['mcu']=capture(u,'RS')
 try:
  gen,status=c.acquire(0,False);data=c.download(gen);r['adc']=save_capture(out/'adc-final',data,0,False,gen,status);r['pass']=True
 except Exception as e:r['pass']=False;r['error']=repr(e)
 finally:r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
 print(r['pass'],r.get('error'))
