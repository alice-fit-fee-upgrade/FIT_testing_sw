set_param general.maxThreads 4
open_checkpoint build/pm12_ipbus_adc_routed.dcp
phys_opt_design -directive AggressiveExplore
route_design -directive AggressiveExplore
report_timing_summary -file build/timing-closed.txt
report_drc -file build/drc-closed.txt
foreach corner {max min} {
 if {[llength [get_timing_paths -quiet -delay_type $corner -slack_lesser_than 0 -max_paths 1]]} {error "Timing failed $corner"}
}
write_checkpoint -force build/pm12_ipbus_adc_closed.dcp
write_bitstream -force build/pm12_ipbus_adc.bit
