import sys,fcntl,contextlib,time,json
from pathlib import Path
sys.path.insert(0,'/home/codex-hil/kasli-phase-tester')
from host.pm_system_test import GatePhaseIPbusDevice,Client,HDMIAdapter,dio_directions,input_cards
with contextlib.ExitStack() as st:
 for name in sorted(['atmel-ice-J41800043065','kasli-diot-00001','pm12-210249A73E43']):
  f=st.enter_context(open('/home/codex-hil/.cache/'+name+'.lock','a+'));fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 d=GatePhaseIPbusDevice();st.callback(d.close);c=Client();st.callback(c.close);input_cards(d);a=HDMIAdapter(d);result=[]
 def snap(label):
  u=c.read(5,2);r=dict(label=label,uptime=u,tdc=c.read(0x201,2),drops=d.read(0x130));result.append(r);print(r,flush=True)
 try:
  snap('initial')
  for mode in [0,15,5,10,0,48,0,32,0,16,0]:
   c.write(0x301,[mode]);time.sleep(.01);snap('mode '+str(mode))
  with dio_directions(a,a.mask):
   snap('SPI enabled')
   for value in [0,65535,0x5555,0xaaaa,1,0x8000,0x1234,0xa55a]:
    a.transfer(False,0x40,value);assert a.transfer(True,0x40)==value;snap('SPI write '+hex(value))
  snap('SPI released')
 finally:
  try:c.write(0x301,[0])
  finally:a.stop();(Path('/srv/codex-hil-nvme/pm12-hdmi-integrated-20261106/reset-source-probe.json')).write_text(json.dumps(result,indent=2)+'\n')
