create_project -force -name gate_phase -part xc7a200t-ffg1156-3
set_property XPM_LIBRARIES {XPM_CDC XPM_MEMORY} [current_project]
add_files {gate_phase.v}
set_property library work [get_files {gate_phase.v}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/ipbus_ctrl.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/ipbus_ctrl.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/ipbus_endpoint.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/ipbus_endpoint.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/ipbus_package.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/ipbus_package.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/ipbus_trans_decl.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/ipbus_trans_decl.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/trans_arb.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/trans_arb.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/transactor.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/transactor.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/transactor_cfg.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/transactor_cfg.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/transactor_if.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/transactor_if.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/transactor_sm.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/transactor_sm.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_buffer_selector.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_buffer_selector.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_arp.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_arp.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_payload.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_payload.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_ping.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_ping.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_resend.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_resend.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_status.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_build_status.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_byte_sum.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_byte_sum.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_clock_crossing_if.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_clock_crossing_if.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_do_rx_reset.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_do_rx_reset.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_dualportram.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_dualportram.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_dualportram_rx-ghdl.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_dualportram_rx-ghdl.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_dualportram_tx.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_dualportram_tx.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_if_flat.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_if_flat.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_ipaddr_ipam.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_ipaddr_ipam.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_ipam_block.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_ipam_block.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_packet_parser.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_packet_parser.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_rxram_mux.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_rxram_mux.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_rxram_shim.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_rxram_shim.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_rxtransactor_if_simple.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_rxtransactor_if_simple.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_status_buffer.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_status_buffer.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_tx_mux.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_tx_mux.vhd}]
add_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_txtransactor_if_simple.vhd}
set_property library work [get_files {imports/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/ipbus/udp_txtransactor_if_simple.vhd}]
read_xdc gate_phase.xdc
synth_design -top gate_phase -part xc7a200t-ffg1156-3
report_timing_summary -file gate_phase_timing_synth.rpt
report_utilization -hierarchical -file gate_phase_utilization_hierarchical_synth.rpt
report_utilization -file gate_phase_utilization_synth.rpt
opt_design -directive ExploreWithRemap
place_design
report_utilization -hierarchical -file gate_phase_utilization_hierarchical_place.rpt
report_utilization -file gate_phase_utilization_place.rpt
report_io -file gate_phase_io.rpt
report_control_sets -verbose -file gate_phase_control_sets.rpt
report_clock_utilization -file gate_phase_clock_utilization.rpt
route_design
phys_opt_design
report_timing_summary -no_header -no_detailed_paths
write_checkpoint -force gate_phase_route.dcp
report_route_status -file gate_phase_route_status.rpt
report_drc -file gate_phase_drc.rpt
report_timing_summary -datasheet -max_paths 10 -file gate_phase_timing.rpt
report_power -file gate_phase_power.rpt