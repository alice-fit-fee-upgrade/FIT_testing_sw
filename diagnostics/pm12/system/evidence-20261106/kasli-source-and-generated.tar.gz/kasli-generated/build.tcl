set_param general.maxThreads 4
source gate_phase.tcl
source qualify.tcl
