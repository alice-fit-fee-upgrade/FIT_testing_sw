"""Receive-only16-lane phase recorder: two gate-return pairs on8 RJ45 sockets.

Reuses ParallelBank/WindowCapture, Control and PhaseRecords unchanged. The base image is RX-only. Optional CFD/HDMI modules explicitly own their
output pads and default to released; phase/data pins remain inputs.
Reference: direct MCX120MHz, MMCM960MHz VCO,480MHz DDR/120MHz words.
"""
import argparse,hashlib,json
from pathlib import Path
from migen import *
from migen.genlib.cdc import MultiReg
from migen.genlib.resetsync import AsyncResetSynchronizer
from migen.build.generic_platform import Pins,IOStandard,Subsignal
from migen.build.platforms.sinara.kasli_diot import Platform
from misoc.cores.uart.core import RS232PHY
from gateware.core import RegisterProtocol
from gateware.lvds8 import ParallelBank
from gateware.lvds8_control import Control

LANES=[dict(logical=i,slot=slot,channel=channel,rj45=channel//4,pair_p=4 if channel%4==1 else 7,pair_n=5 if channel%4==1 else 8)
       for i,(slot,channel) in enumerate((s,c) for s in (6,7) for c in range(1,16,2))]
MAGIC=0x52504831 # RPH1: do not confuse this RX-only map with one whole DIO card.


class Top(Module):
    def __init__(self,platform,network=False,cfd_tx=False,pm_link=False,pm_bridge=False,hdmi=False,hdmi_data_base=4):
        for name in ('sys','sample','ser_rx'):
            setattr(self.clock_domains,'cd_'+name,ClockDomain(name))
        if network:self.clock_domains.cd_ipbus=ClockDomain('ipbus')
        if cfd_tx:self.clock_domains.cd_ser_tx=ClockDomain('ser_tx',reset_less=True)
        pads=platform.request('mcx_clkin');reference=Signal();buffered=Signal()
        self.specials += [Instance('IBUFDS',i_I=pads.p,i_IB=pads.n,o_O=reference),Instance('BUFG',i_I=reference,o_O=buffered)]
        platform.add_period_constraint(pads.p,1e9/(120.2361e6 if pm_link else 120e6))
        locks=[]
        # Independent control and sampling120MHz clocks reproduce the proven
        # LVDS backend's clock domains without an unused serializer output clock.
        for name,slow,fast_domain in [('sys',self.cd_sys,None),('rx',self.cd_sample,self.cd_ser_rx)]:
            feedback=Signal();fb=Signal();word=Signal();fast=Signal();locked=Signal();locks.append(locked)
            extra={}
            if network and name=='sys':
                ipword=Signal();extra=dict(p_CLKOUT2_DIVIDE=24,o_CLKOUT2=ipword)
                self.specials += [Instance('BUFG',i_I=ipword,o_O=self.cd_ipbus.clk),AsyncResetSynchronizer(self.cd_ipbus,~locked)]
            self.specials += [Instance('MMCME2_BASE',name='gate_mmcm_'+name,p_CLKIN1_PERIOD=1e9/120e6,
                p_CLKFBOUT_MULT_F=8.0,p_DIVCLK_DIVIDE=1,p_CLKOUT0_DIVIDE_F=2.0,p_CLKOUT1_DIVIDE=8,
                i_CLKIN1=buffered,i_CLKFBIN=fb,o_CLKFBOUT=feedback,i_RST=0,i_PWRDWN=0,
                o_LOCKED=locked,o_CLKOUT0=fast,o_CLKOUT1=word,**extra),
                Instance('BUFG',i_I=feedback,o_O=fb),Instance('BUFG',i_I=word,o_O=slow.clk),AsyncResetSynchronizer(slow,~locked)]
            if fast_domain is not None:self.specials += Instance('BUFG',i_I=fast,o_O=fast_domain.clk)
            if cfd_tx and name=='sys':self.specials += Instance('BUFG',i_I=fast,o_O=self.cd_ser_tx.clk)
        rx_lock=Signal();self.specials += MultiReg(locks[1],rx_lock)
        ready=Signal();self.comb += ready.eq(locks[0]&rx_lock)
        resources=[]
        for row in LANES:
            connector='diot%d:d%d'%(row['slot']-1,row['channel'])
            resources.append(('gate_lvds',row['logical'],Subsignal('p',Pins(connector+'_p')),Subsignal('n',Pins(connector+'_n')),IOStandard('LVDS_25')))
        platform.add_extension(resources)
        self.submodules.bank=bank=ParallelBank(16,4096)
        hdmi_inputs={}
        if hdmi:
            from gateware.hdmi_integrated import HDMITester,HDMI_TIMING
            # Bus is connected after network arbitration is constructed below.
            hdmi_bus=Record([('address',16),('write_data',32),('read_data',32),('write',1)])
            self.submodules.hdmi=hdmi_test=HDMITester(hdmi_bus,bank,ready,data_base=hdmi_data_base)
            spi_base=4-hdmi_data_base
            spi_clock_index=spi_base//2
            spi_mosi_index=spi_clock_index+1
        for index in range(16):
            pair=platform.request('gate_lvds',index);inp=Signal();word=Signal(8)
            if hdmi and index in (spi_clock_index,spi_mosi_index):
                self.specials += Instance('IOBUFDS_INTERMDISABLE',p_DIFF_TERM='TRUE',p_IBUF_LOW_PWR='FALSE',p_USE_IBUFDISABLE='TRUE',
                    i_I=hdmi_test.sck if index==spi_clock_index else hdmi_test.mosi,i_T=~hdmi_test.output_enable,
                    i_IBUFDISABLE=hdmi_test.output_enable,i_INTERMDISABLE=hdmi_test.output_enable,io_IO=pair.p,io_IOB=pair.n,o_O=inp)
            else:self.specials += Instance('IBUFDS',p_DIFF_TERM='TRUE',p_IBUF_LOW_PWR='FALSE',i_I=pair.p,i_IB=pair.n,o_O=inp)
            self.specials += [Instance('ISERDESE2',p_DATA_RATE='DDR',p_DATA_WIDTH=8,p_INTERFACE_TYPE='NETWORKING',p_NUM_CE=1,
                    i_D=inp,i_CLK=ClockSignal('ser_rx'),i_CLKB=~ClockSignal('ser_rx'),i_CLKDIV=ClockSignal('sample'),
                    i_CE1=1,i_CE2=1,i_BITSLIP=0,i_RST=ResetSignal('sample'),
                    **{'o_Q%d'%(n+1):word[7-n] for n in range(8)})]
            self.comb += bank.rx[index].eq(word)
        if hdmi:
            for channel in (0,2,4,6):
                conn='diot5:d%d'%channel+('_cc' if channel==0 else '')
                platform.add_extension([('hdmi_pair',channel,Subsignal('p',Pins(conn+'_p')),Subsignal('n',Pins(conn+'_n')),IOStandard('LVDS_25'))])
                pair=platform.request('hdmi_pair',channel)
                if channel==spi_base:
                    self.specials += Instance('OBUFTDS',i_I=hdmi_test.sel,i_T=~hdmi_test.output_enable,o_O=pair.p,o_OB=pair.n)
                else:
                    inp=Signal();self.specials += Instance('IBUFDS',p_DIFF_TERM='TRUE',p_IBUF_LOW_PWR='FALSE',i_I=pair.p,i_IB=pair.n,o_O=inp)
                    if channel==spi_base+2:self.comb += hdmi_test.miso.eq(inp)
                    else:
                        word=Signal(8);hdmi_inputs[channel]=word
                        self.specials += Instance('ISERDESE2',p_DATA_RATE='DDR',p_DATA_WIDTH=8,p_INTERFACE_TYPE='NETWORKING',p_NUM_CE=1,
                            i_D=inp,i_CLK=ClockSignal('ser_rx'),i_CLKB=~ClockSignal('ser_rx'),i_CLKDIV=ClockSignal('sample'),
                            i_CE1=1,i_CE2=1,i_BITSLIP=0,i_RST=ResetSignal('sample'),
                            **{'o_Q%d'%(n+1):word[7-n] for n in range(8)})
            for n,word in enumerate([hdmi_inputs[hdmi_data_base],bank.rx[hdmi_data_base//2],hdmi_inputs[hdmi_data_base+2],bank.rx[hdmi_data_base//2+1]]):self.comb += hdmi_test.rx[n].eq(word)
        self.submodules.uart=uart=RS232PHY(platform.request('serial'),120e6,baudrate=1000000)
        self.submodules.bus=uart_bus=RegisterProtocol(uart)
        if network:
            from gateware.ipbus_bridge import IPbusBridge
            from gateware.gate_ethernet import GateEthernet
            self.submodules.ipbus_bridge=bridge=IPbusBridge(uart_bus,clock_domain='ipbus',csr_words=96 if hdmi else (80 if pm_link else 64))
            eth_channel=None
            if pm_link:
                from gateware.pm_link import PMLink
                self.submodules.pm_link=pm=PMLink(platform,bridge.control,buffered,self.cd_sys.clk,self.cd_ipbus.clk,packet_bridge=pm_bridge)
                eth_channel=pm.ethernet_channel
            self.submodules.ethernet=ethernet=GateEthernet(platform,bridge,self.cd_sys.clk,self.cd_ipbus.clk,qpll_channel=eth_channel)
            if pm_bridge:
                from gateware.pm_bridge import PMBridge
                self.submodules.pm_bridge=packet_bridge=PMBridge(platform,pm,pm.bridge_channel,bridge.control,self.cd_sys.clk,self.cd_ipbus.clk)
            bus=bridge.control
        else:bus=uart_bus
        if hdmi:self.comb += [hdmi_bus.address.eq(bus.address),hdmi_bus.write_data.eq(bus.write_data),hdmi_bus.write.eq(bus.write)]
        local=Record([('address',16),('write_data',32),('read_data',32),('write',1)])
        if cfd_tx:
            from gateware.cfd_tx import CFDBurst,add_output
            self.submodules.cfd=burst=CFDBurst(bus,ready)
            add_output(self,platform,burst,ready)
        self.submodules.control=control=Control(bank,local,ready,4096,0,40000000,sample_hz=960000000,period_bins=24,profile_id=3)
        permitted=Signal();unsupported=Signal();selected=Signal(4)
        self.comb += permitted.eq(((bus.address==8)|(bus.address==0x10))&(bus.write_data==0) |
            (bus.address==0x14)|(bus.address==0x1c)|(bus.address==0x20)|(bus.address==0x70) |
            (((bus.address==0x18)|(bus.address==0x84)|(bus.address==0x88))&(bus.write_data==1)))
        if cfd_tx:
            tx_write=Signal()
            self.comb += tx_write.eq((bus.address==0xe0)|(bus.address==0xe8)|(bus.address==0xec)|(bus.address==0xf0)|(bus.address==0xf4))
            old_permitted=permitted;permitted=Signal();self.comb += permitted.eq(old_permitted|tx_write)
        if pm_link:
            extra_permitted=Signal();self.comb += extra_permitted.eq(permitted | ((bus.address==0x100)|((bus.address==0x120) if pm_bridge else 0)))
            permitted=extra_permitted
        if hdmi:
            extra_permitted=Signal();self.comb += extra_permitted.eq(permitted|((bus.address>=0x140)&(bus.address<=0x17c)))
            permitted=extra_permitted
        self.comb += [local.address.eq(bus.address),local.write_data.eq(bus.write_data),local.write.eq(bus.write&permitted),bus.read_data.eq(local.read_data)]
        self.sync += [If(bus.write&~permitted,unsupported.eq(1)),If(bus.write&(bus.address==0x70),unsupported.eq(0)),
                      If(bus.write&(bus.address==0x1c)&(bus.write_data<16),selected.eq(bus.write_data))]
        self.comb += Case(bus.address,{
            0:bus.read_data.eq(MAGIC),0x0c:bus.read_data.eq(local.read_data|(unsupported<<4)),
            0xc0:bus.read_data.eq(0x60),0xc4:bus.read_data.eq(0xaaaa),0xc8:bus.read_data.eq(2),
            0xcc:bus.read_data.eq(Array([(r['slot']<<8)|r['channel'] for r in LANES])[selected])})
        if cfd_tx:self.comb += If((bus.address>=0xe0)&(bus.address<=0xfc),bus.read_data.eq(burst.read_data))
        if pm_link:self.comb += If((bus.address>=0x100)&(bus.address<=0x11c),bus.read_data.eq(pm.read_data))
        if pm_bridge:self.comb += If((bus.address>=0x120)&(bus.address<=0x13c),bus.read_data.eq(packet_bridge.read_data))
        if hdmi:self.comb += If((bus.address>=0x140)&(bus.address<=0x17c),bus.read_data.eq(hdmi_test.read_data))
        if network:
            self.comb += If(bus.address==0xd0,bus.read_data.eq(0x49504232))
            self.comb += If(bus.address==0xd4,bus.read_data.eq(Cat(ethernet.link,ethernet.got_ip)))
        if hdmi:platform.add_platform_command(HDMI_TIMING.replace('{','{{').replace('}','}}'))
        platform.add_platform_command('set_false_path -to [get_pins -of_objects [get_cells -hier -filter {{mr_ff == TRUE}}] -filter {{REF_PIN_NAME == D}}]')
        platform.add_platform_command('set_max_delay -datapath_only -from [get_ports {{gate_lvds_p*}}] -to [get_cells -hier -filter {{REF_NAME == ISERDESE2}}] 2.0')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--ipbus',action='store_true');p.add_argument('--cfd-tx',action='store_true');p.add_argument('--pm-link',action='store_true');p.add_argument('--pm-bridge',action='store_true');p.add_argument('--hdmi',action='store_true');p.add_argument('--hdmi-data-base',type=int,choices=[0,4],default=4);a=p.parse_args()
    if a.pm_bridge:a.pm_link=True
    if a.pm_link and not a.ipbus:p.error('--pm-link requires --ipbus')
    platform=Platform(hw_rev='v1.0');platform.toolchain.bitstream_commands=[s.replace('0xffffffff','0x52504831') for s in platform.toolchain.bitstream_commands]
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False)

    if a.ipbus:
        iproot=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc')
        for name in (iproot/'ipbus-order.txt').read_text().splitlines():platform.add_source(str(iproot/'ipbus'/name))
    platform.build(Top(platform,network=a.ipbus,cfd_tx=a.cfd_tx,pm_link=a.pm_link,pm_bridge=a.pm_bridge,hdmi=a.hdmi,hdmi_data_base=a.hdmi_data_base),build_dir=str(out),build_name='gate_phase',run=False)
    sources=['core.py','lvds8.py','lvds8_control.py','lvds8_phase.py','build_gate_phase.py']
    if a.ipbus:sources += ['ipbus_bridge.py','gate_ethernet.py']
    if a.cfd_tx:sources += ['cfd_tx.py']
    if a.pm_link:sources += ['pm_link.py']
    if a.pm_bridge:sources += ['pm_bridge.py']
    if a.hdmi:sources += ['hdmi_integrated.py']
    manifest=dict(hdmi_data_base=a.hdmi_data_base,hdmi=a.hdmi,pm_bridge=a.pm_bridge,pm_link=a.pm_link,cfd_tx=a.cfd_tx,tx_physical={'slot':7,'channel':0,'pair_p':1,'pair_n':2} if a.cfd_tx else None,ipbus=a.ipbus,ip_address='192.168.2.241' if a.ipbus else None,part=platform.device,magic=MAGIC,profile='external120',receiver_only=not a.cfd_tx,channels=16,depth=4096,
        phase_bins=24,sample_hz=960000000,mapping=LANES,source_sha256={str(Path('gateware')/n):hashlib.sha256((Path('gateware')/n).read_bytes()).hexdigest() for n in sources},generated_sha256={n:hashlib.sha256((out/n).read_bytes()).hexdigest() for n in ['gate_phase.v','gate_phase.xdc']})
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
