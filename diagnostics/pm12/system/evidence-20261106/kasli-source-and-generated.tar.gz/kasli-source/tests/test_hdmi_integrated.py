import unittest
from migen import *
from migen.sim import run_simulation
from gateware.hdmi_integrated import HDMITester
from gateware.lvds8 import ParallelBank
from gateware.ipbus_bridge import IPbusBridge

class Tests(unittest.TestCase):
    def test_spi_32_bits_receive_hold_and_stop(self):
        d=Module();bus=Record([('address',16),('write_data',32),('write',1)])
        ready=Signal(reset=1);d.submodules.bank=bank=ParallelBank(1,16)
        d.submodules.hdmi=h=HDMITester(bus,bank,ready)
        def wr(a,v):
            yield bus.address.eq(a);yield bus.write_data.eq(v);yield bus.write.eq(1);yield;yield bus.write.eq(0);yield
        def bench():
            self.assertFalse((yield h.output_enable))
            yield from wr(0x154,60);yield from wr(0x144,1);yield from wr(0x148,0x81234567)
            bits=[];fall_bits=[];last=0;fall_at=None;tick=0
            while (yield h.busy):
                sck=(yield h.sck)
                if sck and not last:bits.append((yield h.mosi))
                if last and not sck:
                    fall_at=tick;fall_bits.append((yield h.mosi))
                last=sck
                # Drive successive response bits with ample synchronizer settling.
                bit=len(bits) if not sck else len(bits)-1
                yield h.miso.eq((0x1234a55a >> max(0,31-bit))&1)
                yield;tick+=1
                self.assertLess(tick,5000)
            self.assertEqual(bits,[(0x81234567>>i)&1 for i in range(31,-1,-1)])
            self.assertEqual(bits,fall_bits)
            self.assertGreaterEqual(tick-fall_at,60) # SEL held beyond final falling edge
            yield bus.address.eq(0x14c);yield
            self.assertEqual((yield h.read_data),0x1234a55a)
            yield from wr(0x148,0)
            self.assertTrue((yield h.busy));yield from wr(8,0)
            self.assertFalse((yield h.output_enable));self.assertFalse((yield h.busy));self.assertFalse((yield h.sel))
            yield from wr(0x144,1);yield ready.eq(0);yield;yield
            self.assertFalse((yield h.output_enable));self.assertFalse((yield h.busy))
        run_simulation(d,bench(),clocks={'sys':8,'sample':8})

    def test_connector_order_is_reported(self):
        for base,packed in [(0,0x03020100),(4,0x07060504)]:
            d=Module();bus=Record([('address',16),('write_data',32),('write',1)])
            d.submodules.bank=bank=ParallelBank(1,16)
            d.submodules.hdmi=h=HDMITester(bus,bank,Signal(reset=1),data_base=base)
            def bench():
                yield bus.address.eq(0x15c);yield
                self.assertEqual((yield h.read_data),packed)
            run_simulation(d,bench(),clocks={'sys':8,'sample':8})

    def test_hdmi_memory_aperture_routes_and_rejects_writes(self):
        d=Module();u=Record([('address',16),('write_data',32),('read_data',32),('write',1),('read',1)])
        d.submodules.bridge=b=IPbusBridge(u,csr_words=96)
        lane=Signal(2);index=Signal(12)
        d.sync += If(b.control.write,If(b.control.address==0x160,lane.eq(b.control.write_data)),If(b.control.address==0x164,index.eq(b.control.write_data)))
        d.comb += b.control.read_data.eq(Mux(b.control.address==0x168,(lane<<16)|index,0))
        def bench():
            for address,write,error in [(0x320ab,0,False),(0x30000,1,True),(0x34000,0,True)]:
                yield b.address.eq(address);yield b.write.eq(write);yield b.strobe.eq(1)
                for _ in range(40):
                    yield
                    if (yield b.ack) or (yield b.err):
                        self.assertEqual(bool((yield b.err)),error)
                        if not error:self.assertEqual((yield b.rdata),0x200ab)
                        break
                else:self.fail('no response')
                yield b.strobe.eq(0);yield;yield;yield
        run_simulation(d,bench())

if __name__=='__main__':unittest.main()
