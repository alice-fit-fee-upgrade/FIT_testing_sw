import unittest
from host.pm_system_test import HDMIAdapter

class NoHardware:
    def read(self,address):
        return {0x140:0x48444d31,0x15c:0x03020100}[address]
    def write(self,*args):
        raise AssertionError('unsafe request reached hardware')

class Tests(unittest.TestCase):
    def test_shared_bus_rejects_writes_other_addresses_and_payloads(self):
        adapter=HDMIAdapter(NoHardware())
        for request in [(False,0,0),(False,0x40,0x5555),(True,0x40,0),(True,0x41,0),(True,0x42,0),(True,0,65535)]:
            with self.assertRaises(ValueError):adapter.transfer(*request)

if __name__=='__main__':unittest.main()
