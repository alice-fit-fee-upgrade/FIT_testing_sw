set_param general.maxThreads 4
open_checkpoint gate_phase_route.dcp
report_timing_summary -check_timing_verbose -report_unconstrained -file qualification-timing.rpt
report_drc -file qualification-drc.rpt
report_cdc -details -file qualification-cdc.rpt
report_utilization -file qualification-utilization.rpt
set wns [get_property SLACK [get_timing_paths -delay_type max -max_paths 1]]
set whs [get_property SLACK [get_timing_paths -delay_type min -max_paths 1]]
set errors [get_drc_violations -filter {SEVERITY == Error}]
set iserdes [llength [get_cells -hier -filter {REF_NAME == ISERDESE2}]]
set diffout [llength [get_cells -hier -filter {REF_NAME =~ OBUFDS* || REF_NAME =~ OBUFTDS* || REF_NAME =~ IOBUFDS*}]]
set f [open qualification-values.json w]
puts $f "{\"wns_ns\": $wns, \"whs_ns\": $whs, \"drc_errors\": [llength $errors], \"iserdes_count\": $iserdes, \"differential_output_buffers\": $diffout}"
close $f
if {$wns<0 || $whs<0 || [llength $errors] || $iserdes!=16 || $diffout!=0} {error "RX gate-phase implementation does not qualify"}
exit
