/* Machine-generated using Migen */
module gate_phase(
	input mcx_clkin_p,
	input mcx_clkin_n,
	input gate_lvds_p,
	input gate_lvds_n,
	input gate_lvds_p_1,
	input gate_lvds_n_1,
	input gate_lvds_p_2,
	input gate_lvds_n_2,
	input gate_lvds_p_3,
	input gate_lvds_n_3,
	input gate_lvds_p_4,
	input gate_lvds_n_4,
	input gate_lvds_p_5,
	input gate_lvds_n_5,
	input gate_lvds_p_6,
	input gate_lvds_n_6,
	input gate_lvds_p_7,
	input gate_lvds_n_7,
	input gate_lvds_p_8,
	input gate_lvds_n_8,
	input gate_lvds_p_9,
	input gate_lvds_n_9,
	input gate_lvds_p_10,
	input gate_lvds_n_10,
	input gate_lvds_p_11,
	input gate_lvds_n_11,
	input gate_lvds_p_12,
	input gate_lvds_n_12,
	input gate_lvds_p_13,
	input gate_lvds_n_13,
	input gate_lvds_p_14,
	input gate_lvds_n_14,
	input gate_lvds_p_15,
	input gate_lvds_n_15,
	input serial_rx,
	output reg serial_tx,
	input clk125_gtp_p,
	input clk125_gtp_n,
	output sfp_txp,
	output sfp_txn,
	input sfp_rxp,
	input sfp_rxn
);

wire sys_clk;
wire sys_rst;
wire sample_clk;
wire sample_rst;
wire ser_rx_clk;
wire ipbus_clk;
wire ipbus_rst;
wire reference;
wire buffered;
wire feedback0;
wire fb0;
wire word0;
wire fast0;
wire locked0;
wire ipword;
wire feedback1;
wire fb1;
wire word1;
wire fast1;
wire locked1;
wire rx_lock;
wire ready;
wire bank_arm;
wire [12:0] bank_length;
wire bank_ready;
wire [11:0] bank_address;
wire bank_player_enable;
wire bank_player_ready;
wire bank_player_write;
wire bank_player_write_bank;
wire [11:0] bank_player_write_address;
wire [127:0] bank_player_write_data;
wire bank_player_commit;
wire [12:0] bank_player_commit_length;
reg bank_player_active_bank = 1'd0;
reg [12:0] bank_player_length = 13'd15;
reg bank_player_pending = 1'd0;
reg bank_player_error = 1'd0;
reg [11:0] bank_player_position = 12'd0;
reg [31:0] bank_player_loops = 32'd0;
wire [127:0] bank_player_data;
reg [12:0] bank_player_pending_length = 13'd0;
wire [12:0] bank_player_write_port_adr;
wire [127:0] bank_player_write_port_dat_r;
wire bank_player_write_port_we;
wire [127:0] bank_player_write_port_dat_w;
wire [12:0] bank_player_read_port_adr;
wire [127:0] bank_player_read_port_dat_r;
wire [11:0] bank_player_next_position;
wire bank_player_next_bank;
wire [7:0] bank_windowcapture0_data;
wire bank_windowcapture0_rx_ready;
wire bank_windowcapture0_arm;
wire [12:0] bank_windowcapture0_request_length;
wire [11:0] bank_windowcapture0_read_address;
wire [7:0] bank_windowcapture0_read_data;
reg bank_windowcapture0_busy = 1'd0;
reg bank_windowcapture0_done = 1'd0;
reg bank_windowcapture0_error = 1'd0;
wire [12:0] bank_windowcapture0_count;
wire [63:0] bank_windowcapture0_start_sample;
wire bank_windowcapture0_previous;
reg [31:0] bank_windowcapture0_capture_id = 32'd0;
reg bank_windowcapture0_read_valid = 1'd0;
reg bank_windowcapture0_request = 1'd0;
reg bank_windowcapture0_ack = 1'd0;
wire bank_windowcapture0_ack_sys;
wire bank_windowcapture0_request_rx;
reg [12:0] bank_windowcapture0_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture0_length_rx;
wire bank_windowcapture0_ready_sys;
wire [11:0] bank_windowcapture0_wp_adr;
wire [7:0] bank_windowcapture0_wp_dat_r;
wire bank_windowcapture0_wp_we;
wire [7:0] bank_windowcapture0_wp_dat_w;
wire [11:0] bank_windowcapture0_rp_adr;
wire [7:0] bank_windowcapture0_rp_dat_r;
reg bank_windowcapture0_active = 1'd0;
reg [11:0] bank_windowcapture0_address = 12'd0;
reg [12:0] bank_windowcapture0_limit = 13'd0;
reg [63:0] bank_windowcapture0_start_rx = 64'd0;
reg bank_windowcapture0_previous_rx = 1'd0;
reg [12:0] bank_windowcapture0_count_rx = 13'd0;
reg bank_windowcapture0_aborted_rx = 1'd0;
wire bank_windowcapture0_aborted_sys;
reg bank_windowcapture0_invalid = 1'd0;
reg [63:0] bank_windowcapture0_sample = 64'd0;
reg bank_windowcapture0_prev = 1'd0;
reg [2:0] bank_windowcapture0_settle = 3'd0;
wire [7:0] bank_windowcapture1_data;
wire bank_windowcapture1_rx_ready;
wire bank_windowcapture1_arm;
wire [12:0] bank_windowcapture1_request_length;
wire [11:0] bank_windowcapture1_read_address;
wire [7:0] bank_windowcapture1_read_data;
reg bank_windowcapture1_busy = 1'd0;
reg bank_windowcapture1_done = 1'd0;
reg bank_windowcapture1_error = 1'd0;
wire [12:0] bank_windowcapture1_count;
wire [63:0] bank_windowcapture1_start_sample;
wire bank_windowcapture1_previous;
reg [31:0] bank_windowcapture1_capture_id = 32'd0;
reg bank_windowcapture1_read_valid = 1'd0;
reg bank_windowcapture1_request = 1'd0;
reg bank_windowcapture1_ack = 1'd0;
wire bank_windowcapture1_ack_sys;
wire bank_windowcapture1_request_rx;
reg [12:0] bank_windowcapture1_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture1_length_rx;
wire bank_windowcapture1_ready_sys;
wire [11:0] bank_windowcapture1_wp_adr;
wire [7:0] bank_windowcapture1_wp_dat_r;
wire bank_windowcapture1_wp_we;
wire [7:0] bank_windowcapture1_wp_dat_w;
wire [11:0] bank_windowcapture1_rp_adr;
wire [7:0] bank_windowcapture1_rp_dat_r;
reg bank_windowcapture1_active = 1'd0;
reg [11:0] bank_windowcapture1_address = 12'd0;
reg [12:0] bank_windowcapture1_limit = 13'd0;
reg [63:0] bank_windowcapture1_start_rx = 64'd0;
reg bank_windowcapture1_previous_rx = 1'd0;
reg [12:0] bank_windowcapture1_count_rx = 13'd0;
reg bank_windowcapture1_aborted_rx = 1'd0;
wire bank_windowcapture1_aborted_sys;
reg bank_windowcapture1_invalid = 1'd0;
reg [63:0] bank_windowcapture1_sample = 64'd0;
reg bank_windowcapture1_prev = 1'd0;
reg [2:0] bank_windowcapture1_settle = 3'd0;
wire [7:0] bank_windowcapture2_data;
wire bank_windowcapture2_rx_ready;
wire bank_windowcapture2_arm;
wire [12:0] bank_windowcapture2_request_length;
wire [11:0] bank_windowcapture2_read_address;
wire [7:0] bank_windowcapture2_read_data;
reg bank_windowcapture2_busy = 1'd0;
reg bank_windowcapture2_done = 1'd0;
reg bank_windowcapture2_error = 1'd0;
wire [12:0] bank_windowcapture2_count;
wire [63:0] bank_windowcapture2_start_sample;
wire bank_windowcapture2_previous;
reg [31:0] bank_windowcapture2_capture_id = 32'd0;
reg bank_windowcapture2_read_valid = 1'd0;
reg bank_windowcapture2_request = 1'd0;
reg bank_windowcapture2_ack = 1'd0;
wire bank_windowcapture2_ack_sys;
wire bank_windowcapture2_request_rx;
reg [12:0] bank_windowcapture2_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture2_length_rx;
wire bank_windowcapture2_ready_sys;
wire [11:0] bank_windowcapture2_wp_adr;
wire [7:0] bank_windowcapture2_wp_dat_r;
wire bank_windowcapture2_wp_we;
wire [7:0] bank_windowcapture2_wp_dat_w;
wire [11:0] bank_windowcapture2_rp_adr;
wire [7:0] bank_windowcapture2_rp_dat_r;
reg bank_windowcapture2_active = 1'd0;
reg [11:0] bank_windowcapture2_address = 12'd0;
reg [12:0] bank_windowcapture2_limit = 13'd0;
reg [63:0] bank_windowcapture2_start_rx = 64'd0;
reg bank_windowcapture2_previous_rx = 1'd0;
reg [12:0] bank_windowcapture2_count_rx = 13'd0;
reg bank_windowcapture2_aborted_rx = 1'd0;
wire bank_windowcapture2_aborted_sys;
reg bank_windowcapture2_invalid = 1'd0;
reg [63:0] bank_windowcapture2_sample = 64'd0;
reg bank_windowcapture2_prev = 1'd0;
reg [2:0] bank_windowcapture2_settle = 3'd0;
wire [7:0] bank_windowcapture3_data;
wire bank_windowcapture3_rx_ready;
wire bank_windowcapture3_arm;
wire [12:0] bank_windowcapture3_request_length;
wire [11:0] bank_windowcapture3_read_address;
wire [7:0] bank_windowcapture3_read_data;
reg bank_windowcapture3_busy = 1'd0;
reg bank_windowcapture3_done = 1'd0;
reg bank_windowcapture3_error = 1'd0;
wire [12:0] bank_windowcapture3_count;
wire [63:0] bank_windowcapture3_start_sample;
wire bank_windowcapture3_previous;
reg [31:0] bank_windowcapture3_capture_id = 32'd0;
reg bank_windowcapture3_read_valid = 1'd0;
reg bank_windowcapture3_request = 1'd0;
reg bank_windowcapture3_ack = 1'd0;
wire bank_windowcapture3_ack_sys;
wire bank_windowcapture3_request_rx;
reg [12:0] bank_windowcapture3_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture3_length_rx;
wire bank_windowcapture3_ready_sys;
wire [11:0] bank_windowcapture3_wp_adr;
wire [7:0] bank_windowcapture3_wp_dat_r;
wire bank_windowcapture3_wp_we;
wire [7:0] bank_windowcapture3_wp_dat_w;
wire [11:0] bank_windowcapture3_rp_adr;
wire [7:0] bank_windowcapture3_rp_dat_r;
reg bank_windowcapture3_active = 1'd0;
reg [11:0] bank_windowcapture3_address = 12'd0;
reg [12:0] bank_windowcapture3_limit = 13'd0;
reg [63:0] bank_windowcapture3_start_rx = 64'd0;
reg bank_windowcapture3_previous_rx = 1'd0;
reg [12:0] bank_windowcapture3_count_rx = 13'd0;
reg bank_windowcapture3_aborted_rx = 1'd0;
wire bank_windowcapture3_aborted_sys;
reg bank_windowcapture3_invalid = 1'd0;
reg [63:0] bank_windowcapture3_sample = 64'd0;
reg bank_windowcapture3_prev = 1'd0;
reg [2:0] bank_windowcapture3_settle = 3'd0;
wire [7:0] bank_windowcapture4_data;
wire bank_windowcapture4_rx_ready;
wire bank_windowcapture4_arm;
wire [12:0] bank_windowcapture4_request_length;
wire [11:0] bank_windowcapture4_read_address;
wire [7:0] bank_windowcapture4_read_data;
reg bank_windowcapture4_busy = 1'd0;
reg bank_windowcapture4_done = 1'd0;
reg bank_windowcapture4_error = 1'd0;
wire [12:0] bank_windowcapture4_count;
wire [63:0] bank_windowcapture4_start_sample;
wire bank_windowcapture4_previous;
reg [31:0] bank_windowcapture4_capture_id = 32'd0;
reg bank_windowcapture4_read_valid = 1'd0;
reg bank_windowcapture4_request = 1'd0;
reg bank_windowcapture4_ack = 1'd0;
wire bank_windowcapture4_ack_sys;
wire bank_windowcapture4_request_rx;
reg [12:0] bank_windowcapture4_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture4_length_rx;
wire bank_windowcapture4_ready_sys;
wire [11:0] bank_windowcapture4_wp_adr;
wire [7:0] bank_windowcapture4_wp_dat_r;
wire bank_windowcapture4_wp_we;
wire [7:0] bank_windowcapture4_wp_dat_w;
wire [11:0] bank_windowcapture4_rp_adr;
wire [7:0] bank_windowcapture4_rp_dat_r;
reg bank_windowcapture4_active = 1'd0;
reg [11:0] bank_windowcapture4_address = 12'd0;
reg [12:0] bank_windowcapture4_limit = 13'd0;
reg [63:0] bank_windowcapture4_start_rx = 64'd0;
reg bank_windowcapture4_previous_rx = 1'd0;
reg [12:0] bank_windowcapture4_count_rx = 13'd0;
reg bank_windowcapture4_aborted_rx = 1'd0;
wire bank_windowcapture4_aborted_sys;
reg bank_windowcapture4_invalid = 1'd0;
reg [63:0] bank_windowcapture4_sample = 64'd0;
reg bank_windowcapture4_prev = 1'd0;
reg [2:0] bank_windowcapture4_settle = 3'd0;
wire [7:0] bank_windowcapture5_data;
wire bank_windowcapture5_rx_ready;
wire bank_windowcapture5_arm;
wire [12:0] bank_windowcapture5_request_length;
wire [11:0] bank_windowcapture5_read_address;
wire [7:0] bank_windowcapture5_read_data;
reg bank_windowcapture5_busy = 1'd0;
reg bank_windowcapture5_done = 1'd0;
reg bank_windowcapture5_error = 1'd0;
wire [12:0] bank_windowcapture5_count;
wire [63:0] bank_windowcapture5_start_sample;
wire bank_windowcapture5_previous;
reg [31:0] bank_windowcapture5_capture_id = 32'd0;
reg bank_windowcapture5_read_valid = 1'd0;
reg bank_windowcapture5_request = 1'd0;
reg bank_windowcapture5_ack = 1'd0;
wire bank_windowcapture5_ack_sys;
wire bank_windowcapture5_request_rx;
reg [12:0] bank_windowcapture5_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture5_length_rx;
wire bank_windowcapture5_ready_sys;
wire [11:0] bank_windowcapture5_wp_adr;
wire [7:0] bank_windowcapture5_wp_dat_r;
wire bank_windowcapture5_wp_we;
wire [7:0] bank_windowcapture5_wp_dat_w;
wire [11:0] bank_windowcapture5_rp_adr;
wire [7:0] bank_windowcapture5_rp_dat_r;
reg bank_windowcapture5_active = 1'd0;
reg [11:0] bank_windowcapture5_address = 12'd0;
reg [12:0] bank_windowcapture5_limit = 13'd0;
reg [63:0] bank_windowcapture5_start_rx = 64'd0;
reg bank_windowcapture5_previous_rx = 1'd0;
reg [12:0] bank_windowcapture5_count_rx = 13'd0;
reg bank_windowcapture5_aborted_rx = 1'd0;
wire bank_windowcapture5_aborted_sys;
reg bank_windowcapture5_invalid = 1'd0;
reg [63:0] bank_windowcapture5_sample = 64'd0;
reg bank_windowcapture5_prev = 1'd0;
reg [2:0] bank_windowcapture5_settle = 3'd0;
wire [7:0] bank_windowcapture6_data;
wire bank_windowcapture6_rx_ready;
wire bank_windowcapture6_arm;
wire [12:0] bank_windowcapture6_request_length;
wire [11:0] bank_windowcapture6_read_address;
wire [7:0] bank_windowcapture6_read_data;
reg bank_windowcapture6_busy = 1'd0;
reg bank_windowcapture6_done = 1'd0;
reg bank_windowcapture6_error = 1'd0;
wire [12:0] bank_windowcapture6_count;
wire [63:0] bank_windowcapture6_start_sample;
wire bank_windowcapture6_previous;
reg [31:0] bank_windowcapture6_capture_id = 32'd0;
reg bank_windowcapture6_read_valid = 1'd0;
reg bank_windowcapture6_request = 1'd0;
reg bank_windowcapture6_ack = 1'd0;
wire bank_windowcapture6_ack_sys;
wire bank_windowcapture6_request_rx;
reg [12:0] bank_windowcapture6_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture6_length_rx;
wire bank_windowcapture6_ready_sys;
wire [11:0] bank_windowcapture6_wp_adr;
wire [7:0] bank_windowcapture6_wp_dat_r;
wire bank_windowcapture6_wp_we;
wire [7:0] bank_windowcapture6_wp_dat_w;
wire [11:0] bank_windowcapture6_rp_adr;
wire [7:0] bank_windowcapture6_rp_dat_r;
reg bank_windowcapture6_active = 1'd0;
reg [11:0] bank_windowcapture6_address = 12'd0;
reg [12:0] bank_windowcapture6_limit = 13'd0;
reg [63:0] bank_windowcapture6_start_rx = 64'd0;
reg bank_windowcapture6_previous_rx = 1'd0;
reg [12:0] bank_windowcapture6_count_rx = 13'd0;
reg bank_windowcapture6_aborted_rx = 1'd0;
wire bank_windowcapture6_aborted_sys;
reg bank_windowcapture6_invalid = 1'd0;
reg [63:0] bank_windowcapture6_sample = 64'd0;
reg bank_windowcapture6_prev = 1'd0;
reg [2:0] bank_windowcapture6_settle = 3'd0;
wire [7:0] bank_windowcapture7_data;
wire bank_windowcapture7_rx_ready;
wire bank_windowcapture7_arm;
wire [12:0] bank_windowcapture7_request_length;
wire [11:0] bank_windowcapture7_read_address;
wire [7:0] bank_windowcapture7_read_data;
reg bank_windowcapture7_busy = 1'd0;
reg bank_windowcapture7_done = 1'd0;
reg bank_windowcapture7_error = 1'd0;
wire [12:0] bank_windowcapture7_count;
wire [63:0] bank_windowcapture7_start_sample;
wire bank_windowcapture7_previous;
reg [31:0] bank_windowcapture7_capture_id = 32'd0;
reg bank_windowcapture7_read_valid = 1'd0;
reg bank_windowcapture7_request = 1'd0;
reg bank_windowcapture7_ack = 1'd0;
wire bank_windowcapture7_ack_sys;
wire bank_windowcapture7_request_rx;
reg [12:0] bank_windowcapture7_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture7_length_rx;
wire bank_windowcapture7_ready_sys;
wire [11:0] bank_windowcapture7_wp_adr;
wire [7:0] bank_windowcapture7_wp_dat_r;
wire bank_windowcapture7_wp_we;
wire [7:0] bank_windowcapture7_wp_dat_w;
wire [11:0] bank_windowcapture7_rp_adr;
wire [7:0] bank_windowcapture7_rp_dat_r;
reg bank_windowcapture7_active = 1'd0;
reg [11:0] bank_windowcapture7_address = 12'd0;
reg [12:0] bank_windowcapture7_limit = 13'd0;
reg [63:0] bank_windowcapture7_start_rx = 64'd0;
reg bank_windowcapture7_previous_rx = 1'd0;
reg [12:0] bank_windowcapture7_count_rx = 13'd0;
reg bank_windowcapture7_aborted_rx = 1'd0;
wire bank_windowcapture7_aborted_sys;
reg bank_windowcapture7_invalid = 1'd0;
reg [63:0] bank_windowcapture7_sample = 64'd0;
reg bank_windowcapture7_prev = 1'd0;
reg [2:0] bank_windowcapture7_settle = 3'd0;
wire [7:0] bank_windowcapture8_data;
wire bank_windowcapture8_rx_ready;
wire bank_windowcapture8_arm;
wire [12:0] bank_windowcapture8_request_length;
wire [11:0] bank_windowcapture8_read_address;
wire [7:0] bank_windowcapture8_read_data;
reg bank_windowcapture8_busy = 1'd0;
reg bank_windowcapture8_done = 1'd0;
reg bank_windowcapture8_error = 1'd0;
wire [12:0] bank_windowcapture8_count;
wire [63:0] bank_windowcapture8_start_sample;
wire bank_windowcapture8_previous;
reg [31:0] bank_windowcapture8_capture_id = 32'd0;
reg bank_windowcapture8_read_valid = 1'd0;
reg bank_windowcapture8_request = 1'd0;
reg bank_windowcapture8_ack = 1'd0;
wire bank_windowcapture8_ack_sys;
wire bank_windowcapture8_request_rx;
reg [12:0] bank_windowcapture8_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture8_length_rx;
wire bank_windowcapture8_ready_sys;
wire [11:0] bank_windowcapture8_wp_adr;
wire [7:0] bank_windowcapture8_wp_dat_r;
wire bank_windowcapture8_wp_we;
wire [7:0] bank_windowcapture8_wp_dat_w;
wire [11:0] bank_windowcapture8_rp_adr;
wire [7:0] bank_windowcapture8_rp_dat_r;
reg bank_windowcapture8_active = 1'd0;
reg [11:0] bank_windowcapture8_address = 12'd0;
reg [12:0] bank_windowcapture8_limit = 13'd0;
reg [63:0] bank_windowcapture8_start_rx = 64'd0;
reg bank_windowcapture8_previous_rx = 1'd0;
reg [12:0] bank_windowcapture8_count_rx = 13'd0;
reg bank_windowcapture8_aborted_rx = 1'd0;
wire bank_windowcapture8_aborted_sys;
reg bank_windowcapture8_invalid = 1'd0;
reg [63:0] bank_windowcapture8_sample = 64'd0;
reg bank_windowcapture8_prev = 1'd0;
reg [2:0] bank_windowcapture8_settle = 3'd0;
wire [7:0] bank_windowcapture9_data;
wire bank_windowcapture9_rx_ready;
wire bank_windowcapture9_arm;
wire [12:0] bank_windowcapture9_request_length;
wire [11:0] bank_windowcapture9_read_address;
wire [7:0] bank_windowcapture9_read_data;
reg bank_windowcapture9_busy = 1'd0;
reg bank_windowcapture9_done = 1'd0;
reg bank_windowcapture9_error = 1'd0;
wire [12:0] bank_windowcapture9_count;
wire [63:0] bank_windowcapture9_start_sample;
wire bank_windowcapture9_previous;
reg [31:0] bank_windowcapture9_capture_id = 32'd0;
reg bank_windowcapture9_read_valid = 1'd0;
reg bank_windowcapture9_request = 1'd0;
reg bank_windowcapture9_ack = 1'd0;
wire bank_windowcapture9_ack_sys;
wire bank_windowcapture9_request_rx;
reg [12:0] bank_windowcapture9_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture9_length_rx;
wire bank_windowcapture9_ready_sys;
wire [11:0] bank_windowcapture9_wp_adr;
wire [7:0] bank_windowcapture9_wp_dat_r;
wire bank_windowcapture9_wp_we;
wire [7:0] bank_windowcapture9_wp_dat_w;
wire [11:0] bank_windowcapture9_rp_adr;
wire [7:0] bank_windowcapture9_rp_dat_r;
reg bank_windowcapture9_active = 1'd0;
reg [11:0] bank_windowcapture9_address = 12'd0;
reg [12:0] bank_windowcapture9_limit = 13'd0;
reg [63:0] bank_windowcapture9_start_rx = 64'd0;
reg bank_windowcapture9_previous_rx = 1'd0;
reg [12:0] bank_windowcapture9_count_rx = 13'd0;
reg bank_windowcapture9_aborted_rx = 1'd0;
wire bank_windowcapture9_aborted_sys;
reg bank_windowcapture9_invalid = 1'd0;
reg [63:0] bank_windowcapture9_sample = 64'd0;
reg bank_windowcapture9_prev = 1'd0;
reg [2:0] bank_windowcapture9_settle = 3'd0;
wire [7:0] bank_windowcapture10_data;
wire bank_windowcapture10_rx_ready;
wire bank_windowcapture10_arm;
wire [12:0] bank_windowcapture10_request_length;
wire [11:0] bank_windowcapture10_read_address;
wire [7:0] bank_windowcapture10_read_data;
reg bank_windowcapture10_busy = 1'd0;
reg bank_windowcapture10_done = 1'd0;
reg bank_windowcapture10_error = 1'd0;
wire [12:0] bank_windowcapture10_count;
wire [63:0] bank_windowcapture10_start_sample;
wire bank_windowcapture10_previous;
reg [31:0] bank_windowcapture10_capture_id = 32'd0;
reg bank_windowcapture10_read_valid = 1'd0;
reg bank_windowcapture10_request = 1'd0;
reg bank_windowcapture10_ack = 1'd0;
wire bank_windowcapture10_ack_sys;
wire bank_windowcapture10_request_rx;
reg [12:0] bank_windowcapture10_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture10_length_rx;
wire bank_windowcapture10_ready_sys;
wire [11:0] bank_windowcapture10_wp_adr;
wire [7:0] bank_windowcapture10_wp_dat_r;
wire bank_windowcapture10_wp_we;
wire [7:0] bank_windowcapture10_wp_dat_w;
wire [11:0] bank_windowcapture10_rp_adr;
wire [7:0] bank_windowcapture10_rp_dat_r;
reg bank_windowcapture10_active = 1'd0;
reg [11:0] bank_windowcapture10_address = 12'd0;
reg [12:0] bank_windowcapture10_limit = 13'd0;
reg [63:0] bank_windowcapture10_start_rx = 64'd0;
reg bank_windowcapture10_previous_rx = 1'd0;
reg [12:0] bank_windowcapture10_count_rx = 13'd0;
reg bank_windowcapture10_aborted_rx = 1'd0;
wire bank_windowcapture10_aborted_sys;
reg bank_windowcapture10_invalid = 1'd0;
reg [63:0] bank_windowcapture10_sample = 64'd0;
reg bank_windowcapture10_prev = 1'd0;
reg [2:0] bank_windowcapture10_settle = 3'd0;
wire [7:0] bank_windowcapture11_data;
wire bank_windowcapture11_rx_ready;
wire bank_windowcapture11_arm;
wire [12:0] bank_windowcapture11_request_length;
wire [11:0] bank_windowcapture11_read_address;
wire [7:0] bank_windowcapture11_read_data;
reg bank_windowcapture11_busy = 1'd0;
reg bank_windowcapture11_done = 1'd0;
reg bank_windowcapture11_error = 1'd0;
wire [12:0] bank_windowcapture11_count;
wire [63:0] bank_windowcapture11_start_sample;
wire bank_windowcapture11_previous;
reg [31:0] bank_windowcapture11_capture_id = 32'd0;
reg bank_windowcapture11_read_valid = 1'd0;
reg bank_windowcapture11_request = 1'd0;
reg bank_windowcapture11_ack = 1'd0;
wire bank_windowcapture11_ack_sys;
wire bank_windowcapture11_request_rx;
reg [12:0] bank_windowcapture11_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture11_length_rx;
wire bank_windowcapture11_ready_sys;
wire [11:0] bank_windowcapture11_wp_adr;
wire [7:0] bank_windowcapture11_wp_dat_r;
wire bank_windowcapture11_wp_we;
wire [7:0] bank_windowcapture11_wp_dat_w;
wire [11:0] bank_windowcapture11_rp_adr;
wire [7:0] bank_windowcapture11_rp_dat_r;
reg bank_windowcapture11_active = 1'd0;
reg [11:0] bank_windowcapture11_address = 12'd0;
reg [12:0] bank_windowcapture11_limit = 13'd0;
reg [63:0] bank_windowcapture11_start_rx = 64'd0;
reg bank_windowcapture11_previous_rx = 1'd0;
reg [12:0] bank_windowcapture11_count_rx = 13'd0;
reg bank_windowcapture11_aborted_rx = 1'd0;
wire bank_windowcapture11_aborted_sys;
reg bank_windowcapture11_invalid = 1'd0;
reg [63:0] bank_windowcapture11_sample = 64'd0;
reg bank_windowcapture11_prev = 1'd0;
reg [2:0] bank_windowcapture11_settle = 3'd0;
wire [7:0] bank_windowcapture12_data;
wire bank_windowcapture12_rx_ready;
wire bank_windowcapture12_arm;
wire [12:0] bank_windowcapture12_request_length;
wire [11:0] bank_windowcapture12_read_address;
wire [7:0] bank_windowcapture12_read_data;
reg bank_windowcapture12_busy = 1'd0;
reg bank_windowcapture12_done = 1'd0;
reg bank_windowcapture12_error = 1'd0;
wire [12:0] bank_windowcapture12_count;
wire [63:0] bank_windowcapture12_start_sample;
wire bank_windowcapture12_previous;
reg [31:0] bank_windowcapture12_capture_id = 32'd0;
reg bank_windowcapture12_read_valid = 1'd0;
reg bank_windowcapture12_request = 1'd0;
reg bank_windowcapture12_ack = 1'd0;
wire bank_windowcapture12_ack_sys;
wire bank_windowcapture12_request_rx;
reg [12:0] bank_windowcapture12_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture12_length_rx;
wire bank_windowcapture12_ready_sys;
wire [11:0] bank_windowcapture12_wp_adr;
wire [7:0] bank_windowcapture12_wp_dat_r;
wire bank_windowcapture12_wp_we;
wire [7:0] bank_windowcapture12_wp_dat_w;
wire [11:0] bank_windowcapture12_rp_adr;
wire [7:0] bank_windowcapture12_rp_dat_r;
reg bank_windowcapture12_active = 1'd0;
reg [11:0] bank_windowcapture12_address = 12'd0;
reg [12:0] bank_windowcapture12_limit = 13'd0;
reg [63:0] bank_windowcapture12_start_rx = 64'd0;
reg bank_windowcapture12_previous_rx = 1'd0;
reg [12:0] bank_windowcapture12_count_rx = 13'd0;
reg bank_windowcapture12_aborted_rx = 1'd0;
wire bank_windowcapture12_aborted_sys;
reg bank_windowcapture12_invalid = 1'd0;
reg [63:0] bank_windowcapture12_sample = 64'd0;
reg bank_windowcapture12_prev = 1'd0;
reg [2:0] bank_windowcapture12_settle = 3'd0;
wire [7:0] bank_windowcapture13_data;
wire bank_windowcapture13_rx_ready;
wire bank_windowcapture13_arm;
wire [12:0] bank_windowcapture13_request_length;
wire [11:0] bank_windowcapture13_read_address;
wire [7:0] bank_windowcapture13_read_data;
reg bank_windowcapture13_busy = 1'd0;
reg bank_windowcapture13_done = 1'd0;
reg bank_windowcapture13_error = 1'd0;
wire [12:0] bank_windowcapture13_count;
wire [63:0] bank_windowcapture13_start_sample;
wire bank_windowcapture13_previous;
reg [31:0] bank_windowcapture13_capture_id = 32'd0;
reg bank_windowcapture13_read_valid = 1'd0;
reg bank_windowcapture13_request = 1'd0;
reg bank_windowcapture13_ack = 1'd0;
wire bank_windowcapture13_ack_sys;
wire bank_windowcapture13_request_rx;
reg [12:0] bank_windowcapture13_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture13_length_rx;
wire bank_windowcapture13_ready_sys;
wire [11:0] bank_windowcapture13_wp_adr;
wire [7:0] bank_windowcapture13_wp_dat_r;
wire bank_windowcapture13_wp_we;
wire [7:0] bank_windowcapture13_wp_dat_w;
wire [11:0] bank_windowcapture13_rp_adr;
wire [7:0] bank_windowcapture13_rp_dat_r;
reg bank_windowcapture13_active = 1'd0;
reg [11:0] bank_windowcapture13_address = 12'd0;
reg [12:0] bank_windowcapture13_limit = 13'd0;
reg [63:0] bank_windowcapture13_start_rx = 64'd0;
reg bank_windowcapture13_previous_rx = 1'd0;
reg [12:0] bank_windowcapture13_count_rx = 13'd0;
reg bank_windowcapture13_aborted_rx = 1'd0;
wire bank_windowcapture13_aborted_sys;
reg bank_windowcapture13_invalid = 1'd0;
reg [63:0] bank_windowcapture13_sample = 64'd0;
reg bank_windowcapture13_prev = 1'd0;
reg [2:0] bank_windowcapture13_settle = 3'd0;
wire [7:0] bank_windowcapture14_data;
wire bank_windowcapture14_rx_ready;
wire bank_windowcapture14_arm;
wire [12:0] bank_windowcapture14_request_length;
wire [11:0] bank_windowcapture14_read_address;
wire [7:0] bank_windowcapture14_read_data;
reg bank_windowcapture14_busy = 1'd0;
reg bank_windowcapture14_done = 1'd0;
reg bank_windowcapture14_error = 1'd0;
wire [12:0] bank_windowcapture14_count;
wire [63:0] bank_windowcapture14_start_sample;
wire bank_windowcapture14_previous;
reg [31:0] bank_windowcapture14_capture_id = 32'd0;
reg bank_windowcapture14_read_valid = 1'd0;
reg bank_windowcapture14_request = 1'd0;
reg bank_windowcapture14_ack = 1'd0;
wire bank_windowcapture14_ack_sys;
wire bank_windowcapture14_request_rx;
reg [12:0] bank_windowcapture14_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture14_length_rx;
wire bank_windowcapture14_ready_sys;
wire [11:0] bank_windowcapture14_wp_adr;
wire [7:0] bank_windowcapture14_wp_dat_r;
wire bank_windowcapture14_wp_we;
wire [7:0] bank_windowcapture14_wp_dat_w;
wire [11:0] bank_windowcapture14_rp_adr;
wire [7:0] bank_windowcapture14_rp_dat_r;
reg bank_windowcapture14_active = 1'd0;
reg [11:0] bank_windowcapture14_address = 12'd0;
reg [12:0] bank_windowcapture14_limit = 13'd0;
reg [63:0] bank_windowcapture14_start_rx = 64'd0;
reg bank_windowcapture14_previous_rx = 1'd0;
reg [12:0] bank_windowcapture14_count_rx = 13'd0;
reg bank_windowcapture14_aborted_rx = 1'd0;
wire bank_windowcapture14_aborted_sys;
reg bank_windowcapture14_invalid = 1'd0;
reg [63:0] bank_windowcapture14_sample = 64'd0;
reg bank_windowcapture14_prev = 1'd0;
reg [2:0] bank_windowcapture14_settle = 3'd0;
wire [7:0] bank_windowcapture15_data;
wire bank_windowcapture15_rx_ready;
wire bank_windowcapture15_arm;
wire [12:0] bank_windowcapture15_request_length;
wire [11:0] bank_windowcapture15_read_address;
wire [7:0] bank_windowcapture15_read_data;
reg bank_windowcapture15_busy = 1'd0;
reg bank_windowcapture15_done = 1'd0;
reg bank_windowcapture15_error = 1'd0;
wire [12:0] bank_windowcapture15_count;
wire [63:0] bank_windowcapture15_start_sample;
wire bank_windowcapture15_previous;
reg [31:0] bank_windowcapture15_capture_id = 32'd0;
reg bank_windowcapture15_read_valid = 1'd0;
reg bank_windowcapture15_request = 1'd0;
reg bank_windowcapture15_ack = 1'd0;
wire bank_windowcapture15_ack_sys;
wire bank_windowcapture15_request_rx;
reg [12:0] bank_windowcapture15_length_mailbox = 13'd0;
wire [12:0] bank_windowcapture15_length_rx;
wire bank_windowcapture15_ready_sys;
wire [11:0] bank_windowcapture15_wp_adr;
wire [7:0] bank_windowcapture15_wp_dat_r;
wire bank_windowcapture15_wp_we;
wire [7:0] bank_windowcapture15_wp_dat_w;
wire [11:0] bank_windowcapture15_rp_adr;
wire [7:0] bank_windowcapture15_rp_dat_r;
reg bank_windowcapture15_active = 1'd0;
reg [11:0] bank_windowcapture15_address = 12'd0;
reg [12:0] bank_windowcapture15_limit = 13'd0;
reg [63:0] bank_windowcapture15_start_rx = 64'd0;
reg bank_windowcapture15_previous_rx = 1'd0;
reg [12:0] bank_windowcapture15_count_rx = 13'd0;
reg bank_windowcapture15_aborted_rx = 1'd0;
wire bank_windowcapture15_aborted_sys;
reg bank_windowcapture15_invalid = 1'd0;
reg [63:0] bank_windowcapture15_sample = 64'd0;
reg bank_windowcapture15_prev = 1'd0;
reg [2:0] bank_windowcapture15_settle = 3'd0;
wire inp0;
wire [7:0] word2;
wire inp1;
wire [7:0] word3;
wire inp2;
wire [7:0] word4;
wire inp3;
wire [7:0] word5;
wire inp4;
wire [7:0] word6;
wire inp5;
wire [7:0] word7;
wire inp6;
wire [7:0] word8;
wire inp7;
wire [7:0] word9;
wire inp8;
wire [7:0] word10;
wire inp9;
wire [7:0] word11;
wire inp10;
wire [7:0] word12;
wire inp11;
wire [7:0] word13;
wire inp12;
wire [7:0] word14;
wire inp13;
wire [7:0] word15;
wire inp14;
wire [7:0] word16;
wire inp15;
wire [7:0] word17;
reg [31:0] uart_storage = 32'd35791394;
reg uart_sink_stb;
reg uart_sink_ack = 1'd0;
wire [7:0] uart_sink_payload_data;
reg uart_uart_clk_txen = 1'd0;
reg [31:0] uart_phase_accumulator_tx = 32'd0;
reg [7:0] uart_tx_reg = 8'd0;
reg [3:0] uart_tx_bitcount = 4'd0;
reg uart_tx_busy = 1'd0;
reg uart_source_stb = 1'd0;
reg uart_source_ack;
reg [7:0] uart_source_payload_data = 8'd0;
reg uart_uart_clk_rxen = 1'd0;
reg [31:0] uart_phase_accumulator_rx = 32'd0;
wire uart_rx;
reg uart_rx_r = 1'd0;
reg [7:0] uart_rx_reg = 8'd0;
reg [3:0] uart_rx_bitcount = 4'd0;
reg uart_rx_busy = 1'd0;
wire [15:0] bus_address;
wire [31:0] bus_write_data;
wire [31:0] bus_read_data;
reg bus_read;
reg bus_write;
reg [55:0] bus_command = 56'd0;
reg [47:0] bus_reply = 48'd0;
reg [2:0] bus_rx_index = 3'd0;
reg [2:0] bus_tx_index = 3'd0;
reg [23:0] bus_timeout = 24'd0;
wire [31:0] ipbus_bridge_address0;
wire [31:0] ipbus_bridge_wdata;
wire ipbus_bridge_strobe;
wire ipbus_bridge_write;
reg [31:0] ipbus_bridge_rdata = 32'd0;
wire ipbus_bridge_ack;
wire ipbus_bridge_err;
reg [15:0] ipbus_bridge_control_address;
reg [31:0] ipbus_bridge_control_write_data;
reg [31:0] ipbus_bridge_control_read_data;
reg ipbus_bridge_control_write;
reg [31:0] ipbus_bridge_address1 = 32'd0;
reg [31:0] ipbus_bridge_data = 32'd0;
reg ipbus_bridge_writing = 1'd0;
reg [3:0] ipbus_bridge_state = 4'd0;
wire ipbus_bridge_raw;
wire ipbus_bridge_phase;
wire ipbus_bridge_memory;
wire [3:0] ipbus_bridge_lane;
wire [11:0] ipbus_bridge_index;
reg [3:0] ipbus_bridge_hold = 4'd0;
wire ipbus_bridge_available;
reg [3:0] ipbus_bridge_previous_state = 4'd0;
reg ipbus_bridge_previous_write = 1'd0;
wire ipbus_bridge_level;
wire ethernet_ref;
wire ethernet_reset;
wire ethernet_lock;
wire ethernet_clk;
wire ethernet_refclk;
reg ethernet_pcstx_config_valid;
reg [15:0] ethernet_pcstx_config_reg;
reg [1:0] ethernet_pcstx_sgmii_speed;
wire ethernet_pcstx_sink_valid;
reg ethernet_pcstx_sink_ready;
wire ethernet_pcstx_sink_first;
wire ethernet_pcstx_sink_last;
wire [7:0] ethernet_pcstx_sink_payload_data;
reg ethernet_pcstx_encoder_ce0 = 1'd1;
reg [7:0] ethernet_pcstx_encoder0;
reg ethernet_pcstx_encoder1;
reg [9:0] ethernet_pcstx_encoder2 = 10'd0;
reg ethernet_pcstx_encoder3 = 1'd0;
wire [7:0] ethernet_pcstx_encoder_d;
wire ethernet_pcstx_encoder_k;
reg ethernet_pcstx_encoder_disp_in = 1'd0;
reg [9:0] ethernet_pcstx_encoder_output;
reg ethernet_pcstx_encoder_disp_out;
reg [5:0] ethernet_pcstx_encoder_code6b = 6'd0;
reg ethernet_pcstx_encoder_code6b_unbalanced = 1'd0;
reg ethernet_pcstx_encoder_code6b_flip = 1'd0;
reg [3:0] ethernet_pcstx_encoder_code4b = 4'd0;
reg ethernet_pcstx_encoder_code4b_unbalanced = 1'd0;
reg ethernet_pcstx_encoder_code4b_flip = 1'd0;
reg ethernet_pcstx_encoder_alt7_rd0 = 1'd0;
reg ethernet_pcstx_encoder_alt7_rd1 = 1'd0;
reg [5:0] ethernet_pcstx_encoder_output_6b;
wire ethernet_pcstx_encoder_disp_inter;
reg [3:0] ethernet_pcstx_encoder_output_4b;
wire [9:0] ethernet_pcstx_encoder_output_msb_first;
wire ethernet_pcstx_encoder_ce1;
reg ethernet_pcstx_count0 = 1'd0;
reg ethernet_pcstx_parity = 1'd0;
reg ethernet_pcstx_ctype = 1'd0;
reg ethernet_pcstx_enable;
wire ethernet_pcstx_done;
reg [6:0] ethernet_pcstx_count1 = 7'd0;
reg ethernet_pcsrx_seen_valid_ci;
reg ethernet_pcsrx_seen_config_reg;
reg [15:0] ethernet_pcsrx_config_reg = 16'd0;
reg [1:0] ethernet_pcsrx_sgmii_speed;
reg ethernet_pcsrx_source_valid;
wire ethernet_pcsrx_source_ready;
reg ethernet_pcsrx_source_first;
reg ethernet_pcsrx_source_last;
reg [7:0] ethernet_pcsrx_source_payload_data;
reg ethernet_pcsrx_source_payload_error;
wire ethernet_pcsrx_decoder_ce;
wire [9:0] ethernet_pcsrx_decoder_input;
wire [7:0] ethernet_pcsrx_decoder_d;
reg ethernet_pcsrx_decoder_k = 1'd0;
wire ethernet_pcsrx_decoder_invalid;
reg [9:0] ethernet_pcsrx_decoder_input_msb_first;
wire [4:0] ethernet_pcsrx_decoder_code5b;
reg [2:0] ethernet_pcsrx_decoder_code3b = 3'd0;
wire [5:0] ethernet_pcsrx_decoder_adr;
wire [4:0] ethernet_pcsrx_decoder_dat_r;
wire ethernet_pcsrx_decoder_re;
reg [3:0] ethernet_pcsrx_decoder_ones = 4'd0;
reg ethernet_pcsrx_count0 = 1'd0;
reg ethernet_pcsrx_enable;
wire ethernet_pcsrx_done;
reg [6:0] ethernet_pcsrx_count1 = 7'd0;
wire ethernet_pcsrx_timer_ce;
reg ethernet_pcsrx_sink_sink_valid;
wire ethernet_pcsrx_sink_sink_ready;
reg ethernet_pcsrx_sink_sink_first = 1'd0;
reg ethernet_pcsrx_sink_sink_last = 1'd0;
reg [7:0] ethernet_pcsrx_sink_sink_payload_data;
wire ethernet_pcsrx_source_source_valid;
reg ethernet_pcsrx_source_source_ready;
wire ethernet_pcsrx_source_source_first;
wire ethernet_pcsrx_source_source_last;
wire [7:0] ethernet_pcsrx_source_source_payload_data;
wire ethernet_pcsrx_pipe_valid_sink_valid;
wire ethernet_pcsrx_pipe_valid_sink_ready;
wire ethernet_pcsrx_pipe_valid_sink_first;
wire ethernet_pcsrx_pipe_valid_sink_last;
wire [7:0] ethernet_pcsrx_pipe_valid_sink_payload_data;
reg ethernet_pcsrx_pipe_valid_source_valid = 1'd0;
wire ethernet_pcsrx_pipe_valid_source_ready;
reg ethernet_pcsrx_pipe_valid_source_first = 1'd0;
reg ethernet_pcsrx_pipe_valid_source_last = 1'd0;
reg [7:0] ethernet_pcsrx_pipe_valid_source_payload_data = 8'd0;
wire ethernet_sink_sink_valid;
wire ethernet_sink_sink_ready;
wire ethernet_sink_sink_first;
wire ethernet_sink_sink_last;
wire [7:0] ethernet_sink_sink_payload_data;
wire ethernet_sink_sink_payload_be;
wire ethernet_sink_sink_payload_error;
wire ethernet_source_source_valid;
wire ethernet_source_source_ready;
wire ethernet_source_source_first;
wire ethernet_source_source_last;
wire [7:0] ethernet_source_source_payload_data;
wire ethernet_source_source_payload_be;
wire ethernet_source_source_payload_error;
reg ethernet_link_up;
reg ethernet_restart;
reg ethernet_align;
reg [15:0] ethernet_lp_abi_i = 16'd0;
reg [15:0] ethernet_lp_abi_o = 16'd0;
reg ethernet_lp_abi_starter = 1'd1;
wire ethernet_lp_abi_ping_i;
wire ethernet_lp_abi_ping_o0;
reg ethernet_lp_abi_ping_toggle_i = 1'd0;
wire ethernet_lp_abi_ping_toggle_o;
reg ethernet_lp_abi_ping_toggle_o_r = 1'd0;
reg ethernet_lp_abi_ping_o1 = 1'd0;
wire ethernet_lp_abi_pong_i;
wire ethernet_lp_abi_pong_o;
reg ethernet_lp_abi_pong_toggle_i = 1'd0;
wire ethernet_lp_abi_pong_toggle_o;
reg ethernet_lp_abi_pong_toggle_o_r = 1'd0;
wire ethernet_lp_abi_wait;
wire ethernet_lp_abi_done;
reg [7:0] ethernet_lp_abi_count = 8'd128;
(* dont_touch = "true" *) reg [15:0] ethernet_lp_abi_ibuffer = 16'd0;
wire [15:0] ethernet_lp_abi_obuffer;
reg ethernet_config_empty;
wire ethernet_is_sgmii;
reg ethernet_linkdown;
reg ethernet_autoneg_ack;
wire ethernet_seen_valid_ci_i;
wire ethernet_seen_valid_ci_o;
reg ethernet_seen_valid_ci_toggle_i = 1'd0;
wire ethernet_seen_valid_ci_toggle_o;
reg ethernet_seen_valid_ci_toggle_o_r = 1'd0;
reg ethernet_rx_config_reg_abi_i = 1'd0;
wire ethernet_rx_config_reg_abi_o;
reg ethernet_rx_config_reg_abi_toggle_i = 1'd0;
wire ethernet_rx_config_reg_abi_toggle_o;
reg ethernet_rx_config_reg_abi_toggle_o_r = 1'd0;
reg ethernet_rx_config_reg_ack_i = 1'd0;
wire ethernet_rx_config_reg_ack_o;
reg ethernet_rx_config_reg_ack_toggle_i = 1'd0;
wire ethernet_rx_config_reg_ack_toggle_o;
reg ethernet_rx_config_reg_ack_toggle_o_r = 1'd0;
reg ethernet_waittimer0_wait;
wire ethernet_waittimer0_done;
reg [20:0] ethernet_waittimer0_count = 21'd1250000;
reg ethernet_waittimer1_wait;
wire ethernet_waittimer1_done;
reg [20:0] ethernet_waittimer1_count = 21'd1250000;
reg ethernet_waittimer2_wait;
wire ethernet_waittimer2_done;
reg [17:0] ethernet_waittimer2_count = 18'd200000;
reg [19:0] ethernet_checker_count = 20'd0;
reg ethernet_checker_tick = 1'd0;
reg ethernet_checker_error = 1'd0;
wire ethernet_sgmii_speed_valid;
wire [1:0] ethernet_sgmii_tx_speed;
wire [1:0] ethernet_sgmii_rx_speed;
reg [3:0] ethernet_rx_config_reg_count = 4'd0;
reg [15:0] ethernet_rx_config_reg_last = 16'd0;
reg ethernet_pma_a7_gtp_basex_reset = 1'd0;
wire ethernet_pma_a7_gtp_basex_align;
wire ethernet_pma_a7_gtp_basex_restart;
wire ethernet_pma_a7_gtp_basex_rx_valid;
wire eth_tx_clk;
wire eth_tx_rst;
wire eth_rx_clk;
wire eth_rx_rst;
wire eth_tx_half_clk;
wire eth_rx_half_clk;
wire ethernet_pma_a7_gtp_basex_txoutclk;
wire ethernet_pma_a7_gtp_basex_rxoutclk;
wire ethernet_pma_a7_gtp_basex_tx_reset;
wire ethernet_pma_a7_gtp_basex_tx_cm_locked0;
(* dont_touch = "true" *) reg ethernet_pma_a7_gtp_basex_tx_cm_reset0 = 1'd1;
wire [19:0] ethernet_pma_a7_gtp_basex_tx_data0;
wire ethernet_pma_a7_gtp_basex_tx_reset_done;
wire ethernet_pma_a7_gtp_basex_rx_reset;
wire ethernet_pma_a7_gtp_basex_rx_cm_locked0;
(* dont_touch = "true" *) reg ethernet_pma_a7_gtp_basex_rx_cm_reset0 = 1'd1;
wire [19:0] ethernet_pma_a7_gtp_basex_rx_data0;
wire ethernet_pma_a7_gtp_basex_rx_reset_done;
wire ethernet_pma_a7_gtp_basex_rx_pma_reset_done;
wire [8:0] ethernet_pma_a7_gtp_basex_drpaddr;
wire ethernet_pma_a7_gtp_basex_drpen;
wire [15:0] ethernet_pma_a7_gtp_basex_drpdi;
wire ethernet_pma_a7_gtp_basex_drprdy;
wire [15:0] ethernet_pma_a7_gtp_basex_drpdo;
wire ethernet_pma_a7_gtp_basex_drpwe;
wire ethernet_pma_a7_gtp_basex0;
wire ethernet_pma_a7_gtp_basex1;
wire ethernet_pma_a7_gtp_basex2;
wire ethernet_pma_a7_gtp_basex3;
wire ethernet_pma_a7_gtp_basex4;
wire ethernet_pma_a7_gtp_basex5;
wire ethernet_pma_a7_gtp_basex6;
wire ethernet_pma_a7_gtp_basex7;
wire ethernet_pma_a7_gtp_basex8;
wire ethernet_pma_a7_gtp_basex9;
wire ethernet_pma_a7_gtp_basex10;
wire ethernet_pma_a7_gtp_basex11;
wire ethernet_pma_a7_gtp_basex12;
wire ethernet_pma_a7_gtp_basex13;
wire ethernet_pma_a7_gtp_basex14;
wire ethernet_pma_a7_gtp_basex15;
wire ethernet_pma_a7_gtp_basex16;
wire ethernet_pma_a7_gtp_basex17;
wire ethernet_pma_a7_gtp_basex18;
wire ethernet_pma_a7_gtp_basex19;
wire ethernet_pma_a7_gtp_basex20;
wire ethernet_pma_a7_gtp_basex21;
wire ethernet_pma_a7_gtp_basex22;
wire ethernet_pma_a7_gtp_basex23;
wire ethernet_pma_a7_gtp_basex24;
wire ethernet_pma_a7_gtp_basex25;
wire ethernet_pma_a7_gtp_basex26;
wire ethernet_pma_a7_gtp_basex27;
wire ethernet_pma_a7_gtp_basex28;
wire ethernet_pma_a7_gtp_basex29;
wire ethernet_pma_a7_gtp_basex30;
wire ethernet_pma_a7_gtp_basex31;
wire ethernet_pma_a7_gtp_basex32;
wire ethernet_pma_a7_gtp_basex33;
wire ethernet_pma_a7_gtp_basex34;
wire ethernet_pma_a7_gtp_basex35;
wire ethernet_pma_a7_gtp_basex36;
wire ethernet_pma_a7_gtp_basex37;
wire ethernet_pma_a7_gtp_basex38;
wire ethernet_pma_a7_gtp_basex39;
wire ethernet_pma_a7_gtp_basex40;
wire ethernet_pma_a7_gtp_basex41;
wire ethernet_pma_a7_gtp_basex42;
wire ethernet_pma_a7_gtp_basex43;
wire ethernet_pma_a7_gtp_basex44;
wire ethernet_pma_a7_gtp_basex45;
wire ethernet_pma_a7_gtp_basex46;
wire ethernet_pma_a7_gtp_basex47;
wire ethernet_pma_a7_gtp_basex48;
wire ethernet_pma_a7_gtp_basex49;
wire ethernet_pma_a7_gtp_basex50;
wire ethernet_pma_a7_gtp_basex51;
wire ethernet_pma_a7_gtp_basex52;
wire ethernet_pma_a7_gtp_basex53;
wire ethernet_pma_a7_gtp_basex_txoutclk_rebuffer;
wire ethernet_pma_a7_gtp_basex_rxoutclk_rebuffer;
wire ethernet_pma_a7_gtp_basex_tx_cm_reset1;
reg ethernet_pma_a7_gtp_basex_tx_cm_power_down = 1'd0;
wire ethernet_pma_a7_gtp_basex_tx_cm_locked1;
wire ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal;
wire ethernet_pma_a7_gtp_basex_s7pll0_clkout0;
wire ethernet_pma_a7_gtp_basex_s7pll0_clkout_buf0;
wire ethernet_pma_a7_gtp_basex_s7pll0_clkout1;
wire ethernet_pma_a7_gtp_basex_s7pll0_clkout_buf1;
wire ethernet_pma_a7_gtp_basex_rx_cm_reset1;
reg ethernet_pma_a7_gtp_basex_rx_cm_power_down = 1'd0;
wire ethernet_pma_a7_gtp_basex_rx_cm_locked1;
wire ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal;
wire ethernet_pma_a7_gtp_basex_s7pll1_clkout0;
wire ethernet_pma_a7_gtp_basex_s7pll1_clkout_buf0;
wire ethernet_pma_a7_gtp_basex_s7pll1_clkout1;
wire ethernet_pma_a7_gtp_basex_s7pll1_clkout_buf1;
(* dont_touch = "true" *) reg ethernet_pma_a7_gtp_basex_tx_init_qpll_reset0 = 1'd0;
wire ethernet_pma_a7_gtp_basex_tx_init_qpll_lock0;
(* dont_touch = "true" *) reg ethernet_pma_a7_gtp_basex_tx_init_tx_reset0 = 1'd0;
reg ethernet_pma_a7_gtp_basex_tx_init_done;
reg ethernet_pma_a7_gtp_basex_tx_init_qpll_reset1;
reg ethernet_pma_a7_gtp_basex_tx_init_tx_reset1;
wire ethernet_pma_a7_gtp_basex_tx_init_qpll_lock1;
reg [10:0] ethernet_pma_a7_gtp_basex_tx_init_timer = 11'd0;
reg ethernet_pma_a7_gtp_basex_tx_init_tick = 1'd0;
(* dont_touch = "true" *) reg ethernet_pma_a7_gtp_basex_rx_init_rx_reset0 = 1'd0;
wire ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done0;
wire [8:0] ethernet_pma_a7_gtp_basex_rx_init_drpaddr;
reg ethernet_pma_a7_gtp_basex_rx_init_drpen;
reg [15:0] ethernet_pma_a7_gtp_basex_rx_init_drpdi;
wire ethernet_pma_a7_gtp_basex_rx_init_drprdy;
wire [15:0] ethernet_pma_a7_gtp_basex_rx_init_drpdo;
reg ethernet_pma_a7_gtp_basex_rx_init_drpwe;
wire ethernet_pma_a7_gtp_basex_rx_init_enable;
wire ethernet_pma_a7_gtp_basex_rx_init_restart;
reg ethernet_pma_a7_gtp_basex_rx_init_done;
reg ethernet_pma_a7_gtp_basex_rx_init_rx_reset1;
wire ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done1;
reg [15:0] ethernet_pma_a7_gtp_basex_rx_init_drpvalue = 16'd0;
reg ethernet_pma_a7_gtp_basex_rx_init_drpmask;
reg ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done_r = 1'd0;
wire ethernet_pma_a7_gtp_basex_i;
wire ethernet_pma_a7_gtp_basex_o;
reg ethernet_pma_a7_gtp_basex_toggle_i = 1'd0;
wire ethernet_pma_a7_gtp_basex_toggle_o;
reg ethernet_pma_a7_gtp_basex_toggle_o_r = 1'd0;
reg [12:0] ethernet_pma_a7_gtp_basex_cdr_lock_counter = 13'd0;
reg ethernet_pma_a7_gtp_basex_cdr_locked = 1'd0;
wire [9:0] ethernet_pma_a7_gtp_basex_tx_data1;
reg [19:0] ethernet_pma_a7_gtp_basex_tx_data_half = 20'd0;
wire [19:0] ethernet_pma_a7_gtp_basex_rx_data_half;
reg [9:0] ethernet_pma_a7_gtp_basex_rx_data1 = 10'd0;
reg [19:0] ethernet_pma_a7_gtp_basex_buf = 20'd0;
reg ethernet_pma_a7_gtp_basex_phase_half = 1'd0;
reg ethernet_pma_a7_gtp_basex_phase_half_rereg = 1'd0;
wire ethernet_sink_valid;
wire ethernet_sink_ready;
wire ethernet_sink_first;
wire ethernet_sink_last;
wire [7:0] ethernet_sink_payload_data;
wire ethernet_sink_payload_be;
wire ethernet_sink_payload_error;
wire ethernet_source_valid;
wire ethernet_source_ready;
wire ethernet_source_first;
wire ethernet_source_last;
wire [7:0] ethernet_source_payload_data;
wire ethernet_source_payload_be;
wire ethernet_source_payload_error;
wire ethernet_tx_padding_sink_valid;
reg ethernet_tx_padding_sink_ready;
wire ethernet_tx_padding_sink_first;
wire ethernet_tx_padding_sink_last;
wire [7:0] ethernet_tx_padding_sink_payload_data;
wire ethernet_tx_padding_sink_payload_be;
wire ethernet_tx_padding_sink_payload_error;
reg ethernet_tx_padding_source_valid;
wire ethernet_tx_padding_source_ready;
reg ethernet_tx_padding_source_first;
reg ethernet_tx_padding_source_last;
reg [7:0] ethernet_tx_padding_source_payload_data;
reg ethernet_tx_padding_source_payload_be;
reg ethernet_tx_padding_source_payload_error;
reg [15:0] ethernet_tx_padding_counter = 16'd0;
wire ethernet_tx_padding_counter_done;
wire ethernet_tx_crc_sink_valid;
reg ethernet_tx_crc_sink_ready;
wire ethernet_tx_crc_sink_first;
wire ethernet_tx_crc_sink_last;
wire [7:0] ethernet_tx_crc_sink_payload_data;
wire ethernet_tx_crc_sink_payload_be;
wire ethernet_tx_crc_sink_payload_error;
reg ethernet_tx_crc_source_valid;
wire ethernet_tx_crc_source_ready;
reg ethernet_tx_crc_source_first;
reg ethernet_tx_crc_source_last;
reg [7:0] ethernet_tx_crc_source_payload_data;
reg ethernet_tx_crc_source_payload_be;
reg ethernet_tx_crc_source_payload_error;
reg [31:0] ethernet_tx_crc_crc_packet = 32'd0;
reg ethernet_tx_crc_be0 = 1'd0;
wire [7:0] ethernet_tx_crc_data0;
wire ethernet_tx_crc_be1;
reg [31:0] ethernet_tx_crc_value;
reg ethernet_tx_crc_error;
wire [7:0] ethernet_tx_crc_data1;
wire [31:0] ethernet_tx_crc_crc_prev;
reg [31:0] ethernet_tx_crc_crc_next;
reg [31:0] ethernet_tx_crc_reg = 32'd4294967295;
reg ethernet_tx_crc_ce;
reg ethernet_tx_crc_reset;
reg [1:0] ethernet_tx_crc_cnt = 2'd3;
wire ethernet_tx_crc_cnt_done;
reg ethernet_tx_crc_is_ongoing0;
reg ethernet_tx_crc_is_ongoing1;
wire ethernet_tx_crc_sink_sink_valid;
wire ethernet_tx_crc_sink_sink_ready;
wire ethernet_tx_crc_sink_sink_first;
wire ethernet_tx_crc_sink_sink_last;
wire [7:0] ethernet_tx_crc_sink_sink_payload_data;
wire ethernet_tx_crc_sink_sink_payload_be;
wire ethernet_tx_crc_sink_sink_payload_error;
wire ethernet_tx_crc_source_source_valid;
wire ethernet_tx_crc_source_source_ready;
wire ethernet_tx_crc_source_source_first;
wire ethernet_tx_crc_source_source_last;
wire [7:0] ethernet_tx_crc_source_source_payload_data;
wire ethernet_tx_crc_source_source_payload_be;
wire ethernet_tx_crc_source_source_payload_error;
wire ethernet_tx_crc_pipe_valid_sink_valid;
wire ethernet_tx_crc_pipe_valid_sink_ready;
wire ethernet_tx_crc_pipe_valid_sink_first;
wire ethernet_tx_crc_pipe_valid_sink_last;
wire [7:0] ethernet_tx_crc_pipe_valid_sink_payload_data;
wire ethernet_tx_crc_pipe_valid_sink_payload_be;
wire ethernet_tx_crc_pipe_valid_sink_payload_error;
reg ethernet_tx_crc_pipe_valid_source_valid = 1'd0;
wire ethernet_tx_crc_pipe_valid_source_ready;
reg ethernet_tx_crc_pipe_valid_source_first = 1'd0;
reg ethernet_tx_crc_pipe_valid_source_last = 1'd0;
reg [7:0] ethernet_tx_crc_pipe_valid_source_payload_data = 8'd0;
reg ethernet_tx_crc_pipe_valid_source_payload_be = 1'd0;
reg ethernet_tx_crc_pipe_valid_source_payload_error = 1'd0;
wire ethernet_tx_preamble_sink_valid;
reg ethernet_tx_preamble_sink_ready;
wire ethernet_tx_preamble_sink_first;
wire ethernet_tx_preamble_sink_last;
wire [7:0] ethernet_tx_preamble_sink_payload_data;
wire ethernet_tx_preamble_sink_payload_be;
wire ethernet_tx_preamble_sink_payload_error;
reg ethernet_tx_preamble_source_valid;
wire ethernet_tx_preamble_source_ready;
reg ethernet_tx_preamble_source_first;
reg ethernet_tx_preamble_source_last;
reg [7:0] ethernet_tx_preamble_source_payload_data;
reg ethernet_tx_preamble_source_payload_be;
reg ethernet_tx_preamble_source_payload_error;
reg [63:0] ethernet_tx_preamble_preamble = 64'd15372286728091293013;
reg [2:0] ethernet_tx_preamble_count = 3'd0;
wire ethernet_txdatapath_sink_sink_valid;
wire ethernet_txdatapath_sink_sink_ready;
wire ethernet_txdatapath_sink_sink_first;
wire ethernet_txdatapath_sink_sink_last;
wire [7:0] ethernet_txdatapath_sink_sink_payload_data;
wire ethernet_txdatapath_sink_sink_payload_be;
wire ethernet_txdatapath_sink_sink_payload_error;
wire ethernet_txdatapath_source_source_valid;
wire ethernet_txdatapath_source_source_ready;
wire ethernet_txdatapath_source_source_first;
wire ethernet_txdatapath_source_source_last;
wire [7:0] ethernet_txdatapath_source_source_payload_data;
wire ethernet_txdatapath_source_source_payload_be;
wire ethernet_txdatapath_source_source_payload_error;
wire ethernet_txdatapath_cdc_sink_valid;
wire ethernet_txdatapath_cdc_sink_ready;
wire ethernet_txdatapath_cdc_sink_first;
wire ethernet_txdatapath_cdc_sink_last;
wire [7:0] ethernet_txdatapath_cdc_sink_payload_data;
wire ethernet_txdatapath_cdc_sink_payload_be;
wire ethernet_txdatapath_cdc_sink_payload_error;
wire ethernet_txdatapath_cdc_source_valid;
wire ethernet_txdatapath_cdc_source_ready;
wire ethernet_txdatapath_cdc_source_first;
wire ethernet_txdatapath_cdc_source_last;
wire [7:0] ethernet_txdatapath_cdc_source_payload_data;
wire ethernet_txdatapath_cdc_source_payload_be;
wire ethernet_txdatapath_cdc_source_payload_error;
wire ethernet_txdatapath_cdc_asyncfifo_we;
wire ethernet_txdatapath_cdc_asyncfifo_writable;
wire ethernet_txdatapath_cdc_asyncfifo_re;
wire ethernet_txdatapath_cdc_asyncfifo_readable;
wire [11:0] ethernet_txdatapath_cdc_asyncfifo_din;
wire [11:0] ethernet_txdatapath_cdc_asyncfifo_dout;
wire ethernet_txdatapath_cdc_graycounter0_ce;
(* dont_touch = "true" *) reg [5:0] ethernet_txdatapath_cdc_graycounter0_q = 6'd0;
wire [5:0] ethernet_txdatapath_cdc_graycounter0_q_next;
reg [5:0] ethernet_txdatapath_cdc_graycounter0_q_binary = 6'd0;
reg [5:0] ethernet_txdatapath_cdc_graycounter0_q_next_binary;
wire ethernet_txdatapath_cdc_graycounter1_ce;
(* dont_touch = "true" *) reg [5:0] ethernet_txdatapath_cdc_graycounter1_q = 6'd0;
wire [5:0] ethernet_txdatapath_cdc_graycounter1_q_next;
reg [5:0] ethernet_txdatapath_cdc_graycounter1_q_binary = 6'd0;
reg [5:0] ethernet_txdatapath_cdc_graycounter1_q_next_binary;
wire [5:0] ethernet_txdatapath_cdc_produce_rdomain;
wire [5:0] ethernet_txdatapath_cdc_consume_wdomain;
wire [4:0] ethernet_txdatapath_cdc_wrport_adr;
wire [11:0] ethernet_txdatapath_cdc_wrport_dat_r;
wire ethernet_txdatapath_cdc_wrport_we;
wire [11:0] ethernet_txdatapath_cdc_wrport_dat_w;
wire [4:0] ethernet_txdatapath_cdc_rdport_adr;
wire [11:0] ethernet_txdatapath_cdc_rdport_dat_r;
wire [7:0] ethernet_txdatapath_cdc_fifo_in_payload_data;
wire ethernet_txdatapath_cdc_fifo_in_payload_be;
wire ethernet_txdatapath_cdc_fifo_in_payload_error;
wire ethernet_txdatapath_cdc_fifo_in_first;
wire ethernet_txdatapath_cdc_fifo_in_last;
wire [7:0] ethernet_txdatapath_cdc_fifo_out_payload_data;
wire ethernet_txdatapath_cdc_fifo_out_payload_be;
wire ethernet_txdatapath_cdc_fifo_out_payload_error;
wire ethernet_txdatapath_cdc_fifo_out_first;
wire ethernet_txdatapath_cdc_fifo_out_last;
wire ethernet_tx_packet_fifo_sink_sink_valid;
wire ethernet_tx_packet_fifo_sink_sink_ready;
wire ethernet_tx_packet_fifo_sink_sink_first;
wire ethernet_tx_packet_fifo_sink_sink_last;
wire [7:0] ethernet_tx_packet_fifo_sink_sink_payload_data;
wire ethernet_tx_packet_fifo_sink_sink_payload_be;
wire ethernet_tx_packet_fifo_sink_sink_payload_error;
wire ethernet_tx_packet_fifo_source_source_valid;
wire ethernet_tx_packet_fifo_source_source_ready;
reg ethernet_tx_packet_fifo_source_source_first;
wire ethernet_tx_packet_fifo_source_source_last;
wire [7:0] ethernet_tx_packet_fifo_source_source_payload_data;
wire ethernet_tx_packet_fifo_source_source_payload_be;
wire ethernet_tx_packet_fifo_source_source_payload_error;
wire ethernet_tx_packet_fifo_payload_fifo_sink_valid;
wire ethernet_tx_packet_fifo_payload_fifo_sink_ready;
wire ethernet_tx_packet_fifo_payload_fifo_sink_first;
wire ethernet_tx_packet_fifo_payload_fifo_sink_last;
wire [7:0] ethernet_tx_packet_fifo_payload_fifo_sink_payload_data;
wire ethernet_tx_packet_fifo_payload_fifo_sink_payload_be;
wire ethernet_tx_packet_fifo_payload_fifo_sink_payload_error;
wire ethernet_tx_packet_fifo_payload_fifo_source_valid;
wire ethernet_tx_packet_fifo_payload_fifo_source_ready;
wire ethernet_tx_packet_fifo_payload_fifo_source_first;
wire ethernet_tx_packet_fifo_payload_fifo_source_last;
wire [7:0] ethernet_tx_packet_fifo_payload_fifo_source_payload_data;
wire ethernet_tx_packet_fifo_payload_fifo_source_payload_be;
wire ethernet_tx_packet_fifo_payload_fifo_source_payload_error;
wire ethernet_tx_packet_fifo_payload_fifo_re;
reg ethernet_tx_packet_fifo_payload_fifo_readable = 1'd0;
wire ethernet_tx_packet_fifo_payload_fifo_syncfifo_we;
wire ethernet_tx_packet_fifo_payload_fifo_syncfifo_writable;
wire ethernet_tx_packet_fifo_payload_fifo_syncfifo_re;
wire ethernet_tx_packet_fifo_payload_fifo_syncfifo_readable;
wire [11:0] ethernet_tx_packet_fifo_payload_fifo_syncfifo_din;
wire [11:0] ethernet_tx_packet_fifo_payload_fifo_syncfifo_dout;
reg [11:0] ethernet_tx_packet_fifo_payload_fifo_level0 = 12'd0;
reg ethernet_tx_packet_fifo_payload_fifo_replace = 1'd0;
reg [10:0] ethernet_tx_packet_fifo_payload_fifo_produce = 11'd0;
reg [10:0] ethernet_tx_packet_fifo_payload_fifo_consume = 11'd0;
reg [10:0] ethernet_tx_packet_fifo_payload_fifo_wrport_adr;
wire [11:0] ethernet_tx_packet_fifo_payload_fifo_wrport_dat_r;
wire ethernet_tx_packet_fifo_payload_fifo_wrport_we;
wire [11:0] ethernet_tx_packet_fifo_payload_fifo_wrport_dat_w;
wire ethernet_tx_packet_fifo_payload_fifo_do_read;
wire [10:0] ethernet_tx_packet_fifo_payload_fifo_rdport_adr;
wire [11:0] ethernet_tx_packet_fifo_payload_fifo_rdport_dat_r;
wire ethernet_tx_packet_fifo_payload_fifo_rdport_re;
wire [11:0] ethernet_tx_packet_fifo_payload_fifo_level1;
wire [7:0] ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_data;
wire ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_be;
wire ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_error;
wire ethernet_tx_packet_fifo_payload_fifo_fifo_in_first;
wire ethernet_tx_packet_fifo_payload_fifo_fifo_in_last;
wire [7:0] ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_data;
wire ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_be;
wire ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_error;
wire ethernet_tx_packet_fifo_payload_fifo_fifo_out_first;
wire ethernet_tx_packet_fifo_payload_fifo_fifo_out_last;
wire ethernet_tx_packet_fifo_param_fifo_sink_valid;
wire ethernet_tx_packet_fifo_param_fifo_sink_ready;
reg ethernet_tx_packet_fifo_param_fifo_sink_first = 1'd0;
reg ethernet_tx_packet_fifo_param_fifo_sink_last = 1'd0;
reg ethernet_tx_packet_fifo_param_fifo_sink_param_dummy = 1'd0;
wire ethernet_tx_packet_fifo_param_fifo_source_valid;
wire ethernet_tx_packet_fifo_param_fifo_source_ready;
wire ethernet_tx_packet_fifo_param_fifo_source_first;
wire ethernet_tx_packet_fifo_param_fifo_source_last;
wire ethernet_tx_packet_fifo_param_fifo_source_param_dummy;
wire ethernet_tx_packet_fifo_param_fifo_re;
reg ethernet_tx_packet_fifo_param_fifo_readable = 1'd0;
wire ethernet_tx_packet_fifo_param_fifo_syncfifo_we;
wire ethernet_tx_packet_fifo_param_fifo_syncfifo_writable;
wire ethernet_tx_packet_fifo_param_fifo_syncfifo_re;
wire ethernet_tx_packet_fifo_param_fifo_syncfifo_readable;
wire [2:0] ethernet_tx_packet_fifo_param_fifo_syncfifo_din;
wire [2:0] ethernet_tx_packet_fifo_param_fifo_syncfifo_dout;
reg [2:0] ethernet_tx_packet_fifo_param_fifo_level0 = 3'd0;
reg ethernet_tx_packet_fifo_param_fifo_replace = 1'd0;
reg [2:0] ethernet_tx_packet_fifo_param_fifo_produce = 3'd0;
reg [2:0] ethernet_tx_packet_fifo_param_fifo_consume = 3'd0;
reg [2:0] ethernet_tx_packet_fifo_param_fifo_wrport_adr;
wire [2:0] ethernet_tx_packet_fifo_param_fifo_wrport_dat_r;
wire ethernet_tx_packet_fifo_param_fifo_wrport_we;
wire [2:0] ethernet_tx_packet_fifo_param_fifo_wrport_dat_w;
wire ethernet_tx_packet_fifo_param_fifo_do_read;
wire [2:0] ethernet_tx_packet_fifo_param_fifo_rdport_adr;
wire [2:0] ethernet_tx_packet_fifo_param_fifo_rdport_dat_r;
wire ethernet_tx_packet_fifo_param_fifo_rdport_re;
wire [2:0] ethernet_tx_packet_fifo_param_fifo_level1;
wire ethernet_tx_packet_fifo_param_fifo_fifo_in_param_dummy;
wire ethernet_tx_packet_fifo_param_fifo_fifo_in_first;
wire ethernet_tx_packet_fifo_param_fifo_fifo_in_last;
wire ethernet_tx_packet_fifo_param_fifo_fifo_out_param_dummy;
wire ethernet_tx_packet_fifo_param_fifo_fifo_out_first;
wire ethernet_tx_packet_fifo_param_fifo_fifo_out_last;
wire ethernet_tx_gap_sink_valid;
reg ethernet_tx_gap_sink_ready;
wire ethernet_tx_gap_sink_first;
wire ethernet_tx_gap_sink_last;
wire [7:0] ethernet_tx_gap_sink_payload_data;
wire ethernet_tx_gap_sink_payload_be;
wire ethernet_tx_gap_sink_payload_error;
reg ethernet_tx_gap_source_valid;
wire ethernet_tx_gap_source_ready;
reg ethernet_tx_gap_source_first;
reg ethernet_tx_gap_source_last;
reg [7:0] ethernet_tx_gap_source_payload_data;
reg ethernet_tx_gap_source_payload_be;
reg ethernet_tx_gap_source_payload_error;
reg [3:0] ethernet_tx_gap_counter = 4'd0;
reg [31:0] ethernet_preamble_errors_status = 32'd0;
reg [31:0] ethernet_crc_errors_status = 32'd0;
reg [31:0] ethernet_drops_status = 32'd0;
wire ethernet_rx_packet_fifo_sink_sink_valid;
wire ethernet_rx_packet_fifo_sink_sink_ready;
wire ethernet_rx_packet_fifo_sink_sink_first;
wire ethernet_rx_packet_fifo_sink_sink_last;
wire [7:0] ethernet_rx_packet_fifo_sink_sink_payload_data;
wire ethernet_rx_packet_fifo_sink_sink_payload_be;
wire ethernet_rx_packet_fifo_sink_sink_payload_error;
wire ethernet_rx_packet_fifo_source_source_valid;
wire ethernet_rx_packet_fifo_source_source_ready;
wire ethernet_rx_packet_fifo_source_source_first;
wire ethernet_rx_packet_fifo_source_source_last;
wire [7:0] ethernet_rx_packet_fifo_source_source_payload_data;
wire ethernet_rx_packet_fifo_source_source_payload_be;
wire ethernet_rx_packet_fifo_source_source_payload_error;
reg ethernet_rx_packet_fifo_discard = 1'd0;
wire ethernet_rx_packet_fifo_drop;
wire ethernet_rx_packet_fifo_param_fifo_sink_valid;
wire ethernet_rx_packet_fifo_param_fifo_sink_ready;
reg ethernet_rx_packet_fifo_param_fifo_sink_first = 1'd0;
wire ethernet_rx_packet_fifo_param_fifo_sink_last;
reg ethernet_rx_packet_fifo_param_fifo_sink_param_dummy = 1'd0;
wire ethernet_rx_packet_fifo_param_fifo_source_valid;
wire ethernet_rx_packet_fifo_param_fifo_source_ready;
wire ethernet_rx_packet_fifo_param_fifo_source_first;
wire ethernet_rx_packet_fifo_param_fifo_source_last;
wire ethernet_rx_packet_fifo_param_fifo_source_param_dummy;
wire ethernet_rx_packet_fifo_param_fifo_syncfifo_we;
wire ethernet_rx_packet_fifo_param_fifo_syncfifo_writable;
wire ethernet_rx_packet_fifo_param_fifo_syncfifo_re;
wire ethernet_rx_packet_fifo_param_fifo_syncfifo_readable;
wire [2:0] ethernet_rx_packet_fifo_param_fifo_syncfifo_din;
wire [2:0] ethernet_rx_packet_fifo_param_fifo_syncfifo_dout;
reg [2:0] ethernet_rx_packet_fifo_param_fifo_level = 3'd0;
reg ethernet_rx_packet_fifo_param_fifo_replace = 1'd0;
reg [1:0] ethernet_rx_packet_fifo_param_fifo_produce = 2'd0;
reg [1:0] ethernet_rx_packet_fifo_param_fifo_consume = 2'd0;
reg [1:0] ethernet_rx_packet_fifo_param_fifo_wrport_adr;
wire [2:0] ethernet_rx_packet_fifo_param_fifo_wrport_dat_r;
wire ethernet_rx_packet_fifo_param_fifo_wrport_we;
wire [2:0] ethernet_rx_packet_fifo_param_fifo_wrport_dat_w;
wire ethernet_rx_packet_fifo_param_fifo_do_read;
wire [1:0] ethernet_rx_packet_fifo_param_fifo_rdport_adr;
wire [2:0] ethernet_rx_packet_fifo_param_fifo_rdport_dat_r;
wire ethernet_rx_packet_fifo_param_fifo_fifo_in_param_dummy;
wire ethernet_rx_packet_fifo_param_fifo_fifo_in_first;
wire ethernet_rx_packet_fifo_param_fifo_fifo_in_last;
wire ethernet_rx_packet_fifo_param_fifo_fifo_out_param_dummy;
wire ethernet_rx_packet_fifo_param_fifo_fifo_out_first;
wire ethernet_rx_packet_fifo_param_fifo_fifo_out_last;
wire [10:0] ethernet_rx_packet_fifo_wr_port_adr;
wire [11:0] ethernet_rx_packet_fifo_wr_port_dat_r;
wire ethernet_rx_packet_fifo_wr_port_we;
wire [11:0] ethernet_rx_packet_fifo_wr_port_dat_w;
wire [10:0] ethernet_rx_packet_fifo_rd_port_adr;
wire [11:0] ethernet_rx_packet_fifo_rd_port_dat_r;
wire ethernet_rx_packet_fifo_rd_port_re;
reg [11:0] ethernet_rx_packet_fifo_wr_ptr = 12'd0;
reg [11:0] ethernet_rx_packet_fifo_commit_ptr = 12'd0;
reg [11:0] ethernet_rx_packet_fifo_rd_ptr = 12'd0;
reg ethernet_rx_packet_fifo_out_valid = 1'd0;
wire [11:0] ethernet_rx_packet_fifo_used;
wire ethernet_rx_packet_fifo_full;
reg ethernet_rx_packet_fifo_overflow = 1'd0;
reg ethernet_rx_packet_fifo_invalid = 1'd0;
wire ethernet_rx_packet_fifo_commit;
wire ethernet_rx_packet_fifo_fetch;
wire ethernet_i;
wire ethernet_o;
reg ethernet_toggle_i = 1'd0;
wire ethernet_toggle_o;
reg ethernet_toggle_o_r = 1'd0;
wire ethernet_rx_cdc_sink_sink_valid;
wire ethernet_rx_cdc_sink_sink_ready;
wire ethernet_rx_cdc_sink_sink_first;
wire ethernet_rx_cdc_sink_sink_last;
wire [7:0] ethernet_rx_cdc_sink_sink_payload_data;
wire ethernet_rx_cdc_sink_sink_payload_be;
wire ethernet_rx_cdc_sink_sink_payload_error;
wire ethernet_rx_cdc_source_source_valid;
wire ethernet_rx_cdc_source_source_ready;
wire ethernet_rx_cdc_source_source_first;
wire ethernet_rx_cdc_source_source_last;
wire [7:0] ethernet_rx_cdc_source_source_payload_data;
wire ethernet_rx_cdc_source_source_payload_be;
wire ethernet_rx_cdc_source_source_payload_error;
wire ethernet_rx_cdc_cdc_sink_valid;
wire ethernet_rx_cdc_cdc_sink_ready;
wire ethernet_rx_cdc_cdc_sink_first;
wire ethernet_rx_cdc_cdc_sink_last;
wire [7:0] ethernet_rx_cdc_cdc_sink_payload_data;
wire ethernet_rx_cdc_cdc_sink_payload_be;
wire ethernet_rx_cdc_cdc_sink_payload_error;
wire ethernet_rx_cdc_cdc_source_valid;
wire ethernet_rx_cdc_cdc_source_ready;
wire ethernet_rx_cdc_cdc_source_first;
wire ethernet_rx_cdc_cdc_source_last;
wire [7:0] ethernet_rx_cdc_cdc_source_payload_data;
wire ethernet_rx_cdc_cdc_source_payload_be;
wire ethernet_rx_cdc_cdc_source_payload_error;
wire ethernet_rx_cdc_cdc_asyncfifo_we;
wire ethernet_rx_cdc_cdc_asyncfifo_writable;
wire ethernet_rx_cdc_cdc_asyncfifo_re;
wire ethernet_rx_cdc_cdc_asyncfifo_readable;
wire [11:0] ethernet_rx_cdc_cdc_asyncfifo_din;
wire [11:0] ethernet_rx_cdc_cdc_asyncfifo_dout;
wire ethernet_rx_cdc_cdc_graycounter0_ce;
(* dont_touch = "true" *) reg [5:0] ethernet_rx_cdc_cdc_graycounter0_q = 6'd0;
wire [5:0] ethernet_rx_cdc_cdc_graycounter0_q_next;
reg [5:0] ethernet_rx_cdc_cdc_graycounter0_q_binary = 6'd0;
reg [5:0] ethernet_rx_cdc_cdc_graycounter0_q_next_binary;
wire ethernet_rx_cdc_cdc_graycounter1_ce;
(* dont_touch = "true" *) reg [5:0] ethernet_rx_cdc_cdc_graycounter1_q = 6'd0;
wire [5:0] ethernet_rx_cdc_cdc_graycounter1_q_next;
reg [5:0] ethernet_rx_cdc_cdc_graycounter1_q_binary = 6'd0;
reg [5:0] ethernet_rx_cdc_cdc_graycounter1_q_next_binary;
wire [5:0] ethernet_rx_cdc_cdc_produce_rdomain;
wire [5:0] ethernet_rx_cdc_cdc_consume_wdomain;
wire [4:0] ethernet_rx_cdc_cdc_wrport_adr;
wire [11:0] ethernet_rx_cdc_cdc_wrport_dat_r;
wire ethernet_rx_cdc_cdc_wrport_we;
wire [11:0] ethernet_rx_cdc_cdc_wrport_dat_w;
wire [4:0] ethernet_rx_cdc_cdc_rdport_adr;
wire [11:0] ethernet_rx_cdc_cdc_rdport_dat_r;
wire [7:0] ethernet_rx_cdc_cdc_fifo_in_payload_data;
wire ethernet_rx_cdc_cdc_fifo_in_payload_be;
wire ethernet_rx_cdc_cdc_fifo_in_payload_error;
wire ethernet_rx_cdc_cdc_fifo_in_first;
wire ethernet_rx_cdc_cdc_fifo_in_last;
wire [7:0] ethernet_rx_cdc_cdc_fifo_out_payload_data;
wire ethernet_rx_cdc_cdc_fifo_out_payload_be;
wire ethernet_rx_cdc_cdc_fifo_out_payload_error;
wire ethernet_rx_cdc_cdc_fifo_out_first;
wire ethernet_rx_cdc_cdc_fifo_out_last;
wire ethernet_rx_preamble_sink_valid;
reg ethernet_rx_preamble_sink_ready;
wire ethernet_rx_preamble_sink_first;
wire ethernet_rx_preamble_sink_last;
wire [7:0] ethernet_rx_preamble_sink_payload_data;
wire ethernet_rx_preamble_sink_payload_be;
wire ethernet_rx_preamble_sink_payload_error;
reg ethernet_rx_preamble_source_valid;
wire ethernet_rx_preamble_source_ready;
reg ethernet_rx_preamble_source_first;
reg ethernet_rx_preamble_source_last;
wire [7:0] ethernet_rx_preamble_source_payload_data;
wire ethernet_rx_preamble_source_payload_be;
reg ethernet_rx_preamble_source_payload_error;
reg ethernet_rx_preamble_error;
reg [63:0] ethernet_rx_preamble_preamble = 64'd15372286728091293013;
wire ethernet_pulsesynchronizer0_i;
wire ethernet_pulsesynchronizer0_o;
reg ethernet_pulsesynchronizer0_toggle_i = 1'd0;
wire ethernet_pulsesynchronizer0_toggle_o;
reg ethernet_pulsesynchronizer0_toggle_o_r = 1'd0;
wire ethernet_liteethmaccrc32checker_sink_sink_valid;
reg ethernet_liteethmaccrc32checker_sink_sink_ready;
wire ethernet_liteethmaccrc32checker_sink_sink_first;
wire ethernet_liteethmaccrc32checker_sink_sink_last;
wire [7:0] ethernet_liteethmaccrc32checker_sink_sink_payload_data;
wire ethernet_liteethmaccrc32checker_sink_sink_payload_be;
wire ethernet_liteethmaccrc32checker_sink_sink_payload_error;
reg ethernet_liteethmaccrc32checker_source_source_valid;
wire ethernet_liteethmaccrc32checker_source_source_ready;
wire ethernet_liteethmaccrc32checker_source_source_first;
reg ethernet_liteethmaccrc32checker_source_source_last;
wire [7:0] ethernet_liteethmaccrc32checker_source_source_payload_data;
reg ethernet_liteethmaccrc32checker_source_source_payload_be;
reg ethernet_liteethmaccrc32checker_source_source_payload_error;
reg ethernet_liteethmaccrc32checker_error;
wire [7:0] ethernet_liteethmaccrc32checker_crc_data0;
wire ethernet_liteethmaccrc32checker_crc_be;
reg ethernet_liteethmaccrc32checker_crc_error;
reg [7:0] ethernet_liteethmaccrc32checker_crc_data1;
wire [31:0] ethernet_liteethmaccrc32checker_crc_crc_prev;
reg [31:0] ethernet_liteethmaccrc32checker_crc_crc_next;
reg [31:0] ethernet_liteethmaccrc32checker_crc_reg = 32'd4294967295;
reg ethernet_liteethmaccrc32checker_crc_ce;
reg ethernet_liteethmaccrc32checker_crc_reset;
reg ethernet_liteethmaccrc32checker_syncfifo_sink_valid;
wire ethernet_liteethmaccrc32checker_syncfifo_sink_ready;
wire ethernet_liteethmaccrc32checker_syncfifo_sink_first;
wire ethernet_liteethmaccrc32checker_syncfifo_sink_last;
wire [7:0] ethernet_liteethmaccrc32checker_syncfifo_sink_payload_data;
wire ethernet_liteethmaccrc32checker_syncfifo_sink_payload_be;
wire ethernet_liteethmaccrc32checker_syncfifo_sink_payload_error;
wire ethernet_liteethmaccrc32checker_syncfifo_source_valid;
reg ethernet_liteethmaccrc32checker_syncfifo_source_ready;
wire ethernet_liteethmaccrc32checker_syncfifo_source_first;
wire ethernet_liteethmaccrc32checker_syncfifo_source_last;
wire [7:0] ethernet_liteethmaccrc32checker_syncfifo_source_payload_data;
wire ethernet_liteethmaccrc32checker_syncfifo_source_payload_be;
wire ethernet_liteethmaccrc32checker_syncfifo_source_payload_error;
wire ethernet_liteethmaccrc32checker_syncfifo_syncfifo_we;
wire ethernet_liteethmaccrc32checker_syncfifo_syncfifo_writable;
wire ethernet_liteethmaccrc32checker_syncfifo_syncfifo_re;
wire ethernet_liteethmaccrc32checker_syncfifo_syncfifo_readable;
wire [11:0] ethernet_liteethmaccrc32checker_syncfifo_syncfifo_din;
wire [11:0] ethernet_liteethmaccrc32checker_syncfifo_syncfifo_dout;
reg [2:0] ethernet_liteethmaccrc32checker_syncfifo_level = 3'd0;
reg ethernet_liteethmaccrc32checker_syncfifo_replace = 1'd0;
reg [2:0] ethernet_liteethmaccrc32checker_syncfifo_produce = 3'd0;
reg [2:0] ethernet_liteethmaccrc32checker_syncfifo_consume = 3'd0;
reg [2:0] ethernet_liteethmaccrc32checker_syncfifo_wrport_adr;
wire [11:0] ethernet_liteethmaccrc32checker_syncfifo_wrport_dat_r;
wire ethernet_liteethmaccrc32checker_syncfifo_wrport_we;
wire [11:0] ethernet_liteethmaccrc32checker_syncfifo_wrport_dat_w;
wire ethernet_liteethmaccrc32checker_syncfifo_do_read;
wire [2:0] ethernet_liteethmaccrc32checker_syncfifo_rdport_adr;
wire [11:0] ethernet_liteethmaccrc32checker_syncfifo_rdport_dat_r;
wire [7:0] ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_data;
wire ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_be;
wire ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_error;
wire ethernet_liteethmaccrc32checker_syncfifo_fifo_in_first;
wire ethernet_liteethmaccrc32checker_syncfifo_fifo_in_last;
wire [7:0] ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_data;
wire ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_be;
wire ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_error;
wire ethernet_liteethmaccrc32checker_syncfifo_fifo_out_first;
wire ethernet_liteethmaccrc32checker_syncfifo_fifo_out_last;
reg ethernet_liteethmaccrc32checker_fifo_reset;
wire ethernet_liteethmaccrc32checker_fifo_in;
wire ethernet_liteethmaccrc32checker_fifo_out;
wire ethernet_liteethmaccrc32checker_fifo_full;
reg ethernet_liteethmaccrc32checker_is_ongoing0;
reg ethernet_liteethmaccrc32checker_is_ongoing1;
reg ethernet_liteethmaccrc32checker_be = 1'd0;
reg ethernet_liteethmaccrc32checker_last_error = 1'd0;
wire ethernet_liteethmaccrc32checker_last_word_error;
reg ethernet_liteethmaccrc32checker_packet_error = 1'd0;
reg ethernet_liteethmaccrc32checker_is_ongoing2;
wire ethernet_bufferizeendpoints_sink_sink_valid;
wire ethernet_bufferizeendpoints_sink_sink_ready;
wire ethernet_bufferizeendpoints_sink_sink_first;
wire ethernet_bufferizeendpoints_sink_sink_last;
wire [7:0] ethernet_bufferizeendpoints_sink_sink_payload_data;
wire ethernet_bufferizeendpoints_sink_sink_payload_be;
wire ethernet_bufferizeendpoints_sink_sink_payload_error;
wire ethernet_bufferizeendpoints_source_source_valid;
wire ethernet_bufferizeendpoints_source_source_ready;
wire ethernet_bufferizeendpoints_source_source_first;
wire ethernet_bufferizeendpoints_source_source_last;
wire [7:0] ethernet_bufferizeendpoints_source_source_payload_data;
wire ethernet_bufferizeendpoints_source_source_payload_be;
wire ethernet_bufferizeendpoints_source_source_payload_error;
wire ethernet_bufferizeendpoints_pipe_valid_sink_valid;
wire ethernet_bufferizeendpoints_pipe_valid_sink_ready;
wire ethernet_bufferizeendpoints_pipe_valid_sink_first;
wire ethernet_bufferizeendpoints_pipe_valid_sink_last;
wire [7:0] ethernet_bufferizeendpoints_pipe_valid_sink_payload_data;
wire ethernet_bufferizeendpoints_pipe_valid_sink_payload_be;
wire ethernet_bufferizeendpoints_pipe_valid_sink_payload_error;
reg ethernet_bufferizeendpoints_pipe_valid_source_valid = 1'd0;
wire ethernet_bufferizeendpoints_pipe_valid_source_ready;
reg ethernet_bufferizeendpoints_pipe_valid_source_first = 1'd0;
reg ethernet_bufferizeendpoints_pipe_valid_source_last = 1'd0;
reg [7:0] ethernet_bufferizeendpoints_pipe_valid_source_payload_data = 8'd0;
reg ethernet_bufferizeendpoints_pipe_valid_source_payload_be = 1'd0;
reg ethernet_bufferizeendpoints_pipe_valid_source_payload_error = 1'd0;
wire ethernet_pulsesynchronizer1_i;
wire ethernet_pulsesynchronizer1_o;
reg ethernet_pulsesynchronizer1_toggle_i = 1'd0;
wire ethernet_pulsesynchronizer1_toggle_o;
reg ethernet_pulsesynchronizer1_toggle_o_r = 1'd0;
wire ethernet_rx_padding_sink_valid;
wire ethernet_rx_padding_sink_ready;
wire ethernet_rx_padding_sink_first;
wire ethernet_rx_padding_sink_last;
wire [7:0] ethernet_rx_padding_sink_payload_data;
wire ethernet_rx_padding_sink_payload_be;
wire ethernet_rx_padding_sink_payload_error;
wire ethernet_rx_padding_source_valid;
wire ethernet_rx_padding_source_ready;
wire ethernet_rx_padding_source_first;
wire ethernet_rx_padding_source_last;
wire [7:0] ethernet_rx_padding_source_payload_data;
wire ethernet_rx_padding_source_payload_be;
reg ethernet_rx_padding_source_payload_error;
reg [10:0] ethernet_rx_padding_length = 11'd0;
wire [3:0] ethernet_rx_padding_length_inc;
reg ethernet_first = 1'd1;
wire ethernet_got;
wire ethernet_link;
wire ethernet_got_ip;
wire [15:0] local_address;
wire [31:0] local_write_data;
reg [31:0] local_read_data;
wire local_write;
reg [15:0] control_output_mask = 16'd0;
reg control_command_error = 1'd0;
reg control_capture_fault = 1'd0;
wire control_valid;
reg control_enabled = 1'd0;
reg [11:0] control_tx_address = 12'd0;
reg [12:0] control_tx_length = 13'd25;
reg [31:0] control0 = 32'd0;
reg [31:0] control1 = 32'd0;
reg [31:0] control2 = 32'd0;
reg [31:0] control3 = 32'd0;
reg [3:0] control_bank = 4'd0;
reg [11:0] control_rx_address = 12'd0;
reg [12:0] control_capture_length = 13'd4096;
reg control_arm = 1'd0;
reg control_watching = 1'd0;
reg control_seen_busy = 1'd0;
reg [19:0] control_timer = 20'd0;
reg [15:0] control_capture_outputs = 16'd0;
reg [31:0] control_capture_sequence = 32'd0;
wire control_busy0;
wire control_done0;
wire control_error;
reg control_capture_armed = 1'd0;
reg control_generator_armed = 1'd0;
reg control_trigger_pending = 1'd0;
reg [31:0] control_trigger_id = 32'd0;
reg [31:0] control_capture_trigger_id = 32'd0;
reg [63:0] control_cycle = 64'd0;
reg [63:0] control_trigger_cycle = 64'd0;
reg [11:0] control_trigger_position = 12'd0;
reg [31:0] control_trigger_loop = 32'd0;
wire control_reserved;
wire control_launch;
wire control_raw_busy;
wire control_phase_busy;
wire control_phase_done;
wire control_start;
reg control_busy1 = 1'd0;
reg control_done1 = 1'd0;
wire [12:0] control_length;
reg [10:0] control_count0 = 11'd0;
wire [11:0] control_address;
wire [11:0] control_read_address;
reg [11:0] control_index = 12'd0;
reg [1:0] control_stage = 2'd0;
reg [1:0] control_state = 2'd0;
reg [10:0] control_frame = 11'd0;
reg control_previous0 = 1'd0;
reg [15:0] control_partial0 = 16'd0;
wire [7:0] control_rising0;
wire [23:0] control_mask0;
reg [4:0] control_first0;
wire [4:0] control_count1;
wire [31:0] control_record0;
wire [10:0] control_wp_memory0_adr;
wire [31:0] control_wp_memory0_dat_r;
wire control_wp_memory0_we;
wire [31:0] control_wp_memory0_dat_w;
wire [10:0] control_rp_memory0_adr;
wire [31:0] control_rp_memory0_dat_r;
reg control_previous1 = 1'd0;
reg [15:0] control_partial1 = 16'd0;
wire [7:0] control_rising1;
wire [23:0] control_mask1;
reg [4:0] control_first1;
wire [4:0] control_count2;
wire [31:0] control_record1;
wire [10:0] control_wp_memory1_adr;
wire [31:0] control_wp_memory1_dat_r;
wire control_wp_memory1_we;
wire [31:0] control_wp_memory1_dat_w;
wire [10:0] control_rp_memory1_adr;
wire [31:0] control_rp_memory1_dat_r;
reg control_previous2 = 1'd0;
reg [15:0] control_partial2 = 16'd0;
wire [7:0] control_rising2;
wire [23:0] control_mask2;
reg [4:0] control_first2;
wire [4:0] control_count3;
wire [31:0] control_record2;
wire [10:0] control_wp_memory2_adr;
wire [31:0] control_wp_memory2_dat_r;
wire control_wp_memory2_we;
wire [31:0] control_wp_memory2_dat_w;
wire [10:0] control_rp_memory2_adr;
wire [31:0] control_rp_memory2_dat_r;
reg control_previous3 = 1'd0;
reg [15:0] control_partial3 = 16'd0;
wire [7:0] control_rising3;
wire [23:0] control_mask3;
reg [4:0] control_first3;
wire [4:0] control_count4;
wire [31:0] control_record3;
wire [10:0] control_wp_memory3_adr;
wire [31:0] control_wp_memory3_dat_r;
wire control_wp_memory3_we;
wire [31:0] control_wp_memory3_dat_w;
wire [10:0] control_rp_memory3_adr;
wire [31:0] control_rp_memory3_dat_r;
reg control_previous4 = 1'd0;
reg [15:0] control_partial4 = 16'd0;
wire [7:0] control_rising4;
wire [23:0] control_mask4;
reg [4:0] control_first4;
wire [4:0] control_count5;
wire [31:0] control_record4;
wire [10:0] control_wp_memory4_adr;
wire [31:0] control_wp_memory4_dat_r;
wire control_wp_memory4_we;
wire [31:0] control_wp_memory4_dat_w;
wire [10:0] control_rp_memory4_adr;
wire [31:0] control_rp_memory4_dat_r;
reg control_previous5 = 1'd0;
reg [15:0] control_partial5 = 16'd0;
wire [7:0] control_rising5;
wire [23:0] control_mask5;
reg [4:0] control_first5;
wire [4:0] control_count6;
wire [31:0] control_record5;
wire [10:0] control_wp_memory5_adr;
wire [31:0] control_wp_memory5_dat_r;
wire control_wp_memory5_we;
wire [31:0] control_wp_memory5_dat_w;
wire [10:0] control_rp_memory5_adr;
wire [31:0] control_rp_memory5_dat_r;
reg control_previous6 = 1'd0;
reg [15:0] control_partial6 = 16'd0;
wire [7:0] control_rising6;
wire [23:0] control_mask6;
reg [4:0] control_first6;
wire [4:0] control_count7;
wire [31:0] control_record6;
wire [10:0] control_wp_memory6_adr;
wire [31:0] control_wp_memory6_dat_r;
wire control_wp_memory6_we;
wire [31:0] control_wp_memory6_dat_w;
wire [10:0] control_rp_memory6_adr;
wire [31:0] control_rp_memory6_dat_r;
reg control_previous7 = 1'd0;
reg [15:0] control_partial7 = 16'd0;
wire [7:0] control_rising7;
wire [23:0] control_mask7;
reg [4:0] control_first7;
wire [4:0] control_count8;
wire [31:0] control_record7;
wire [10:0] control_wp_memory7_adr;
wire [31:0] control_wp_memory7_dat_r;
wire control_wp_memory7_we;
wire [31:0] control_wp_memory7_dat_w;
wire [10:0] control_rp_memory7_adr;
wire [31:0] control_rp_memory7_dat_r;
reg control_previous8 = 1'd0;
reg [15:0] control_partial8 = 16'd0;
wire [7:0] control_rising8;
wire [23:0] control_mask8;
reg [4:0] control_first8;
wire [4:0] control_count9;
wire [31:0] control_record8;
wire [10:0] control_wp_memory8_adr;
wire [31:0] control_wp_memory8_dat_r;
wire control_wp_memory8_we;
wire [31:0] control_wp_memory8_dat_w;
wire [10:0] control_rp_memory8_adr;
wire [31:0] control_rp_memory8_dat_r;
reg control_previous9 = 1'd0;
reg [15:0] control_partial9 = 16'd0;
wire [7:0] control_rising9;
wire [23:0] control_mask9;
reg [4:0] control_first9;
wire [4:0] control_count10;
wire [31:0] control_record9;
wire [10:0] control_wp_memory9_adr;
wire [31:0] control_wp_memory9_dat_r;
wire control_wp_memory9_we;
wire [31:0] control_wp_memory9_dat_w;
wire [10:0] control_rp_memory9_adr;
wire [31:0] control_rp_memory9_dat_r;
reg control_previous10 = 1'd0;
reg [15:0] control_partial10 = 16'd0;
wire [7:0] control_rising10;
wire [23:0] control_mask10;
reg [4:0] control_first10;
wire [4:0] control_count11;
wire [31:0] control_record10;
wire [10:0] control_wp_memory10_adr;
wire [31:0] control_wp_memory10_dat_r;
wire control_wp_memory10_we;
wire [31:0] control_wp_memory10_dat_w;
wire [10:0] control_rp_memory10_adr;
wire [31:0] control_rp_memory10_dat_r;
reg control_previous11 = 1'd0;
reg [15:0] control_partial11 = 16'd0;
wire [7:0] control_rising11;
wire [23:0] control_mask11;
reg [4:0] control_first11;
wire [4:0] control_count12;
wire [31:0] control_record11;
wire [10:0] control_wp_memory11_adr;
wire [31:0] control_wp_memory11_dat_r;
wire control_wp_memory11_we;
wire [31:0] control_wp_memory11_dat_w;
wire [10:0] control_rp_memory11_adr;
wire [31:0] control_rp_memory11_dat_r;
reg control_previous12 = 1'd0;
reg [15:0] control_partial12 = 16'd0;
wire [7:0] control_rising12;
wire [23:0] control_mask12;
reg [4:0] control_first12;
wire [4:0] control_count13;
wire [31:0] control_record12;
wire [10:0] control_wp_memory12_adr;
wire [31:0] control_wp_memory12_dat_r;
wire control_wp_memory12_we;
wire [31:0] control_wp_memory12_dat_w;
wire [10:0] control_rp_memory12_adr;
wire [31:0] control_rp_memory12_dat_r;
reg control_previous13 = 1'd0;
reg [15:0] control_partial13 = 16'd0;
wire [7:0] control_rising13;
wire [23:0] control_mask13;
reg [4:0] control_first13;
wire [4:0] control_count14;
wire [31:0] control_record13;
wire [10:0] control_wp_memory13_adr;
wire [31:0] control_wp_memory13_dat_r;
wire control_wp_memory13_we;
wire [31:0] control_wp_memory13_dat_w;
wire [10:0] control_rp_memory13_adr;
wire [31:0] control_rp_memory13_dat_r;
reg control_previous14 = 1'd0;
reg [15:0] control_partial14 = 16'd0;
wire [7:0] control_rising14;
wire [23:0] control_mask14;
reg [4:0] control_first14;
wire [4:0] control_count15;
wire [31:0] control_record14;
wire [10:0] control_wp_memory14_adr;
wire [31:0] control_wp_memory14_dat_r;
wire control_wp_memory14_we;
wire [31:0] control_wp_memory14_dat_w;
wire [10:0] control_rp_memory14_adr;
wire [31:0] control_rp_memory14_dat_r;
reg control_previous15 = 1'd0;
reg [15:0] control_partial15 = 16'd0;
wire [7:0] control_rising15;
wire [23:0] control_mask15;
reg [4:0] control_first15;
wire [4:0] control_count16;
wire [31:0] control_record15;
wire [10:0] control_wp_memory15_adr;
wire [31:0] control_wp_memory15_dat_r;
wire control_wp_memory15_we;
wire [31:0] control_wp_memory15_dat_w;
wire [10:0] control_rp_memory15_adr;
wire [31:0] control_rp_memory15_dat_r;
wire [11:0] control_capture_address;
wire permitted;
reg unsupported = 1'd0;
reg [3:0] selected = 4'd0;
reg [2:0] state = 3'd0;
reg [2:0] next_state;
reg [23:0] bus_timeout_next_value0;
reg bus_timeout_next_value_ce0;
reg [55:0] bus_command_next_value1;
reg bus_command_next_value_ce1;
reg [2:0] bus_rx_index_next_value2;
reg bus_rx_index_next_value_ce2;
reg [47:0] bus_reply_next_value3;
reg bus_reply_next_value_ce3;
reg [2:0] bus_tx_index_next_value4;
reg bus_tx_index_next_value_ce4;
reg [2:0] clockdomainsrenamer0_state = 3'd0;
reg [2:0] clockdomainsrenamer0_next_state;
reg ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value0;
reg ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value_ce0;
reg ethernet_pcstx_ctype_a7_1000basex_clockdomainsrenamer0_next_value1;
reg ethernet_pcstx_ctype_a7_1000basex_clockdomainsrenamer0_next_value_ce1;
reg [2:0] clockdomainsrenamer1_state = 3'd0;
reg [2:0] clockdomainsrenamer1_next_state;
reg ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value;
reg ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value_ce;
reg [7:0] clockdomainsrenamer1_next_value0;
reg clockdomainsrenamer1_next_value_ce0;
reg [7:0] clockdomainsrenamer1_next_value1;
reg clockdomainsrenamer1_next_value_ce1;
reg [2:0] clockdomainsrenamer2_state = 3'd0;
reg [2:0] clockdomainsrenamer2_next_state;
wire s7pll0_reset0;
wire s7pll0_reset1;
wire s7pll0_reset2;
wire s7pll0_reset3;
wire s7pll0_reset4;
wire s7pll0_reset5;
wire s7pll0_reset6;
wire s7pll0_reset7;
wire s7pll0_pll_fb;
wire s7pll1_reset0;
wire s7pll1_reset1;
wire s7pll1_reset2;
wire s7pll1_reset3;
wire s7pll1_reset4;
wire s7pll1_reset5;
wire s7pll1_reset6;
wire s7pll1_reset7;
wire s7pll1_pll_fb;
reg [1:0] gtptxinit_state = 2'd0;
reg [1:0] gtptxinit_next_state;
reg [3:0] gtprxinit_state = 4'd0;
reg [3:0] gtprxinit_next_state;
reg [15:0] ethernet_pma_a7_gtp_basex_rx_init_drpvalue_a7_1000basex_next_value;
reg ethernet_pma_a7_gtp_basex_rx_init_drpvalue_a7_1000basex_next_value_ce;
reg txdatapath_liteethmacpaddinginserter_state = 1'd0;
reg txdatapath_liteethmacpaddinginserter_next_state;
reg [15:0] ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value;
reg ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value_ce;
reg [1:0] txdatapath_bufferizeendpoints_state = 2'd0;
reg [1:0] txdatapath_bufferizeendpoints_next_state;
reg [31:0] ethernet_tx_crc_crc_packet_clockdomainsrenamer_clockdomainsrenamer1_next_value0;
reg ethernet_tx_crc_crc_packet_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce0;
reg ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value1;
reg ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce1;
reg [1:0] txdatapath_liteethmacpreambleinserter_state = 2'd0;
reg [1:0] txdatapath_liteethmacpreambleinserter_next_state;
reg [2:0] ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value;
reg ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value_ce;
reg txdatapath_liteethmacgap_state = 1'd0;
reg txdatapath_liteethmacgap_next_state;
reg [3:0] ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value;
reg ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value_ce;
reg rxdatapath_liteethmacpreamblechecker_state = 1'd0;
reg rxdatapath_liteethmacpreamblechecker_next_state;
reg [1:0] rxdatapath_bufferizeendpoints_state = 2'd0;
reg [1:0] rxdatapath_bufferizeendpoints_next_state;
reg ethernet_liteethmaccrc32checker_be_clockdomainsrenamer_next_value0;
reg ethernet_liteethmaccrc32checker_be_clockdomainsrenamer_next_value_ce0;
reg ethernet_liteethmaccrc32checker_last_error_clockdomainsrenamer_next_value1;
reg ethernet_liteethmaccrc32checker_last_error_clockdomainsrenamer_next_value_ce1;
wire [39:0] slice_proxy;
reg [10:0] self0;
reg [12:0] self1;
reg [7:0] self2;
reg [12:0] self3;
reg [31:0] self4;
reg [31:0] self5;
reg self6;
reg [31:0] self7;
reg [2:0] t_self0;
reg [2:0] t_self1;
reg [2:0] f_self;
reg [5:0] rhs_self0;
reg rhs_self1;
reg rhs_self2;
reg [3:0] rhs_self3;
reg rhs_self4;
reg rhs_self5;
wire xilinxasyncresetsynchronizerimpl0_async_reset;
wire xilinxasyncresetsynchronizerimpl0_rst_meta;
wire xilinxasyncresetsynchronizerimpl1_async_reset;
wire xilinxasyncresetsynchronizerimpl1_rst_meta;
wire xilinxasyncresetsynchronizerimpl2_async_reset;
wire xilinxasyncresetsynchronizerimpl2_rst_meta;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl00 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl01 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl10 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl11 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl20 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl21 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl30 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl31 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl40 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl41 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl50 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl51 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl60 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl61 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl70 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl71 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl80 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl81 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl90 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl91 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl100 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl101 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl110 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl111 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl120 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl121 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl130 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl131 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl140 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl141 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl150 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl151 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl160 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl161 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl170 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl171 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl180 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl181 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl190 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl191 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl200 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl201 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl210 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl211 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl220 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl221 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl230 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl231 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl240 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl241 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl250 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl251 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl260 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl261 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl270 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl271 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl280 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl281 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl290 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl291 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl300 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl301 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl310 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl311 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl320 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl321 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl330 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl331 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl340 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl341 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl350 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl351 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl360 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl361 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl370 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl371 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl380 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl381 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl390 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl391 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl400 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl401 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl410 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl411 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl420 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl421 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl430 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl431 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl440 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl441 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl450 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl451 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl460 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl461 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl470 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl471 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl480 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl481 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl490 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl491 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl500 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl501 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl510 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl511 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl520 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl521 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl530 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl531 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl540 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl541 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl550 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl551 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl560 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl561 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl570 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl571 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl580 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl581 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl590 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl591 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl600 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl601 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl610 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl611 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl620 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl621 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl630 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl631 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl640 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl641 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl650 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl651 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl660 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl661 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl670 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl671 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl680 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl681 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl690 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl691 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl700 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl701 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl710 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl711 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl720 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl721 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl730 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl731 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl740 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl741 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl750 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl751 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl760 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl761 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl770 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl771 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl780 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl781 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl790 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl791 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl800 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl801 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl810 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl811 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl820 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl821 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl830 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl831 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl840 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl841 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl850 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl851 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl860 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl861 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl870 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl871 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl880 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl881 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl890 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl891 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl900 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl901 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl910 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl911 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl920 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl921 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl930 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl931 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl940 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl941 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl950 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl951 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl960 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl961 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl970 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl971 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl980 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl981 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl990 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl991 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1000 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1001 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl1010 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl1011 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1020 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1021 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1030 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1031 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1040 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1041 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1050 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1051 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1060 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1061 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1070 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1071 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1080 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1081 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl1090 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl1091 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1100 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1101 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1110 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1111 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1120 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1121 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1130 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1131 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1140 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1141 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1150 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1151 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1160 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1161 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl1170 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl1171 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1180 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1181 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1190 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1191 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1200 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1201 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1210 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1211 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1220 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1221 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1230 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1231 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1240 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1241 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl1250 = 64'd0;
(* async_reg = "true", dont_touch = "true" *) reg [63:0] xilinxmultiregimpl1251 = 64'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1260 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1261 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1270 = 13'd0;
(* async_reg = "true", dont_touch = "true" *) reg [12:0] xilinxmultiregimpl1271 = 13'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1280 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1281 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1290 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1291 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1300 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1301 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1310 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1311 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [15:0] xilinxmultiregimpl1320 = 16'd0;
(* async_reg = "true", dont_touch = "true" *) reg [15:0] xilinxmultiregimpl1321 = 16'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1330 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1331 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1340 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1341 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1350 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1351 = 1'd0;
wire xilinxasyncresetsynchronizerimpl3_async_reset;
wire xilinxasyncresetsynchronizerimpl3_rst_meta;
wire xilinxasyncresetsynchronizerimpl4_async_reset;
wire xilinxasyncresetsynchronizerimpl4_rst_meta;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1360 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1361 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1370 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1371 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1380 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1381 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [5:0] xilinxmultiregimpl1390 = 6'd0;
(* async_reg = "true", dont_touch = "true" *) reg [5:0] xilinxmultiregimpl1391 = 6'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [5:0] xilinxmultiregimpl1400 = 6'd0;
(* async_reg = "true", dont_touch = "true" *) reg [5:0] xilinxmultiregimpl1401 = 6'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1410 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1411 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [5:0] xilinxmultiregimpl1420 = 6'd0;
(* async_reg = "true", dont_touch = "true" *) reg [5:0] xilinxmultiregimpl1421 = 6'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg [5:0] xilinxmultiregimpl1430 = 6'd0;
(* async_reg = "true", dont_touch = "true" *) reg [5:0] xilinxmultiregimpl1431 = 6'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1440 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1441 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1450 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1451 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1460 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1461 = 1'd0;
(* async_reg = "true", mr_ff = "true", dont_touch = "true" *) reg xilinxmultiregimpl1470 = 1'd0;
(* async_reg = "true", dont_touch = "true" *) reg xilinxmultiregimpl1471 = 1'd0;

// synthesis translate_off
reg dummy_s;
initial dummy_s <= 1'd0;
// synthesis translate_on

assign ready = (locked0 & rx_lock);
assign bank_windowcapture0_data = word2;
assign bank_windowcapture1_data = word3;
assign bank_windowcapture2_data = word4;
assign bank_windowcapture3_data = word5;
assign bank_windowcapture4_data = word6;
assign bank_windowcapture5_data = word7;
assign bank_windowcapture6_data = word8;
assign bank_windowcapture7_data = word9;
assign bank_windowcapture8_data = word10;
assign bank_windowcapture9_data = word11;
assign bank_windowcapture10_data = word12;
assign bank_windowcapture11_data = word13;
assign bank_windowcapture12_data = word14;
assign bank_windowcapture13_data = word15;
assign bank_windowcapture14_data = word16;
assign bank_windowcapture15_data = word17;
assign permitted = ((((((((ipbus_bridge_control_address == 4'd8) | (ipbus_bridge_control_address == 5'd16)) & (ipbus_bridge_control_write_data == 1'd0)) | (ipbus_bridge_control_address == 5'd20)) | (ipbus_bridge_control_address == 5'd28)) | (ipbus_bridge_control_address == 6'd32)) | (ipbus_bridge_control_address == 7'd112)) | ((((ipbus_bridge_control_address == 5'd24) | (ipbus_bridge_control_address == 8'd132)) | (ipbus_bridge_control_address == 8'd136)) & (ipbus_bridge_control_write_data == 1'd1)));
assign local_address = ipbus_bridge_control_address;
assign local_write_data = ipbus_bridge_control_write_data;
assign local_write = (ipbus_bridge_control_write & permitted);

// synthesis translate_off
reg dummy_d;
// synthesis translate_on
always @(*) begin
	ipbus_bridge_control_read_data <= 32'd0;
	ipbus_bridge_control_read_data <= local_read_data;
	case (ipbus_bridge_control_address)
		1'd0: begin
			ipbus_bridge_control_read_data <= 31'd1380993073;
		end
		4'd12: begin
			ipbus_bridge_control_read_data <= (local_read_data | (unsupported <<< 3'd4));
		end
		8'd192: begin
			ipbus_bridge_control_read_data <= 7'd96;
		end
		8'd196: begin
			ipbus_bridge_control_read_data <= 16'd43690;
		end
		8'd200: begin
			ipbus_bridge_control_read_data <= 2'd2;
		end
		8'd204: begin
			ipbus_bridge_control_read_data <= self0;
		end
	endcase
	if ((ipbus_bridge_control_address == 8'd208)) begin
		ipbus_bridge_control_read_data <= 31'd1229996594;
	end
	if ((ipbus_bridge_control_address == 8'd212)) begin
		ipbus_bridge_control_read_data <= {ethernet_got_ip, ethernet_link};
	end
// synthesis translate_off
	dummy_d <= dummy_s;
// synthesis translate_on
end
assign bank_windowcapture0_arm = bank_arm;
assign bank_windowcapture0_request_length = bank_length;
assign bank_windowcapture0_rx_ready = bank_ready;
assign bank_windowcapture0_read_address = bank_address;
assign bank_windowcapture1_arm = bank_arm;
assign bank_windowcapture1_request_length = bank_length;
assign bank_windowcapture1_rx_ready = bank_ready;
assign bank_windowcapture1_read_address = bank_address;
assign bank_windowcapture2_arm = bank_arm;
assign bank_windowcapture2_request_length = bank_length;
assign bank_windowcapture2_rx_ready = bank_ready;
assign bank_windowcapture2_read_address = bank_address;
assign bank_windowcapture3_arm = bank_arm;
assign bank_windowcapture3_request_length = bank_length;
assign bank_windowcapture3_rx_ready = bank_ready;
assign bank_windowcapture3_read_address = bank_address;
assign bank_windowcapture4_arm = bank_arm;
assign bank_windowcapture4_request_length = bank_length;
assign bank_windowcapture4_rx_ready = bank_ready;
assign bank_windowcapture4_read_address = bank_address;
assign bank_windowcapture5_arm = bank_arm;
assign bank_windowcapture5_request_length = bank_length;
assign bank_windowcapture5_rx_ready = bank_ready;
assign bank_windowcapture5_read_address = bank_address;
assign bank_windowcapture6_arm = bank_arm;
assign bank_windowcapture6_request_length = bank_length;
assign bank_windowcapture6_rx_ready = bank_ready;
assign bank_windowcapture6_read_address = bank_address;
assign bank_windowcapture7_arm = bank_arm;
assign bank_windowcapture7_request_length = bank_length;
assign bank_windowcapture7_rx_ready = bank_ready;
assign bank_windowcapture7_read_address = bank_address;
assign bank_windowcapture8_arm = bank_arm;
assign bank_windowcapture8_request_length = bank_length;
assign bank_windowcapture8_rx_ready = bank_ready;
assign bank_windowcapture8_read_address = bank_address;
assign bank_windowcapture9_arm = bank_arm;
assign bank_windowcapture9_request_length = bank_length;
assign bank_windowcapture9_rx_ready = bank_ready;
assign bank_windowcapture9_read_address = bank_address;
assign bank_windowcapture10_arm = bank_arm;
assign bank_windowcapture10_request_length = bank_length;
assign bank_windowcapture10_rx_ready = bank_ready;
assign bank_windowcapture10_read_address = bank_address;
assign bank_windowcapture11_arm = bank_arm;
assign bank_windowcapture11_request_length = bank_length;
assign bank_windowcapture11_rx_ready = bank_ready;
assign bank_windowcapture11_read_address = bank_address;
assign bank_windowcapture12_arm = bank_arm;
assign bank_windowcapture12_request_length = bank_length;
assign bank_windowcapture12_rx_ready = bank_ready;
assign bank_windowcapture12_read_address = bank_address;
assign bank_windowcapture13_arm = bank_arm;
assign bank_windowcapture13_request_length = bank_length;
assign bank_windowcapture13_rx_ready = bank_ready;
assign bank_windowcapture13_read_address = bank_address;
assign bank_windowcapture14_arm = bank_arm;
assign bank_windowcapture14_request_length = bank_length;
assign bank_windowcapture14_rx_ready = bank_ready;
assign bank_windowcapture14_read_address = bank_address;
assign bank_windowcapture15_arm = bank_arm;
assign bank_windowcapture15_request_length = bank_length;
assign bank_windowcapture15_rx_ready = bank_ready;
assign bank_windowcapture15_read_address = bank_address;
assign bank_player_write_port_adr = {bank_player_write_bank, bank_player_write_address};
assign bank_player_write_port_dat_w = bank_player_write_data;
assign bank_player_write_port_we = ((bank_player_write & (bank_player_write_bank != bank_player_active_bank)) & (~bank_player_pending));
assign bank_player_next_position = (((bank_player_enable & bank_player_ready) & (~(bank_player_position == (bank_player_length - 1'd1)))) ? (bank_player_position + 1'd1) : 1'd0);
assign bank_player_next_bank = ((bank_player_pending & ((~(bank_player_enable & bank_player_ready)) | (bank_player_position == (bank_player_length - 1'd1)))) ? (~bank_player_active_bank) : bank_player_active_bank);
assign bank_player_read_port_adr = {bank_player_next_bank, bank_player_next_position};
assign bank_player_data = ((bank_player_enable & bank_player_ready) ? bank_player_read_port_dat_r : 1'd0);
assign bank_windowcapture0_wp_adr = bank_windowcapture0_address;
assign bank_windowcapture0_wp_dat_w = bank_windowcapture0_data;
assign bank_windowcapture0_wp_we = (bank_windowcapture0_active & bank_windowcapture0_rx_ready);
assign bank_windowcapture0_rp_adr = bank_windowcapture0_read_address;
assign bank_windowcapture0_read_data = bank_windowcapture0_rp_dat_r;
assign bank_windowcapture1_wp_adr = bank_windowcapture1_address;
assign bank_windowcapture1_wp_dat_w = bank_windowcapture1_data;
assign bank_windowcapture1_wp_we = (bank_windowcapture1_active & bank_windowcapture1_rx_ready);
assign bank_windowcapture1_rp_adr = bank_windowcapture1_read_address;
assign bank_windowcapture1_read_data = bank_windowcapture1_rp_dat_r;
assign bank_windowcapture2_wp_adr = bank_windowcapture2_address;
assign bank_windowcapture2_wp_dat_w = bank_windowcapture2_data;
assign bank_windowcapture2_wp_we = (bank_windowcapture2_active & bank_windowcapture2_rx_ready);
assign bank_windowcapture2_rp_adr = bank_windowcapture2_read_address;
assign bank_windowcapture2_read_data = bank_windowcapture2_rp_dat_r;
assign bank_windowcapture3_wp_adr = bank_windowcapture3_address;
assign bank_windowcapture3_wp_dat_w = bank_windowcapture3_data;
assign bank_windowcapture3_wp_we = (bank_windowcapture3_active & bank_windowcapture3_rx_ready);
assign bank_windowcapture3_rp_adr = bank_windowcapture3_read_address;
assign bank_windowcapture3_read_data = bank_windowcapture3_rp_dat_r;
assign bank_windowcapture4_wp_adr = bank_windowcapture4_address;
assign bank_windowcapture4_wp_dat_w = bank_windowcapture4_data;
assign bank_windowcapture4_wp_we = (bank_windowcapture4_active & bank_windowcapture4_rx_ready);
assign bank_windowcapture4_rp_adr = bank_windowcapture4_read_address;
assign bank_windowcapture4_read_data = bank_windowcapture4_rp_dat_r;
assign bank_windowcapture5_wp_adr = bank_windowcapture5_address;
assign bank_windowcapture5_wp_dat_w = bank_windowcapture5_data;
assign bank_windowcapture5_wp_we = (bank_windowcapture5_active & bank_windowcapture5_rx_ready);
assign bank_windowcapture5_rp_adr = bank_windowcapture5_read_address;
assign bank_windowcapture5_read_data = bank_windowcapture5_rp_dat_r;
assign bank_windowcapture6_wp_adr = bank_windowcapture6_address;
assign bank_windowcapture6_wp_dat_w = bank_windowcapture6_data;
assign bank_windowcapture6_wp_we = (bank_windowcapture6_active & bank_windowcapture6_rx_ready);
assign bank_windowcapture6_rp_adr = bank_windowcapture6_read_address;
assign bank_windowcapture6_read_data = bank_windowcapture6_rp_dat_r;
assign bank_windowcapture7_wp_adr = bank_windowcapture7_address;
assign bank_windowcapture7_wp_dat_w = bank_windowcapture7_data;
assign bank_windowcapture7_wp_we = (bank_windowcapture7_active & bank_windowcapture7_rx_ready);
assign bank_windowcapture7_rp_adr = bank_windowcapture7_read_address;
assign bank_windowcapture7_read_data = bank_windowcapture7_rp_dat_r;
assign bank_windowcapture8_wp_adr = bank_windowcapture8_address;
assign bank_windowcapture8_wp_dat_w = bank_windowcapture8_data;
assign bank_windowcapture8_wp_we = (bank_windowcapture8_active & bank_windowcapture8_rx_ready);
assign bank_windowcapture8_rp_adr = bank_windowcapture8_read_address;
assign bank_windowcapture8_read_data = bank_windowcapture8_rp_dat_r;
assign bank_windowcapture9_wp_adr = bank_windowcapture9_address;
assign bank_windowcapture9_wp_dat_w = bank_windowcapture9_data;
assign bank_windowcapture9_wp_we = (bank_windowcapture9_active & bank_windowcapture9_rx_ready);
assign bank_windowcapture9_rp_adr = bank_windowcapture9_read_address;
assign bank_windowcapture9_read_data = bank_windowcapture9_rp_dat_r;
assign bank_windowcapture10_wp_adr = bank_windowcapture10_address;
assign bank_windowcapture10_wp_dat_w = bank_windowcapture10_data;
assign bank_windowcapture10_wp_we = (bank_windowcapture10_active & bank_windowcapture10_rx_ready);
assign bank_windowcapture10_rp_adr = bank_windowcapture10_read_address;
assign bank_windowcapture10_read_data = bank_windowcapture10_rp_dat_r;
assign bank_windowcapture11_wp_adr = bank_windowcapture11_address;
assign bank_windowcapture11_wp_dat_w = bank_windowcapture11_data;
assign bank_windowcapture11_wp_we = (bank_windowcapture11_active & bank_windowcapture11_rx_ready);
assign bank_windowcapture11_rp_adr = bank_windowcapture11_read_address;
assign bank_windowcapture11_read_data = bank_windowcapture11_rp_dat_r;
assign bank_windowcapture12_wp_adr = bank_windowcapture12_address;
assign bank_windowcapture12_wp_dat_w = bank_windowcapture12_data;
assign bank_windowcapture12_wp_we = (bank_windowcapture12_active & bank_windowcapture12_rx_ready);
assign bank_windowcapture12_rp_adr = bank_windowcapture12_read_address;
assign bank_windowcapture12_read_data = bank_windowcapture12_rp_dat_r;
assign bank_windowcapture13_wp_adr = bank_windowcapture13_address;
assign bank_windowcapture13_wp_dat_w = bank_windowcapture13_data;
assign bank_windowcapture13_wp_we = (bank_windowcapture13_active & bank_windowcapture13_rx_ready);
assign bank_windowcapture13_rp_adr = bank_windowcapture13_read_address;
assign bank_windowcapture13_read_data = bank_windowcapture13_rp_dat_r;
assign bank_windowcapture14_wp_adr = bank_windowcapture14_address;
assign bank_windowcapture14_wp_dat_w = bank_windowcapture14_data;
assign bank_windowcapture14_wp_we = (bank_windowcapture14_active & bank_windowcapture14_rx_ready);
assign bank_windowcapture14_rp_adr = bank_windowcapture14_read_address;
assign bank_windowcapture14_read_data = bank_windowcapture14_rp_dat_r;
assign bank_windowcapture15_wp_adr = bank_windowcapture15_address;
assign bank_windowcapture15_wp_dat_w = bank_windowcapture15_data;
assign bank_windowcapture15_wp_we = (bank_windowcapture15_active & bank_windowcapture15_rx_ready);
assign bank_windowcapture15_rp_adr = bank_windowcapture15_read_address;
assign bank_windowcapture15_read_data = bank_windowcapture15_rp_dat_r;
assign bus_address = bus_command[23:8];
assign bus_write_data = bus_command[55:24];
assign uart_sink_payload_data = bus_reply[7:0];

// synthesis translate_off
reg dummy_d_1;
// synthesis translate_on
always @(*) begin
	uart_sink_stb <= 1'd0;
	uart_source_ack <= 1'd0;
	bus_read <= 1'd0;
	bus_write <= 1'd0;
	next_state <= 3'd0;
	bus_timeout_next_value0 <= 24'd0;
	bus_timeout_next_value_ce0 <= 1'd0;
	bus_command_next_value1 <= 56'd0;
	bus_command_next_value_ce1 <= 1'd0;
	bus_rx_index_next_value2 <= 3'd0;
	bus_rx_index_next_value_ce2 <= 1'd0;
	bus_reply_next_value3 <= 48'd0;
	bus_reply_next_value_ce3 <= 1'd0;
	bus_tx_index_next_value4 <= 3'd0;
	bus_tx_index_next_value_ce4 <= 1'd0;
	next_state <= state;
	case (state)
		1'd1: begin
			bus_read <= (bus_command[7:0] == 1'd0);
			bus_write <= (bus_command[7:0] == 1'd1);
			next_state <= 2'd2;
		end
		2'd2: begin
			next_state <= 2'd3;
		end
		2'd3: begin
			bus_reply_next_value3 <= {bus_read_data, bus_address};
			bus_reply_next_value_ce3 <= 1'd1;
			bus_tx_index_next_value4 <= 1'd0;
			bus_tx_index_next_value_ce4 <= 1'd1;
			next_state <= 3'd4;
		end
		3'd4: begin
			uart_sink_stb <= 1'd1;
			if (uart_sink_ack) begin
				bus_reply_next_value3 <= (bus_reply >>> 4'd8);
				bus_reply_next_value_ce3 <= 1'd1;
				if ((bus_tx_index == 3'd5)) begin
					next_state <= 1'd0;
				end else begin
					bus_tx_index_next_value4 <= (bus_tx_index + 1'd1);
					bus_tx_index_next_value_ce4 <= 1'd1;
				end
			end
		end
		default: begin
			uart_source_ack <= 1'd1;
			if (uart_source_stb) begin
				bus_timeout_next_value0 <= 1'd0;
				bus_timeout_next_value_ce0 <= 1'd1;
				bus_command_next_value1 <= {uart_source_payload_data, bus_command[55:8]};
				bus_command_next_value_ce1 <= 1'd1;
				if ((bus_rx_index == 3'd6)) begin
					bus_rx_index_next_value2 <= 1'd0;
					bus_rx_index_next_value_ce2 <= 1'd1;
					next_state <= 1'd1;
				end else begin
					bus_rx_index_next_value2 <= (bus_rx_index + 1'd1);
					bus_rx_index_next_value_ce2 <= 1'd1;
				end
			end else begin
				if ((bus_rx_index != 1'd0)) begin
					bus_timeout_next_value0 <= (bus_timeout + 1'd1);
					bus_timeout_next_value_ce0 <= 1'd1;
					if ((bus_timeout == 24'd16777215)) begin
						bus_rx_index_next_value2 <= 1'd0;
						bus_rx_index_next_value_ce2 <= 1'd1;
						bus_timeout_next_value0 <= 1'd0;
						bus_timeout_next_value_ce0 <= 1'd1;
					end
				end
			end
		end
	endcase
// synthesis translate_off
	dummy_d_1 <= dummy_s;
// synthesis translate_on
end
assign ipbus_bridge_available = ((~(bus_read | bus_write)) & (ipbus_bridge_hold == 1'd0));
assign ipbus_bridge_memory = (ipbus_bridge_raw | ipbus_bridge_phase);
assign ipbus_bridge_raw = (ipbus_bridge_address1[31:16] == 1'd1);
assign ipbus_bridge_phase = (ipbus_bridge_address1[31:16] == 2'd2);
assign ipbus_bridge_lane = ipbus_bridge_address1[15:12];
assign ipbus_bridge_index = ipbus_bridge_address1[11:0];
assign bus_read_data = ipbus_bridge_control_read_data;
assign ipbus_bridge_ack = ((ipbus_bridge_state == 3'd7) & ipbus_bridge_strobe);
assign ipbus_bridge_err = ((ipbus_bridge_state == 4'd8) & ipbus_bridge_strobe);
assign ipbus_bridge_level = (ipbus_bridge_available & ((((ipbus_bridge_state == 1'd1) | (ipbus_bridge_state == 2'd2)) & ipbus_bridge_memory) | (((ipbus_bridge_state == 2'd3) & (~ipbus_bridge_memory)) & ipbus_bridge_writing)));

// synthesis translate_off
reg dummy_d_2;
// synthesis translate_on
always @(*) begin
	ipbus_bridge_control_address <= 16'd0;
	ipbus_bridge_control_write_data <= 32'd0;
	ipbus_bridge_control_write <= 1'd0;
	ipbus_bridge_control_address <= bus_address;
	ipbus_bridge_control_write_data <= bus_write_data;
	ipbus_bridge_control_write <= bus_write;
	if (ipbus_bridge_available) begin
		if (((ipbus_bridge_state >= 1'd1) & (ipbus_bridge_state <= 3'd6))) begin
			ipbus_bridge_control_write <= 1'd0;
			ipbus_bridge_control_write_data <= ipbus_bridge_data;
			ipbus_bridge_control_address <= (ipbus_bridge_address1[13:0] <<< 2'd2);
			if (ipbus_bridge_memory) begin
				ipbus_bridge_control_address <= (ipbus_bridge_phase ? 8'd188 : 7'd80);
				if ((ipbus_bridge_state == 1'd1)) begin
					ipbus_bridge_control_address <= 5'd28;
					ipbus_bridge_control_write_data <= ipbus_bridge_lane;
					ipbus_bridge_control_write <= 1'd1;
				end
				if ((ipbus_bridge_state == 2'd2)) begin
					ipbus_bridge_control_address <= 6'd32;
					ipbus_bridge_control_write_data <= ipbus_bridge_index;
					ipbus_bridge_control_write <= 1'd1;
				end
			end else begin
				if ((ipbus_bridge_state == 2'd3)) begin
					ipbus_bridge_control_write <= ipbus_bridge_writing;
				end
			end
		end
	end
	if (((ipbus_bridge_available & (ipbus_bridge_state >= 1'd1)) & (ipbus_bridge_state <= 3'd6))) begin
		ipbus_bridge_control_write <= (ipbus_bridge_level & ((ipbus_bridge_state != ipbus_bridge_previous_state) | (~ipbus_bridge_previous_write)));
	end
// synthesis translate_off
	dummy_d_2 <= dummy_s;
// synthesis translate_on
end
assign ethernet_source_ready = 1'd1;
assign ethernet_sink_first = ethernet_first;
assign ethernet_sink_payload_be = 1'd1;
assign ethernet_pma_a7_gtp_basex_tx_data1 = ethernet_pcstx_encoder2;
assign ethernet_pcsrx_decoder_input = ethernet_pma_a7_gtp_basex_rx_data1;
assign ethernet_pcsrx_decoder_ce = ethernet_pma_a7_gtp_basex_rx_valid;
assign ethernet_pma_a7_gtp_basex_align = ethernet_align;
assign ethernet_pma_a7_gtp_basex_restart = ethernet_restart;
assign ethernet_source_source_payload_be = 1'd1;
assign ethernet_pcstx_sink_valid = ethernet_sink_sink_valid;
assign ethernet_sink_sink_ready = ethernet_pcstx_sink_ready;
assign ethernet_pcstx_sink_first = ethernet_sink_sink_first;
assign ethernet_pcstx_sink_last = ethernet_sink_sink_last;
assign ethernet_pcstx_sink_payload_data = ethernet_sink_sink_payload_data;
assign ethernet_source_source_valid = ethernet_pcsrx_source_valid;
assign ethernet_pcsrx_source_ready = ethernet_source_source_ready;
assign ethernet_source_source_first = ethernet_pcsrx_source_first;
assign ethernet_source_source_last = ethernet_pcsrx_source_last;
assign ethernet_source_source_payload_data = ethernet_pcsrx_source_payload_data;
assign ethernet_source_source_payload_error = ethernet_pcsrx_source_payload_error;
assign ethernet_seen_valid_ci_i = ethernet_pcsrx_seen_valid_ci;
assign ethernet_is_sgmii = ethernet_lp_abi_o[0];
assign ethernet_sgmii_speed_valid = ((ethernet_lp_abi_o[11:10] != 2'd3) & (ethernet_lp_abi_o != 1'd0));
assign ethernet_sgmii_tx_speed = (ethernet_sgmii_speed_valid ? ethernet_lp_abi_o[11:10] : 2'd2);
assign ethernet_sgmii_rx_speed = (((ethernet_lp_abi_i[11:10] != 2'd3) & (ethernet_lp_abi_i != 1'd0)) ? ethernet_lp_abi_i[11:10] : 2'd2);

// synthesis translate_off
reg dummy_d_3;
// synthesis translate_on
always @(*) begin
	ethernet_pcstx_sgmii_speed <= 2'd0;
	ethernet_pcsrx_sgmii_speed <= 2'd0;
	ethernet_linkdown <= 1'd0;
	if ((~ethernet_is_sgmii)) begin
		ethernet_linkdown <= (ethernet_lp_abi_o == 1'd0);
		ethernet_pcstx_sgmii_speed <= 2'd2;
		ethernet_pcsrx_sgmii_speed <= 2'd2;
	end else begin
		ethernet_linkdown <= ((~ethernet_lp_abi_o[15]) | (~ethernet_sgmii_speed_valid));
		ethernet_pcstx_sgmii_speed <= ethernet_sgmii_tx_speed;
		ethernet_pcsrx_sgmii_speed <= ethernet_sgmii_rx_speed;
	end
// synthesis translate_off
	dummy_d_3 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_4;
// synthesis translate_on
always @(*) begin
	ethernet_pcstx_config_reg <= 16'd0;
	if ((~ethernet_config_empty)) begin
		ethernet_pcstx_config_reg[0] <= ethernet_is_sgmii;
		ethernet_pcstx_config_reg[5] <= (~ethernet_is_sgmii);
		if (ethernet_is_sgmii) begin
			ethernet_pcstx_config_reg[11:10] <= ethernet_sgmii_tx_speed;
			ethernet_pcstx_config_reg[12] <= 1'd1;
			ethernet_pcstx_config_reg[15] <= ethernet_link_up;
		end
		ethernet_pcstx_config_reg[14] <= ethernet_autoneg_ack;
	end
// synthesis translate_off
	dummy_d_4 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pcstx_encoder_ce1 = ethernet_pcstx_encoder_ce0;
assign ethernet_pcstx_encoder_d = ethernet_pcstx_encoder0;
assign ethernet_pcstx_encoder_k = ethernet_pcstx_encoder1;
assign ethernet_pcstx_encoder_disp_inter = (ethernet_pcstx_encoder_disp_in ^ ethernet_pcstx_encoder_code6b_unbalanced);

// synthesis translate_off
reg dummy_d_5;
// synthesis translate_on
always @(*) begin
	ethernet_pcstx_encoder_output_6b <= 6'd0;
	if (((~ethernet_pcstx_encoder_disp_in) & ethernet_pcstx_encoder_code6b_flip)) begin
		ethernet_pcstx_encoder_output_6b <= (~ethernet_pcstx_encoder_code6b);
	end else begin
		ethernet_pcstx_encoder_output_6b <= ethernet_pcstx_encoder_code6b;
	end
// synthesis translate_off
	dummy_d_5 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_6;
// synthesis translate_on
always @(*) begin
	ethernet_pcstx_encoder_disp_out <= 1'd0;
	ethernet_pcstx_encoder_output_4b <= 4'd0;
	if (((~ethernet_pcstx_encoder_disp_inter) & ethernet_pcstx_encoder_alt7_rd0)) begin
		ethernet_pcstx_encoder_disp_out <= (~ethernet_pcstx_encoder_disp_inter);
		ethernet_pcstx_encoder_output_4b <= 3'd7;
	end else begin
		if ((ethernet_pcstx_encoder_disp_inter & ethernet_pcstx_encoder_alt7_rd1)) begin
			ethernet_pcstx_encoder_disp_out <= (~ethernet_pcstx_encoder_disp_inter);
			ethernet_pcstx_encoder_output_4b <= 4'd8;
		end else begin
			ethernet_pcstx_encoder_disp_out <= (ethernet_pcstx_encoder_disp_inter ^ ethernet_pcstx_encoder_code4b_unbalanced);
			if (((~ethernet_pcstx_encoder_disp_inter) & ethernet_pcstx_encoder_code4b_flip)) begin
				ethernet_pcstx_encoder_output_4b <= (~ethernet_pcstx_encoder_code4b);
			end else begin
				ethernet_pcstx_encoder_output_4b <= ethernet_pcstx_encoder_code4b;
			end
		end
	end
// synthesis translate_off
	dummy_d_6 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pcstx_encoder_output_msb_first = {ethernet_pcstx_encoder_output_6b, ethernet_pcstx_encoder_output_4b};

// synthesis translate_off
reg dummy_d_7;
// synthesis translate_on
always @(*) begin
	ethernet_pcstx_encoder_output <= 10'd0;
	ethernet_pcstx_encoder_output[0] <= ethernet_pcstx_encoder_output_msb_first[9];
	ethernet_pcstx_encoder_output[1] <= ethernet_pcstx_encoder_output_msb_first[8];
	ethernet_pcstx_encoder_output[2] <= ethernet_pcstx_encoder_output_msb_first[7];
	ethernet_pcstx_encoder_output[3] <= ethernet_pcstx_encoder_output_msb_first[6];
	ethernet_pcstx_encoder_output[4] <= ethernet_pcstx_encoder_output_msb_first[5];
	ethernet_pcstx_encoder_output[5] <= ethernet_pcstx_encoder_output_msb_first[4];
	ethernet_pcstx_encoder_output[6] <= ethernet_pcstx_encoder_output_msb_first[3];
	ethernet_pcstx_encoder_output[7] <= ethernet_pcstx_encoder_output_msb_first[2];
	ethernet_pcstx_encoder_output[8] <= ethernet_pcstx_encoder_output_msb_first[1];
	ethernet_pcstx_encoder_output[9] <= ethernet_pcstx_encoder_output_msb_first[0];
// synthesis translate_off
	dummy_d_7 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pcstx_done = (ethernet_pcstx_count1 == 1'd0);

// synthesis translate_off
reg dummy_d_8;
// synthesis translate_on
always @(*) begin
	ethernet_pcstx_sink_ready <= 1'd0;
	ethernet_pcstx_encoder0 <= 8'd0;
	ethernet_pcstx_encoder1 <= 1'd0;
	ethernet_pcstx_enable <= 1'd0;
	clockdomainsrenamer0_next_state <= 3'd0;
	ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value0 <= 1'd0;
	ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value_ce0 <= 1'd0;
	ethernet_pcstx_ctype_a7_1000basex_clockdomainsrenamer0_next_value1 <= 1'd0;
	ethernet_pcstx_ctype_a7_1000basex_clockdomainsrenamer0_next_value_ce1 <= 1'd0;
	clockdomainsrenamer0_next_state <= clockdomainsrenamer0_state;
	case (clockdomainsrenamer0_state)
		1'd1: begin
			case (ethernet_pcstx_ctype)
				1'd0: begin
					ethernet_pcstx_encoder0 <= 8'd181;
				end
				1'd1: begin
					ethernet_pcstx_encoder0 <= 7'd66;
				end
			endcase
			ethernet_pcstx_ctype_a7_1000basex_clockdomainsrenamer0_next_value1 <= (~ethernet_pcstx_ctype);
			ethernet_pcstx_ctype_a7_1000basex_clockdomainsrenamer0_next_value_ce1 <= 1'd1;
			clockdomainsrenamer0_next_state <= 2'd2;
		end
		2'd2: begin
			ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value0 <= (ethernet_pcstx_count0 + 1'd1);
			ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value_ce0 <= 1'd1;
			case (ethernet_pcstx_count0)
				1'd0: begin
					ethernet_pcstx_encoder0 <= ethernet_pcstx_config_reg[7:0];
				end
				1'd1: begin
					ethernet_pcstx_encoder0 <= ethernet_pcstx_config_reg[15:8];
				end
			endcase
			if ((ethernet_pcstx_count0 == 1'd1)) begin
				clockdomainsrenamer0_next_state <= 1'd0;
			end
		end
		2'd3: begin
			case (ethernet_pcstx_encoder3)
				1'd0: begin
					ethernet_pcstx_encoder0 <= 8'd197;
				end
				1'd1: begin
					ethernet_pcstx_encoder0 <= 7'd80;
				end
			endcase
			clockdomainsrenamer0_next_state <= 1'd0;
		end
		3'd4: begin
			ethernet_pcstx_enable <= 1'd1;
			ethernet_pcstx_sink_ready <= ethernet_pcstx_done;
			if (ethernet_pcstx_sink_valid) begin
				ethernet_pcstx_encoder0 <= ethernet_pcstx_sink_payload_data;
			end else begin
				ethernet_pcstx_encoder1 <= 1'd1;
				ethernet_pcstx_encoder0 <= 8'd253;
				clockdomainsrenamer0_next_state <= 3'd5;
			end
		end
		3'd5: begin
			ethernet_pcstx_encoder1 <= 1'd1;
			ethernet_pcstx_encoder0 <= 8'd247;
			if (ethernet_pcstx_parity) begin
				clockdomainsrenamer0_next_state <= 1'd0;
			end
		end
		default: begin
			ethernet_pcstx_encoder1 <= 1'd1;
			ethernet_pcstx_encoder0 <= 8'd188;
			if (ethernet_pcstx_config_valid) begin
				ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value0 <= 1'd0;
				ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value_ce0 <= 1'd1;
				clockdomainsrenamer0_next_state <= 1'd1;
			end else begin
				if (ethernet_pcstx_sink_valid) begin
					ethernet_pcstx_sink_ready <= ethernet_pcstx_done;
					ethernet_pcstx_encoder0 <= 8'd251;
					clockdomainsrenamer0_next_state <= 3'd4;
				end else begin
					clockdomainsrenamer0_next_state <= 2'd3;
				end
			end
		end
	endcase
// synthesis translate_off
	dummy_d_8 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pcsrx_timer_ce = ethernet_pcsrx_decoder_ce;

// synthesis translate_off
reg dummy_d_9;
// synthesis translate_on
always @(*) begin
	ethernet_pcsrx_decoder_input_msb_first <= 10'd0;
	ethernet_pcsrx_decoder_input_msb_first[0] <= ethernet_pcsrx_decoder_input[9];
	ethernet_pcsrx_decoder_input_msb_first[1] <= ethernet_pcsrx_decoder_input[8];
	ethernet_pcsrx_decoder_input_msb_first[2] <= ethernet_pcsrx_decoder_input[7];
	ethernet_pcsrx_decoder_input_msb_first[3] <= ethernet_pcsrx_decoder_input[6];
	ethernet_pcsrx_decoder_input_msb_first[4] <= ethernet_pcsrx_decoder_input[5];
	ethernet_pcsrx_decoder_input_msb_first[5] <= ethernet_pcsrx_decoder_input[4];
	ethernet_pcsrx_decoder_input_msb_first[6] <= ethernet_pcsrx_decoder_input[3];
	ethernet_pcsrx_decoder_input_msb_first[7] <= ethernet_pcsrx_decoder_input[2];
	ethernet_pcsrx_decoder_input_msb_first[8] <= ethernet_pcsrx_decoder_input[1];
	ethernet_pcsrx_decoder_input_msb_first[9] <= ethernet_pcsrx_decoder_input[0];
// synthesis translate_off
	dummy_d_9 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pcsrx_decoder_adr = ethernet_pcsrx_decoder_input_msb_first[9:4];
assign ethernet_pcsrx_decoder_re = ethernet_pcsrx_decoder_ce;
assign ethernet_pcsrx_decoder_code5b = ethernet_pcsrx_decoder_dat_r;
assign ethernet_pcsrx_decoder_d = {ethernet_pcsrx_decoder_code3b, ethernet_pcsrx_decoder_code5b};
assign ethernet_pcsrx_decoder_invalid = (((ethernet_pcsrx_decoder_ones != 3'd4) & (ethernet_pcsrx_decoder_ones != 3'd5)) & (ethernet_pcsrx_decoder_ones != 3'd6));
assign ethernet_pcsrx_done = (ethernet_pcsrx_count1 == 1'd0);
assign ethernet_pcsrx_pipe_valid_sink_ready = ((~ethernet_pcsrx_pipe_valid_source_valid) | ethernet_pcsrx_pipe_valid_source_ready);
assign ethernet_pcsrx_pipe_valid_sink_valid = ethernet_pcsrx_sink_sink_valid;
assign ethernet_pcsrx_sink_sink_ready = ethernet_pcsrx_pipe_valid_sink_ready;
assign ethernet_pcsrx_pipe_valid_sink_first = ethernet_pcsrx_sink_sink_first;
assign ethernet_pcsrx_pipe_valid_sink_last = ethernet_pcsrx_sink_sink_last;
assign ethernet_pcsrx_pipe_valid_sink_payload_data = ethernet_pcsrx_sink_sink_payload_data;
assign ethernet_pcsrx_source_source_valid = ethernet_pcsrx_pipe_valid_source_valid;
assign ethernet_pcsrx_pipe_valid_source_ready = ethernet_pcsrx_source_source_ready;
assign ethernet_pcsrx_source_source_first = ethernet_pcsrx_pipe_valid_source_first;
assign ethernet_pcsrx_source_source_last = ethernet_pcsrx_pipe_valid_source_last;
assign ethernet_pcsrx_source_source_payload_data = ethernet_pcsrx_pipe_valid_source_payload_data;

// synthesis translate_off
reg dummy_d_10;
// synthesis translate_on
always @(*) begin
	ethernet_pcsrx_seen_valid_ci <= 1'd0;
	ethernet_pcsrx_seen_config_reg <= 1'd0;
	ethernet_pcsrx_source_valid <= 1'd0;
	ethernet_pcsrx_source_first <= 1'd0;
	ethernet_pcsrx_source_last <= 1'd0;
	ethernet_pcsrx_source_payload_data <= 8'd0;
	ethernet_pcsrx_source_payload_error <= 1'd0;
	ethernet_pcsrx_enable <= 1'd0;
	ethernet_pcsrx_sink_sink_valid <= 1'd0;
	ethernet_pcsrx_sink_sink_payload_data <= 8'd0;
	ethernet_pcsrx_source_source_ready <= 1'd0;
	clockdomainsrenamer1_next_state <= 3'd0;
	ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value <= 1'd0;
	ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value_ce <= 1'd0;
	clockdomainsrenamer1_next_value0 <= 8'd0;
	clockdomainsrenamer1_next_value_ce0 <= 1'd0;
	clockdomainsrenamer1_next_value1 <= 8'd0;
	clockdomainsrenamer1_next_value_ce1 <= 1'd0;
	if ((ethernet_pcsrx_timer_ce & ethernet_pcsrx_done)) begin
		ethernet_pcsrx_source_valid <= ethernet_pcsrx_source_source_valid;
		ethernet_pcsrx_source_source_ready <= ethernet_pcsrx_source_ready;
		ethernet_pcsrx_source_first <= ethernet_pcsrx_source_source_first;
		ethernet_pcsrx_source_payload_data <= ethernet_pcsrx_source_source_payload_data;
		ethernet_pcsrx_source_last <= (ethernet_pcsrx_source_source_valid & (~ethernet_pcsrx_sink_sink_valid));
	end
	clockdomainsrenamer1_next_state <= clockdomainsrenamer1_state;
	case (clockdomainsrenamer1_state)
		1'd1: begin
			if (ethernet_pcsrx_decoder_ce) begin
				if (((~ethernet_pcsrx_decoder_k) & (~ethernet_pcsrx_decoder_invalid))) begin
					if (((ethernet_pcsrx_decoder_d == 8'd181) | (ethernet_pcsrx_decoder_d == 7'd66))) begin
						ethernet_pcsrx_seen_valid_ci <= 1'd1;
						clockdomainsrenamer1_next_state <= 2'd2;
					end
					if (((ethernet_pcsrx_decoder_d == 8'd197) | (ethernet_pcsrx_decoder_d == 7'd80))) begin
						ethernet_pcsrx_seen_valid_ci <= 1'd1;
						clockdomainsrenamer1_next_state <= 1'd0;
					end
				end else begin
					clockdomainsrenamer1_next_state <= 3'd4;
				end
			end
		end
		2'd2: begin
			if (ethernet_pcsrx_decoder_ce) begin
				if (((~ethernet_pcsrx_decoder_k) & (~ethernet_pcsrx_decoder_invalid))) begin
					ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value <= (ethernet_pcsrx_count0 + 1'd1);
					ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value_ce <= 1'd1;
					case (ethernet_pcsrx_count0)
						1'd0: begin
							clockdomainsrenamer1_next_value0 <= ethernet_pcsrx_decoder_d;
							clockdomainsrenamer1_next_value_ce0 <= 1'd1;
						end
						1'd1: begin
							clockdomainsrenamer1_next_value1 <= ethernet_pcsrx_decoder_d;
							clockdomainsrenamer1_next_value_ce1 <= 1'd1;
						end
					endcase
					if ((ethernet_pcsrx_count0 == 1'd1)) begin
						ethernet_pcsrx_seen_config_reg <= 1'd1;
						clockdomainsrenamer1_next_state <= 1'd0;
					end
				end else begin
					clockdomainsrenamer1_next_state <= 3'd4;
				end
			end
		end
		2'd3: begin
			if (ethernet_pcsrx_decoder_ce) begin
				if (((~ethernet_pcsrx_decoder_k) & (~ethernet_pcsrx_decoder_invalid))) begin
					ethernet_pcsrx_enable <= 1'd1;
					ethernet_pcsrx_sink_sink_valid <= ethernet_pcsrx_done;
					ethernet_pcsrx_sink_sink_payload_data <= ethernet_pcsrx_decoder_d;
				end else begin
					if (((ethernet_pcsrx_decoder_k & (ethernet_pcsrx_decoder_d == 8'd253)) & (~ethernet_pcsrx_decoder_invalid))) begin
						clockdomainsrenamer1_next_state <= 1'd0;
					end else begin
						ethernet_pcsrx_source_payload_error <= 1'd1;
						ethernet_pcsrx_source_last <= 1'd1;
						ethernet_pcsrx_source_valid <= 1'd1;
						if (ethernet_pcsrx_source_ready) begin
							clockdomainsrenamer1_next_state <= 3'd4;
						end
					end
				end
			end
		end
		3'd4: begin
			clockdomainsrenamer1_next_state <= 1'd0;
		end
		default: begin
			if (ethernet_pcsrx_decoder_ce) begin
				if (ethernet_pcsrx_decoder_k) begin
					if ((ethernet_pcsrx_decoder_d == 8'd188)) begin
						ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value <= 1'd0;
						ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value_ce <= 1'd1;
						clockdomainsrenamer1_next_state <= 1'd1;
					end
					if ((ethernet_pcsrx_decoder_d == 8'd251)) begin
						ethernet_pcsrx_enable <= 1'd1;
						ethernet_pcsrx_sink_sink_valid <= 1'd1;
						ethernet_pcsrx_sink_sink_payload_data <= 7'd85;
						clockdomainsrenamer1_next_state <= 2'd3;
					end
				end
			end
		end
	endcase
// synthesis translate_off
	dummy_d_10 <= dummy_s;
// synthesis translate_on
end
assign ethernet_lp_abi_wait = (~ethernet_lp_abi_ping_i);
assign ethernet_lp_abi_ping_i = ((ethernet_lp_abi_starter | ethernet_lp_abi_pong_o) | ethernet_lp_abi_done);
assign ethernet_lp_abi_pong_i = ethernet_lp_abi_ping_o1;
assign ethernet_lp_abi_ping_o0 = (ethernet_lp_abi_ping_toggle_o ^ ethernet_lp_abi_ping_toggle_o_r);
assign ethernet_lp_abi_pong_o = (ethernet_lp_abi_pong_toggle_o ^ ethernet_lp_abi_pong_toggle_o_r);
assign ethernet_lp_abi_done = (ethernet_lp_abi_count == 1'd0);
assign ethernet_seen_valid_ci_o = (ethernet_seen_valid_ci_toggle_o ^ ethernet_seen_valid_ci_toggle_o_r);
assign ethernet_rx_config_reg_abi_o = (ethernet_rx_config_reg_abi_toggle_o ^ ethernet_rx_config_reg_abi_toggle_o_r);
assign ethernet_rx_config_reg_ack_o = (ethernet_rx_config_reg_ack_toggle_o ^ ethernet_rx_config_reg_ack_toggle_o_r);
assign ethernet_waittimer0_done = (ethernet_waittimer0_count == 1'd0);
assign ethernet_waittimer1_done = (ethernet_waittimer1_count == 1'd0);
assign ethernet_waittimer2_done = (ethernet_waittimer2_count == 1'd0);

// synthesis translate_off
reg dummy_d_11;
// synthesis translate_on
always @(*) begin
	ethernet_pcstx_config_valid <= 1'd0;
	ethernet_link_up <= 1'd0;
	ethernet_restart <= 1'd0;
	ethernet_align <= 1'd0;
	ethernet_config_empty <= 1'd0;
	ethernet_autoneg_ack <= 1'd0;
	ethernet_waittimer0_wait <= 1'd0;
	ethernet_waittimer1_wait <= 1'd0;
	ethernet_waittimer2_wait <= 1'd0;
	clockdomainsrenamer2_next_state <= 3'd0;
	clockdomainsrenamer2_next_state <= clockdomainsrenamer2_state;
	case (clockdomainsrenamer2_state)
		1'd1: begin
			ethernet_align <= 1'd1;
			ethernet_pcstx_config_valid <= 1'd1;
			if (ethernet_rx_config_reg_abi_o) begin
				clockdomainsrenamer2_next_state <= 2'd2;
			end
			if ((ethernet_checker_tick & ethernet_checker_error)) begin
				ethernet_restart <= 1'd1;
				clockdomainsrenamer2_next_state <= 1'd0;
			end
		end
		2'd2: begin
			ethernet_pcstx_config_valid <= 1'd1;
			ethernet_autoneg_ack <= 1'd1;
			if (ethernet_rx_config_reg_ack_o) begin
				clockdomainsrenamer2_next_state <= 2'd3;
			end
			if ((ethernet_checker_tick & ethernet_checker_error)) begin
				ethernet_restart <= 1'd1;
				clockdomainsrenamer2_next_state <= 1'd0;
			end
		end
		2'd3: begin
			ethernet_pcstx_config_valid <= 1'd1;
			ethernet_autoneg_ack <= 1'd1;
			ethernet_waittimer1_wait <= (~ethernet_is_sgmii);
			ethernet_waittimer2_wait <= ethernet_is_sgmii;
			if (((ethernet_is_sgmii & ethernet_waittimer2_done) | ((~ethernet_is_sgmii) & ethernet_waittimer1_done))) begin
				clockdomainsrenamer2_next_state <= 3'd4;
			end
			if ((ethernet_checker_tick & ethernet_checker_error)) begin
				ethernet_restart <= 1'd1;
				clockdomainsrenamer2_next_state <= 1'd0;
			end
		end
		3'd4: begin
			ethernet_link_up <= (~ethernet_linkdown);
			if (((ethernet_checker_tick & ethernet_checker_error) | ethernet_linkdown)) begin
				ethernet_restart <= 1'd1;
				clockdomainsrenamer2_next_state <= 1'd0;
			end
		end
		default: begin
			ethernet_pcstx_config_valid <= 1'd1;
			ethernet_config_empty <= 1'd1;
			ethernet_waittimer0_wait <= 1'd1;
			if (ethernet_waittimer0_done) begin
				clockdomainsrenamer2_next_state <= 1'd1;
			end
		end
	endcase
// synthesis translate_off
	dummy_d_11 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pma_a7_gtp_basex_rx_valid = 1'd1;
assign ethernet_pma_a7_gtp_basex_tx_cm_reset1 = ethernet_pma_a7_gtp_basex_tx_cm_reset0;
assign ethernet_pma_a7_gtp_basex_tx_cm_locked0 = ethernet_pma_a7_gtp_basex_tx_cm_locked1;
assign ethernet_pma_a7_gtp_basex_rx_cm_reset1 = ethernet_pma_a7_gtp_basex_rx_cm_reset0;
assign ethernet_pma_a7_gtp_basex_rx_cm_locked0 = ethernet_pma_a7_gtp_basex_rx_cm_locked1;
assign ethernet_reset = ethernet_pma_a7_gtp_basex_tx_init_qpll_reset0;
assign ethernet_pma_a7_gtp_basex_tx_init_qpll_lock0 = ethernet_lock;
assign ethernet_pma_a7_gtp_basex_tx_reset = (ethernet_pma_a7_gtp_basex_tx_init_tx_reset0 | ethernet_pma_a7_gtp_basex_reset);
assign ethernet_pma_a7_gtp_basex_rx_init_enable = ethernet_pma_a7_gtp_basex_tx_init_done;
assign ethernet_pma_a7_gtp_basex_rx_reset = (ethernet_pma_a7_gtp_basex_rx_init_rx_reset0 | ethernet_pma_a7_gtp_basex_reset);
assign ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done0 = ethernet_pma_a7_gtp_basex_rx_pma_reset_done;
assign ethernet_pma_a7_gtp_basex_drpaddr = ethernet_pma_a7_gtp_basex_rx_init_drpaddr;
assign ethernet_pma_a7_gtp_basex_drpen = ethernet_pma_a7_gtp_basex_rx_init_drpen;
assign ethernet_pma_a7_gtp_basex_drpdi = ethernet_pma_a7_gtp_basex_rx_init_drpdi;
assign ethernet_pma_a7_gtp_basex_rx_init_drprdy = ethernet_pma_a7_gtp_basex_drprdy;
assign ethernet_pma_a7_gtp_basex_rx_init_drpdo = ethernet_pma_a7_gtp_basex_drpdo;
assign ethernet_pma_a7_gtp_basex_drpwe = ethernet_pma_a7_gtp_basex_rx_init_drpwe;
assign ethernet_pma_a7_gtp_basex_i = ethernet_pma_a7_gtp_basex_restart;
assign ethernet_pma_a7_gtp_basex_rx_init_restart = ethernet_pma_a7_gtp_basex_o;
assign ethernet_pma_a7_gtp_basex_tx_data0 = ethernet_pma_a7_gtp_basex_tx_data_half;
assign ethernet_pma_a7_gtp_basex_rx_data_half = ethernet_pma_a7_gtp_basex_rx_data0;
assign ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal = ethernet_pma_a7_gtp_basex_txoutclk_rebuffer;
assign eth_tx_half_clk = ethernet_pma_a7_gtp_basex_s7pll0_clkout_buf0;
assign eth_tx_clk = ethernet_pma_a7_gtp_basex_s7pll0_clkout_buf1;
assign ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal = ethernet_pma_a7_gtp_basex_rxoutclk_rebuffer;
assign eth_rx_half_clk = ethernet_pma_a7_gtp_basex_s7pll1_clkout_buf0;
assign eth_rx_clk = ethernet_pma_a7_gtp_basex_s7pll1_clkout_buf1;

// synthesis translate_off
reg dummy_d_12;
// synthesis translate_on
always @(*) begin
	ethernet_pma_a7_gtp_basex_tx_init_done <= 1'd0;
	ethernet_pma_a7_gtp_basex_tx_init_qpll_reset1 <= 1'd0;
	ethernet_pma_a7_gtp_basex_tx_init_tx_reset1 <= 1'd0;
	gtptxinit_next_state <= 2'd0;
	gtptxinit_next_state <= gtptxinit_state;
	case (gtptxinit_state)
		1'd1: begin
			ethernet_pma_a7_gtp_basex_tx_init_tx_reset1 <= 1'd1;
			ethernet_pma_a7_gtp_basex_tx_init_qpll_reset1 <= 1'd1;
			if (ethernet_pma_a7_gtp_basex_tx_init_tick) begin
				gtptxinit_next_state <= 2'd2;
			end
		end
		2'd2: begin
			ethernet_pma_a7_gtp_basex_tx_init_tx_reset1 <= 1'd1;
			if ((ethernet_pma_a7_gtp_basex_tx_init_qpll_lock1 & ethernet_pma_a7_gtp_basex_tx_init_tick)) begin
				gtptxinit_next_state <= 2'd3;
			end
		end
		2'd3: begin
			ethernet_pma_a7_gtp_basex_tx_init_done <= 1'd1;
		end
		default: begin
			if (ethernet_pma_a7_gtp_basex_tx_init_tick) begin
				gtptxinit_next_state <= 1'd1;
			end
		end
	endcase
// synthesis translate_off
	dummy_d_12 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pma_a7_gtp_basex_rx_init_drpaddr = 5'd17;

// synthesis translate_off
reg dummy_d_13;
// synthesis translate_on
always @(*) begin
	ethernet_pma_a7_gtp_basex_rx_init_drpdi <= 16'd0;
	if (ethernet_pma_a7_gtp_basex_rx_init_drpmask) begin
		ethernet_pma_a7_gtp_basex_rx_init_drpdi <= (ethernet_pma_a7_gtp_basex_rx_init_drpvalue & 16'd63487);
	end else begin
		ethernet_pma_a7_gtp_basex_rx_init_drpdi <= ethernet_pma_a7_gtp_basex_rx_init_drpvalue;
	end
// synthesis translate_off
	dummy_d_13 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_14;
// synthesis translate_on
always @(*) begin
	ethernet_pma_a7_gtp_basex_rx_init_drpen <= 1'd0;
	ethernet_pma_a7_gtp_basex_rx_init_drpwe <= 1'd0;
	ethernet_pma_a7_gtp_basex_rx_init_done <= 1'd0;
	ethernet_pma_a7_gtp_basex_rx_init_rx_reset1 <= 1'd0;
	ethernet_pma_a7_gtp_basex_rx_init_drpmask <= 1'd0;
	gtprxinit_next_state <= 4'd0;
	ethernet_pma_a7_gtp_basex_rx_init_drpvalue_a7_1000basex_next_value <= 16'd0;
	ethernet_pma_a7_gtp_basex_rx_init_drpvalue_a7_1000basex_next_value_ce <= 1'd0;
	gtprxinit_next_state <= gtprxinit_state;
	case (gtprxinit_state)
		1'd1: begin
			ethernet_pma_a7_gtp_basex_rx_init_rx_reset1 <= 1'd1;
			gtprxinit_next_state <= 2'd2;
		end
		2'd2: begin
			ethernet_pma_a7_gtp_basex_rx_init_rx_reset1 <= 1'd1;
			ethernet_pma_a7_gtp_basex_rx_init_drpen <= 1'd1;
			gtprxinit_next_state <= 2'd3;
		end
		2'd3: begin
			ethernet_pma_a7_gtp_basex_rx_init_rx_reset1 <= 1'd1;
			if (ethernet_pma_a7_gtp_basex_rx_init_drprdy) begin
				ethernet_pma_a7_gtp_basex_rx_init_drpvalue_a7_1000basex_next_value <= ethernet_pma_a7_gtp_basex_rx_init_drpdo;
				ethernet_pma_a7_gtp_basex_rx_init_drpvalue_a7_1000basex_next_value_ce <= 1'd1;
				gtprxinit_next_state <= 3'd4;
			end
		end
		3'd4: begin
			ethernet_pma_a7_gtp_basex_rx_init_rx_reset1 <= 1'd1;
			ethernet_pma_a7_gtp_basex_rx_init_drpmask <= 1'd1;
			ethernet_pma_a7_gtp_basex_rx_init_drpen <= 1'd1;
			ethernet_pma_a7_gtp_basex_rx_init_drpwe <= 1'd1;
			gtprxinit_next_state <= 3'd5;
		end
		3'd5: begin
			ethernet_pma_a7_gtp_basex_rx_init_rx_reset1 <= 1'd1;
			if (ethernet_pma_a7_gtp_basex_rx_init_drprdy) begin
				gtprxinit_next_state <= 3'd6;
			end
		end
		3'd6: begin
			if ((ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done_r & (~ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done1))) begin
				gtprxinit_next_state <= 3'd7;
			end
		end
		3'd7: begin
			ethernet_pma_a7_gtp_basex_rx_init_drpen <= 1'd1;
			ethernet_pma_a7_gtp_basex_rx_init_drpwe <= 1'd1;
			gtprxinit_next_state <= 4'd8;
		end
		4'd8: begin
			if (ethernet_pma_a7_gtp_basex_rx_init_drprdy) begin
				gtprxinit_next_state <= 4'd9;
			end
		end
		4'd9: begin
			ethernet_pma_a7_gtp_basex_rx_init_done <= 1'd1;
			if (ethernet_pma_a7_gtp_basex_rx_init_restart) begin
				gtprxinit_next_state <= 1'd0;
			end
		end
		default: begin
			if (ethernet_pma_a7_gtp_basex_rx_init_enable) begin
				gtprxinit_next_state <= 1'd1;
			end
		end
	endcase
// synthesis translate_off
	dummy_d_14 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pma_a7_gtp_basex_o = (ethernet_pma_a7_gtp_basex_toggle_o ^ ethernet_pma_a7_gtp_basex_toggle_o_r);
assign ethernet_tx_padding_counter_done = (ethernet_tx_padding_counter >= 6'd59);

// synthesis translate_off
reg dummy_d_15;
// synthesis translate_on
always @(*) begin
	ethernet_tx_padding_sink_ready <= 1'd0;
	ethernet_tx_padding_source_valid <= 1'd0;
	ethernet_tx_padding_source_first <= 1'd0;
	ethernet_tx_padding_source_last <= 1'd0;
	ethernet_tx_padding_source_payload_data <= 8'd0;
	ethernet_tx_padding_source_payload_be <= 1'd0;
	ethernet_tx_padding_source_payload_error <= 1'd0;
	txdatapath_liteethmacpaddinginserter_next_state <= 1'd0;
	ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value <= 16'd0;
	ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value_ce <= 1'd0;
	txdatapath_liteethmacpaddinginserter_next_state <= txdatapath_liteethmacpaddinginserter_state;
	case (txdatapath_liteethmacpaddinginserter_state)
		1'd1: begin
			ethernet_tx_padding_source_valid <= 1'd1;
			ethernet_tx_padding_source_payload_be <= 1'd1;
			if (ethernet_tx_padding_counter_done) begin
				ethernet_tx_padding_source_payload_be <= 1'd1;
				ethernet_tx_padding_source_last <= 1'd1;
			end
			ethernet_tx_padding_source_payload_data <= 1'd0;
			if ((ethernet_tx_padding_source_valid & ethernet_tx_padding_source_ready)) begin
				ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value <= (ethernet_tx_padding_counter + 1'd1);
				ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value_ce <= 1'd1;
				if (ethernet_tx_padding_counter_done) begin
					ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value <= 1'd0;
					ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value_ce <= 1'd1;
					txdatapath_liteethmacpaddinginserter_next_state <= 1'd0;
				end
			end
		end
		default: begin
			ethernet_tx_padding_source_valid <= ethernet_tx_padding_sink_valid;
			ethernet_tx_padding_sink_ready <= ethernet_tx_padding_source_ready;
			ethernet_tx_padding_source_first <= ethernet_tx_padding_sink_first;
			ethernet_tx_padding_source_last <= ethernet_tx_padding_sink_last;
			ethernet_tx_padding_source_payload_data <= ethernet_tx_padding_sink_payload_data;
			ethernet_tx_padding_source_payload_be <= ethernet_tx_padding_sink_payload_be;
			ethernet_tx_padding_source_payload_error <= ethernet_tx_padding_sink_payload_error;
			if (ethernet_tx_padding_sink_last) begin
				if ((~ethernet_tx_padding_sink_payload_be)) begin
					ethernet_tx_padding_source_payload_data[7:0] <= 1'd0;
				end
				if ((~ethernet_tx_padding_counter_done)) begin
					ethernet_tx_padding_source_last <= 1'd0;
					ethernet_tx_padding_source_payload_be <= 1'd1;
				end else begin
					if (((ethernet_tx_padding_counter == 6'd59) & (ethernet_tx_padding_sink_payload_be < 1'd1))) begin
						ethernet_tx_padding_source_payload_be <= 1'd1;
					end
				end
			end
			if ((ethernet_tx_padding_source_valid & ethernet_tx_padding_source_ready)) begin
				ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value <= (ethernet_tx_padding_counter + 1'd1);
				ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value_ce <= 1'd1;
				if (ethernet_tx_padding_sink_last) begin
					if ((~ethernet_tx_padding_counter_done)) begin
						txdatapath_liteethmacpaddinginserter_next_state <= 1'd1;
					end else begin
						ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value <= 1'd0;
						ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value_ce <= 1'd1;
					end
				end
			end
		end
	endcase
// synthesis translate_off
	dummy_d_15 <= dummy_s;
// synthesis translate_on
end
assign ethernet_tx_crc_data0 = ethernet_tx_crc_sink_payload_data;
assign ethernet_tx_crc_be1 = ethernet_tx_crc_sink_payload_be;
assign ethernet_tx_crc_cnt_done = (ethernet_tx_crc_cnt == 1'd0);
assign ethernet_tx_crc_sink_valid = ethernet_tx_crc_source_source_valid;
assign ethernet_tx_crc_source_source_ready = ethernet_tx_crc_sink_ready;
assign ethernet_tx_crc_sink_first = ethernet_tx_crc_source_source_first;
assign ethernet_tx_crc_sink_last = ethernet_tx_crc_source_source_last;
assign ethernet_tx_crc_sink_payload_data = ethernet_tx_crc_source_source_payload_data;
assign ethernet_tx_crc_sink_payload_be = ethernet_tx_crc_source_source_payload_be;
assign ethernet_tx_crc_sink_payload_error = ethernet_tx_crc_source_source_payload_error;
assign ethernet_tx_crc_data1 = ethernet_tx_crc_data0;
assign ethernet_tx_crc_crc_prev = ethernet_tx_crc_reg;

// synthesis translate_off
reg dummy_d_16;
// synthesis translate_on
always @(*) begin
	ethernet_tx_crc_value <= 32'd0;
	ethernet_tx_crc_error <= 1'd0;
	if (ethernet_tx_crc_be1) begin
		ethernet_tx_crc_value <= ({ethernet_tx_crc_crc_next[0], ethernet_tx_crc_crc_next[1], ethernet_tx_crc_crc_next[2], ethernet_tx_crc_crc_next[3], ethernet_tx_crc_crc_next[4], ethernet_tx_crc_crc_next[5], ethernet_tx_crc_crc_next[6], ethernet_tx_crc_crc_next[7], ethernet_tx_crc_crc_next[8], ethernet_tx_crc_crc_next[9], ethernet_tx_crc_crc_next[10], ethernet_tx_crc_crc_next[11], ethernet_tx_crc_crc_next[12], ethernet_tx_crc_crc_next[13], ethernet_tx_crc_crc_next[14], ethernet_tx_crc_crc_next[15], ethernet_tx_crc_crc_next[16], ethernet_tx_crc_crc_next[17], ethernet_tx_crc_crc_next[18], ethernet_tx_crc_crc_next[19], ethernet_tx_crc_crc_next[20], ethernet_tx_crc_crc_next[21], ethernet_tx_crc_crc_next[22], ethernet_tx_crc_crc_next[23], ethernet_tx_crc_crc_next[24], ethernet_tx_crc_crc_next[25], ethernet_tx_crc_crc_next[26], ethernet_tx_crc_crc_next[27], ethernet_tx_crc_crc_next[28], ethernet_tx_crc_crc_next[29], ethernet_tx_crc_crc_next[30], ethernet_tx_crc_crc_next[31]} ^ 32'd4294967295);
		ethernet_tx_crc_error <= (ethernet_tx_crc_crc_next != 32'd3338984827);
	end
// synthesis translate_off
	dummy_d_16 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_17;
// synthesis translate_on
always @(*) begin
	ethernet_tx_crc_crc_next <= 32'd0;
	ethernet_tx_crc_crc_next[0] <= (((ethernet_tx_crc_crc_prev[24] ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[1] <= (((((((ethernet_tx_crc_crc_prev[25] ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_data1[6]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[2] <= (((((((((ethernet_tx_crc_crc_prev[26] ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_data1[6]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[3] <= (((((((ethernet_tx_crc_crc_prev[27] ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_data1[6]);
	ethernet_tx_crc_crc_next[4] <= (((((((((ethernet_tx_crc_crc_prev[28] ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[5] <= (((((((((((((ethernet_tx_crc_crc_prev[29] ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_data1[6]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[6] <= (((((((((((ethernet_tx_crc_crc_prev[30] ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_data1[6]);
	ethernet_tx_crc_crc_next[7] <= (((((((((ethernet_tx_crc_crc_prev[31] ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[8] <= ((((((((ethernet_tx_crc_crc_prev[0] ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_data1[6]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[9] <= ((((((((ethernet_tx_crc_crc_prev[1] ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_data1[6]);
	ethernet_tx_crc_crc_next[10] <= ((((((((ethernet_tx_crc_crc_prev[2] ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[11] <= ((((((((ethernet_tx_crc_crc_prev[3] ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_data1[6]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[12] <= ((((((((((((ethernet_tx_crc_crc_prev[4] ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_data1[6]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[13] <= ((((((((((((ethernet_tx_crc_crc_prev[5] ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_data1[6]);
	ethernet_tx_crc_crc_next[14] <= ((((((((((ethernet_tx_crc_crc_prev[6] ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]);
	ethernet_tx_crc_crc_next[15] <= ((((((((ethernet_tx_crc_crc_prev[7] ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]);
	ethernet_tx_crc_crc_next[16] <= ((((((ethernet_tx_crc_crc_prev[8] ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[17] <= ((((((ethernet_tx_crc_crc_prev[9] ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_data1[6]);
	ethernet_tx_crc_crc_next[18] <= ((((((ethernet_tx_crc_crc_prev[10] ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]);
	ethernet_tx_crc_crc_next[19] <= ((((ethernet_tx_crc_crc_prev[11] ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]);
	ethernet_tx_crc_crc_next[20] <= ((ethernet_tx_crc_crc_prev[12] ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]);
	ethernet_tx_crc_crc_next[21] <= ((ethernet_tx_crc_crc_prev[13] ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]);
	ethernet_tx_crc_crc_next[22] <= ((ethernet_tx_crc_crc_prev[14] ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[23] <= ((((((ethernet_tx_crc_crc_prev[15] ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_data1[6]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[24] <= ((((((ethernet_tx_crc_crc_prev[16] ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_data1[6]);
	ethernet_tx_crc_crc_next[25] <= ((((ethernet_tx_crc_crc_prev[17] ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]);
	ethernet_tx_crc_crc_next[26] <= ((((((((ethernet_tx_crc_crc_prev[18] ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]) ^ ethernet_tx_crc_crc_prev[24]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_data1[7]);
	ethernet_tx_crc_crc_next[27] <= ((((((((ethernet_tx_crc_crc_prev[19] ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]) ^ ethernet_tx_crc_crc_prev[25]) ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_data1[6]);
	ethernet_tx_crc_crc_next[28] <= ((((((ethernet_tx_crc_crc_prev[20] ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]) ^ ethernet_tx_crc_crc_prev[26]) ^ ethernet_tx_crc_data1[5]);
	ethernet_tx_crc_crc_next[29] <= ((((((ethernet_tx_crc_crc_prev[21] ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_crc_prev[30]) ^ ethernet_tx_crc_data1[1]) ^ ethernet_tx_crc_crc_prev[27]) ^ ethernet_tx_crc_data1[4]);
	ethernet_tx_crc_crc_next[30] <= ((((ethernet_tx_crc_crc_prev[22] ^ ethernet_tx_crc_crc_prev[31]) ^ ethernet_tx_crc_data1[0]) ^ ethernet_tx_crc_crc_prev[28]) ^ ethernet_tx_crc_data1[3]);
	ethernet_tx_crc_crc_next[31] <= ((ethernet_tx_crc_crc_prev[23] ^ ethernet_tx_crc_crc_prev[29]) ^ ethernet_tx_crc_data1[2]);
// synthesis translate_off
	dummy_d_17 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_18;
// synthesis translate_on
always @(*) begin
	ethernet_tx_crc_sink_ready <= 1'd0;
	ethernet_tx_crc_source_valid <= 1'd0;
	ethernet_tx_crc_source_first <= 1'd0;
	ethernet_tx_crc_source_last <= 1'd0;
	ethernet_tx_crc_source_payload_data <= 8'd0;
	ethernet_tx_crc_source_payload_be <= 1'd0;
	ethernet_tx_crc_source_payload_error <= 1'd0;
	ethernet_tx_crc_ce <= 1'd0;
	ethernet_tx_crc_reset <= 1'd0;
	ethernet_tx_crc_is_ongoing0 <= 1'd0;
	ethernet_tx_crc_is_ongoing1 <= 1'd0;
	txdatapath_bufferizeendpoints_next_state <= 2'd0;
	ethernet_tx_crc_crc_packet_clockdomainsrenamer_clockdomainsrenamer1_next_value0 <= 32'd0;
	ethernet_tx_crc_crc_packet_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce0 <= 1'd0;
	ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value1 <= 1'd0;
	ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce1 <= 1'd0;
	txdatapath_bufferizeendpoints_next_state <= txdatapath_bufferizeendpoints_state;
	case (txdatapath_bufferizeendpoints_state)
		1'd1: begin
			ethernet_tx_crc_ce <= (ethernet_tx_crc_sink_valid & ethernet_tx_crc_source_ready);
			ethernet_tx_crc_source_valid <= ethernet_tx_crc_sink_valid;
			ethernet_tx_crc_sink_ready <= ethernet_tx_crc_source_ready;
			ethernet_tx_crc_source_first <= ethernet_tx_crc_sink_first;
			ethernet_tx_crc_source_last <= ethernet_tx_crc_sink_last;
			ethernet_tx_crc_source_payload_data <= ethernet_tx_crc_sink_payload_data;
			ethernet_tx_crc_source_payload_be <= ethernet_tx_crc_sink_payload_be;
			ethernet_tx_crc_source_payload_error <= ethernet_tx_crc_sink_payload_error;
			ethernet_tx_crc_source_last <= 1'd0;
			ethernet_tx_crc_source_payload_be <= 1'd1;
			if (ethernet_tx_crc_sink_last) begin
				if (ethernet_tx_crc_sink_payload_be) begin
					ethernet_tx_crc_source_payload_data <= slice_proxy[7:0];
				end
				if ((1'd0 & (ethernet_tx_crc_sink_payload_be <= 4'd15))) begin
					ethernet_tx_crc_source_last <= 1'd1;
					ethernet_tx_crc_source_payload_be <= ((ethernet_tx_crc_sink_payload_be <<< 3'd4) | 4'd15);
				end
			end
			if (((ethernet_tx_crc_sink_valid & ethernet_tx_crc_sink_last) & ethernet_tx_crc_source_ready)) begin
				if ((1'd0 & (ethernet_tx_crc_sink_payload_be <= 4'd15))) begin
					txdatapath_bufferizeendpoints_next_state <= 1'd0;
				end else begin
					ethernet_tx_crc_crc_packet_clockdomainsrenamer_clockdomainsrenamer1_next_value0 <= ethernet_tx_crc_value;
					ethernet_tx_crc_crc_packet_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce0 <= 1'd1;
					if (1'd0) begin
						ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value1 <= (ethernet_tx_crc_sink_payload_be >>> 3'd4);
						ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce1 <= 1'd1;
					end else begin
						ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value1 <= ethernet_tx_crc_sink_payload_be;
						ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce1 <= 1'd1;
					end
					txdatapath_bufferizeendpoints_next_state <= 2'd2;
				end
			end
		end
		2'd2: begin
			ethernet_tx_crc_source_valid <= 1'd1;
			ethernet_tx_crc_source_payload_be <= 1'd1;
			case (ethernet_tx_crc_cnt)
				1'd0: begin
					ethernet_tx_crc_source_payload_data <= ethernet_tx_crc_crc_packet[31:24];
				end
				1'd1: begin
					ethernet_tx_crc_source_payload_data <= ethernet_tx_crc_crc_packet[23:16];
				end
				2'd2: begin
					ethernet_tx_crc_source_payload_data <= ethernet_tx_crc_crc_packet[15:8];
				end
				default: begin
					ethernet_tx_crc_source_payload_data <= ethernet_tx_crc_crc_packet[7:0];
				end
			endcase
			if (ethernet_tx_crc_cnt_done) begin
				ethernet_tx_crc_source_last <= 1'd1;
				if (ethernet_tx_crc_source_ready) begin
					txdatapath_bufferizeendpoints_next_state <= 1'd0;
				end
			end
			ethernet_tx_crc_is_ongoing1 <= 1'd1;
		end
		default: begin
			ethernet_tx_crc_reset <= 1'd1;
			ethernet_tx_crc_sink_ready <= 1'd1;
			if (ethernet_tx_crc_sink_valid) begin
				ethernet_tx_crc_sink_ready <= 1'd0;
				txdatapath_bufferizeendpoints_next_state <= 1'd1;
			end
			ethernet_tx_crc_is_ongoing0 <= 1'd1;
		end
	endcase
// synthesis translate_off
	dummy_d_18 <= dummy_s;
// synthesis translate_on
end
assign ethernet_tx_crc_pipe_valid_sink_ready = ((~ethernet_tx_crc_pipe_valid_source_valid) | ethernet_tx_crc_pipe_valid_source_ready);
assign ethernet_tx_crc_pipe_valid_sink_valid = ethernet_tx_crc_sink_sink_valid;
assign ethernet_tx_crc_sink_sink_ready = ethernet_tx_crc_pipe_valid_sink_ready;
assign ethernet_tx_crc_pipe_valid_sink_first = ethernet_tx_crc_sink_sink_first;
assign ethernet_tx_crc_pipe_valid_sink_last = ethernet_tx_crc_sink_sink_last;
assign ethernet_tx_crc_pipe_valid_sink_payload_data = ethernet_tx_crc_sink_sink_payload_data;
assign ethernet_tx_crc_pipe_valid_sink_payload_be = ethernet_tx_crc_sink_sink_payload_be;
assign ethernet_tx_crc_pipe_valid_sink_payload_error = ethernet_tx_crc_sink_sink_payload_error;
assign ethernet_tx_crc_source_source_valid = ethernet_tx_crc_pipe_valid_source_valid;
assign ethernet_tx_crc_pipe_valid_source_ready = ethernet_tx_crc_source_source_ready;
assign ethernet_tx_crc_source_source_first = ethernet_tx_crc_pipe_valid_source_first;
assign ethernet_tx_crc_source_source_last = ethernet_tx_crc_pipe_valid_source_last;
assign ethernet_tx_crc_source_source_payload_data = ethernet_tx_crc_pipe_valid_source_payload_data;
assign ethernet_tx_crc_source_source_payload_be = ethernet_tx_crc_pipe_valid_source_payload_be;
assign ethernet_tx_crc_source_source_payload_error = ethernet_tx_crc_pipe_valid_source_payload_error;

// synthesis translate_off
reg dummy_d_19;
// synthesis translate_on
always @(*) begin
	ethernet_tx_preamble_sink_ready <= 1'd0;
	ethernet_tx_preamble_source_valid <= 1'd0;
	ethernet_tx_preamble_source_first <= 1'd0;
	ethernet_tx_preamble_source_last <= 1'd0;
	ethernet_tx_preamble_source_payload_data <= 8'd0;
	ethernet_tx_preamble_source_payload_be <= 1'd0;
	ethernet_tx_preamble_source_payload_error <= 1'd0;
	txdatapath_liteethmacpreambleinserter_next_state <= 2'd0;
	ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value <= 3'd0;
	ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value_ce <= 1'd0;
	ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_sink_payload_data;
	ethernet_tx_preamble_source_payload_be <= ethernet_tx_preamble_sink_payload_be;
	txdatapath_liteethmacpreambleinserter_next_state <= txdatapath_liteethmacpreambleinserter_state;
	case (txdatapath_liteethmacpreambleinserter_state)
		1'd1: begin
			ethernet_tx_preamble_source_valid <= 1'd1;
			ethernet_tx_preamble_source_payload_be <= 1'd1;
			case (ethernet_tx_preamble_count)
				1'd0: begin
					ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_preamble[7:0];
				end
				1'd1: begin
					ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_preamble[15:8];
				end
				2'd2: begin
					ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_preamble[23:16];
				end
				2'd3: begin
					ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_preamble[31:24];
				end
				3'd4: begin
					ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_preamble[39:32];
				end
				3'd5: begin
					ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_preamble[47:40];
				end
				3'd6: begin
					ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_preamble[55:48];
				end
				default: begin
					ethernet_tx_preamble_source_payload_data <= ethernet_tx_preamble_preamble[63:56];
				end
			endcase
			if (ethernet_tx_preamble_source_ready) begin
				if ((ethernet_tx_preamble_count == 3'd7)) begin
					txdatapath_liteethmacpreambleinserter_next_state <= 2'd2;
				end else begin
					ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value <= (ethernet_tx_preamble_count + 1'd1);
					ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value_ce <= 1'd1;
				end
			end
		end
		2'd2: begin
			ethernet_tx_preamble_source_valid <= ethernet_tx_preamble_sink_valid;
			ethernet_tx_preamble_sink_ready <= ethernet_tx_preamble_source_ready;
			ethernet_tx_preamble_source_first <= ethernet_tx_preamble_sink_first;
			ethernet_tx_preamble_source_last <= ethernet_tx_preamble_sink_last;
			ethernet_tx_preamble_source_payload_error <= ethernet_tx_preamble_sink_payload_error;
			if (((ethernet_tx_preamble_sink_valid & ethernet_tx_preamble_sink_last) & ethernet_tx_preamble_source_ready)) begin
				txdatapath_liteethmacpreambleinserter_next_state <= 1'd0;
			end
		end
		default: begin
			ethernet_tx_preamble_sink_ready <= 1'd1;
			ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value <= 1'd0;
			ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value_ce <= 1'd1;
			if (ethernet_tx_preamble_sink_valid) begin
				ethernet_tx_preamble_sink_ready <= 1'd0;
				txdatapath_liteethmacpreambleinserter_next_state <= 1'd1;
			end
		end
	endcase
// synthesis translate_off
	dummy_d_19 <= dummy_s;
// synthesis translate_on
end
assign ethernet_txdatapath_cdc_sink_valid = ethernet_txdatapath_sink_sink_valid;
assign ethernet_txdatapath_sink_sink_ready = ethernet_txdatapath_cdc_sink_ready;
assign ethernet_txdatapath_cdc_sink_first = ethernet_txdatapath_sink_sink_first;
assign ethernet_txdatapath_cdc_sink_last = ethernet_txdatapath_sink_sink_last;
assign ethernet_txdatapath_cdc_sink_payload_data = ethernet_txdatapath_sink_sink_payload_data;
assign ethernet_txdatapath_cdc_sink_payload_be = ethernet_txdatapath_sink_sink_payload_be;
assign ethernet_txdatapath_cdc_sink_payload_error = ethernet_txdatapath_sink_sink_payload_error;
assign ethernet_txdatapath_source_source_valid = ethernet_txdatapath_cdc_source_valid;
assign ethernet_txdatapath_cdc_source_ready = ethernet_txdatapath_source_source_ready;
assign ethernet_txdatapath_source_source_first = ethernet_txdatapath_cdc_source_first;
assign ethernet_txdatapath_source_source_last = ethernet_txdatapath_cdc_source_last;
assign ethernet_txdatapath_source_source_payload_data = ethernet_txdatapath_cdc_source_payload_data;
assign ethernet_txdatapath_source_source_payload_be = ethernet_txdatapath_cdc_source_payload_be;
assign ethernet_txdatapath_source_source_payload_error = ethernet_txdatapath_cdc_source_payload_error;
assign ethernet_txdatapath_cdc_asyncfifo_din = {ethernet_txdatapath_cdc_fifo_in_last, ethernet_txdatapath_cdc_fifo_in_first, ethernet_txdatapath_cdc_fifo_in_payload_error, ethernet_txdatapath_cdc_fifo_in_payload_be, ethernet_txdatapath_cdc_fifo_in_payload_data};
assign {ethernet_txdatapath_cdc_fifo_out_last, ethernet_txdatapath_cdc_fifo_out_first, ethernet_txdatapath_cdc_fifo_out_payload_error, ethernet_txdatapath_cdc_fifo_out_payload_be, ethernet_txdatapath_cdc_fifo_out_payload_data} = ethernet_txdatapath_cdc_asyncfifo_dout;
assign ethernet_txdatapath_cdc_sink_ready = ethernet_txdatapath_cdc_asyncfifo_writable;
assign ethernet_txdatapath_cdc_asyncfifo_we = ethernet_txdatapath_cdc_sink_valid;
assign ethernet_txdatapath_cdc_fifo_in_first = ethernet_txdatapath_cdc_sink_first;
assign ethernet_txdatapath_cdc_fifo_in_last = ethernet_txdatapath_cdc_sink_last;
assign ethernet_txdatapath_cdc_fifo_in_payload_data = ethernet_txdatapath_cdc_sink_payload_data;
assign ethernet_txdatapath_cdc_fifo_in_payload_be = ethernet_txdatapath_cdc_sink_payload_be;
assign ethernet_txdatapath_cdc_fifo_in_payload_error = ethernet_txdatapath_cdc_sink_payload_error;
assign ethernet_txdatapath_cdc_source_valid = ethernet_txdatapath_cdc_asyncfifo_readable;
assign ethernet_txdatapath_cdc_source_first = ethernet_txdatapath_cdc_fifo_out_first;
assign ethernet_txdatapath_cdc_source_last = ethernet_txdatapath_cdc_fifo_out_last;
assign ethernet_txdatapath_cdc_source_payload_data = ethernet_txdatapath_cdc_fifo_out_payload_data;
assign ethernet_txdatapath_cdc_source_payload_be = ethernet_txdatapath_cdc_fifo_out_payload_be;
assign ethernet_txdatapath_cdc_source_payload_error = ethernet_txdatapath_cdc_fifo_out_payload_error;
assign ethernet_txdatapath_cdc_asyncfifo_re = ethernet_txdatapath_cdc_source_ready;
assign ethernet_txdatapath_cdc_graycounter0_ce = (ethernet_txdatapath_cdc_asyncfifo_writable & ethernet_txdatapath_cdc_asyncfifo_we);
assign ethernet_txdatapath_cdc_graycounter1_ce = (ethernet_txdatapath_cdc_asyncfifo_readable & ethernet_txdatapath_cdc_asyncfifo_re);
assign ethernet_txdatapath_cdc_asyncfifo_writable = (((ethernet_txdatapath_cdc_graycounter0_q[5] == ethernet_txdatapath_cdc_consume_wdomain[5]) | (ethernet_txdatapath_cdc_graycounter0_q[4] == ethernet_txdatapath_cdc_consume_wdomain[4])) | (ethernet_txdatapath_cdc_graycounter0_q[3:0] != ethernet_txdatapath_cdc_consume_wdomain[3:0]));
assign ethernet_txdatapath_cdc_asyncfifo_readable = (ethernet_txdatapath_cdc_graycounter1_q != ethernet_txdatapath_cdc_produce_rdomain);
assign ethernet_txdatapath_cdc_wrport_adr = ethernet_txdatapath_cdc_graycounter0_q_binary[4:0];
assign ethernet_txdatapath_cdc_wrport_dat_w = ethernet_txdatapath_cdc_asyncfifo_din;
assign ethernet_txdatapath_cdc_wrport_we = ethernet_txdatapath_cdc_graycounter0_ce;
assign ethernet_txdatapath_cdc_rdport_adr = ethernet_txdatapath_cdc_graycounter1_q_next_binary[4:0];
assign ethernet_txdatapath_cdc_asyncfifo_dout = ethernet_txdatapath_cdc_rdport_dat_r;

// synthesis translate_off
reg dummy_d_20;
// synthesis translate_on
always @(*) begin
	ethernet_txdatapath_cdc_graycounter0_q_next_binary <= 6'd0;
	if (ethernet_txdatapath_cdc_graycounter0_ce) begin
		ethernet_txdatapath_cdc_graycounter0_q_next_binary <= (ethernet_txdatapath_cdc_graycounter0_q_binary + 1'd1);
	end else begin
		ethernet_txdatapath_cdc_graycounter0_q_next_binary <= ethernet_txdatapath_cdc_graycounter0_q_binary;
	end
// synthesis translate_off
	dummy_d_20 <= dummy_s;
// synthesis translate_on
end
assign ethernet_txdatapath_cdc_graycounter0_q_next = (ethernet_txdatapath_cdc_graycounter0_q_next_binary ^ ethernet_txdatapath_cdc_graycounter0_q_next_binary[5:1]);

// synthesis translate_off
reg dummy_d_21;
// synthesis translate_on
always @(*) begin
	ethernet_txdatapath_cdc_graycounter1_q_next_binary <= 6'd0;
	if (ethernet_txdatapath_cdc_graycounter1_ce) begin
		ethernet_txdatapath_cdc_graycounter1_q_next_binary <= (ethernet_txdatapath_cdc_graycounter1_q_binary + 1'd1);
	end else begin
		ethernet_txdatapath_cdc_graycounter1_q_next_binary <= ethernet_txdatapath_cdc_graycounter1_q_binary;
	end
// synthesis translate_off
	dummy_d_21 <= dummy_s;
// synthesis translate_on
end
assign ethernet_txdatapath_cdc_graycounter1_q_next = (ethernet_txdatapath_cdc_graycounter1_q_next_binary ^ ethernet_txdatapath_cdc_graycounter1_q_next_binary[5:1]);
assign ethernet_tx_packet_fifo_payload_fifo_sink_first = ethernet_tx_packet_fifo_sink_sink_first;
assign ethernet_tx_packet_fifo_payload_fifo_sink_last = ethernet_tx_packet_fifo_sink_sink_last;
assign ethernet_tx_packet_fifo_payload_fifo_sink_payload_data = ethernet_tx_packet_fifo_sink_sink_payload_data;
assign ethernet_tx_packet_fifo_payload_fifo_sink_payload_be = ethernet_tx_packet_fifo_sink_sink_payload_be;
assign ethernet_tx_packet_fifo_payload_fifo_sink_payload_error = ethernet_tx_packet_fifo_sink_sink_payload_error;
assign ethernet_tx_packet_fifo_param_fifo_sink_valid = ((ethernet_tx_packet_fifo_sink_sink_valid & ethernet_tx_packet_fifo_sink_sink_last) & ethernet_tx_packet_fifo_payload_fifo_sink_ready);
assign ethernet_tx_packet_fifo_payload_fifo_sink_valid = (ethernet_tx_packet_fifo_sink_sink_valid & ethernet_tx_packet_fifo_param_fifo_sink_ready);
assign ethernet_tx_packet_fifo_sink_sink_ready = (ethernet_tx_packet_fifo_param_fifo_sink_ready & ethernet_tx_packet_fifo_payload_fifo_sink_ready);
assign ethernet_tx_packet_fifo_source_source_valid = ethernet_tx_packet_fifo_param_fifo_source_valid;

// synthesis translate_off
reg dummy_d_22;
// synthesis translate_on
always @(*) begin
	ethernet_tx_packet_fifo_source_source_first <= 1'd0;
	ethernet_tx_packet_fifo_source_source_first <= ethernet_tx_packet_fifo_param_fifo_source_first;
	ethernet_tx_packet_fifo_source_source_first <= ethernet_tx_packet_fifo_payload_fifo_source_first;
// synthesis translate_off
	dummy_d_22 <= dummy_s;
// synthesis translate_on
end
assign ethernet_tx_packet_fifo_source_source_last = ethernet_tx_packet_fifo_payload_fifo_source_last;
assign ethernet_tx_packet_fifo_source_source_payload_data = ethernet_tx_packet_fifo_payload_fifo_source_payload_data;
assign ethernet_tx_packet_fifo_source_source_payload_be = ethernet_tx_packet_fifo_payload_fifo_source_payload_be;
assign ethernet_tx_packet_fifo_source_source_payload_error = ethernet_tx_packet_fifo_payload_fifo_source_payload_error;
assign ethernet_tx_packet_fifo_param_fifo_source_ready = ((ethernet_tx_packet_fifo_source_source_valid & ethernet_tx_packet_fifo_source_source_last) & ethernet_tx_packet_fifo_source_source_ready);
assign ethernet_tx_packet_fifo_payload_fifo_source_ready = (ethernet_tx_packet_fifo_source_source_valid & ethernet_tx_packet_fifo_source_source_ready);
assign ethernet_tx_packet_fifo_payload_fifo_syncfifo_din = {ethernet_tx_packet_fifo_payload_fifo_fifo_in_last, ethernet_tx_packet_fifo_payload_fifo_fifo_in_first, ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_error, ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_be, ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_data};
assign {ethernet_tx_packet_fifo_payload_fifo_fifo_out_last, ethernet_tx_packet_fifo_payload_fifo_fifo_out_first, ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_error, ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_be, ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_data} = ethernet_tx_packet_fifo_payload_fifo_syncfifo_dout;
assign ethernet_tx_packet_fifo_payload_fifo_sink_ready = ethernet_tx_packet_fifo_payload_fifo_syncfifo_writable;
assign ethernet_tx_packet_fifo_payload_fifo_syncfifo_we = ethernet_tx_packet_fifo_payload_fifo_sink_valid;
assign ethernet_tx_packet_fifo_payload_fifo_fifo_in_first = ethernet_tx_packet_fifo_payload_fifo_sink_first;
assign ethernet_tx_packet_fifo_payload_fifo_fifo_in_last = ethernet_tx_packet_fifo_payload_fifo_sink_last;
assign ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_data = ethernet_tx_packet_fifo_payload_fifo_sink_payload_data;
assign ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_be = ethernet_tx_packet_fifo_payload_fifo_sink_payload_be;
assign ethernet_tx_packet_fifo_payload_fifo_fifo_in_payload_error = ethernet_tx_packet_fifo_payload_fifo_sink_payload_error;
assign ethernet_tx_packet_fifo_payload_fifo_source_valid = ethernet_tx_packet_fifo_payload_fifo_readable;
assign ethernet_tx_packet_fifo_payload_fifo_source_first = ethernet_tx_packet_fifo_payload_fifo_fifo_out_first;
assign ethernet_tx_packet_fifo_payload_fifo_source_last = ethernet_tx_packet_fifo_payload_fifo_fifo_out_last;
assign ethernet_tx_packet_fifo_payload_fifo_source_payload_data = ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_data;
assign ethernet_tx_packet_fifo_payload_fifo_source_payload_be = ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_be;
assign ethernet_tx_packet_fifo_payload_fifo_source_payload_error = ethernet_tx_packet_fifo_payload_fifo_fifo_out_payload_error;
assign ethernet_tx_packet_fifo_payload_fifo_re = ethernet_tx_packet_fifo_payload_fifo_source_ready;
assign ethernet_tx_packet_fifo_payload_fifo_syncfifo_re = (ethernet_tx_packet_fifo_payload_fifo_syncfifo_readable & ((~ethernet_tx_packet_fifo_payload_fifo_readable) | ethernet_tx_packet_fifo_payload_fifo_re));
assign ethernet_tx_packet_fifo_payload_fifo_level1 = (ethernet_tx_packet_fifo_payload_fifo_level0 + ethernet_tx_packet_fifo_payload_fifo_readable);

// synthesis translate_off
reg dummy_d_23;
// synthesis translate_on
always @(*) begin
	ethernet_tx_packet_fifo_payload_fifo_wrport_adr <= 11'd0;
	if (ethernet_tx_packet_fifo_payload_fifo_replace) begin
		ethernet_tx_packet_fifo_payload_fifo_wrport_adr <= (ethernet_tx_packet_fifo_payload_fifo_produce - 1'd1);
	end else begin
		ethernet_tx_packet_fifo_payload_fifo_wrport_adr <= ethernet_tx_packet_fifo_payload_fifo_produce;
	end
// synthesis translate_off
	dummy_d_23 <= dummy_s;
// synthesis translate_on
end
assign ethernet_tx_packet_fifo_payload_fifo_wrport_dat_w = ethernet_tx_packet_fifo_payload_fifo_syncfifo_din;
assign ethernet_tx_packet_fifo_payload_fifo_wrport_we = (ethernet_tx_packet_fifo_payload_fifo_syncfifo_we & (ethernet_tx_packet_fifo_payload_fifo_syncfifo_writable | ethernet_tx_packet_fifo_payload_fifo_replace));
assign ethernet_tx_packet_fifo_payload_fifo_do_read = (ethernet_tx_packet_fifo_payload_fifo_syncfifo_readable & ethernet_tx_packet_fifo_payload_fifo_syncfifo_re);
assign ethernet_tx_packet_fifo_payload_fifo_rdport_adr = ethernet_tx_packet_fifo_payload_fifo_consume;
assign ethernet_tx_packet_fifo_payload_fifo_syncfifo_dout = ethernet_tx_packet_fifo_payload_fifo_rdport_dat_r;
assign ethernet_tx_packet_fifo_payload_fifo_rdport_re = ethernet_tx_packet_fifo_payload_fifo_do_read;
assign ethernet_tx_packet_fifo_payload_fifo_syncfifo_writable = (ethernet_tx_packet_fifo_payload_fifo_level0 != 12'd2048);
assign ethernet_tx_packet_fifo_payload_fifo_syncfifo_readable = (ethernet_tx_packet_fifo_payload_fifo_level0 != 1'd0);
assign ethernet_tx_packet_fifo_param_fifo_syncfifo_din = {ethernet_tx_packet_fifo_param_fifo_fifo_in_last, ethernet_tx_packet_fifo_param_fifo_fifo_in_first, ethernet_tx_packet_fifo_param_fifo_fifo_in_param_dummy};
assign {ethernet_tx_packet_fifo_param_fifo_fifo_out_last, ethernet_tx_packet_fifo_param_fifo_fifo_out_first, ethernet_tx_packet_fifo_param_fifo_fifo_out_param_dummy} = ethernet_tx_packet_fifo_param_fifo_syncfifo_dout;
assign ethernet_tx_packet_fifo_param_fifo_sink_ready = ethernet_tx_packet_fifo_param_fifo_syncfifo_writable;
assign ethernet_tx_packet_fifo_param_fifo_syncfifo_we = ethernet_tx_packet_fifo_param_fifo_sink_valid;
assign ethernet_tx_packet_fifo_param_fifo_fifo_in_first = ethernet_tx_packet_fifo_param_fifo_sink_first;
assign ethernet_tx_packet_fifo_param_fifo_fifo_in_last = ethernet_tx_packet_fifo_param_fifo_sink_last;
assign ethernet_tx_packet_fifo_param_fifo_fifo_in_param_dummy = ethernet_tx_packet_fifo_param_fifo_sink_param_dummy;
assign ethernet_tx_packet_fifo_param_fifo_source_valid = ethernet_tx_packet_fifo_param_fifo_readable;
assign ethernet_tx_packet_fifo_param_fifo_source_first = ethernet_tx_packet_fifo_param_fifo_fifo_out_first;
assign ethernet_tx_packet_fifo_param_fifo_source_last = ethernet_tx_packet_fifo_param_fifo_fifo_out_last;
assign ethernet_tx_packet_fifo_param_fifo_source_param_dummy = ethernet_tx_packet_fifo_param_fifo_fifo_out_param_dummy;
assign ethernet_tx_packet_fifo_param_fifo_re = ethernet_tx_packet_fifo_param_fifo_source_ready;
assign ethernet_tx_packet_fifo_param_fifo_syncfifo_re = (ethernet_tx_packet_fifo_param_fifo_syncfifo_readable & ((~ethernet_tx_packet_fifo_param_fifo_readable) | ethernet_tx_packet_fifo_param_fifo_re));
assign ethernet_tx_packet_fifo_param_fifo_level1 = (ethernet_tx_packet_fifo_param_fifo_level0 + ethernet_tx_packet_fifo_param_fifo_readable);

// synthesis translate_off
reg dummy_d_24;
// synthesis translate_on
always @(*) begin
	ethernet_tx_packet_fifo_param_fifo_wrport_adr <= 3'd0;
	if (ethernet_tx_packet_fifo_param_fifo_replace) begin
		ethernet_tx_packet_fifo_param_fifo_wrport_adr <= (ethernet_tx_packet_fifo_param_fifo_produce - 1'd1);
	end else begin
		ethernet_tx_packet_fifo_param_fifo_wrport_adr <= ethernet_tx_packet_fifo_param_fifo_produce;
	end
// synthesis translate_off
	dummy_d_24 <= dummy_s;
// synthesis translate_on
end
assign ethernet_tx_packet_fifo_param_fifo_wrport_dat_w = ethernet_tx_packet_fifo_param_fifo_syncfifo_din;
assign ethernet_tx_packet_fifo_param_fifo_wrport_we = (ethernet_tx_packet_fifo_param_fifo_syncfifo_we & (ethernet_tx_packet_fifo_param_fifo_syncfifo_writable | ethernet_tx_packet_fifo_param_fifo_replace));
assign ethernet_tx_packet_fifo_param_fifo_do_read = (ethernet_tx_packet_fifo_param_fifo_syncfifo_readable & ethernet_tx_packet_fifo_param_fifo_syncfifo_re);
assign ethernet_tx_packet_fifo_param_fifo_rdport_adr = ethernet_tx_packet_fifo_param_fifo_consume;
assign ethernet_tx_packet_fifo_param_fifo_syncfifo_dout = ethernet_tx_packet_fifo_param_fifo_rdport_dat_r;
assign ethernet_tx_packet_fifo_param_fifo_rdport_re = ethernet_tx_packet_fifo_param_fifo_do_read;
assign ethernet_tx_packet_fifo_param_fifo_syncfifo_writable = (ethernet_tx_packet_fifo_param_fifo_level0 != 3'd5);
assign ethernet_tx_packet_fifo_param_fifo_syncfifo_readable = (ethernet_tx_packet_fifo_param_fifo_level0 != 1'd0);

// synthesis translate_off
reg dummy_d_25;
// synthesis translate_on
always @(*) begin
	ethernet_tx_gap_sink_ready <= 1'd0;
	ethernet_tx_gap_source_valid <= 1'd0;
	ethernet_tx_gap_source_first <= 1'd0;
	ethernet_tx_gap_source_last <= 1'd0;
	ethernet_tx_gap_source_payload_data <= 8'd0;
	ethernet_tx_gap_source_payload_be <= 1'd0;
	ethernet_tx_gap_source_payload_error <= 1'd0;
	txdatapath_liteethmacgap_next_state <= 1'd0;
	ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value <= 4'd0;
	ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value_ce <= 1'd0;
	txdatapath_liteethmacgap_next_state <= txdatapath_liteethmacgap_state;
	case (txdatapath_liteethmacgap_state)
		1'd1: begin
			ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value <= (ethernet_tx_gap_counter - 1'd1);
			ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value_ce <= 1'd1;
			if ((ethernet_tx_gap_counter == 1'd1)) begin
				txdatapath_liteethmacgap_next_state <= 1'd0;
			end
		end
		default: begin
			ethernet_tx_gap_source_valid <= ethernet_tx_gap_sink_valid;
			ethernet_tx_gap_sink_ready <= ethernet_tx_gap_source_ready;
			ethernet_tx_gap_source_first <= ethernet_tx_gap_sink_first;
			ethernet_tx_gap_source_last <= ethernet_tx_gap_sink_last;
			ethernet_tx_gap_source_payload_data <= ethernet_tx_gap_sink_payload_data;
			ethernet_tx_gap_source_payload_be <= ethernet_tx_gap_sink_payload_be;
			ethernet_tx_gap_source_payload_error <= ethernet_tx_gap_sink_payload_error;
			if (((ethernet_tx_gap_sink_valid & ethernet_tx_gap_sink_last) & ethernet_tx_gap_sink_ready)) begin
				ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value <= 4'd12;
				ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value_ce <= 1'd1;
				txdatapath_liteethmacgap_next_state <= 1'd1;
			end
		end
	endcase
// synthesis translate_off
	dummy_d_25 <= dummy_s;
// synthesis translate_on
end
assign ethernet_tx_padding_sink_valid = ethernet_sink_valid;
assign ethernet_sink_ready = ethernet_tx_padding_sink_ready;
assign ethernet_tx_padding_sink_first = ethernet_sink_first;
assign ethernet_tx_padding_sink_last = ethernet_sink_last;
assign ethernet_tx_padding_sink_payload_data = ethernet_sink_payload_data;
assign ethernet_tx_padding_sink_payload_be = ethernet_sink_payload_be;
assign ethernet_tx_padding_sink_payload_error = ethernet_sink_payload_error;
assign ethernet_tx_crc_sink_sink_valid = ethernet_tx_padding_source_valid;
assign ethernet_tx_padding_source_ready = ethernet_tx_crc_sink_sink_ready;
assign ethernet_tx_crc_sink_sink_first = ethernet_tx_padding_source_first;
assign ethernet_tx_crc_sink_sink_last = ethernet_tx_padding_source_last;
assign ethernet_tx_crc_sink_sink_payload_data = ethernet_tx_padding_source_payload_data;
assign ethernet_tx_crc_sink_sink_payload_be = ethernet_tx_padding_source_payload_be;
assign ethernet_tx_crc_sink_sink_payload_error = ethernet_tx_padding_source_payload_error;
assign ethernet_tx_preamble_sink_valid = ethernet_tx_crc_source_valid;
assign ethernet_tx_crc_source_ready = ethernet_tx_preamble_sink_ready;
assign ethernet_tx_preamble_sink_first = ethernet_tx_crc_source_first;
assign ethernet_tx_preamble_sink_last = ethernet_tx_crc_source_last;
assign ethernet_tx_preamble_sink_payload_data = ethernet_tx_crc_source_payload_data;
assign ethernet_tx_preamble_sink_payload_be = ethernet_tx_crc_source_payload_be;
assign ethernet_tx_preamble_sink_payload_error = ethernet_tx_crc_source_payload_error;
assign ethernet_txdatapath_sink_sink_valid = ethernet_tx_preamble_source_valid;
assign ethernet_tx_preamble_source_ready = ethernet_txdatapath_sink_sink_ready;
assign ethernet_txdatapath_sink_sink_first = ethernet_tx_preamble_source_first;
assign ethernet_txdatapath_sink_sink_last = ethernet_tx_preamble_source_last;
assign ethernet_txdatapath_sink_sink_payload_data = ethernet_tx_preamble_source_payload_data;
assign ethernet_txdatapath_sink_sink_payload_be = ethernet_tx_preamble_source_payload_be;
assign ethernet_txdatapath_sink_sink_payload_error = ethernet_tx_preamble_source_payload_error;
assign ethernet_tx_packet_fifo_sink_sink_valid = ethernet_txdatapath_source_source_valid;
assign ethernet_txdatapath_source_source_ready = ethernet_tx_packet_fifo_sink_sink_ready;
assign ethernet_tx_packet_fifo_sink_sink_first = ethernet_txdatapath_source_source_first;
assign ethernet_tx_packet_fifo_sink_sink_last = ethernet_txdatapath_source_source_last;
assign ethernet_tx_packet_fifo_sink_sink_payload_data = ethernet_txdatapath_source_source_payload_data;
assign ethernet_tx_packet_fifo_sink_sink_payload_be = ethernet_txdatapath_source_source_payload_be;
assign ethernet_tx_packet_fifo_sink_sink_payload_error = ethernet_txdatapath_source_source_payload_error;
assign ethernet_tx_gap_sink_valid = ethernet_tx_packet_fifo_source_source_valid;
assign ethernet_tx_packet_fifo_source_source_ready = ethernet_tx_gap_sink_ready;
assign ethernet_tx_gap_sink_first = ethernet_tx_packet_fifo_source_source_first;
assign ethernet_tx_gap_sink_last = ethernet_tx_packet_fifo_source_source_last;
assign ethernet_tx_gap_sink_payload_data = ethernet_tx_packet_fifo_source_source_payload_data;
assign ethernet_tx_gap_sink_payload_be = ethernet_tx_packet_fifo_source_source_payload_be;
assign ethernet_tx_gap_sink_payload_error = ethernet_tx_packet_fifo_source_source_payload_error;
assign ethernet_sink_sink_valid = ethernet_tx_gap_source_valid;
assign ethernet_tx_gap_source_ready = ethernet_sink_sink_ready;
assign ethernet_sink_sink_first = ethernet_tx_gap_source_first;
assign ethernet_sink_sink_last = ethernet_tx_gap_source_last;
assign ethernet_sink_sink_payload_data = ethernet_tx_gap_source_payload_data;
assign ethernet_sink_sink_payload_be = ethernet_tx_gap_source_payload_be;
assign ethernet_sink_sink_payload_error = ethernet_tx_gap_source_payload_error;
assign ethernet_i = ethernet_rx_packet_fifo_drop;
assign ethernet_pulsesynchronizer0_i = ethernet_rx_preamble_error;
assign ethernet_pulsesynchronizer1_i = ethernet_liteethmaccrc32checker_error;
assign ethernet_rx_packet_fifo_used = (ethernet_rx_packet_fifo_wr_ptr - (ethernet_rx_packet_fifo_rd_ptr - ethernet_rx_packet_fifo_out_valid));
assign ethernet_rx_packet_fifo_full = (ethernet_rx_packet_fifo_used == 12'd2048);
assign ethernet_rx_packet_fifo_sink_sink_ready = 1'd1;
assign ethernet_rx_packet_fifo_wr_port_adr = ethernet_rx_packet_fifo_wr_ptr[10:0];
assign ethernet_rx_packet_fifo_wr_port_dat_w = {ethernet_rx_packet_fifo_sink_sink_last, ethernet_rx_packet_fifo_sink_sink_first, {ethernet_rx_packet_fifo_sink_sink_payload_error, ethernet_rx_packet_fifo_sink_sink_payload_be, ethernet_rx_packet_fifo_sink_sink_payload_data}};
assign ethernet_rx_packet_fifo_wr_port_we = ((ethernet_rx_packet_fifo_sink_sink_valid & (~ethernet_rx_packet_fifo_overflow)) & (~ethernet_rx_packet_fifo_full));
assign ethernet_rx_packet_fifo_commit = ((((((ethernet_rx_packet_fifo_sink_sink_valid & ethernet_rx_packet_fifo_sink_sink_last) & (~ethernet_rx_packet_fifo_overflow)) & (~ethernet_rx_packet_fifo_full)) & (~ethernet_rx_packet_fifo_invalid)) & (~ethernet_rx_packet_fifo_discard)) & ethernet_rx_packet_fifo_param_fifo_sink_ready);
assign ethernet_rx_packet_fifo_param_fifo_sink_valid = ethernet_rx_packet_fifo_commit;
assign ethernet_rx_packet_fifo_param_fifo_sink_last = 1'd1;
assign ethernet_rx_packet_fifo_drop = ((ethernet_rx_packet_fifo_sink_sink_valid & ethernet_rx_packet_fifo_sink_sink_last) & (~ethernet_rx_packet_fifo_commit));
assign ethernet_rx_packet_fifo_fetch = ((ethernet_rx_packet_fifo_rd_ptr != ethernet_rx_packet_fifo_commit_ptr) & ((~ethernet_rx_packet_fifo_out_valid) | (ethernet_rx_packet_fifo_source_source_valid & ethernet_rx_packet_fifo_source_source_ready)));
assign ethernet_rx_packet_fifo_rd_port_adr = ethernet_rx_packet_fifo_rd_ptr[10:0];
assign ethernet_rx_packet_fifo_rd_port_re = ethernet_rx_packet_fifo_fetch;
assign {ethernet_rx_packet_fifo_source_source_payload_error, ethernet_rx_packet_fifo_source_source_payload_be, ethernet_rx_packet_fifo_source_source_payload_data} = ethernet_rx_packet_fifo_rd_port_dat_r[9:0];
assign ethernet_rx_packet_fifo_source_source_first = ethernet_rx_packet_fifo_rd_port_dat_r[10];
assign ethernet_rx_packet_fifo_source_source_last = ethernet_rx_packet_fifo_rd_port_dat_r[11];
assign ethernet_rx_packet_fifo_source_source_valid = (ethernet_rx_packet_fifo_out_valid & ethernet_rx_packet_fifo_param_fifo_source_valid);
assign ethernet_rx_packet_fifo_param_fifo_source_ready = ((ethernet_rx_packet_fifo_source_source_valid & ethernet_rx_packet_fifo_source_source_last) & ethernet_rx_packet_fifo_source_source_ready);
assign ethernet_rx_packet_fifo_param_fifo_syncfifo_din = {ethernet_rx_packet_fifo_param_fifo_fifo_in_last, ethernet_rx_packet_fifo_param_fifo_fifo_in_first, ethernet_rx_packet_fifo_param_fifo_fifo_in_param_dummy};
assign {ethernet_rx_packet_fifo_param_fifo_fifo_out_last, ethernet_rx_packet_fifo_param_fifo_fifo_out_first, ethernet_rx_packet_fifo_param_fifo_fifo_out_param_dummy} = ethernet_rx_packet_fifo_param_fifo_syncfifo_dout;
assign ethernet_rx_packet_fifo_param_fifo_sink_ready = ethernet_rx_packet_fifo_param_fifo_syncfifo_writable;
assign ethernet_rx_packet_fifo_param_fifo_syncfifo_we = ethernet_rx_packet_fifo_param_fifo_sink_valid;
assign ethernet_rx_packet_fifo_param_fifo_fifo_in_first = ethernet_rx_packet_fifo_param_fifo_sink_first;
assign ethernet_rx_packet_fifo_param_fifo_fifo_in_last = ethernet_rx_packet_fifo_param_fifo_sink_last;
assign ethernet_rx_packet_fifo_param_fifo_fifo_in_param_dummy = ethernet_rx_packet_fifo_param_fifo_sink_param_dummy;
assign ethernet_rx_packet_fifo_param_fifo_source_valid = ethernet_rx_packet_fifo_param_fifo_syncfifo_readable;
assign ethernet_rx_packet_fifo_param_fifo_source_first = ethernet_rx_packet_fifo_param_fifo_fifo_out_first;
assign ethernet_rx_packet_fifo_param_fifo_source_last = ethernet_rx_packet_fifo_param_fifo_fifo_out_last;
assign ethernet_rx_packet_fifo_param_fifo_source_param_dummy = ethernet_rx_packet_fifo_param_fifo_fifo_out_param_dummy;
assign ethernet_rx_packet_fifo_param_fifo_syncfifo_re = ethernet_rx_packet_fifo_param_fifo_source_ready;

// synthesis translate_off
reg dummy_d_26;
// synthesis translate_on
always @(*) begin
	ethernet_rx_packet_fifo_param_fifo_wrport_adr <= 2'd0;
	if (ethernet_rx_packet_fifo_param_fifo_replace) begin
		ethernet_rx_packet_fifo_param_fifo_wrport_adr <= (ethernet_rx_packet_fifo_param_fifo_produce - 1'd1);
	end else begin
		ethernet_rx_packet_fifo_param_fifo_wrport_adr <= ethernet_rx_packet_fifo_param_fifo_produce;
	end
// synthesis translate_off
	dummy_d_26 <= dummy_s;
// synthesis translate_on
end
assign ethernet_rx_packet_fifo_param_fifo_wrport_dat_w = ethernet_rx_packet_fifo_param_fifo_syncfifo_din;
assign ethernet_rx_packet_fifo_param_fifo_wrport_we = (ethernet_rx_packet_fifo_param_fifo_syncfifo_we & (ethernet_rx_packet_fifo_param_fifo_syncfifo_writable | ethernet_rx_packet_fifo_param_fifo_replace));
assign ethernet_rx_packet_fifo_param_fifo_do_read = (ethernet_rx_packet_fifo_param_fifo_syncfifo_readable & ethernet_rx_packet_fifo_param_fifo_syncfifo_re);
assign ethernet_rx_packet_fifo_param_fifo_rdport_adr = ethernet_rx_packet_fifo_param_fifo_consume;
assign ethernet_rx_packet_fifo_param_fifo_syncfifo_dout = ethernet_rx_packet_fifo_param_fifo_rdport_dat_r;
assign ethernet_rx_packet_fifo_param_fifo_syncfifo_writable = (ethernet_rx_packet_fifo_param_fifo_level != 3'd4);
assign ethernet_rx_packet_fifo_param_fifo_syncfifo_readable = (ethernet_rx_packet_fifo_param_fifo_level != 1'd0);
assign ethernet_o = (ethernet_toggle_o ^ ethernet_toggle_o_r);
assign ethernet_rx_cdc_cdc_sink_valid = ethernet_rx_cdc_sink_sink_valid;
assign ethernet_rx_cdc_sink_sink_ready = ethernet_rx_cdc_cdc_sink_ready;
assign ethernet_rx_cdc_cdc_sink_first = ethernet_rx_cdc_sink_sink_first;
assign ethernet_rx_cdc_cdc_sink_last = ethernet_rx_cdc_sink_sink_last;
assign ethernet_rx_cdc_cdc_sink_payload_data = ethernet_rx_cdc_sink_sink_payload_data;
assign ethernet_rx_cdc_cdc_sink_payload_be = ethernet_rx_cdc_sink_sink_payload_be;
assign ethernet_rx_cdc_cdc_sink_payload_error = ethernet_rx_cdc_sink_sink_payload_error;
assign ethernet_rx_cdc_source_source_valid = ethernet_rx_cdc_cdc_source_valid;
assign ethernet_rx_cdc_cdc_source_ready = ethernet_rx_cdc_source_source_ready;
assign ethernet_rx_cdc_source_source_first = ethernet_rx_cdc_cdc_source_first;
assign ethernet_rx_cdc_source_source_last = ethernet_rx_cdc_cdc_source_last;
assign ethernet_rx_cdc_source_source_payload_data = ethernet_rx_cdc_cdc_source_payload_data;
assign ethernet_rx_cdc_source_source_payload_be = ethernet_rx_cdc_cdc_source_payload_be;
assign ethernet_rx_cdc_source_source_payload_error = ethernet_rx_cdc_cdc_source_payload_error;
assign ethernet_rx_cdc_cdc_asyncfifo_din = {ethernet_rx_cdc_cdc_fifo_in_last, ethernet_rx_cdc_cdc_fifo_in_first, ethernet_rx_cdc_cdc_fifo_in_payload_error, ethernet_rx_cdc_cdc_fifo_in_payload_be, ethernet_rx_cdc_cdc_fifo_in_payload_data};
assign {ethernet_rx_cdc_cdc_fifo_out_last, ethernet_rx_cdc_cdc_fifo_out_first, ethernet_rx_cdc_cdc_fifo_out_payload_error, ethernet_rx_cdc_cdc_fifo_out_payload_be, ethernet_rx_cdc_cdc_fifo_out_payload_data} = ethernet_rx_cdc_cdc_asyncfifo_dout;
assign ethernet_rx_cdc_cdc_sink_ready = ethernet_rx_cdc_cdc_asyncfifo_writable;
assign ethernet_rx_cdc_cdc_asyncfifo_we = ethernet_rx_cdc_cdc_sink_valid;
assign ethernet_rx_cdc_cdc_fifo_in_first = ethernet_rx_cdc_cdc_sink_first;
assign ethernet_rx_cdc_cdc_fifo_in_last = ethernet_rx_cdc_cdc_sink_last;
assign ethernet_rx_cdc_cdc_fifo_in_payload_data = ethernet_rx_cdc_cdc_sink_payload_data;
assign ethernet_rx_cdc_cdc_fifo_in_payload_be = ethernet_rx_cdc_cdc_sink_payload_be;
assign ethernet_rx_cdc_cdc_fifo_in_payload_error = ethernet_rx_cdc_cdc_sink_payload_error;
assign ethernet_rx_cdc_cdc_source_valid = ethernet_rx_cdc_cdc_asyncfifo_readable;
assign ethernet_rx_cdc_cdc_source_first = ethernet_rx_cdc_cdc_fifo_out_first;
assign ethernet_rx_cdc_cdc_source_last = ethernet_rx_cdc_cdc_fifo_out_last;
assign ethernet_rx_cdc_cdc_source_payload_data = ethernet_rx_cdc_cdc_fifo_out_payload_data;
assign ethernet_rx_cdc_cdc_source_payload_be = ethernet_rx_cdc_cdc_fifo_out_payload_be;
assign ethernet_rx_cdc_cdc_source_payload_error = ethernet_rx_cdc_cdc_fifo_out_payload_error;
assign ethernet_rx_cdc_cdc_asyncfifo_re = ethernet_rx_cdc_cdc_source_ready;
assign ethernet_rx_cdc_cdc_graycounter0_ce = (ethernet_rx_cdc_cdc_asyncfifo_writable & ethernet_rx_cdc_cdc_asyncfifo_we);
assign ethernet_rx_cdc_cdc_graycounter1_ce = (ethernet_rx_cdc_cdc_asyncfifo_readable & ethernet_rx_cdc_cdc_asyncfifo_re);
assign ethernet_rx_cdc_cdc_asyncfifo_writable = (((ethernet_rx_cdc_cdc_graycounter0_q[5] == ethernet_rx_cdc_cdc_consume_wdomain[5]) | (ethernet_rx_cdc_cdc_graycounter0_q[4] == ethernet_rx_cdc_cdc_consume_wdomain[4])) | (ethernet_rx_cdc_cdc_graycounter0_q[3:0] != ethernet_rx_cdc_cdc_consume_wdomain[3:0]));
assign ethernet_rx_cdc_cdc_asyncfifo_readable = (ethernet_rx_cdc_cdc_graycounter1_q != ethernet_rx_cdc_cdc_produce_rdomain);
assign ethernet_rx_cdc_cdc_wrport_adr = ethernet_rx_cdc_cdc_graycounter0_q_binary[4:0];
assign ethernet_rx_cdc_cdc_wrport_dat_w = ethernet_rx_cdc_cdc_asyncfifo_din;
assign ethernet_rx_cdc_cdc_wrport_we = ethernet_rx_cdc_cdc_graycounter0_ce;
assign ethernet_rx_cdc_cdc_rdport_adr = ethernet_rx_cdc_cdc_graycounter1_q_next_binary[4:0];
assign ethernet_rx_cdc_cdc_asyncfifo_dout = ethernet_rx_cdc_cdc_rdport_dat_r;

// synthesis translate_off
reg dummy_d_27;
// synthesis translate_on
always @(*) begin
	ethernet_rx_cdc_cdc_graycounter0_q_next_binary <= 6'd0;
	if (ethernet_rx_cdc_cdc_graycounter0_ce) begin
		ethernet_rx_cdc_cdc_graycounter0_q_next_binary <= (ethernet_rx_cdc_cdc_graycounter0_q_binary + 1'd1);
	end else begin
		ethernet_rx_cdc_cdc_graycounter0_q_next_binary <= ethernet_rx_cdc_cdc_graycounter0_q_binary;
	end
// synthesis translate_off
	dummy_d_27 <= dummy_s;
// synthesis translate_on
end
assign ethernet_rx_cdc_cdc_graycounter0_q_next = (ethernet_rx_cdc_cdc_graycounter0_q_next_binary ^ ethernet_rx_cdc_cdc_graycounter0_q_next_binary[5:1]);

// synthesis translate_off
reg dummy_d_28;
// synthesis translate_on
always @(*) begin
	ethernet_rx_cdc_cdc_graycounter1_q_next_binary <= 6'd0;
	if (ethernet_rx_cdc_cdc_graycounter1_ce) begin
		ethernet_rx_cdc_cdc_graycounter1_q_next_binary <= (ethernet_rx_cdc_cdc_graycounter1_q_binary + 1'd1);
	end else begin
		ethernet_rx_cdc_cdc_graycounter1_q_next_binary <= ethernet_rx_cdc_cdc_graycounter1_q_binary;
	end
// synthesis translate_off
	dummy_d_28 <= dummy_s;
// synthesis translate_on
end
assign ethernet_rx_cdc_cdc_graycounter1_q_next = (ethernet_rx_cdc_cdc_graycounter1_q_next_binary ^ ethernet_rx_cdc_cdc_graycounter1_q_next_binary[5:1]);
assign ethernet_rx_preamble_source_payload_data = ethernet_rx_preamble_sink_payload_data;
assign ethernet_rx_preamble_source_payload_be = ethernet_rx_preamble_sink_payload_be;

// synthesis translate_off
reg dummy_d_29;
// synthesis translate_on
always @(*) begin
	ethernet_rx_preamble_sink_ready <= 1'd0;
	ethernet_rx_preamble_source_valid <= 1'd0;
	ethernet_rx_preamble_source_first <= 1'd0;
	ethernet_rx_preamble_source_last <= 1'd0;
	ethernet_rx_preamble_source_payload_error <= 1'd0;
	ethernet_rx_preamble_error <= 1'd0;
	rxdatapath_liteethmacpreamblechecker_next_state <= 1'd0;
	rxdatapath_liteethmacpreamblechecker_next_state <= rxdatapath_liteethmacpreamblechecker_state;
	case (rxdatapath_liteethmacpreamblechecker_state)
		1'd1: begin
			ethernet_rx_preamble_source_valid <= ethernet_rx_preamble_sink_valid;
			ethernet_rx_preamble_sink_ready <= ethernet_rx_preamble_source_ready;
			ethernet_rx_preamble_source_first <= ethernet_rx_preamble_sink_first;
			ethernet_rx_preamble_source_last <= ethernet_rx_preamble_sink_last;
			ethernet_rx_preamble_source_payload_error <= ethernet_rx_preamble_sink_payload_error;
			if (((ethernet_rx_preamble_source_valid & ethernet_rx_preamble_source_last) & ethernet_rx_preamble_source_ready)) begin
				rxdatapath_liteethmacpreamblechecker_next_state <= 1'd0;
			end
		end
		default: begin
			ethernet_rx_preamble_sink_ready <= 1'd1;
			if (((ethernet_rx_preamble_sink_valid & (~ethernet_rx_preamble_sink_last)) & (ethernet_rx_preamble_sink_payload_data == ethernet_rx_preamble_preamble[63:56]))) begin
				rxdatapath_liteethmacpreamblechecker_next_state <= 1'd1;
			end
			if ((ethernet_rx_preamble_sink_valid & ethernet_rx_preamble_sink_last)) begin
				ethernet_rx_preamble_error <= 1'd1;
			end
		end
	endcase
// synthesis translate_off
	dummy_d_29 <= dummy_s;
// synthesis translate_on
end
assign ethernet_pulsesynchronizer0_o = (ethernet_pulsesynchronizer0_toggle_o ^ ethernet_pulsesynchronizer0_toggle_o_r);
assign ethernet_liteethmaccrc32checker_fifo_full = (ethernet_liteethmaccrc32checker_syncfifo_level == 3'd4);
assign ethernet_liteethmaccrc32checker_fifo_out = (ethernet_liteethmaccrc32checker_source_source_valid & ethernet_liteethmaccrc32checker_source_source_ready);
assign ethernet_liteethmaccrc32checker_syncfifo_sink_first = ethernet_liteethmaccrc32checker_sink_sink_first;
assign ethernet_liteethmaccrc32checker_syncfifo_sink_last = ethernet_liteethmaccrc32checker_sink_sink_last;
assign ethernet_liteethmaccrc32checker_syncfifo_sink_payload_data = ethernet_liteethmaccrc32checker_sink_sink_payload_data;
assign ethernet_liteethmaccrc32checker_syncfifo_sink_payload_be = ethernet_liteethmaccrc32checker_sink_sink_payload_be;
assign ethernet_liteethmaccrc32checker_syncfifo_sink_payload_error = ethernet_liteethmaccrc32checker_sink_sink_payload_error;

// synthesis translate_off
reg dummy_d_30;
// synthesis translate_on
always @(*) begin
	ethernet_liteethmaccrc32checker_syncfifo_sink_valid <= 1'd0;
	ethernet_liteethmaccrc32checker_syncfifo_sink_valid <= ethernet_liteethmaccrc32checker_sink_sink_valid;
	ethernet_liteethmaccrc32checker_syncfifo_sink_valid <= ethernet_liteethmaccrc32checker_fifo_in;
// synthesis translate_off
	dummy_d_30 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_31;
// synthesis translate_on
always @(*) begin
	ethernet_liteethmaccrc32checker_sink_sink_ready <= 1'd0;
	ethernet_liteethmaccrc32checker_sink_sink_ready <= ethernet_liteethmaccrc32checker_syncfifo_sink_ready;
	ethernet_liteethmaccrc32checker_sink_sink_ready <= ethernet_liteethmaccrc32checker_fifo_in;
// synthesis translate_off
	dummy_d_31 <= dummy_s;
// synthesis translate_on
end
assign ethernet_liteethmaccrc32checker_fifo_in = (((ethernet_liteethmaccrc32checker_sink_sink_valid & ((~ethernet_liteethmaccrc32checker_fifo_full) | ethernet_liteethmaccrc32checker_fifo_out)) & (~ethernet_liteethmaccrc32checker_is_ongoing0)) & (~ethernet_liteethmaccrc32checker_is_ongoing1));
assign ethernet_liteethmaccrc32checker_crc_data0 = ethernet_liteethmaccrc32checker_sink_sink_payload_data;
assign ethernet_liteethmaccrc32checker_crc_be = ethernet_liteethmaccrc32checker_sink_sink_payload_be;
assign ethernet_liteethmaccrc32checker_last_word_error = ((ethernet_liteethmaccrc32checker_crc_error | ethernet_liteethmaccrc32checker_packet_error) | ((ethernet_liteethmaccrc32checker_sink_sink_payload_error & ethernet_liteethmaccrc32checker_sink_sink_payload_be) != 1'd0));
assign ethernet_liteethmaccrc32checker_source_source_first = ethernet_liteethmaccrc32checker_syncfifo_source_first;
assign ethernet_liteethmaccrc32checker_source_source_payload_data = ethernet_liteethmaccrc32checker_syncfifo_source_payload_data;
assign ethernet_liteethmaccrc32checker_sink_sink_valid = ethernet_bufferizeendpoints_source_source_valid;
assign ethernet_bufferizeendpoints_source_source_ready = ethernet_liteethmaccrc32checker_sink_sink_ready;
assign ethernet_liteethmaccrc32checker_sink_sink_first = ethernet_bufferizeendpoints_source_source_first;
assign ethernet_liteethmaccrc32checker_sink_sink_last = ethernet_bufferizeendpoints_source_source_last;
assign ethernet_liteethmaccrc32checker_sink_sink_payload_data = ethernet_bufferizeendpoints_source_source_payload_data;
assign ethernet_liteethmaccrc32checker_sink_sink_payload_be = ethernet_bufferizeendpoints_source_source_payload_be;
assign ethernet_liteethmaccrc32checker_sink_sink_payload_error = ethernet_bufferizeendpoints_source_source_payload_error;
assign ethernet_liteethmaccrc32checker_crc_crc_prev = ethernet_liteethmaccrc32checker_crc_reg;

// synthesis translate_off
reg dummy_d_32;
// synthesis translate_on
always @(*) begin
	ethernet_liteethmaccrc32checker_crc_error <= 1'd0;
	ethernet_liteethmaccrc32checker_crc_data1 <= 8'd0;
	ethernet_liteethmaccrc32checker_crc_data1 <= ethernet_liteethmaccrc32checker_crc_data0;
	if (ethernet_liteethmaccrc32checker_crc_be) begin
		ethernet_liteethmaccrc32checker_crc_data1 <= (ethernet_liteethmaccrc32checker_crc_data0 & 8'd255);
		ethernet_liteethmaccrc32checker_crc_error <= (ethernet_liteethmaccrc32checker_crc_crc_next != 32'd3338984827);
	end
// synthesis translate_off
	dummy_d_32 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_33;
// synthesis translate_on
always @(*) begin
	ethernet_liteethmaccrc32checker_crc_crc_next <= 32'd0;
	ethernet_liteethmaccrc32checker_crc_crc_next[0] <= (((ethernet_liteethmaccrc32checker_crc_crc_prev[24] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[1] <= (((((((ethernet_liteethmaccrc32checker_crc_crc_prev[25] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[2] <= (((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[26] ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[3] <= (((((((ethernet_liteethmaccrc32checker_crc_crc_prev[27] ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]);
	ethernet_liteethmaccrc32checker_crc_crc_next[4] <= (((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[28] ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[5] <= (((((((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[29] ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[6] <= (((((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[30] ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]);
	ethernet_liteethmaccrc32checker_crc_crc_next[7] <= (((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[31] ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[8] <= ((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[0] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[9] <= ((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[1] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]);
	ethernet_liteethmaccrc32checker_crc_crc_next[10] <= ((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[2] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[11] <= ((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[3] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[12] <= ((((((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[4] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[13] <= ((((((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[5] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]);
	ethernet_liteethmaccrc32checker_crc_crc_next[14] <= ((((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[6] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]);
	ethernet_liteethmaccrc32checker_crc_crc_next[15] <= ((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[7] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]);
	ethernet_liteethmaccrc32checker_crc_crc_next[16] <= ((((((ethernet_liteethmaccrc32checker_crc_crc_prev[8] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[17] <= ((((((ethernet_liteethmaccrc32checker_crc_crc_prev[9] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]);
	ethernet_liteethmaccrc32checker_crc_crc_next[18] <= ((((((ethernet_liteethmaccrc32checker_crc_crc_prev[10] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]);
	ethernet_liteethmaccrc32checker_crc_crc_next[19] <= ((((ethernet_liteethmaccrc32checker_crc_crc_prev[11] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]);
	ethernet_liteethmaccrc32checker_crc_crc_next[20] <= ((ethernet_liteethmaccrc32checker_crc_crc_prev[12] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]);
	ethernet_liteethmaccrc32checker_crc_crc_next[21] <= ((ethernet_liteethmaccrc32checker_crc_crc_prev[13] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]);
	ethernet_liteethmaccrc32checker_crc_crc_next[22] <= ((ethernet_liteethmaccrc32checker_crc_crc_prev[14] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[23] <= ((((((ethernet_liteethmaccrc32checker_crc_crc_prev[15] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[24] <= ((((((ethernet_liteethmaccrc32checker_crc_crc_prev[16] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]);
	ethernet_liteethmaccrc32checker_crc_crc_next[25] <= ((((ethernet_liteethmaccrc32checker_crc_crc_prev[17] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]);
	ethernet_liteethmaccrc32checker_crc_crc_next[26] <= ((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[18] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[24]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_data1[7]);
	ethernet_liteethmaccrc32checker_crc_crc_next[27] <= ((((((((ethernet_liteethmaccrc32checker_crc_crc_prev[19] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[25]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_data1[6]);
	ethernet_liteethmaccrc32checker_crc_crc_next[28] <= ((((((ethernet_liteethmaccrc32checker_crc_crc_prev[20] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[26]) ^ ethernet_liteethmaccrc32checker_crc_data1[5]);
	ethernet_liteethmaccrc32checker_crc_crc_next[29] <= ((((((ethernet_liteethmaccrc32checker_crc_crc_prev[21] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[30]) ^ ethernet_liteethmaccrc32checker_crc_data1[1]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[27]) ^ ethernet_liteethmaccrc32checker_crc_data1[4]);
	ethernet_liteethmaccrc32checker_crc_crc_next[30] <= ((((ethernet_liteethmaccrc32checker_crc_crc_prev[22] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[31]) ^ ethernet_liteethmaccrc32checker_crc_data1[0]) ^ ethernet_liteethmaccrc32checker_crc_crc_prev[28]) ^ ethernet_liteethmaccrc32checker_crc_data1[3]);
	ethernet_liteethmaccrc32checker_crc_crc_next[31] <= ((ethernet_liteethmaccrc32checker_crc_crc_prev[23] ^ ethernet_liteethmaccrc32checker_crc_crc_prev[29]) ^ ethernet_liteethmaccrc32checker_crc_data1[2]);
// synthesis translate_off
	dummy_d_33 <= dummy_s;
// synthesis translate_on
end
assign ethernet_liteethmaccrc32checker_syncfifo_syncfifo_din = {ethernet_liteethmaccrc32checker_syncfifo_fifo_in_last, ethernet_liteethmaccrc32checker_syncfifo_fifo_in_first, ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_error, ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_be, ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_data};
assign {ethernet_liteethmaccrc32checker_syncfifo_fifo_out_last, ethernet_liteethmaccrc32checker_syncfifo_fifo_out_first, ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_error, ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_be, ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_data} = ethernet_liteethmaccrc32checker_syncfifo_syncfifo_dout;
assign ethernet_liteethmaccrc32checker_syncfifo_sink_ready = ethernet_liteethmaccrc32checker_syncfifo_syncfifo_writable;
assign ethernet_liteethmaccrc32checker_syncfifo_syncfifo_we = ethernet_liteethmaccrc32checker_syncfifo_sink_valid;
assign ethernet_liteethmaccrc32checker_syncfifo_fifo_in_first = ethernet_liteethmaccrc32checker_syncfifo_sink_first;
assign ethernet_liteethmaccrc32checker_syncfifo_fifo_in_last = ethernet_liteethmaccrc32checker_syncfifo_sink_last;
assign ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_data = ethernet_liteethmaccrc32checker_syncfifo_sink_payload_data;
assign ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_be = ethernet_liteethmaccrc32checker_syncfifo_sink_payload_be;
assign ethernet_liteethmaccrc32checker_syncfifo_fifo_in_payload_error = ethernet_liteethmaccrc32checker_syncfifo_sink_payload_error;
assign ethernet_liteethmaccrc32checker_syncfifo_source_valid = ethernet_liteethmaccrc32checker_syncfifo_syncfifo_readable;
assign ethernet_liteethmaccrc32checker_syncfifo_source_first = ethernet_liteethmaccrc32checker_syncfifo_fifo_out_first;
assign ethernet_liteethmaccrc32checker_syncfifo_source_last = ethernet_liteethmaccrc32checker_syncfifo_fifo_out_last;
assign ethernet_liteethmaccrc32checker_syncfifo_source_payload_data = ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_data;
assign ethernet_liteethmaccrc32checker_syncfifo_source_payload_be = ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_be;
assign ethernet_liteethmaccrc32checker_syncfifo_source_payload_error = ethernet_liteethmaccrc32checker_syncfifo_fifo_out_payload_error;
assign ethernet_liteethmaccrc32checker_syncfifo_syncfifo_re = ethernet_liteethmaccrc32checker_syncfifo_source_ready;

// synthesis translate_off
reg dummy_d_34;
// synthesis translate_on
always @(*) begin
	ethernet_liteethmaccrc32checker_syncfifo_wrport_adr <= 3'd0;
	if (ethernet_liteethmaccrc32checker_syncfifo_replace) begin
		ethernet_liteethmaccrc32checker_syncfifo_wrport_adr <= (ethernet_liteethmaccrc32checker_syncfifo_produce - 1'd1);
	end else begin
		ethernet_liteethmaccrc32checker_syncfifo_wrport_adr <= ethernet_liteethmaccrc32checker_syncfifo_produce;
	end
// synthesis translate_off
	dummy_d_34 <= dummy_s;
// synthesis translate_on
end
assign ethernet_liteethmaccrc32checker_syncfifo_wrport_dat_w = ethernet_liteethmaccrc32checker_syncfifo_syncfifo_din;
assign ethernet_liteethmaccrc32checker_syncfifo_wrport_we = (ethernet_liteethmaccrc32checker_syncfifo_syncfifo_we & (ethernet_liteethmaccrc32checker_syncfifo_syncfifo_writable | ethernet_liteethmaccrc32checker_syncfifo_replace));
assign ethernet_liteethmaccrc32checker_syncfifo_do_read = (ethernet_liteethmaccrc32checker_syncfifo_syncfifo_readable & ethernet_liteethmaccrc32checker_syncfifo_syncfifo_re);
assign ethernet_liteethmaccrc32checker_syncfifo_rdport_adr = ethernet_liteethmaccrc32checker_syncfifo_consume;
assign ethernet_liteethmaccrc32checker_syncfifo_syncfifo_dout = ethernet_liteethmaccrc32checker_syncfifo_rdport_dat_r;
assign ethernet_liteethmaccrc32checker_syncfifo_syncfifo_writable = (ethernet_liteethmaccrc32checker_syncfifo_level != 3'd5);
assign ethernet_liteethmaccrc32checker_syncfifo_syncfifo_readable = (ethernet_liteethmaccrc32checker_syncfifo_level != 1'd0);

// synthesis translate_off
reg dummy_d_35;
// synthesis translate_on
always @(*) begin
	ethernet_liteethmaccrc32checker_source_source_valid <= 1'd0;
	ethernet_liteethmaccrc32checker_source_source_last <= 1'd0;
	ethernet_liteethmaccrc32checker_source_source_payload_be <= 1'd0;
	ethernet_liteethmaccrc32checker_source_source_payload_error <= 1'd0;
	ethernet_liteethmaccrc32checker_error <= 1'd0;
	ethernet_liteethmaccrc32checker_crc_ce <= 1'd0;
	ethernet_liteethmaccrc32checker_crc_reset <= 1'd0;
	ethernet_liteethmaccrc32checker_syncfifo_source_ready <= 1'd0;
	ethernet_liteethmaccrc32checker_fifo_reset <= 1'd0;
	ethernet_liteethmaccrc32checker_is_ongoing0 <= 1'd0;
	ethernet_liteethmaccrc32checker_is_ongoing1 <= 1'd0;
	ethernet_liteethmaccrc32checker_is_ongoing2 <= 1'd0;
	rxdatapath_bufferizeendpoints_next_state <= 2'd0;
	ethernet_liteethmaccrc32checker_be_clockdomainsrenamer_next_value0 <= 1'd0;
	ethernet_liteethmaccrc32checker_be_clockdomainsrenamer_next_value_ce0 <= 1'd0;
	ethernet_liteethmaccrc32checker_last_error_clockdomainsrenamer_next_value1 <= 1'd0;
	ethernet_liteethmaccrc32checker_last_error_clockdomainsrenamer_next_value_ce1 <= 1'd0;
	ethernet_liteethmaccrc32checker_source_source_payload_error <= ethernet_liteethmaccrc32checker_syncfifo_source_payload_error;
	rxdatapath_bufferizeendpoints_next_state <= rxdatapath_bufferizeendpoints_state;
	case (rxdatapath_bufferizeendpoints_state)
		1'd1: begin
			ethernet_liteethmaccrc32checker_is_ongoing1 <= 1'd1;
			ethernet_liteethmaccrc32checker_source_source_valid <= ethernet_liteethmaccrc32checker_syncfifo_source_valid;
			ethernet_liteethmaccrc32checker_syncfifo_source_ready <= ethernet_liteethmaccrc32checker_source_source_ready;
			ethernet_liteethmaccrc32checker_source_source_last <= ethernet_liteethmaccrc32checker_syncfifo_source_last;
			ethernet_liteethmaccrc32checker_source_source_payload_error <= (ethernet_liteethmaccrc32checker_syncfifo_source_payload_error | {1{ethernet_liteethmaccrc32checker_last_error}});
			ethernet_liteethmaccrc32checker_source_source_payload_be <= ethernet_liteethmaccrc32checker_be;
			if ((ethernet_liteethmaccrc32checker_source_source_valid & ethernet_liteethmaccrc32checker_source_source_ready)) begin
				rxdatapath_bufferizeendpoints_next_state <= 1'd0;
			end
		end
		2'd2: begin
			if ((ethernet_liteethmaccrc32checker_sink_sink_valid & ethernet_liteethmaccrc32checker_sink_sink_ready)) begin
				ethernet_liteethmaccrc32checker_crc_ce <= 1'd1;
				rxdatapath_bufferizeendpoints_next_state <= 2'd3;
			end
		end
		2'd3: begin
			ethernet_liteethmaccrc32checker_syncfifo_source_ready <= ethernet_liteethmaccrc32checker_fifo_out;
			ethernet_liteethmaccrc32checker_source_source_valid <= (ethernet_liteethmaccrc32checker_sink_sink_valid & ethernet_liteethmaccrc32checker_fifo_full);
			ethernet_liteethmaccrc32checker_source_source_payload_be <= 1'd1;
			if (1'd1) begin
				ethernet_liteethmaccrc32checker_source_source_last <= ethernet_liteethmaccrc32checker_sink_sink_last;
				if (ethernet_liteethmaccrc32checker_sink_sink_last) begin
					ethernet_liteethmaccrc32checker_source_source_payload_be <= ethernet_liteethmaccrc32checker_sink_sink_payload_be;
				end
			end else begin
				if ((ethernet_liteethmaccrc32checker_sink_sink_payload_be <= 4'd15)) begin
					ethernet_liteethmaccrc32checker_source_source_last <= ethernet_liteethmaccrc32checker_sink_sink_last;
					ethernet_liteethmaccrc32checker_source_source_payload_be <= ((ethernet_liteethmaccrc32checker_sink_sink_payload_be <<< 3'd4) | 4'd15);
				end else begin
					ethernet_liteethmaccrc32checker_be_clockdomainsrenamer_next_value0 <= (ethernet_liteethmaccrc32checker_sink_sink_payload_be >>> 3'd4);
					ethernet_liteethmaccrc32checker_be_clockdomainsrenamer_next_value_ce0 <= 1'd1;
					ethernet_liteethmaccrc32checker_last_error_clockdomainsrenamer_next_value1 <= ethernet_liteethmaccrc32checker_last_word_error;
					ethernet_liteethmaccrc32checker_last_error_clockdomainsrenamer_next_value_ce1 <= 1'd1;
				end
			end
			ethernet_liteethmaccrc32checker_source_source_payload_error <= (ethernet_liteethmaccrc32checker_sink_sink_last ? {1{ethernet_liteethmaccrc32checker_last_word_error}} : ethernet_liteethmaccrc32checker_syncfifo_source_payload_error);
			ethernet_liteethmaccrc32checker_error <= ((ethernet_liteethmaccrc32checker_sink_sink_valid & ethernet_liteethmaccrc32checker_sink_sink_last) & ethernet_liteethmaccrc32checker_crc_error);
			if ((ethernet_liteethmaccrc32checker_sink_sink_valid & ethernet_liteethmaccrc32checker_sink_sink_ready)) begin
				ethernet_liteethmaccrc32checker_crc_ce <= 1'd1;
				if ((ethernet_liteethmaccrc32checker_sink_sink_last & (ethernet_liteethmaccrc32checker_sink_sink_payload_be > 4'd15))) begin
					rxdatapath_bufferizeendpoints_next_state <= 1'd1;
				end else begin
					if (ethernet_liteethmaccrc32checker_sink_sink_last) begin
						rxdatapath_bufferizeendpoints_next_state <= 1'd0;
					end
				end
			end
		end
		default: begin
			ethernet_liteethmaccrc32checker_is_ongoing0 <= 1'd1;
			ethernet_liteethmaccrc32checker_crc_reset <= 1'd1;
			ethernet_liteethmaccrc32checker_fifo_reset <= 1'd1;
			rxdatapath_bufferizeendpoints_next_state <= 2'd2;
			ethernet_liteethmaccrc32checker_is_ongoing2 <= 1'd1;
		end
	endcase
// synthesis translate_off
	dummy_d_35 <= dummy_s;
// synthesis translate_on
end
assign ethernet_bufferizeendpoints_pipe_valid_sink_ready = ((~ethernet_bufferizeendpoints_pipe_valid_source_valid) | ethernet_bufferizeendpoints_pipe_valid_source_ready);
assign ethernet_bufferizeendpoints_pipe_valid_sink_valid = ethernet_bufferizeendpoints_sink_sink_valid;
assign ethernet_bufferizeendpoints_sink_sink_ready = ethernet_bufferizeendpoints_pipe_valid_sink_ready;
assign ethernet_bufferizeendpoints_pipe_valid_sink_first = ethernet_bufferizeendpoints_sink_sink_first;
assign ethernet_bufferizeendpoints_pipe_valid_sink_last = ethernet_bufferizeendpoints_sink_sink_last;
assign ethernet_bufferizeendpoints_pipe_valid_sink_payload_data = ethernet_bufferizeendpoints_sink_sink_payload_data;
assign ethernet_bufferizeendpoints_pipe_valid_sink_payload_be = ethernet_bufferizeendpoints_sink_sink_payload_be;
assign ethernet_bufferizeendpoints_pipe_valid_sink_payload_error = ethernet_bufferizeendpoints_sink_sink_payload_error;
assign ethernet_bufferizeendpoints_source_source_valid = ethernet_bufferizeendpoints_pipe_valid_source_valid;
assign ethernet_bufferizeendpoints_pipe_valid_source_ready = ethernet_bufferizeendpoints_source_source_ready;
assign ethernet_bufferizeendpoints_source_source_first = ethernet_bufferizeendpoints_pipe_valid_source_first;
assign ethernet_bufferizeendpoints_source_source_last = ethernet_bufferizeendpoints_pipe_valid_source_last;
assign ethernet_bufferizeendpoints_source_source_payload_data = ethernet_bufferizeendpoints_pipe_valid_source_payload_data;
assign ethernet_bufferizeendpoints_source_source_payload_be = ethernet_bufferizeendpoints_pipe_valid_source_payload_be;
assign ethernet_bufferizeendpoints_source_source_payload_error = ethernet_bufferizeendpoints_pipe_valid_source_payload_error;
assign ethernet_pulsesynchronizer1_o = (ethernet_pulsesynchronizer1_toggle_o ^ ethernet_pulsesynchronizer1_toggle_o_r);
assign ethernet_rx_padding_length_inc = (1'd0 + ethernet_rx_padding_sink_payload_be);
assign ethernet_rx_padding_source_valid = ethernet_rx_padding_sink_valid;
assign ethernet_rx_padding_sink_ready = ethernet_rx_padding_source_ready;
assign ethernet_rx_padding_source_first = ethernet_rx_padding_sink_first;
assign ethernet_rx_padding_source_last = ethernet_rx_padding_sink_last;
assign ethernet_rx_padding_source_payload_data = ethernet_rx_padding_sink_payload_data;
assign ethernet_rx_padding_source_payload_be = ethernet_rx_padding_sink_payload_be;

// synthesis translate_off
reg dummy_d_36;
// synthesis translate_on
always @(*) begin
	ethernet_rx_padding_source_payload_error <= 1'd0;
	if (((ethernet_rx_padding_sink_valid & ethernet_rx_padding_sink_last) & ((ethernet_rx_padding_length + ethernet_rx_padding_length_inc) < 6'd60))) begin
		ethernet_rx_padding_source_payload_error <= {1{1'd1}};
	end else begin
		ethernet_rx_padding_source_payload_error <= ethernet_rx_padding_sink_payload_error;
	end
// synthesis translate_off
	dummy_d_36 <= dummy_s;
// synthesis translate_on
end
assign ethernet_rx_packet_fifo_sink_sink_valid = ethernet_source_source_valid;
assign ethernet_source_source_ready = ethernet_rx_packet_fifo_sink_sink_ready;
assign ethernet_rx_packet_fifo_sink_sink_first = ethernet_source_source_first;
assign ethernet_rx_packet_fifo_sink_sink_last = ethernet_source_source_last;
assign ethernet_rx_packet_fifo_sink_sink_payload_data = ethernet_source_source_payload_data;
assign ethernet_rx_packet_fifo_sink_sink_payload_be = ethernet_source_source_payload_be;
assign ethernet_rx_packet_fifo_sink_sink_payload_error = ethernet_source_source_payload_error;
assign ethernet_rx_cdc_sink_sink_valid = ethernet_rx_packet_fifo_source_source_valid;
assign ethernet_rx_packet_fifo_source_source_ready = ethernet_rx_cdc_sink_sink_ready;
assign ethernet_rx_cdc_sink_sink_first = ethernet_rx_packet_fifo_source_source_first;
assign ethernet_rx_cdc_sink_sink_last = ethernet_rx_packet_fifo_source_source_last;
assign ethernet_rx_cdc_sink_sink_payload_data = ethernet_rx_packet_fifo_source_source_payload_data;
assign ethernet_rx_cdc_sink_sink_payload_be = ethernet_rx_packet_fifo_source_source_payload_be;
assign ethernet_rx_cdc_sink_sink_payload_error = ethernet_rx_packet_fifo_source_source_payload_error;
assign ethernet_rx_preamble_sink_valid = ethernet_rx_cdc_source_source_valid;
assign ethernet_rx_cdc_source_source_ready = ethernet_rx_preamble_sink_ready;
assign ethernet_rx_preamble_sink_first = ethernet_rx_cdc_source_source_first;
assign ethernet_rx_preamble_sink_last = ethernet_rx_cdc_source_source_last;
assign ethernet_rx_preamble_sink_payload_data = ethernet_rx_cdc_source_source_payload_data;
assign ethernet_rx_preamble_sink_payload_be = ethernet_rx_cdc_source_source_payload_be;
assign ethernet_rx_preamble_sink_payload_error = ethernet_rx_cdc_source_source_payload_error;
assign ethernet_bufferizeendpoints_sink_sink_valid = ethernet_rx_preamble_source_valid;
assign ethernet_rx_preamble_source_ready = ethernet_bufferizeendpoints_sink_sink_ready;
assign ethernet_bufferizeendpoints_sink_sink_first = ethernet_rx_preamble_source_first;
assign ethernet_bufferizeendpoints_sink_sink_last = ethernet_rx_preamble_source_last;
assign ethernet_bufferizeendpoints_sink_sink_payload_data = ethernet_rx_preamble_source_payload_data;
assign ethernet_bufferizeendpoints_sink_sink_payload_be = ethernet_rx_preamble_source_payload_be;
assign ethernet_bufferizeendpoints_sink_sink_payload_error = ethernet_rx_preamble_source_payload_error;
assign ethernet_rx_padding_sink_valid = ethernet_liteethmaccrc32checker_source_source_valid;
assign ethernet_liteethmaccrc32checker_source_source_ready = ethernet_rx_padding_sink_ready;
assign ethernet_rx_padding_sink_first = ethernet_liteethmaccrc32checker_source_source_first;
assign ethernet_rx_padding_sink_last = ethernet_liteethmaccrc32checker_source_source_last;
assign ethernet_rx_padding_sink_payload_data = ethernet_liteethmaccrc32checker_source_source_payload_data;
assign ethernet_rx_padding_sink_payload_be = ethernet_liteethmaccrc32checker_source_source_payload_be;
assign ethernet_rx_padding_sink_payload_error = ethernet_liteethmaccrc32checker_source_source_payload_error;
assign ethernet_source_valid = ethernet_rx_padding_source_valid;
assign ethernet_rx_padding_source_ready = ethernet_source_ready;
assign ethernet_source_first = ethernet_rx_padding_source_first;
assign ethernet_source_last = ethernet_rx_padding_source_last;
assign ethernet_source_payload_data = ethernet_rx_padding_source_payload_data;
assign ethernet_source_payload_be = ethernet_rx_padding_source_payload_be;
assign ethernet_source_payload_error = ethernet_rx_padding_source_payload_error;
assign control_reserved = ((control_capture_armed | control_generator_armed) | control_trigger_pending);
assign control_launch = ((((control_trigger_pending & ready) & (~bank_player_pending)) & (~local_write)) & ((~control_enabled) | (bank_player_position == (bank_player_length - 1'd1))));
assign control_phase_busy = control_busy1;
assign control_phase_done = control_done1;
assign control_start = (((((control_watching & control_seen_busy) & control_done0) & (~control_raw_busy)) & (~control_phase_busy)) & (~control_capture_fault));
assign control_length = control_capture_length;
assign control_read_address = control_rx_address;
assign control_capture_address = (control_phase_busy ? control_address : control_rx_address);
assign control_raw_busy = ({bank_windowcapture15_busy, bank_windowcapture14_busy, bank_windowcapture13_busy, bank_windowcapture12_busy, bank_windowcapture11_busy, bank_windowcapture10_busy, bank_windowcapture9_busy, bank_windowcapture8_busy, bank_windowcapture7_busy, bank_windowcapture6_busy, bank_windowcapture5_busy, bank_windowcapture4_busy, bank_windowcapture3_busy, bank_windowcapture2_busy, bank_windowcapture1_busy, bank_windowcapture0_busy} != 1'd0);
assign control_busy0 = (control_raw_busy | control_phase_busy);
assign control_done0 = ({bank_windowcapture15_done, bank_windowcapture14_done, bank_windowcapture13_done, bank_windowcapture12_done, bank_windowcapture11_done, bank_windowcapture10_done, bank_windowcapture9_done, bank_windowcapture8_done, bank_windowcapture7_done, bank_windowcapture6_done, bank_windowcapture5_done, bank_windowcapture4_done, bank_windowcapture3_done, bank_windowcapture2_done, bank_windowcapture1_done, bank_windowcapture0_done} == 16'd65535);
assign control_error = ({bank_windowcapture15_error, bank_windowcapture14_error, bank_windowcapture13_error, bank_windowcapture12_error, bank_windowcapture11_error, bank_windowcapture10_error, bank_windowcapture9_error, bank_windowcapture8_error, bank_windowcapture7_error, bank_windowcapture6_error, bank_windowcapture5_error, bank_windowcapture4_error, bank_windowcapture3_error, bank_windowcapture2_error, bank_windowcapture1_error, bank_windowcapture0_error} != 1'd0);
assign control_valid = ((((control_done0 & (~control_busy0)) & (~control_watching)) & (~control_capture_fault)) & control_phase_done);
assign bank_arm = control_arm;
assign bank_length = control_capture_length;
assign bank_ready = ready;
assign bank_address = control_capture_address;
assign bank_player_ready = ready;
assign bank_player_enable = control_enabled;
assign bank_player_write_bank = (~bank_player_active_bank);
assign bank_player_write_address = control_tx_address;
assign bank_player_write_data = {control3, control2, control1, control0};
assign bank_player_commit_length = control_tx_length;
assign bank_player_write = (((local_write & (local_address == 6'd48)) & (~control_command_error)) & (~control_reserved));
assign bank_player_commit = (((((local_write & (local_address == 6'd56)) & (~control_command_error)) & (~control_busy0)) & (~control_watching)) & (~control_reserved));

// synthesis translate_off
reg dummy_d_37;
// synthesis translate_on
always @(*) begin
	local_read_data <= 32'd0;
	local_read_data <= 32'd4294967295;
	case (local_address)
		1'd0: begin
			local_read_data <= 31'd1280718897;
		end
		3'd4: begin
			local_read_data <= 17'd65538;
		end
		4'd8: begin
			local_read_data <= control_enabled;
		end
		4'd12: begin
			local_read_data <= {bank_player_active_bank, bank_player_pending, bank_player_error, control_command_error, control_capture_fault, control_valid, control_busy0, ready};
		end
		5'd16: begin
			local_read_data <= control_output_mask;
		end
		5'd20: begin
			local_read_data <= control_capture_length;
		end
		5'd28: begin
			local_read_data <= control_bank;
		end
		6'd32: begin
			local_read_data <= control_rx_address;
		end
		6'd36: begin
			local_read_data <= control_tx_address;
		end
		6'd52: begin
			local_read_data <= bank_player_length;
		end
		6'd60: begin
			local_read_data <= bank_player_loops;
		end
		7'd80: begin
			local_read_data <= ((control_valid & (control_rx_address < self1)) ? self2 : 32'd4294967295);
		end
		7'd84: begin
			local_read_data <= (control_valid ? self3 : 1'd0);
		end
		7'd88: begin
			local_read_data <= self4;
		end
		7'd92: begin
			local_read_data <= self5;
		end
		7'd96: begin
			local_read_data <= self6;
		end
		7'd100: begin
			local_read_data <= control_capture_sequence;
		end
		7'd104: begin
			local_read_data <= control_capture_outputs;
		end
		7'd116: begin
			local_read_data <= 26'd40000000;
		end
		7'd120: begin
			local_read_data <= 13'd4096;
		end
		7'd124: begin
			local_read_data <= 1'd0;
		end
		8'd128: begin
			local_read_data <= 5'd16;
		end
		8'd140: begin
			local_read_data <= {control_trigger_pending, control_generator_armed, control_capture_armed};
		end
		8'd144: begin
			local_read_data <= control_trigger_id;
		end
		8'd148: begin
			local_read_data <= control_trigger_cycle[31:0];
		end
		8'd152: begin
			local_read_data <= control_trigger_cycle[63:32];
		end
		8'd156: begin
			local_read_data <= control_trigger_position;
		end
		8'd160: begin
			local_read_data <= control_trigger_loop;
		end
		8'd164: begin
			local_read_data <= control_capture_trigger_id;
		end
		8'd168: begin
			local_read_data <= 30'd960000000;
		end
		8'd172: begin
			local_read_data <= 5'd24;
		end
		8'd176: begin
			local_read_data <= 2'd3;
		end
		8'd180: begin
			local_read_data <= 27'd120000000;
		end
		8'd184: begin
			local_read_data <= (control_valid ? control_count0 : 1'd0);
		end
		8'd188: begin
			local_read_data <= ((control_valid & (control_rx_address < control_count0)) ? self7 : 32'd4294967295);
		end
	endcase
// synthesis translate_off
	dummy_d_37 <= dummy_s;
// synthesis translate_on
end
assign control_address = control_index;
assign control_rising0 = (bank_windowcapture0_read_data & (~{bank_windowcapture0_read_data[6:0], control_previous0}));
assign control_mask0 = {control_rising0, control_partial0};

// synthesis translate_off
reg dummy_d_38;
// synthesis translate_on
always @(*) begin
	control_first0 <= 5'd0;
	control_first0 <= 1'd0;
	if (control_mask0[23]) begin
		control_first0 <= 5'd23;
	end
	if (control_mask0[22]) begin
		control_first0 <= 5'd22;
	end
	if (control_mask0[21]) begin
		control_first0 <= 5'd21;
	end
	if (control_mask0[20]) begin
		control_first0 <= 5'd20;
	end
	if (control_mask0[19]) begin
		control_first0 <= 5'd19;
	end
	if (control_mask0[18]) begin
		control_first0 <= 5'd18;
	end
	if (control_mask0[17]) begin
		control_first0 <= 5'd17;
	end
	if (control_mask0[16]) begin
		control_first0 <= 5'd16;
	end
	if (control_mask0[15]) begin
		control_first0 <= 4'd15;
	end
	if (control_mask0[14]) begin
		control_first0 <= 4'd14;
	end
	if (control_mask0[13]) begin
		control_first0 <= 4'd13;
	end
	if (control_mask0[12]) begin
		control_first0 <= 4'd12;
	end
	if (control_mask0[11]) begin
		control_first0 <= 4'd11;
	end
	if (control_mask0[10]) begin
		control_first0 <= 4'd10;
	end
	if (control_mask0[9]) begin
		control_first0 <= 4'd9;
	end
	if (control_mask0[8]) begin
		control_first0 <= 4'd8;
	end
	if (control_mask0[7]) begin
		control_first0 <= 3'd7;
	end
	if (control_mask0[6]) begin
		control_first0 <= 3'd6;
	end
	if (control_mask0[5]) begin
		control_first0 <= 3'd5;
	end
	if (control_mask0[4]) begin
		control_first0 <= 3'd4;
	end
	if (control_mask0[3]) begin
		control_first0 <= 2'd3;
	end
	if (control_mask0[2]) begin
		control_first0 <= 2'd2;
	end
	if (control_mask0[1]) begin
		control_first0 <= 1'd1;
	end
	if (control_mask0[0]) begin
		control_first0 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_38 <= dummy_s;
// synthesis translate_on
end
assign control_count1 = (((((control_mask0[0] + control_mask0[1]) + (control_mask0[2] + control_mask0[3])) + ((control_mask0[4] + control_mask0[5]) + (control_mask0[6] + control_mask0[7]))) + (((control_mask0[8] + control_mask0[9]) + (control_mask0[10] + control_mask0[11])) + ((control_mask0[12] + control_mask0[13]) + (control_mask0[14] + control_mask0[15])))) + (((control_mask0[16] + control_mask0[17]) + (control_mask0[18] + control_mask0[19])) + ((control_mask0[20] + control_mask0[21]) + (control_mask0[22] + control_mask0[23]))));
assign control_record0 = {(control_count1 > 1'd1), (control_count1 != 1'd0), 9'd0, control_count1, 11'd0, control_first0};
assign control_wp_memory0_adr = control_frame;
assign control_wp_memory0_dat_w = control_record0;
assign control_wp_memory0_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory0_adr = control_read_address;
assign control_rising1 = (bank_windowcapture1_read_data & (~{bank_windowcapture1_read_data[6:0], control_previous1}));
assign control_mask1 = {control_rising1, control_partial1};

// synthesis translate_off
reg dummy_d_39;
// synthesis translate_on
always @(*) begin
	control_first1 <= 5'd0;
	control_first1 <= 1'd0;
	if (control_mask1[23]) begin
		control_first1 <= 5'd23;
	end
	if (control_mask1[22]) begin
		control_first1 <= 5'd22;
	end
	if (control_mask1[21]) begin
		control_first1 <= 5'd21;
	end
	if (control_mask1[20]) begin
		control_first1 <= 5'd20;
	end
	if (control_mask1[19]) begin
		control_first1 <= 5'd19;
	end
	if (control_mask1[18]) begin
		control_first1 <= 5'd18;
	end
	if (control_mask1[17]) begin
		control_first1 <= 5'd17;
	end
	if (control_mask1[16]) begin
		control_first1 <= 5'd16;
	end
	if (control_mask1[15]) begin
		control_first1 <= 4'd15;
	end
	if (control_mask1[14]) begin
		control_first1 <= 4'd14;
	end
	if (control_mask1[13]) begin
		control_first1 <= 4'd13;
	end
	if (control_mask1[12]) begin
		control_first1 <= 4'd12;
	end
	if (control_mask1[11]) begin
		control_first1 <= 4'd11;
	end
	if (control_mask1[10]) begin
		control_first1 <= 4'd10;
	end
	if (control_mask1[9]) begin
		control_first1 <= 4'd9;
	end
	if (control_mask1[8]) begin
		control_first1 <= 4'd8;
	end
	if (control_mask1[7]) begin
		control_first1 <= 3'd7;
	end
	if (control_mask1[6]) begin
		control_first1 <= 3'd6;
	end
	if (control_mask1[5]) begin
		control_first1 <= 3'd5;
	end
	if (control_mask1[4]) begin
		control_first1 <= 3'd4;
	end
	if (control_mask1[3]) begin
		control_first1 <= 2'd3;
	end
	if (control_mask1[2]) begin
		control_first1 <= 2'd2;
	end
	if (control_mask1[1]) begin
		control_first1 <= 1'd1;
	end
	if (control_mask1[0]) begin
		control_first1 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_39 <= dummy_s;
// synthesis translate_on
end
assign control_count2 = (((((control_mask1[0] + control_mask1[1]) + (control_mask1[2] + control_mask1[3])) + ((control_mask1[4] + control_mask1[5]) + (control_mask1[6] + control_mask1[7]))) + (((control_mask1[8] + control_mask1[9]) + (control_mask1[10] + control_mask1[11])) + ((control_mask1[12] + control_mask1[13]) + (control_mask1[14] + control_mask1[15])))) + (((control_mask1[16] + control_mask1[17]) + (control_mask1[18] + control_mask1[19])) + ((control_mask1[20] + control_mask1[21]) + (control_mask1[22] + control_mask1[23]))));
assign control_record1 = {(control_count2 > 1'd1), (control_count2 != 1'd0), 9'd0, control_count2, 11'd0, control_first1};
assign control_wp_memory1_adr = control_frame;
assign control_wp_memory1_dat_w = control_record1;
assign control_wp_memory1_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory1_adr = control_read_address;
assign control_rising2 = (bank_windowcapture2_read_data & (~{bank_windowcapture2_read_data[6:0], control_previous2}));
assign control_mask2 = {control_rising2, control_partial2};

// synthesis translate_off
reg dummy_d_40;
// synthesis translate_on
always @(*) begin
	control_first2 <= 5'd0;
	control_first2 <= 1'd0;
	if (control_mask2[23]) begin
		control_first2 <= 5'd23;
	end
	if (control_mask2[22]) begin
		control_first2 <= 5'd22;
	end
	if (control_mask2[21]) begin
		control_first2 <= 5'd21;
	end
	if (control_mask2[20]) begin
		control_first2 <= 5'd20;
	end
	if (control_mask2[19]) begin
		control_first2 <= 5'd19;
	end
	if (control_mask2[18]) begin
		control_first2 <= 5'd18;
	end
	if (control_mask2[17]) begin
		control_first2 <= 5'd17;
	end
	if (control_mask2[16]) begin
		control_first2 <= 5'd16;
	end
	if (control_mask2[15]) begin
		control_first2 <= 4'd15;
	end
	if (control_mask2[14]) begin
		control_first2 <= 4'd14;
	end
	if (control_mask2[13]) begin
		control_first2 <= 4'd13;
	end
	if (control_mask2[12]) begin
		control_first2 <= 4'd12;
	end
	if (control_mask2[11]) begin
		control_first2 <= 4'd11;
	end
	if (control_mask2[10]) begin
		control_first2 <= 4'd10;
	end
	if (control_mask2[9]) begin
		control_first2 <= 4'd9;
	end
	if (control_mask2[8]) begin
		control_first2 <= 4'd8;
	end
	if (control_mask2[7]) begin
		control_first2 <= 3'd7;
	end
	if (control_mask2[6]) begin
		control_first2 <= 3'd6;
	end
	if (control_mask2[5]) begin
		control_first2 <= 3'd5;
	end
	if (control_mask2[4]) begin
		control_first2 <= 3'd4;
	end
	if (control_mask2[3]) begin
		control_first2 <= 2'd3;
	end
	if (control_mask2[2]) begin
		control_first2 <= 2'd2;
	end
	if (control_mask2[1]) begin
		control_first2 <= 1'd1;
	end
	if (control_mask2[0]) begin
		control_first2 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_40 <= dummy_s;
// synthesis translate_on
end
assign control_count3 = (((((control_mask2[0] + control_mask2[1]) + (control_mask2[2] + control_mask2[3])) + ((control_mask2[4] + control_mask2[5]) + (control_mask2[6] + control_mask2[7]))) + (((control_mask2[8] + control_mask2[9]) + (control_mask2[10] + control_mask2[11])) + ((control_mask2[12] + control_mask2[13]) + (control_mask2[14] + control_mask2[15])))) + (((control_mask2[16] + control_mask2[17]) + (control_mask2[18] + control_mask2[19])) + ((control_mask2[20] + control_mask2[21]) + (control_mask2[22] + control_mask2[23]))));
assign control_record2 = {(control_count3 > 1'd1), (control_count3 != 1'd0), 9'd0, control_count3, 11'd0, control_first2};
assign control_wp_memory2_adr = control_frame;
assign control_wp_memory2_dat_w = control_record2;
assign control_wp_memory2_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory2_adr = control_read_address;
assign control_rising3 = (bank_windowcapture3_read_data & (~{bank_windowcapture3_read_data[6:0], control_previous3}));
assign control_mask3 = {control_rising3, control_partial3};

// synthesis translate_off
reg dummy_d_41;
// synthesis translate_on
always @(*) begin
	control_first3 <= 5'd0;
	control_first3 <= 1'd0;
	if (control_mask3[23]) begin
		control_first3 <= 5'd23;
	end
	if (control_mask3[22]) begin
		control_first3 <= 5'd22;
	end
	if (control_mask3[21]) begin
		control_first3 <= 5'd21;
	end
	if (control_mask3[20]) begin
		control_first3 <= 5'd20;
	end
	if (control_mask3[19]) begin
		control_first3 <= 5'd19;
	end
	if (control_mask3[18]) begin
		control_first3 <= 5'd18;
	end
	if (control_mask3[17]) begin
		control_first3 <= 5'd17;
	end
	if (control_mask3[16]) begin
		control_first3 <= 5'd16;
	end
	if (control_mask3[15]) begin
		control_first3 <= 4'd15;
	end
	if (control_mask3[14]) begin
		control_first3 <= 4'd14;
	end
	if (control_mask3[13]) begin
		control_first3 <= 4'd13;
	end
	if (control_mask3[12]) begin
		control_first3 <= 4'd12;
	end
	if (control_mask3[11]) begin
		control_first3 <= 4'd11;
	end
	if (control_mask3[10]) begin
		control_first3 <= 4'd10;
	end
	if (control_mask3[9]) begin
		control_first3 <= 4'd9;
	end
	if (control_mask3[8]) begin
		control_first3 <= 4'd8;
	end
	if (control_mask3[7]) begin
		control_first3 <= 3'd7;
	end
	if (control_mask3[6]) begin
		control_first3 <= 3'd6;
	end
	if (control_mask3[5]) begin
		control_first3 <= 3'd5;
	end
	if (control_mask3[4]) begin
		control_first3 <= 3'd4;
	end
	if (control_mask3[3]) begin
		control_first3 <= 2'd3;
	end
	if (control_mask3[2]) begin
		control_first3 <= 2'd2;
	end
	if (control_mask3[1]) begin
		control_first3 <= 1'd1;
	end
	if (control_mask3[0]) begin
		control_first3 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_41 <= dummy_s;
// synthesis translate_on
end
assign control_count4 = (((((control_mask3[0] + control_mask3[1]) + (control_mask3[2] + control_mask3[3])) + ((control_mask3[4] + control_mask3[5]) + (control_mask3[6] + control_mask3[7]))) + (((control_mask3[8] + control_mask3[9]) + (control_mask3[10] + control_mask3[11])) + ((control_mask3[12] + control_mask3[13]) + (control_mask3[14] + control_mask3[15])))) + (((control_mask3[16] + control_mask3[17]) + (control_mask3[18] + control_mask3[19])) + ((control_mask3[20] + control_mask3[21]) + (control_mask3[22] + control_mask3[23]))));
assign control_record3 = {(control_count4 > 1'd1), (control_count4 != 1'd0), 9'd0, control_count4, 11'd0, control_first3};
assign control_wp_memory3_adr = control_frame;
assign control_wp_memory3_dat_w = control_record3;
assign control_wp_memory3_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory3_adr = control_read_address;
assign control_rising4 = (bank_windowcapture4_read_data & (~{bank_windowcapture4_read_data[6:0], control_previous4}));
assign control_mask4 = {control_rising4, control_partial4};

// synthesis translate_off
reg dummy_d_42;
// synthesis translate_on
always @(*) begin
	control_first4 <= 5'd0;
	control_first4 <= 1'd0;
	if (control_mask4[23]) begin
		control_first4 <= 5'd23;
	end
	if (control_mask4[22]) begin
		control_first4 <= 5'd22;
	end
	if (control_mask4[21]) begin
		control_first4 <= 5'd21;
	end
	if (control_mask4[20]) begin
		control_first4 <= 5'd20;
	end
	if (control_mask4[19]) begin
		control_first4 <= 5'd19;
	end
	if (control_mask4[18]) begin
		control_first4 <= 5'd18;
	end
	if (control_mask4[17]) begin
		control_first4 <= 5'd17;
	end
	if (control_mask4[16]) begin
		control_first4 <= 5'd16;
	end
	if (control_mask4[15]) begin
		control_first4 <= 4'd15;
	end
	if (control_mask4[14]) begin
		control_first4 <= 4'd14;
	end
	if (control_mask4[13]) begin
		control_first4 <= 4'd13;
	end
	if (control_mask4[12]) begin
		control_first4 <= 4'd12;
	end
	if (control_mask4[11]) begin
		control_first4 <= 4'd11;
	end
	if (control_mask4[10]) begin
		control_first4 <= 4'd10;
	end
	if (control_mask4[9]) begin
		control_first4 <= 4'd9;
	end
	if (control_mask4[8]) begin
		control_first4 <= 4'd8;
	end
	if (control_mask4[7]) begin
		control_first4 <= 3'd7;
	end
	if (control_mask4[6]) begin
		control_first4 <= 3'd6;
	end
	if (control_mask4[5]) begin
		control_first4 <= 3'd5;
	end
	if (control_mask4[4]) begin
		control_first4 <= 3'd4;
	end
	if (control_mask4[3]) begin
		control_first4 <= 2'd3;
	end
	if (control_mask4[2]) begin
		control_first4 <= 2'd2;
	end
	if (control_mask4[1]) begin
		control_first4 <= 1'd1;
	end
	if (control_mask4[0]) begin
		control_first4 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_42 <= dummy_s;
// synthesis translate_on
end
assign control_count5 = (((((control_mask4[0] + control_mask4[1]) + (control_mask4[2] + control_mask4[3])) + ((control_mask4[4] + control_mask4[5]) + (control_mask4[6] + control_mask4[7]))) + (((control_mask4[8] + control_mask4[9]) + (control_mask4[10] + control_mask4[11])) + ((control_mask4[12] + control_mask4[13]) + (control_mask4[14] + control_mask4[15])))) + (((control_mask4[16] + control_mask4[17]) + (control_mask4[18] + control_mask4[19])) + ((control_mask4[20] + control_mask4[21]) + (control_mask4[22] + control_mask4[23]))));
assign control_record4 = {(control_count5 > 1'd1), (control_count5 != 1'd0), 9'd0, control_count5, 11'd0, control_first4};
assign control_wp_memory4_adr = control_frame;
assign control_wp_memory4_dat_w = control_record4;
assign control_wp_memory4_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory4_adr = control_read_address;
assign control_rising5 = (bank_windowcapture5_read_data & (~{bank_windowcapture5_read_data[6:0], control_previous5}));
assign control_mask5 = {control_rising5, control_partial5};

// synthesis translate_off
reg dummy_d_43;
// synthesis translate_on
always @(*) begin
	control_first5 <= 5'd0;
	control_first5 <= 1'd0;
	if (control_mask5[23]) begin
		control_first5 <= 5'd23;
	end
	if (control_mask5[22]) begin
		control_first5 <= 5'd22;
	end
	if (control_mask5[21]) begin
		control_first5 <= 5'd21;
	end
	if (control_mask5[20]) begin
		control_first5 <= 5'd20;
	end
	if (control_mask5[19]) begin
		control_first5 <= 5'd19;
	end
	if (control_mask5[18]) begin
		control_first5 <= 5'd18;
	end
	if (control_mask5[17]) begin
		control_first5 <= 5'd17;
	end
	if (control_mask5[16]) begin
		control_first5 <= 5'd16;
	end
	if (control_mask5[15]) begin
		control_first5 <= 4'd15;
	end
	if (control_mask5[14]) begin
		control_first5 <= 4'd14;
	end
	if (control_mask5[13]) begin
		control_first5 <= 4'd13;
	end
	if (control_mask5[12]) begin
		control_first5 <= 4'd12;
	end
	if (control_mask5[11]) begin
		control_first5 <= 4'd11;
	end
	if (control_mask5[10]) begin
		control_first5 <= 4'd10;
	end
	if (control_mask5[9]) begin
		control_first5 <= 4'd9;
	end
	if (control_mask5[8]) begin
		control_first5 <= 4'd8;
	end
	if (control_mask5[7]) begin
		control_first5 <= 3'd7;
	end
	if (control_mask5[6]) begin
		control_first5 <= 3'd6;
	end
	if (control_mask5[5]) begin
		control_first5 <= 3'd5;
	end
	if (control_mask5[4]) begin
		control_first5 <= 3'd4;
	end
	if (control_mask5[3]) begin
		control_first5 <= 2'd3;
	end
	if (control_mask5[2]) begin
		control_first5 <= 2'd2;
	end
	if (control_mask5[1]) begin
		control_first5 <= 1'd1;
	end
	if (control_mask5[0]) begin
		control_first5 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_43 <= dummy_s;
// synthesis translate_on
end
assign control_count6 = (((((control_mask5[0] + control_mask5[1]) + (control_mask5[2] + control_mask5[3])) + ((control_mask5[4] + control_mask5[5]) + (control_mask5[6] + control_mask5[7]))) + (((control_mask5[8] + control_mask5[9]) + (control_mask5[10] + control_mask5[11])) + ((control_mask5[12] + control_mask5[13]) + (control_mask5[14] + control_mask5[15])))) + (((control_mask5[16] + control_mask5[17]) + (control_mask5[18] + control_mask5[19])) + ((control_mask5[20] + control_mask5[21]) + (control_mask5[22] + control_mask5[23]))));
assign control_record5 = {(control_count6 > 1'd1), (control_count6 != 1'd0), 9'd0, control_count6, 11'd0, control_first5};
assign control_wp_memory5_adr = control_frame;
assign control_wp_memory5_dat_w = control_record5;
assign control_wp_memory5_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory5_adr = control_read_address;
assign control_rising6 = (bank_windowcapture6_read_data & (~{bank_windowcapture6_read_data[6:0], control_previous6}));
assign control_mask6 = {control_rising6, control_partial6};

// synthesis translate_off
reg dummy_d_44;
// synthesis translate_on
always @(*) begin
	control_first6 <= 5'd0;
	control_first6 <= 1'd0;
	if (control_mask6[23]) begin
		control_first6 <= 5'd23;
	end
	if (control_mask6[22]) begin
		control_first6 <= 5'd22;
	end
	if (control_mask6[21]) begin
		control_first6 <= 5'd21;
	end
	if (control_mask6[20]) begin
		control_first6 <= 5'd20;
	end
	if (control_mask6[19]) begin
		control_first6 <= 5'd19;
	end
	if (control_mask6[18]) begin
		control_first6 <= 5'd18;
	end
	if (control_mask6[17]) begin
		control_first6 <= 5'd17;
	end
	if (control_mask6[16]) begin
		control_first6 <= 5'd16;
	end
	if (control_mask6[15]) begin
		control_first6 <= 4'd15;
	end
	if (control_mask6[14]) begin
		control_first6 <= 4'd14;
	end
	if (control_mask6[13]) begin
		control_first6 <= 4'd13;
	end
	if (control_mask6[12]) begin
		control_first6 <= 4'd12;
	end
	if (control_mask6[11]) begin
		control_first6 <= 4'd11;
	end
	if (control_mask6[10]) begin
		control_first6 <= 4'd10;
	end
	if (control_mask6[9]) begin
		control_first6 <= 4'd9;
	end
	if (control_mask6[8]) begin
		control_first6 <= 4'd8;
	end
	if (control_mask6[7]) begin
		control_first6 <= 3'd7;
	end
	if (control_mask6[6]) begin
		control_first6 <= 3'd6;
	end
	if (control_mask6[5]) begin
		control_first6 <= 3'd5;
	end
	if (control_mask6[4]) begin
		control_first6 <= 3'd4;
	end
	if (control_mask6[3]) begin
		control_first6 <= 2'd3;
	end
	if (control_mask6[2]) begin
		control_first6 <= 2'd2;
	end
	if (control_mask6[1]) begin
		control_first6 <= 1'd1;
	end
	if (control_mask6[0]) begin
		control_first6 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_44 <= dummy_s;
// synthesis translate_on
end
assign control_count7 = (((((control_mask6[0] + control_mask6[1]) + (control_mask6[2] + control_mask6[3])) + ((control_mask6[4] + control_mask6[5]) + (control_mask6[6] + control_mask6[7]))) + (((control_mask6[8] + control_mask6[9]) + (control_mask6[10] + control_mask6[11])) + ((control_mask6[12] + control_mask6[13]) + (control_mask6[14] + control_mask6[15])))) + (((control_mask6[16] + control_mask6[17]) + (control_mask6[18] + control_mask6[19])) + ((control_mask6[20] + control_mask6[21]) + (control_mask6[22] + control_mask6[23]))));
assign control_record6 = {(control_count7 > 1'd1), (control_count7 != 1'd0), 9'd0, control_count7, 11'd0, control_first6};
assign control_wp_memory6_adr = control_frame;
assign control_wp_memory6_dat_w = control_record6;
assign control_wp_memory6_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory6_adr = control_read_address;
assign control_rising7 = (bank_windowcapture7_read_data & (~{bank_windowcapture7_read_data[6:0], control_previous7}));
assign control_mask7 = {control_rising7, control_partial7};

// synthesis translate_off
reg dummy_d_45;
// synthesis translate_on
always @(*) begin
	control_first7 <= 5'd0;
	control_first7 <= 1'd0;
	if (control_mask7[23]) begin
		control_first7 <= 5'd23;
	end
	if (control_mask7[22]) begin
		control_first7 <= 5'd22;
	end
	if (control_mask7[21]) begin
		control_first7 <= 5'd21;
	end
	if (control_mask7[20]) begin
		control_first7 <= 5'd20;
	end
	if (control_mask7[19]) begin
		control_first7 <= 5'd19;
	end
	if (control_mask7[18]) begin
		control_first7 <= 5'd18;
	end
	if (control_mask7[17]) begin
		control_first7 <= 5'd17;
	end
	if (control_mask7[16]) begin
		control_first7 <= 5'd16;
	end
	if (control_mask7[15]) begin
		control_first7 <= 4'd15;
	end
	if (control_mask7[14]) begin
		control_first7 <= 4'd14;
	end
	if (control_mask7[13]) begin
		control_first7 <= 4'd13;
	end
	if (control_mask7[12]) begin
		control_first7 <= 4'd12;
	end
	if (control_mask7[11]) begin
		control_first7 <= 4'd11;
	end
	if (control_mask7[10]) begin
		control_first7 <= 4'd10;
	end
	if (control_mask7[9]) begin
		control_first7 <= 4'd9;
	end
	if (control_mask7[8]) begin
		control_first7 <= 4'd8;
	end
	if (control_mask7[7]) begin
		control_first7 <= 3'd7;
	end
	if (control_mask7[6]) begin
		control_first7 <= 3'd6;
	end
	if (control_mask7[5]) begin
		control_first7 <= 3'd5;
	end
	if (control_mask7[4]) begin
		control_first7 <= 3'd4;
	end
	if (control_mask7[3]) begin
		control_first7 <= 2'd3;
	end
	if (control_mask7[2]) begin
		control_first7 <= 2'd2;
	end
	if (control_mask7[1]) begin
		control_first7 <= 1'd1;
	end
	if (control_mask7[0]) begin
		control_first7 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_45 <= dummy_s;
// synthesis translate_on
end
assign control_count8 = (((((control_mask7[0] + control_mask7[1]) + (control_mask7[2] + control_mask7[3])) + ((control_mask7[4] + control_mask7[5]) + (control_mask7[6] + control_mask7[7]))) + (((control_mask7[8] + control_mask7[9]) + (control_mask7[10] + control_mask7[11])) + ((control_mask7[12] + control_mask7[13]) + (control_mask7[14] + control_mask7[15])))) + (((control_mask7[16] + control_mask7[17]) + (control_mask7[18] + control_mask7[19])) + ((control_mask7[20] + control_mask7[21]) + (control_mask7[22] + control_mask7[23]))));
assign control_record7 = {(control_count8 > 1'd1), (control_count8 != 1'd0), 9'd0, control_count8, 11'd0, control_first7};
assign control_wp_memory7_adr = control_frame;
assign control_wp_memory7_dat_w = control_record7;
assign control_wp_memory7_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory7_adr = control_read_address;
assign control_rising8 = (bank_windowcapture8_read_data & (~{bank_windowcapture8_read_data[6:0], control_previous8}));
assign control_mask8 = {control_rising8, control_partial8};

// synthesis translate_off
reg dummy_d_46;
// synthesis translate_on
always @(*) begin
	control_first8 <= 5'd0;
	control_first8 <= 1'd0;
	if (control_mask8[23]) begin
		control_first8 <= 5'd23;
	end
	if (control_mask8[22]) begin
		control_first8 <= 5'd22;
	end
	if (control_mask8[21]) begin
		control_first8 <= 5'd21;
	end
	if (control_mask8[20]) begin
		control_first8 <= 5'd20;
	end
	if (control_mask8[19]) begin
		control_first8 <= 5'd19;
	end
	if (control_mask8[18]) begin
		control_first8 <= 5'd18;
	end
	if (control_mask8[17]) begin
		control_first8 <= 5'd17;
	end
	if (control_mask8[16]) begin
		control_first8 <= 5'd16;
	end
	if (control_mask8[15]) begin
		control_first8 <= 4'd15;
	end
	if (control_mask8[14]) begin
		control_first8 <= 4'd14;
	end
	if (control_mask8[13]) begin
		control_first8 <= 4'd13;
	end
	if (control_mask8[12]) begin
		control_first8 <= 4'd12;
	end
	if (control_mask8[11]) begin
		control_first8 <= 4'd11;
	end
	if (control_mask8[10]) begin
		control_first8 <= 4'd10;
	end
	if (control_mask8[9]) begin
		control_first8 <= 4'd9;
	end
	if (control_mask8[8]) begin
		control_first8 <= 4'd8;
	end
	if (control_mask8[7]) begin
		control_first8 <= 3'd7;
	end
	if (control_mask8[6]) begin
		control_first8 <= 3'd6;
	end
	if (control_mask8[5]) begin
		control_first8 <= 3'd5;
	end
	if (control_mask8[4]) begin
		control_first8 <= 3'd4;
	end
	if (control_mask8[3]) begin
		control_first8 <= 2'd3;
	end
	if (control_mask8[2]) begin
		control_first8 <= 2'd2;
	end
	if (control_mask8[1]) begin
		control_first8 <= 1'd1;
	end
	if (control_mask8[0]) begin
		control_first8 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_46 <= dummy_s;
// synthesis translate_on
end
assign control_count9 = (((((control_mask8[0] + control_mask8[1]) + (control_mask8[2] + control_mask8[3])) + ((control_mask8[4] + control_mask8[5]) + (control_mask8[6] + control_mask8[7]))) + (((control_mask8[8] + control_mask8[9]) + (control_mask8[10] + control_mask8[11])) + ((control_mask8[12] + control_mask8[13]) + (control_mask8[14] + control_mask8[15])))) + (((control_mask8[16] + control_mask8[17]) + (control_mask8[18] + control_mask8[19])) + ((control_mask8[20] + control_mask8[21]) + (control_mask8[22] + control_mask8[23]))));
assign control_record8 = {(control_count9 > 1'd1), (control_count9 != 1'd0), 9'd0, control_count9, 11'd0, control_first8};
assign control_wp_memory8_adr = control_frame;
assign control_wp_memory8_dat_w = control_record8;
assign control_wp_memory8_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory8_adr = control_read_address;
assign control_rising9 = (bank_windowcapture9_read_data & (~{bank_windowcapture9_read_data[6:0], control_previous9}));
assign control_mask9 = {control_rising9, control_partial9};

// synthesis translate_off
reg dummy_d_47;
// synthesis translate_on
always @(*) begin
	control_first9 <= 5'd0;
	control_first9 <= 1'd0;
	if (control_mask9[23]) begin
		control_first9 <= 5'd23;
	end
	if (control_mask9[22]) begin
		control_first9 <= 5'd22;
	end
	if (control_mask9[21]) begin
		control_first9 <= 5'd21;
	end
	if (control_mask9[20]) begin
		control_first9 <= 5'd20;
	end
	if (control_mask9[19]) begin
		control_first9 <= 5'd19;
	end
	if (control_mask9[18]) begin
		control_first9 <= 5'd18;
	end
	if (control_mask9[17]) begin
		control_first9 <= 5'd17;
	end
	if (control_mask9[16]) begin
		control_first9 <= 5'd16;
	end
	if (control_mask9[15]) begin
		control_first9 <= 4'd15;
	end
	if (control_mask9[14]) begin
		control_first9 <= 4'd14;
	end
	if (control_mask9[13]) begin
		control_first9 <= 4'd13;
	end
	if (control_mask9[12]) begin
		control_first9 <= 4'd12;
	end
	if (control_mask9[11]) begin
		control_first9 <= 4'd11;
	end
	if (control_mask9[10]) begin
		control_first9 <= 4'd10;
	end
	if (control_mask9[9]) begin
		control_first9 <= 4'd9;
	end
	if (control_mask9[8]) begin
		control_first9 <= 4'd8;
	end
	if (control_mask9[7]) begin
		control_first9 <= 3'd7;
	end
	if (control_mask9[6]) begin
		control_first9 <= 3'd6;
	end
	if (control_mask9[5]) begin
		control_first9 <= 3'd5;
	end
	if (control_mask9[4]) begin
		control_first9 <= 3'd4;
	end
	if (control_mask9[3]) begin
		control_first9 <= 2'd3;
	end
	if (control_mask9[2]) begin
		control_first9 <= 2'd2;
	end
	if (control_mask9[1]) begin
		control_first9 <= 1'd1;
	end
	if (control_mask9[0]) begin
		control_first9 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_47 <= dummy_s;
// synthesis translate_on
end
assign control_count10 = (((((control_mask9[0] + control_mask9[1]) + (control_mask9[2] + control_mask9[3])) + ((control_mask9[4] + control_mask9[5]) + (control_mask9[6] + control_mask9[7]))) + (((control_mask9[8] + control_mask9[9]) + (control_mask9[10] + control_mask9[11])) + ((control_mask9[12] + control_mask9[13]) + (control_mask9[14] + control_mask9[15])))) + (((control_mask9[16] + control_mask9[17]) + (control_mask9[18] + control_mask9[19])) + ((control_mask9[20] + control_mask9[21]) + (control_mask9[22] + control_mask9[23]))));
assign control_record9 = {(control_count10 > 1'd1), (control_count10 != 1'd0), 9'd0, control_count10, 11'd0, control_first9};
assign control_wp_memory9_adr = control_frame;
assign control_wp_memory9_dat_w = control_record9;
assign control_wp_memory9_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory9_adr = control_read_address;
assign control_rising10 = (bank_windowcapture10_read_data & (~{bank_windowcapture10_read_data[6:0], control_previous10}));
assign control_mask10 = {control_rising10, control_partial10};

// synthesis translate_off
reg dummy_d_48;
// synthesis translate_on
always @(*) begin
	control_first10 <= 5'd0;
	control_first10 <= 1'd0;
	if (control_mask10[23]) begin
		control_first10 <= 5'd23;
	end
	if (control_mask10[22]) begin
		control_first10 <= 5'd22;
	end
	if (control_mask10[21]) begin
		control_first10 <= 5'd21;
	end
	if (control_mask10[20]) begin
		control_first10 <= 5'd20;
	end
	if (control_mask10[19]) begin
		control_first10 <= 5'd19;
	end
	if (control_mask10[18]) begin
		control_first10 <= 5'd18;
	end
	if (control_mask10[17]) begin
		control_first10 <= 5'd17;
	end
	if (control_mask10[16]) begin
		control_first10 <= 5'd16;
	end
	if (control_mask10[15]) begin
		control_first10 <= 4'd15;
	end
	if (control_mask10[14]) begin
		control_first10 <= 4'd14;
	end
	if (control_mask10[13]) begin
		control_first10 <= 4'd13;
	end
	if (control_mask10[12]) begin
		control_first10 <= 4'd12;
	end
	if (control_mask10[11]) begin
		control_first10 <= 4'd11;
	end
	if (control_mask10[10]) begin
		control_first10 <= 4'd10;
	end
	if (control_mask10[9]) begin
		control_first10 <= 4'd9;
	end
	if (control_mask10[8]) begin
		control_first10 <= 4'd8;
	end
	if (control_mask10[7]) begin
		control_first10 <= 3'd7;
	end
	if (control_mask10[6]) begin
		control_first10 <= 3'd6;
	end
	if (control_mask10[5]) begin
		control_first10 <= 3'd5;
	end
	if (control_mask10[4]) begin
		control_first10 <= 3'd4;
	end
	if (control_mask10[3]) begin
		control_first10 <= 2'd3;
	end
	if (control_mask10[2]) begin
		control_first10 <= 2'd2;
	end
	if (control_mask10[1]) begin
		control_first10 <= 1'd1;
	end
	if (control_mask10[0]) begin
		control_first10 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_48 <= dummy_s;
// synthesis translate_on
end
assign control_count11 = (((((control_mask10[0] + control_mask10[1]) + (control_mask10[2] + control_mask10[3])) + ((control_mask10[4] + control_mask10[5]) + (control_mask10[6] + control_mask10[7]))) + (((control_mask10[8] + control_mask10[9]) + (control_mask10[10] + control_mask10[11])) + ((control_mask10[12] + control_mask10[13]) + (control_mask10[14] + control_mask10[15])))) + (((control_mask10[16] + control_mask10[17]) + (control_mask10[18] + control_mask10[19])) + ((control_mask10[20] + control_mask10[21]) + (control_mask10[22] + control_mask10[23]))));
assign control_record10 = {(control_count11 > 1'd1), (control_count11 != 1'd0), 9'd0, control_count11, 11'd0, control_first10};
assign control_wp_memory10_adr = control_frame;
assign control_wp_memory10_dat_w = control_record10;
assign control_wp_memory10_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory10_adr = control_read_address;
assign control_rising11 = (bank_windowcapture11_read_data & (~{bank_windowcapture11_read_data[6:0], control_previous11}));
assign control_mask11 = {control_rising11, control_partial11};

// synthesis translate_off
reg dummy_d_49;
// synthesis translate_on
always @(*) begin
	control_first11 <= 5'd0;
	control_first11 <= 1'd0;
	if (control_mask11[23]) begin
		control_first11 <= 5'd23;
	end
	if (control_mask11[22]) begin
		control_first11 <= 5'd22;
	end
	if (control_mask11[21]) begin
		control_first11 <= 5'd21;
	end
	if (control_mask11[20]) begin
		control_first11 <= 5'd20;
	end
	if (control_mask11[19]) begin
		control_first11 <= 5'd19;
	end
	if (control_mask11[18]) begin
		control_first11 <= 5'd18;
	end
	if (control_mask11[17]) begin
		control_first11 <= 5'd17;
	end
	if (control_mask11[16]) begin
		control_first11 <= 5'd16;
	end
	if (control_mask11[15]) begin
		control_first11 <= 4'd15;
	end
	if (control_mask11[14]) begin
		control_first11 <= 4'd14;
	end
	if (control_mask11[13]) begin
		control_first11 <= 4'd13;
	end
	if (control_mask11[12]) begin
		control_first11 <= 4'd12;
	end
	if (control_mask11[11]) begin
		control_first11 <= 4'd11;
	end
	if (control_mask11[10]) begin
		control_first11 <= 4'd10;
	end
	if (control_mask11[9]) begin
		control_first11 <= 4'd9;
	end
	if (control_mask11[8]) begin
		control_first11 <= 4'd8;
	end
	if (control_mask11[7]) begin
		control_first11 <= 3'd7;
	end
	if (control_mask11[6]) begin
		control_first11 <= 3'd6;
	end
	if (control_mask11[5]) begin
		control_first11 <= 3'd5;
	end
	if (control_mask11[4]) begin
		control_first11 <= 3'd4;
	end
	if (control_mask11[3]) begin
		control_first11 <= 2'd3;
	end
	if (control_mask11[2]) begin
		control_first11 <= 2'd2;
	end
	if (control_mask11[1]) begin
		control_first11 <= 1'd1;
	end
	if (control_mask11[0]) begin
		control_first11 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_49 <= dummy_s;
// synthesis translate_on
end
assign control_count12 = (((((control_mask11[0] + control_mask11[1]) + (control_mask11[2] + control_mask11[3])) + ((control_mask11[4] + control_mask11[5]) + (control_mask11[6] + control_mask11[7]))) + (((control_mask11[8] + control_mask11[9]) + (control_mask11[10] + control_mask11[11])) + ((control_mask11[12] + control_mask11[13]) + (control_mask11[14] + control_mask11[15])))) + (((control_mask11[16] + control_mask11[17]) + (control_mask11[18] + control_mask11[19])) + ((control_mask11[20] + control_mask11[21]) + (control_mask11[22] + control_mask11[23]))));
assign control_record11 = {(control_count12 > 1'd1), (control_count12 != 1'd0), 9'd0, control_count12, 11'd0, control_first11};
assign control_wp_memory11_adr = control_frame;
assign control_wp_memory11_dat_w = control_record11;
assign control_wp_memory11_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory11_adr = control_read_address;
assign control_rising12 = (bank_windowcapture12_read_data & (~{bank_windowcapture12_read_data[6:0], control_previous12}));
assign control_mask12 = {control_rising12, control_partial12};

// synthesis translate_off
reg dummy_d_50;
// synthesis translate_on
always @(*) begin
	control_first12 <= 5'd0;
	control_first12 <= 1'd0;
	if (control_mask12[23]) begin
		control_first12 <= 5'd23;
	end
	if (control_mask12[22]) begin
		control_first12 <= 5'd22;
	end
	if (control_mask12[21]) begin
		control_first12 <= 5'd21;
	end
	if (control_mask12[20]) begin
		control_first12 <= 5'd20;
	end
	if (control_mask12[19]) begin
		control_first12 <= 5'd19;
	end
	if (control_mask12[18]) begin
		control_first12 <= 5'd18;
	end
	if (control_mask12[17]) begin
		control_first12 <= 5'd17;
	end
	if (control_mask12[16]) begin
		control_first12 <= 5'd16;
	end
	if (control_mask12[15]) begin
		control_first12 <= 4'd15;
	end
	if (control_mask12[14]) begin
		control_first12 <= 4'd14;
	end
	if (control_mask12[13]) begin
		control_first12 <= 4'd13;
	end
	if (control_mask12[12]) begin
		control_first12 <= 4'd12;
	end
	if (control_mask12[11]) begin
		control_first12 <= 4'd11;
	end
	if (control_mask12[10]) begin
		control_first12 <= 4'd10;
	end
	if (control_mask12[9]) begin
		control_first12 <= 4'd9;
	end
	if (control_mask12[8]) begin
		control_first12 <= 4'd8;
	end
	if (control_mask12[7]) begin
		control_first12 <= 3'd7;
	end
	if (control_mask12[6]) begin
		control_first12 <= 3'd6;
	end
	if (control_mask12[5]) begin
		control_first12 <= 3'd5;
	end
	if (control_mask12[4]) begin
		control_first12 <= 3'd4;
	end
	if (control_mask12[3]) begin
		control_first12 <= 2'd3;
	end
	if (control_mask12[2]) begin
		control_first12 <= 2'd2;
	end
	if (control_mask12[1]) begin
		control_first12 <= 1'd1;
	end
	if (control_mask12[0]) begin
		control_first12 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_50 <= dummy_s;
// synthesis translate_on
end
assign control_count13 = (((((control_mask12[0] + control_mask12[1]) + (control_mask12[2] + control_mask12[3])) + ((control_mask12[4] + control_mask12[5]) + (control_mask12[6] + control_mask12[7]))) + (((control_mask12[8] + control_mask12[9]) + (control_mask12[10] + control_mask12[11])) + ((control_mask12[12] + control_mask12[13]) + (control_mask12[14] + control_mask12[15])))) + (((control_mask12[16] + control_mask12[17]) + (control_mask12[18] + control_mask12[19])) + ((control_mask12[20] + control_mask12[21]) + (control_mask12[22] + control_mask12[23]))));
assign control_record12 = {(control_count13 > 1'd1), (control_count13 != 1'd0), 9'd0, control_count13, 11'd0, control_first12};
assign control_wp_memory12_adr = control_frame;
assign control_wp_memory12_dat_w = control_record12;
assign control_wp_memory12_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory12_adr = control_read_address;
assign control_rising13 = (bank_windowcapture13_read_data & (~{bank_windowcapture13_read_data[6:0], control_previous13}));
assign control_mask13 = {control_rising13, control_partial13};

// synthesis translate_off
reg dummy_d_51;
// synthesis translate_on
always @(*) begin
	control_first13 <= 5'd0;
	control_first13 <= 1'd0;
	if (control_mask13[23]) begin
		control_first13 <= 5'd23;
	end
	if (control_mask13[22]) begin
		control_first13 <= 5'd22;
	end
	if (control_mask13[21]) begin
		control_first13 <= 5'd21;
	end
	if (control_mask13[20]) begin
		control_first13 <= 5'd20;
	end
	if (control_mask13[19]) begin
		control_first13 <= 5'd19;
	end
	if (control_mask13[18]) begin
		control_first13 <= 5'd18;
	end
	if (control_mask13[17]) begin
		control_first13 <= 5'd17;
	end
	if (control_mask13[16]) begin
		control_first13 <= 5'd16;
	end
	if (control_mask13[15]) begin
		control_first13 <= 4'd15;
	end
	if (control_mask13[14]) begin
		control_first13 <= 4'd14;
	end
	if (control_mask13[13]) begin
		control_first13 <= 4'd13;
	end
	if (control_mask13[12]) begin
		control_first13 <= 4'd12;
	end
	if (control_mask13[11]) begin
		control_first13 <= 4'd11;
	end
	if (control_mask13[10]) begin
		control_first13 <= 4'd10;
	end
	if (control_mask13[9]) begin
		control_first13 <= 4'd9;
	end
	if (control_mask13[8]) begin
		control_first13 <= 4'd8;
	end
	if (control_mask13[7]) begin
		control_first13 <= 3'd7;
	end
	if (control_mask13[6]) begin
		control_first13 <= 3'd6;
	end
	if (control_mask13[5]) begin
		control_first13 <= 3'd5;
	end
	if (control_mask13[4]) begin
		control_first13 <= 3'd4;
	end
	if (control_mask13[3]) begin
		control_first13 <= 2'd3;
	end
	if (control_mask13[2]) begin
		control_first13 <= 2'd2;
	end
	if (control_mask13[1]) begin
		control_first13 <= 1'd1;
	end
	if (control_mask13[0]) begin
		control_first13 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_51 <= dummy_s;
// synthesis translate_on
end
assign control_count14 = (((((control_mask13[0] + control_mask13[1]) + (control_mask13[2] + control_mask13[3])) + ((control_mask13[4] + control_mask13[5]) + (control_mask13[6] + control_mask13[7]))) + (((control_mask13[8] + control_mask13[9]) + (control_mask13[10] + control_mask13[11])) + ((control_mask13[12] + control_mask13[13]) + (control_mask13[14] + control_mask13[15])))) + (((control_mask13[16] + control_mask13[17]) + (control_mask13[18] + control_mask13[19])) + ((control_mask13[20] + control_mask13[21]) + (control_mask13[22] + control_mask13[23]))));
assign control_record13 = {(control_count14 > 1'd1), (control_count14 != 1'd0), 9'd0, control_count14, 11'd0, control_first13};
assign control_wp_memory13_adr = control_frame;
assign control_wp_memory13_dat_w = control_record13;
assign control_wp_memory13_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory13_adr = control_read_address;
assign control_rising14 = (bank_windowcapture14_read_data & (~{bank_windowcapture14_read_data[6:0], control_previous14}));
assign control_mask14 = {control_rising14, control_partial14};

// synthesis translate_off
reg dummy_d_52;
// synthesis translate_on
always @(*) begin
	control_first14 <= 5'd0;
	control_first14 <= 1'd0;
	if (control_mask14[23]) begin
		control_first14 <= 5'd23;
	end
	if (control_mask14[22]) begin
		control_first14 <= 5'd22;
	end
	if (control_mask14[21]) begin
		control_first14 <= 5'd21;
	end
	if (control_mask14[20]) begin
		control_first14 <= 5'd20;
	end
	if (control_mask14[19]) begin
		control_first14 <= 5'd19;
	end
	if (control_mask14[18]) begin
		control_first14 <= 5'd18;
	end
	if (control_mask14[17]) begin
		control_first14 <= 5'd17;
	end
	if (control_mask14[16]) begin
		control_first14 <= 5'd16;
	end
	if (control_mask14[15]) begin
		control_first14 <= 4'd15;
	end
	if (control_mask14[14]) begin
		control_first14 <= 4'd14;
	end
	if (control_mask14[13]) begin
		control_first14 <= 4'd13;
	end
	if (control_mask14[12]) begin
		control_first14 <= 4'd12;
	end
	if (control_mask14[11]) begin
		control_first14 <= 4'd11;
	end
	if (control_mask14[10]) begin
		control_first14 <= 4'd10;
	end
	if (control_mask14[9]) begin
		control_first14 <= 4'd9;
	end
	if (control_mask14[8]) begin
		control_first14 <= 4'd8;
	end
	if (control_mask14[7]) begin
		control_first14 <= 3'd7;
	end
	if (control_mask14[6]) begin
		control_first14 <= 3'd6;
	end
	if (control_mask14[5]) begin
		control_first14 <= 3'd5;
	end
	if (control_mask14[4]) begin
		control_first14 <= 3'd4;
	end
	if (control_mask14[3]) begin
		control_first14 <= 2'd3;
	end
	if (control_mask14[2]) begin
		control_first14 <= 2'd2;
	end
	if (control_mask14[1]) begin
		control_first14 <= 1'd1;
	end
	if (control_mask14[0]) begin
		control_first14 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_52 <= dummy_s;
// synthesis translate_on
end
assign control_count15 = (((((control_mask14[0] + control_mask14[1]) + (control_mask14[2] + control_mask14[3])) + ((control_mask14[4] + control_mask14[5]) + (control_mask14[6] + control_mask14[7]))) + (((control_mask14[8] + control_mask14[9]) + (control_mask14[10] + control_mask14[11])) + ((control_mask14[12] + control_mask14[13]) + (control_mask14[14] + control_mask14[15])))) + (((control_mask14[16] + control_mask14[17]) + (control_mask14[18] + control_mask14[19])) + ((control_mask14[20] + control_mask14[21]) + (control_mask14[22] + control_mask14[23]))));
assign control_record14 = {(control_count15 > 1'd1), (control_count15 != 1'd0), 9'd0, control_count15, 11'd0, control_first14};
assign control_wp_memory14_adr = control_frame;
assign control_wp_memory14_dat_w = control_record14;
assign control_wp_memory14_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory14_adr = control_read_address;
assign control_rising15 = (bank_windowcapture15_read_data & (~{bank_windowcapture15_read_data[6:0], control_previous15}));
assign control_mask15 = {control_rising15, control_partial15};

// synthesis translate_off
reg dummy_d_53;
// synthesis translate_on
always @(*) begin
	control_first15 <= 5'd0;
	control_first15 <= 1'd0;
	if (control_mask15[23]) begin
		control_first15 <= 5'd23;
	end
	if (control_mask15[22]) begin
		control_first15 <= 5'd22;
	end
	if (control_mask15[21]) begin
		control_first15 <= 5'd21;
	end
	if (control_mask15[20]) begin
		control_first15 <= 5'd20;
	end
	if (control_mask15[19]) begin
		control_first15 <= 5'd19;
	end
	if (control_mask15[18]) begin
		control_first15 <= 5'd18;
	end
	if (control_mask15[17]) begin
		control_first15 <= 5'd17;
	end
	if (control_mask15[16]) begin
		control_first15 <= 5'd16;
	end
	if (control_mask15[15]) begin
		control_first15 <= 4'd15;
	end
	if (control_mask15[14]) begin
		control_first15 <= 4'd14;
	end
	if (control_mask15[13]) begin
		control_first15 <= 4'd13;
	end
	if (control_mask15[12]) begin
		control_first15 <= 4'd12;
	end
	if (control_mask15[11]) begin
		control_first15 <= 4'd11;
	end
	if (control_mask15[10]) begin
		control_first15 <= 4'd10;
	end
	if (control_mask15[9]) begin
		control_first15 <= 4'd9;
	end
	if (control_mask15[8]) begin
		control_first15 <= 4'd8;
	end
	if (control_mask15[7]) begin
		control_first15 <= 3'd7;
	end
	if (control_mask15[6]) begin
		control_first15 <= 3'd6;
	end
	if (control_mask15[5]) begin
		control_first15 <= 3'd5;
	end
	if (control_mask15[4]) begin
		control_first15 <= 3'd4;
	end
	if (control_mask15[3]) begin
		control_first15 <= 2'd3;
	end
	if (control_mask15[2]) begin
		control_first15 <= 2'd2;
	end
	if (control_mask15[1]) begin
		control_first15 <= 1'd1;
	end
	if (control_mask15[0]) begin
		control_first15 <= 1'd0;
	end
// synthesis translate_off
	dummy_d_53 <= dummy_s;
// synthesis translate_on
end
assign control_count16 = (((((control_mask15[0] + control_mask15[1]) + (control_mask15[2] + control_mask15[3])) + ((control_mask15[4] + control_mask15[5]) + (control_mask15[6] + control_mask15[7]))) + (((control_mask15[8] + control_mask15[9]) + (control_mask15[10] + control_mask15[11])) + ((control_mask15[12] + control_mask15[13]) + (control_mask15[14] + control_mask15[15])))) + (((control_mask15[16] + control_mask15[17]) + (control_mask15[18] + control_mask15[19])) + ((control_mask15[20] + control_mask15[21]) + (control_mask15[22] + control_mask15[23]))));
assign control_record15 = {(control_count16 > 1'd1), (control_count16 != 1'd0), 9'd0, control_count16, 11'd0, control_first15};
assign control_wp_memory15_adr = control_frame;
assign control_wp_memory15_dat_w = control_record15;
assign control_wp_memory15_we = ((control_busy1 & (control_state == 2'd3)) & (control_stage == 2'd2));
assign control_rp_memory15_adr = control_read_address;
assign slice_proxy = {ethernet_tx_crc_value, ethernet_tx_crc_sink_payload_data[7:0]};

// synthesis translate_off
reg dummy_d_54;
// synthesis translate_on
always @(*) begin
	self0 <= 11'd0;
	case (selected)
		1'd0: begin
			self0 <= 11'd1537;
		end
		1'd1: begin
			self0 <= 11'd1539;
		end
		2'd2: begin
			self0 <= 11'd1541;
		end
		2'd3: begin
			self0 <= 11'd1543;
		end
		3'd4: begin
			self0 <= 11'd1545;
		end
		3'd5: begin
			self0 <= 11'd1547;
		end
		3'd6: begin
			self0 <= 11'd1549;
		end
		3'd7: begin
			self0 <= 11'd1551;
		end
		4'd8: begin
			self0 <= 11'd1793;
		end
		4'd9: begin
			self0 <= 11'd1795;
		end
		4'd10: begin
			self0 <= 11'd1797;
		end
		4'd11: begin
			self0 <= 11'd1799;
		end
		4'd12: begin
			self0 <= 11'd1801;
		end
		4'd13: begin
			self0 <= 11'd1803;
		end
		4'd14: begin
			self0 <= 11'd1805;
		end
		default: begin
			self0 <= 11'd1807;
		end
	endcase
// synthesis translate_off
	dummy_d_54 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_55;
// synthesis translate_on
always @(*) begin
	self1 <= 13'd0;
	case (control_bank)
		1'd0: begin
			self1 <= bank_windowcapture0_count;
		end
		1'd1: begin
			self1 <= bank_windowcapture1_count;
		end
		2'd2: begin
			self1 <= bank_windowcapture2_count;
		end
		2'd3: begin
			self1 <= bank_windowcapture3_count;
		end
		3'd4: begin
			self1 <= bank_windowcapture4_count;
		end
		3'd5: begin
			self1 <= bank_windowcapture5_count;
		end
		3'd6: begin
			self1 <= bank_windowcapture6_count;
		end
		3'd7: begin
			self1 <= bank_windowcapture7_count;
		end
		4'd8: begin
			self1 <= bank_windowcapture8_count;
		end
		4'd9: begin
			self1 <= bank_windowcapture9_count;
		end
		4'd10: begin
			self1 <= bank_windowcapture10_count;
		end
		4'd11: begin
			self1 <= bank_windowcapture11_count;
		end
		4'd12: begin
			self1 <= bank_windowcapture12_count;
		end
		4'd13: begin
			self1 <= bank_windowcapture13_count;
		end
		4'd14: begin
			self1 <= bank_windowcapture14_count;
		end
		default: begin
			self1 <= bank_windowcapture15_count;
		end
	endcase
// synthesis translate_off
	dummy_d_55 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_56;
// synthesis translate_on
always @(*) begin
	self2 <= 8'd0;
	case (control_bank)
		1'd0: begin
			self2 <= bank_windowcapture0_read_data;
		end
		1'd1: begin
			self2 <= bank_windowcapture1_read_data;
		end
		2'd2: begin
			self2 <= bank_windowcapture2_read_data;
		end
		2'd3: begin
			self2 <= bank_windowcapture3_read_data;
		end
		3'd4: begin
			self2 <= bank_windowcapture4_read_data;
		end
		3'd5: begin
			self2 <= bank_windowcapture5_read_data;
		end
		3'd6: begin
			self2 <= bank_windowcapture6_read_data;
		end
		3'd7: begin
			self2 <= bank_windowcapture7_read_data;
		end
		4'd8: begin
			self2 <= bank_windowcapture8_read_data;
		end
		4'd9: begin
			self2 <= bank_windowcapture9_read_data;
		end
		4'd10: begin
			self2 <= bank_windowcapture10_read_data;
		end
		4'd11: begin
			self2 <= bank_windowcapture11_read_data;
		end
		4'd12: begin
			self2 <= bank_windowcapture12_read_data;
		end
		4'd13: begin
			self2 <= bank_windowcapture13_read_data;
		end
		4'd14: begin
			self2 <= bank_windowcapture14_read_data;
		end
		default: begin
			self2 <= bank_windowcapture15_read_data;
		end
	endcase
// synthesis translate_off
	dummy_d_56 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_57;
// synthesis translate_on
always @(*) begin
	self3 <= 13'd0;
	case (control_bank)
		1'd0: begin
			self3 <= bank_windowcapture0_count;
		end
		1'd1: begin
			self3 <= bank_windowcapture1_count;
		end
		2'd2: begin
			self3 <= bank_windowcapture2_count;
		end
		2'd3: begin
			self3 <= bank_windowcapture3_count;
		end
		3'd4: begin
			self3 <= bank_windowcapture4_count;
		end
		3'd5: begin
			self3 <= bank_windowcapture5_count;
		end
		3'd6: begin
			self3 <= bank_windowcapture6_count;
		end
		3'd7: begin
			self3 <= bank_windowcapture7_count;
		end
		4'd8: begin
			self3 <= bank_windowcapture8_count;
		end
		4'd9: begin
			self3 <= bank_windowcapture9_count;
		end
		4'd10: begin
			self3 <= bank_windowcapture10_count;
		end
		4'd11: begin
			self3 <= bank_windowcapture11_count;
		end
		4'd12: begin
			self3 <= bank_windowcapture12_count;
		end
		4'd13: begin
			self3 <= bank_windowcapture13_count;
		end
		4'd14: begin
			self3 <= bank_windowcapture14_count;
		end
		default: begin
			self3 <= bank_windowcapture15_count;
		end
	endcase
// synthesis translate_off
	dummy_d_57 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_58;
// synthesis translate_on
always @(*) begin
	self4 <= 32'd0;
	case (control_bank)
		1'd0: begin
			self4 <= bank_windowcapture0_start_sample[31:0];
		end
		1'd1: begin
			self4 <= bank_windowcapture1_start_sample[31:0];
		end
		2'd2: begin
			self4 <= bank_windowcapture2_start_sample[31:0];
		end
		2'd3: begin
			self4 <= bank_windowcapture3_start_sample[31:0];
		end
		3'd4: begin
			self4 <= bank_windowcapture4_start_sample[31:0];
		end
		3'd5: begin
			self4 <= bank_windowcapture5_start_sample[31:0];
		end
		3'd6: begin
			self4 <= bank_windowcapture6_start_sample[31:0];
		end
		3'd7: begin
			self4 <= bank_windowcapture7_start_sample[31:0];
		end
		4'd8: begin
			self4 <= bank_windowcapture8_start_sample[31:0];
		end
		4'd9: begin
			self4 <= bank_windowcapture9_start_sample[31:0];
		end
		4'd10: begin
			self4 <= bank_windowcapture10_start_sample[31:0];
		end
		4'd11: begin
			self4 <= bank_windowcapture11_start_sample[31:0];
		end
		4'd12: begin
			self4 <= bank_windowcapture12_start_sample[31:0];
		end
		4'd13: begin
			self4 <= bank_windowcapture13_start_sample[31:0];
		end
		4'd14: begin
			self4 <= bank_windowcapture14_start_sample[31:0];
		end
		default: begin
			self4 <= bank_windowcapture15_start_sample[31:0];
		end
	endcase
// synthesis translate_off
	dummy_d_58 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_59;
// synthesis translate_on
always @(*) begin
	self5 <= 32'd0;
	case (control_bank)
		1'd0: begin
			self5 <= bank_windowcapture0_start_sample[63:32];
		end
		1'd1: begin
			self5 <= bank_windowcapture1_start_sample[63:32];
		end
		2'd2: begin
			self5 <= bank_windowcapture2_start_sample[63:32];
		end
		2'd3: begin
			self5 <= bank_windowcapture3_start_sample[63:32];
		end
		3'd4: begin
			self5 <= bank_windowcapture4_start_sample[63:32];
		end
		3'd5: begin
			self5 <= bank_windowcapture5_start_sample[63:32];
		end
		3'd6: begin
			self5 <= bank_windowcapture6_start_sample[63:32];
		end
		3'd7: begin
			self5 <= bank_windowcapture7_start_sample[63:32];
		end
		4'd8: begin
			self5 <= bank_windowcapture8_start_sample[63:32];
		end
		4'd9: begin
			self5 <= bank_windowcapture9_start_sample[63:32];
		end
		4'd10: begin
			self5 <= bank_windowcapture10_start_sample[63:32];
		end
		4'd11: begin
			self5 <= bank_windowcapture11_start_sample[63:32];
		end
		4'd12: begin
			self5 <= bank_windowcapture12_start_sample[63:32];
		end
		4'd13: begin
			self5 <= bank_windowcapture13_start_sample[63:32];
		end
		4'd14: begin
			self5 <= bank_windowcapture14_start_sample[63:32];
		end
		default: begin
			self5 <= bank_windowcapture15_start_sample[63:32];
		end
	endcase
// synthesis translate_off
	dummy_d_59 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_60;
// synthesis translate_on
always @(*) begin
	self6 <= 1'd0;
	case (control_bank)
		1'd0: begin
			self6 <= bank_windowcapture0_previous;
		end
		1'd1: begin
			self6 <= bank_windowcapture1_previous;
		end
		2'd2: begin
			self6 <= bank_windowcapture2_previous;
		end
		2'd3: begin
			self6 <= bank_windowcapture3_previous;
		end
		3'd4: begin
			self6 <= bank_windowcapture4_previous;
		end
		3'd5: begin
			self6 <= bank_windowcapture5_previous;
		end
		3'd6: begin
			self6 <= bank_windowcapture6_previous;
		end
		3'd7: begin
			self6 <= bank_windowcapture7_previous;
		end
		4'd8: begin
			self6 <= bank_windowcapture8_previous;
		end
		4'd9: begin
			self6 <= bank_windowcapture9_previous;
		end
		4'd10: begin
			self6 <= bank_windowcapture10_previous;
		end
		4'd11: begin
			self6 <= bank_windowcapture11_previous;
		end
		4'd12: begin
			self6 <= bank_windowcapture12_previous;
		end
		4'd13: begin
			self6 <= bank_windowcapture13_previous;
		end
		4'd14: begin
			self6 <= bank_windowcapture14_previous;
		end
		default: begin
			self6 <= bank_windowcapture15_previous;
		end
	endcase
// synthesis translate_off
	dummy_d_60 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_61;
// synthesis translate_on
always @(*) begin
	self7 <= 32'd0;
	case (control_bank)
		1'd0: begin
			self7 <= control_rp_memory0_dat_r;
		end
		1'd1: begin
			self7 <= control_rp_memory1_dat_r;
		end
		2'd2: begin
			self7 <= control_rp_memory2_dat_r;
		end
		2'd3: begin
			self7 <= control_rp_memory3_dat_r;
		end
		3'd4: begin
			self7 <= control_rp_memory4_dat_r;
		end
		3'd5: begin
			self7 <= control_rp_memory5_dat_r;
		end
		3'd6: begin
			self7 <= control_rp_memory6_dat_r;
		end
		3'd7: begin
			self7 <= control_rp_memory7_dat_r;
		end
		4'd8: begin
			self7 <= control_rp_memory8_dat_r;
		end
		4'd9: begin
			self7 <= control_rp_memory9_dat_r;
		end
		4'd10: begin
			self7 <= control_rp_memory10_dat_r;
		end
		4'd11: begin
			self7 <= control_rp_memory11_dat_r;
		end
		4'd12: begin
			self7 <= control_rp_memory12_dat_r;
		end
		4'd13: begin
			self7 <= control_rp_memory13_dat_r;
		end
		4'd14: begin
			self7 <= control_rp_memory14_dat_r;
		end
		default: begin
			self7 <= control_rp_memory15_dat_r;
		end
	endcase
// synthesis translate_off
	dummy_d_61 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_62;
// synthesis translate_on
always @(*) begin
	t_self0 <= 3'd0;
	case (ethernet_pcsrx_decoder_input_msb_first[3:0])
		1'd0: begin
			t_self0 <= 1'd0;
		end
		1'd1: begin
			t_self0 <= 1'd0;
		end
		2'd2: begin
			t_self0 <= 3'd4;
		end
		2'd3: begin
			t_self0 <= 2'd3;
		end
		3'd4: begin
			t_self0 <= 1'd0;
		end
		3'd5: begin
			t_self0 <= 2'd2;
		end
		3'd6: begin
			t_self0 <= 3'd6;
		end
		3'd7: begin
			t_self0 <= 1'd0;
		end
		4'd8: begin
			t_self0 <= 3'd7;
		end
		4'd9: begin
			t_self0 <= 1'd1;
		end
		4'd10: begin
			t_self0 <= 3'd5;
		end
		4'd11: begin
			t_self0 <= 1'd0;
		end
		4'd12: begin
			t_self0 <= 1'd0;
		end
		4'd13: begin
			t_self0 <= 1'd0;
		end
		4'd14: begin
			t_self0 <= 1'd0;
		end
		default: begin
			t_self0 <= 1'd0;
		end
	endcase
// synthesis translate_off
	dummy_d_62 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_63;
// synthesis translate_on
always @(*) begin
	t_self1 <= 3'd0;
	case (ethernet_pcsrx_decoder_input_msb_first[3:0])
		1'd0: begin
			t_self1 <= 1'd0;
		end
		1'd1: begin
			t_self1 <= 1'd0;
		end
		2'd2: begin
			t_self1 <= 1'd0;
		end
		2'd3: begin
			t_self1 <= 1'd0;
		end
		3'd4: begin
			t_self1 <= 1'd0;
		end
		3'd5: begin
			t_self1 <= 3'd5;
		end
		3'd6: begin
			t_self1 <= 1'd1;
		end
		3'd7: begin
			t_self1 <= 3'd7;
		end
		4'd8: begin
			t_self1 <= 1'd0;
		end
		4'd9: begin
			t_self1 <= 3'd6;
		end
		4'd10: begin
			t_self1 <= 2'd2;
		end
		4'd11: begin
			t_self1 <= 1'd0;
		end
		4'd12: begin
			t_self1 <= 2'd3;
		end
		4'd13: begin
			t_self1 <= 3'd4;
		end
		4'd14: begin
			t_self1 <= 1'd0;
		end
		default: begin
			t_self1 <= 1'd0;
		end
	endcase
// synthesis translate_off
	dummy_d_63 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_64;
// synthesis translate_on
always @(*) begin
	f_self <= 3'd0;
	case (ethernet_pcsrx_decoder_input_msb_first[3:0])
		1'd0: begin
			f_self <= 1'd0;
		end
		1'd1: begin
			f_self <= 3'd7;
		end
		2'd2: begin
			f_self <= 3'd4;
		end
		2'd3: begin
			f_self <= 2'd3;
		end
		3'd4: begin
			f_self <= 1'd0;
		end
		3'd5: begin
			f_self <= 2'd2;
		end
		3'd6: begin
			f_self <= 3'd6;
		end
		3'd7: begin
			f_self <= 3'd7;
		end
		4'd8: begin
			f_self <= 3'd7;
		end
		4'd9: begin
			f_self <= 1'd1;
		end
		4'd10: begin
			f_self <= 3'd5;
		end
		4'd11: begin
			f_self <= 1'd0;
		end
		4'd12: begin
			f_self <= 2'd3;
		end
		4'd13: begin
			f_self <= 3'd4;
		end
		4'd14: begin
			f_self <= 3'd7;
		end
		default: begin
			f_self <= 1'd0;
		end
	endcase
// synthesis translate_off
	dummy_d_64 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_65;
// synthesis translate_on
always @(*) begin
	rhs_self0 <= 6'd0;
	case (ethernet_pcstx_encoder_d[4:0])
		1'd0: begin
			rhs_self0 <= 5'd24;
		end
		1'd1: begin
			rhs_self0 <= 6'd34;
		end
		2'd2: begin
			rhs_self0 <= 5'd18;
		end
		2'd3: begin
			rhs_self0 <= 6'd49;
		end
		3'd4: begin
			rhs_self0 <= 4'd10;
		end
		3'd5: begin
			rhs_self0 <= 6'd41;
		end
		3'd6: begin
			rhs_self0 <= 5'd25;
		end
		3'd7: begin
			rhs_self0 <= 3'd7;
		end
		4'd8: begin
			rhs_self0 <= 3'd6;
		end
		4'd9: begin
			rhs_self0 <= 6'd37;
		end
		4'd10: begin
			rhs_self0 <= 5'd21;
		end
		4'd11: begin
			rhs_self0 <= 6'd52;
		end
		4'd12: begin
			rhs_self0 <= 4'd13;
		end
		4'd13: begin
			rhs_self0 <= 6'd44;
		end
		4'd14: begin
			rhs_self0 <= 5'd28;
		end
		4'd15: begin
			rhs_self0 <= 6'd40;
		end
		5'd16: begin
			rhs_self0 <= 6'd36;
		end
		5'd17: begin
			rhs_self0 <= 6'd35;
		end
		5'd18: begin
			rhs_self0 <= 5'd19;
		end
		5'd19: begin
			rhs_self0 <= 6'd50;
		end
		5'd20: begin
			rhs_self0 <= 4'd11;
		end
		5'd21: begin
			rhs_self0 <= 6'd42;
		end
		5'd22: begin
			rhs_self0 <= 5'd26;
		end
		5'd23: begin
			rhs_self0 <= 3'd5;
		end
		5'd24: begin
			rhs_self0 <= 4'd12;
		end
		5'd25: begin
			rhs_self0 <= 6'd38;
		end
		5'd26: begin
			rhs_self0 <= 5'd22;
		end
		5'd27: begin
			rhs_self0 <= 4'd9;
		end
		5'd28: begin
			rhs_self0 <= 4'd14;
		end
		5'd29: begin
			rhs_self0 <= 5'd17;
		end
		5'd30: begin
			rhs_self0 <= 6'd33;
		end
		default: begin
			rhs_self0 <= 5'd20;
		end
	endcase
// synthesis translate_off
	dummy_d_65 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_66;
// synthesis translate_on
always @(*) begin
	rhs_self1 <= 1'd0;
	case (ethernet_pcstx_encoder_d[4:0])
		1'd0: begin
			rhs_self1 <= 1'd1;
		end
		1'd1: begin
			rhs_self1 <= 1'd1;
		end
		2'd2: begin
			rhs_self1 <= 1'd1;
		end
		2'd3: begin
			rhs_self1 <= 1'd0;
		end
		3'd4: begin
			rhs_self1 <= 1'd1;
		end
		3'd5: begin
			rhs_self1 <= 1'd0;
		end
		3'd6: begin
			rhs_self1 <= 1'd0;
		end
		3'd7: begin
			rhs_self1 <= 1'd0;
		end
		4'd8: begin
			rhs_self1 <= 1'd1;
		end
		4'd9: begin
			rhs_self1 <= 1'd0;
		end
		4'd10: begin
			rhs_self1 <= 1'd0;
		end
		4'd11: begin
			rhs_self1 <= 1'd0;
		end
		4'd12: begin
			rhs_self1 <= 1'd0;
		end
		4'd13: begin
			rhs_self1 <= 1'd0;
		end
		4'd14: begin
			rhs_self1 <= 1'd0;
		end
		4'd15: begin
			rhs_self1 <= 1'd1;
		end
		5'd16: begin
			rhs_self1 <= 1'd1;
		end
		5'd17: begin
			rhs_self1 <= 1'd0;
		end
		5'd18: begin
			rhs_self1 <= 1'd0;
		end
		5'd19: begin
			rhs_self1 <= 1'd0;
		end
		5'd20: begin
			rhs_self1 <= 1'd0;
		end
		5'd21: begin
			rhs_self1 <= 1'd0;
		end
		5'd22: begin
			rhs_self1 <= 1'd0;
		end
		5'd23: begin
			rhs_self1 <= 1'd1;
		end
		5'd24: begin
			rhs_self1 <= 1'd1;
		end
		5'd25: begin
			rhs_self1 <= 1'd0;
		end
		5'd26: begin
			rhs_self1 <= 1'd0;
		end
		5'd27: begin
			rhs_self1 <= 1'd1;
		end
		5'd28: begin
			rhs_self1 <= 1'd0;
		end
		5'd29: begin
			rhs_self1 <= 1'd1;
		end
		5'd30: begin
			rhs_self1 <= 1'd1;
		end
		default: begin
			rhs_self1 <= 1'd1;
		end
	endcase
// synthesis translate_off
	dummy_d_66 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_67;
// synthesis translate_on
always @(*) begin
	rhs_self2 <= 1'd0;
	case (ethernet_pcstx_encoder_d[4:0])
		1'd0: begin
			rhs_self2 <= 1'd1;
		end
		1'd1: begin
			rhs_self2 <= 1'd1;
		end
		2'd2: begin
			rhs_self2 <= 1'd1;
		end
		2'd3: begin
			rhs_self2 <= 1'd0;
		end
		3'd4: begin
			rhs_self2 <= 1'd1;
		end
		3'd5: begin
			rhs_self2 <= 1'd0;
		end
		3'd6: begin
			rhs_self2 <= 1'd0;
		end
		3'd7: begin
			rhs_self2 <= 1'd1;
		end
		4'd8: begin
			rhs_self2 <= 1'd1;
		end
		4'd9: begin
			rhs_self2 <= 1'd0;
		end
		4'd10: begin
			rhs_self2 <= 1'd0;
		end
		4'd11: begin
			rhs_self2 <= 1'd0;
		end
		4'd12: begin
			rhs_self2 <= 1'd0;
		end
		4'd13: begin
			rhs_self2 <= 1'd0;
		end
		4'd14: begin
			rhs_self2 <= 1'd0;
		end
		4'd15: begin
			rhs_self2 <= 1'd1;
		end
		5'd16: begin
			rhs_self2 <= 1'd1;
		end
		5'd17: begin
			rhs_self2 <= 1'd0;
		end
		5'd18: begin
			rhs_self2 <= 1'd0;
		end
		5'd19: begin
			rhs_self2 <= 1'd0;
		end
		5'd20: begin
			rhs_self2 <= 1'd0;
		end
		5'd21: begin
			rhs_self2 <= 1'd0;
		end
		5'd22: begin
			rhs_self2 <= 1'd0;
		end
		5'd23: begin
			rhs_self2 <= 1'd1;
		end
		5'd24: begin
			rhs_self2 <= 1'd1;
		end
		5'd25: begin
			rhs_self2 <= 1'd0;
		end
		5'd26: begin
			rhs_self2 <= 1'd0;
		end
		5'd27: begin
			rhs_self2 <= 1'd1;
		end
		5'd28: begin
			rhs_self2 <= 1'd0;
		end
		5'd29: begin
			rhs_self2 <= 1'd1;
		end
		5'd30: begin
			rhs_self2 <= 1'd1;
		end
		default: begin
			rhs_self2 <= 1'd1;
		end
	endcase
// synthesis translate_off
	dummy_d_67 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_68;
// synthesis translate_on
always @(*) begin
	rhs_self3 <= 4'd0;
	case (ethernet_pcstx_encoder_d[7:5])
		1'd0: begin
			rhs_self3 <= 3'd4;
		end
		1'd1: begin
			rhs_self3 <= 4'd9;
		end
		2'd2: begin
			rhs_self3 <= 3'd5;
		end
		2'd3: begin
			rhs_self3 <= 2'd3;
		end
		3'd4: begin
			rhs_self3 <= 2'd2;
		end
		3'd5: begin
			rhs_self3 <= 4'd10;
		end
		3'd6: begin
			rhs_self3 <= 3'd6;
		end
		default: begin
			rhs_self3 <= 1'd1;
		end
	endcase
// synthesis translate_off
	dummy_d_68 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_69;
// synthesis translate_on
always @(*) begin
	rhs_self4 <= 1'd0;
	case (ethernet_pcstx_encoder_d[7:5])
		1'd0: begin
			rhs_self4 <= 1'd1;
		end
		1'd1: begin
			rhs_self4 <= 1'd0;
		end
		2'd2: begin
			rhs_self4 <= 1'd0;
		end
		2'd3: begin
			rhs_self4 <= 1'd0;
		end
		3'd4: begin
			rhs_self4 <= 1'd1;
		end
		3'd5: begin
			rhs_self4 <= 1'd0;
		end
		3'd6: begin
			rhs_self4 <= 1'd0;
		end
		default: begin
			rhs_self4 <= 1'd1;
		end
	endcase
// synthesis translate_off
	dummy_d_69 <= dummy_s;
// synthesis translate_on
end

// synthesis translate_off
reg dummy_d_70;
// synthesis translate_on
always @(*) begin
	rhs_self5 <= 1'd0;
	case (ethernet_pcstx_encoder_d[7:5])
		1'd0: begin
			rhs_self5 <= 1'd1;
		end
		1'd1: begin
			rhs_self5 <= 1'd0;
		end
		2'd2: begin
			rhs_self5 <= 1'd0;
		end
		2'd3: begin
			rhs_self5 <= 1'd1;
		end
		3'd4: begin
			rhs_self5 <= 1'd1;
		end
		3'd5: begin
			rhs_self5 <= 1'd0;
		end
		3'd6: begin
			rhs_self5 <= 1'd0;
		end
		default: begin
			rhs_self5 <= 1'd1;
		end
	endcase
// synthesis translate_off
	dummy_d_70 <= dummy_s;
// synthesis translate_on
end
assign xilinxasyncresetsynchronizerimpl0_async_reset = (~locked0);
assign xilinxasyncresetsynchronizerimpl1_async_reset = (~locked0);
assign xilinxasyncresetsynchronizerimpl2_async_reset = (~locked1);
assign rx_lock = xilinxmultiregimpl01;
assign bank_windowcapture0_request_rx = xilinxmultiregimpl11;
assign bank_windowcapture0_ack_sys = xilinxmultiregimpl21;
assign bank_windowcapture0_ready_sys = xilinxmultiregimpl31;
assign bank_windowcapture0_length_rx = xilinxmultiregimpl41;
assign bank_windowcapture0_start_sample = xilinxmultiregimpl51;
assign bank_windowcapture0_previous = xilinxmultiregimpl61;
assign bank_windowcapture0_count = xilinxmultiregimpl71;
assign bank_windowcapture0_aborted_sys = xilinxmultiregimpl81;
assign bank_windowcapture1_request_rx = xilinxmultiregimpl91;
assign bank_windowcapture1_ack_sys = xilinxmultiregimpl101;
assign bank_windowcapture1_ready_sys = xilinxmultiregimpl111;
assign bank_windowcapture1_length_rx = xilinxmultiregimpl121;
assign bank_windowcapture1_start_sample = xilinxmultiregimpl131;
assign bank_windowcapture1_previous = xilinxmultiregimpl141;
assign bank_windowcapture1_count = xilinxmultiregimpl151;
assign bank_windowcapture1_aborted_sys = xilinxmultiregimpl161;
assign bank_windowcapture2_request_rx = xilinxmultiregimpl171;
assign bank_windowcapture2_ack_sys = xilinxmultiregimpl181;
assign bank_windowcapture2_ready_sys = xilinxmultiregimpl191;
assign bank_windowcapture2_length_rx = xilinxmultiregimpl201;
assign bank_windowcapture2_start_sample = xilinxmultiregimpl211;
assign bank_windowcapture2_previous = xilinxmultiregimpl221;
assign bank_windowcapture2_count = xilinxmultiregimpl231;
assign bank_windowcapture2_aborted_sys = xilinxmultiregimpl241;
assign bank_windowcapture3_request_rx = xilinxmultiregimpl251;
assign bank_windowcapture3_ack_sys = xilinxmultiregimpl261;
assign bank_windowcapture3_ready_sys = xilinxmultiregimpl271;
assign bank_windowcapture3_length_rx = xilinxmultiregimpl281;
assign bank_windowcapture3_start_sample = xilinxmultiregimpl291;
assign bank_windowcapture3_previous = xilinxmultiregimpl301;
assign bank_windowcapture3_count = xilinxmultiregimpl311;
assign bank_windowcapture3_aborted_sys = xilinxmultiregimpl321;
assign bank_windowcapture4_request_rx = xilinxmultiregimpl331;
assign bank_windowcapture4_ack_sys = xilinxmultiregimpl341;
assign bank_windowcapture4_ready_sys = xilinxmultiregimpl351;
assign bank_windowcapture4_length_rx = xilinxmultiregimpl361;
assign bank_windowcapture4_start_sample = xilinxmultiregimpl371;
assign bank_windowcapture4_previous = xilinxmultiregimpl381;
assign bank_windowcapture4_count = xilinxmultiregimpl391;
assign bank_windowcapture4_aborted_sys = xilinxmultiregimpl401;
assign bank_windowcapture5_request_rx = xilinxmultiregimpl411;
assign bank_windowcapture5_ack_sys = xilinxmultiregimpl421;
assign bank_windowcapture5_ready_sys = xilinxmultiregimpl431;
assign bank_windowcapture5_length_rx = xilinxmultiregimpl441;
assign bank_windowcapture5_start_sample = xilinxmultiregimpl451;
assign bank_windowcapture5_previous = xilinxmultiregimpl461;
assign bank_windowcapture5_count = xilinxmultiregimpl471;
assign bank_windowcapture5_aborted_sys = xilinxmultiregimpl481;
assign bank_windowcapture6_request_rx = xilinxmultiregimpl491;
assign bank_windowcapture6_ack_sys = xilinxmultiregimpl501;
assign bank_windowcapture6_ready_sys = xilinxmultiregimpl511;
assign bank_windowcapture6_length_rx = xilinxmultiregimpl521;
assign bank_windowcapture6_start_sample = xilinxmultiregimpl531;
assign bank_windowcapture6_previous = xilinxmultiregimpl541;
assign bank_windowcapture6_count = xilinxmultiregimpl551;
assign bank_windowcapture6_aborted_sys = xilinxmultiregimpl561;
assign bank_windowcapture7_request_rx = xilinxmultiregimpl571;
assign bank_windowcapture7_ack_sys = xilinxmultiregimpl581;
assign bank_windowcapture7_ready_sys = xilinxmultiregimpl591;
assign bank_windowcapture7_length_rx = xilinxmultiregimpl601;
assign bank_windowcapture7_start_sample = xilinxmultiregimpl611;
assign bank_windowcapture7_previous = xilinxmultiregimpl621;
assign bank_windowcapture7_count = xilinxmultiregimpl631;
assign bank_windowcapture7_aborted_sys = xilinxmultiregimpl641;
assign bank_windowcapture8_request_rx = xilinxmultiregimpl651;
assign bank_windowcapture8_ack_sys = xilinxmultiregimpl661;
assign bank_windowcapture8_ready_sys = xilinxmultiregimpl671;
assign bank_windowcapture8_length_rx = xilinxmultiregimpl681;
assign bank_windowcapture8_start_sample = xilinxmultiregimpl691;
assign bank_windowcapture8_previous = xilinxmultiregimpl701;
assign bank_windowcapture8_count = xilinxmultiregimpl711;
assign bank_windowcapture8_aborted_sys = xilinxmultiregimpl721;
assign bank_windowcapture9_request_rx = xilinxmultiregimpl731;
assign bank_windowcapture9_ack_sys = xilinxmultiregimpl741;
assign bank_windowcapture9_ready_sys = xilinxmultiregimpl751;
assign bank_windowcapture9_length_rx = xilinxmultiregimpl761;
assign bank_windowcapture9_start_sample = xilinxmultiregimpl771;
assign bank_windowcapture9_previous = xilinxmultiregimpl781;
assign bank_windowcapture9_count = xilinxmultiregimpl791;
assign bank_windowcapture9_aborted_sys = xilinxmultiregimpl801;
assign bank_windowcapture10_request_rx = xilinxmultiregimpl811;
assign bank_windowcapture10_ack_sys = xilinxmultiregimpl821;
assign bank_windowcapture10_ready_sys = xilinxmultiregimpl831;
assign bank_windowcapture10_length_rx = xilinxmultiregimpl841;
assign bank_windowcapture10_start_sample = xilinxmultiregimpl851;
assign bank_windowcapture10_previous = xilinxmultiregimpl861;
assign bank_windowcapture10_count = xilinxmultiregimpl871;
assign bank_windowcapture10_aborted_sys = xilinxmultiregimpl881;
assign bank_windowcapture11_request_rx = xilinxmultiregimpl891;
assign bank_windowcapture11_ack_sys = xilinxmultiregimpl901;
assign bank_windowcapture11_ready_sys = xilinxmultiregimpl911;
assign bank_windowcapture11_length_rx = xilinxmultiregimpl921;
assign bank_windowcapture11_start_sample = xilinxmultiregimpl931;
assign bank_windowcapture11_previous = xilinxmultiregimpl941;
assign bank_windowcapture11_count = xilinxmultiregimpl951;
assign bank_windowcapture11_aborted_sys = xilinxmultiregimpl961;
assign bank_windowcapture12_request_rx = xilinxmultiregimpl971;
assign bank_windowcapture12_ack_sys = xilinxmultiregimpl981;
assign bank_windowcapture12_ready_sys = xilinxmultiregimpl991;
assign bank_windowcapture12_length_rx = xilinxmultiregimpl1001;
assign bank_windowcapture12_start_sample = xilinxmultiregimpl1011;
assign bank_windowcapture12_previous = xilinxmultiregimpl1021;
assign bank_windowcapture12_count = xilinxmultiregimpl1031;
assign bank_windowcapture12_aborted_sys = xilinxmultiregimpl1041;
assign bank_windowcapture13_request_rx = xilinxmultiregimpl1051;
assign bank_windowcapture13_ack_sys = xilinxmultiregimpl1061;
assign bank_windowcapture13_ready_sys = xilinxmultiregimpl1071;
assign bank_windowcapture13_length_rx = xilinxmultiregimpl1081;
assign bank_windowcapture13_start_sample = xilinxmultiregimpl1091;
assign bank_windowcapture13_previous = xilinxmultiregimpl1101;
assign bank_windowcapture13_count = xilinxmultiregimpl1111;
assign bank_windowcapture13_aborted_sys = xilinxmultiregimpl1121;
assign bank_windowcapture14_request_rx = xilinxmultiregimpl1131;
assign bank_windowcapture14_ack_sys = xilinxmultiregimpl1141;
assign bank_windowcapture14_ready_sys = xilinxmultiregimpl1151;
assign bank_windowcapture14_length_rx = xilinxmultiregimpl1161;
assign bank_windowcapture14_start_sample = xilinxmultiregimpl1171;
assign bank_windowcapture14_previous = xilinxmultiregimpl1181;
assign bank_windowcapture14_count = xilinxmultiregimpl1191;
assign bank_windowcapture14_aborted_sys = xilinxmultiregimpl1201;
assign bank_windowcapture15_request_rx = xilinxmultiregimpl1211;
assign bank_windowcapture15_ack_sys = xilinxmultiregimpl1221;
assign bank_windowcapture15_ready_sys = xilinxmultiregimpl1231;
assign bank_windowcapture15_length_rx = xilinxmultiregimpl1241;
assign bank_windowcapture15_start_sample = xilinxmultiregimpl1251;
assign bank_windowcapture15_previous = xilinxmultiregimpl1261;
assign bank_windowcapture15_count = xilinxmultiregimpl1271;
assign bank_windowcapture15_aborted_sys = xilinxmultiregimpl1281;
assign uart_rx = xilinxmultiregimpl1291;
assign ethernet_lp_abi_ping_toggle_o = xilinxmultiregimpl1301;
assign ethernet_lp_abi_pong_toggle_o = xilinxmultiregimpl1311;
assign ethernet_lp_abi_obuffer = xilinxmultiregimpl1321;
assign ethernet_seen_valid_ci_toggle_o = xilinxmultiregimpl1331;
assign ethernet_rx_config_reg_abi_toggle_o = xilinxmultiregimpl1341;
assign ethernet_rx_config_reg_ack_toggle_o = xilinxmultiregimpl1351;
assign xilinxasyncresetsynchronizerimpl3_async_reset = (~ethernet_pma_a7_gtp_basex_tx_cm_locked1);
assign xilinxasyncresetsynchronizerimpl4_async_reset = (~ethernet_pma_a7_gtp_basex_rx_cm_locked1);
assign ethernet_pma_a7_gtp_basex_tx_init_qpll_lock1 = xilinxmultiregimpl1361;
assign ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done1 = xilinxmultiregimpl1371;
assign ethernet_pma_a7_gtp_basex_toggle_o = xilinxmultiregimpl1381;
assign ethernet_txdatapath_cdc_produce_rdomain = xilinxmultiregimpl1391;
assign ethernet_txdatapath_cdc_consume_wdomain = xilinxmultiregimpl1401;
assign ethernet_toggle_o = xilinxmultiregimpl1411;
assign ethernet_rx_cdc_cdc_produce_rdomain = xilinxmultiregimpl1421;
assign ethernet_rx_cdc_cdc_consume_wdomain = xilinxmultiregimpl1431;
assign ethernet_pulsesynchronizer0_toggle_o = xilinxmultiregimpl1441;
assign ethernet_pulsesynchronizer1_toggle_o = xilinxmultiregimpl1451;
assign ethernet_link = xilinxmultiregimpl1461;
assign ethernet_got_ip = xilinxmultiregimpl1471;

always @(posedge eth_rx_clk) begin
	if (ethernet_pcsrx_seen_config_reg) begin
		ethernet_rx_config_reg_last <= ethernet_pcsrx_config_reg;
		if ((ethernet_pcsrx_config_reg != ethernet_rx_config_reg_last)) begin
			ethernet_rx_config_reg_count <= 3'd7;
		end else begin
			if ((ethernet_rx_config_reg_count != 1'd0)) begin
				ethernet_rx_config_reg_count <= (ethernet_rx_config_reg_count - 1'd1);
			end else begin
				if (ethernet_pcsrx_config_reg[14]) begin
					ethernet_rx_config_reg_ack_i <= 1'd1;
				end else begin
					ethernet_rx_config_reg_abi_i <= 1'd1;
				end
			end
		end
		ethernet_lp_abi_i <= ethernet_pcsrx_config_reg;
	end
	if (ethernet_pcsrx_decoder_ce) begin
		ethernet_pcsrx_decoder_k <= 1'd0;
		if ((ethernet_pcsrx_decoder_input_msb_first[9:4] == 4'd15)) begin
			ethernet_pcsrx_decoder_k <= 1'd1;
			ethernet_pcsrx_decoder_code3b <= t_self0;
		end else begin
			if ((ethernet_pcsrx_decoder_input_msb_first[9:4] == 6'd48)) begin
				ethernet_pcsrx_decoder_k <= 1'd1;
				ethernet_pcsrx_decoder_code3b <= t_self1;
			end else begin
				if (((ethernet_pcsrx_decoder_input_msb_first[3:0] == 3'd7) | (ethernet_pcsrx_decoder_input_msb_first[3:0] == 4'd8))) begin
					if (((((((ethernet_pcsrx_decoder_input_msb_first[9:4] != 6'd35) & (ethernet_pcsrx_decoder_input_msb_first[9:4] != 5'd19)) & (ethernet_pcsrx_decoder_input_msb_first[9:4] != 4'd11)) & (ethernet_pcsrx_decoder_input_msb_first[9:4] != 6'd52)) & (ethernet_pcsrx_decoder_input_msb_first[9:4] != 6'd44)) & (ethernet_pcsrx_decoder_input_msb_first[9:4] != 5'd28))) begin
						ethernet_pcsrx_decoder_k <= 1'd1;
					end
				end
				ethernet_pcsrx_decoder_code3b <= f_self;
			end
		end
	end
	if (ethernet_pcsrx_decoder_ce) begin
		ethernet_pcsrx_decoder_ones <= (((((((((ethernet_pcsrx_decoder_input[0] + ethernet_pcsrx_decoder_input[1]) + ethernet_pcsrx_decoder_input[2]) + ethernet_pcsrx_decoder_input[3]) + ethernet_pcsrx_decoder_input[4]) + ethernet_pcsrx_decoder_input[5]) + ethernet_pcsrx_decoder_input[6]) + ethernet_pcsrx_decoder_input[7]) + ethernet_pcsrx_decoder_input[8]) + ethernet_pcsrx_decoder_input[9]);
	end
	if (ethernet_pcsrx_timer_ce) begin
		ethernet_pcsrx_count1 <= (ethernet_pcsrx_count1 - 1'd1);
		if (((~ethernet_pcsrx_enable) | ethernet_pcsrx_done)) begin
			case (ethernet_pcsrx_sgmii_speed)
				1'd0: begin
					ethernet_pcsrx_count1 <= 7'd99;
				end
				1'd1: begin
					ethernet_pcsrx_count1 <= 4'd9;
				end
				2'd2: begin
					ethernet_pcsrx_count1 <= 1'd0;
				end
			endcase
		end
	end
	if (((~ethernet_pcsrx_pipe_valid_source_valid) | ethernet_pcsrx_pipe_valid_source_ready)) begin
		ethernet_pcsrx_pipe_valid_source_valid <= ethernet_pcsrx_pipe_valid_sink_valid;
		ethernet_pcsrx_pipe_valid_source_first <= ethernet_pcsrx_pipe_valid_sink_first;
		ethernet_pcsrx_pipe_valid_source_last <= ethernet_pcsrx_pipe_valid_sink_last;
		ethernet_pcsrx_pipe_valid_source_payload_data <= ethernet_pcsrx_pipe_valid_sink_payload_data;
	end
	clockdomainsrenamer1_state <= clockdomainsrenamer1_next_state;
	if (ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value_ce) begin
		ethernet_pcsrx_count0 <= ethernet_pcsrx_count0_a7_1000basex_clockdomainsrenamer1_next_value;
	end
	if (clockdomainsrenamer1_next_value_ce0) begin
		ethernet_pcsrx_config_reg[7:0] <= clockdomainsrenamer1_next_value0;
	end
	if (clockdomainsrenamer1_next_value_ce1) begin
		ethernet_pcsrx_config_reg[15:8] <= clockdomainsrenamer1_next_value1;
	end
	ethernet_lp_abi_starter <= 1'd0;
	if (ethernet_lp_abi_pong_o) begin
		ethernet_lp_abi_ibuffer <= ethernet_lp_abi_i;
	end
	if (ethernet_lp_abi_ping_i) begin
		ethernet_lp_abi_ping_toggle_i <= (~ethernet_lp_abi_ping_toggle_i);
	end
	ethernet_lp_abi_pong_toggle_o_r <= ethernet_lp_abi_pong_toggle_o;
	if (ethernet_lp_abi_wait) begin
		if ((~ethernet_lp_abi_done)) begin
			ethernet_lp_abi_count <= (ethernet_lp_abi_count - 1'd1);
		end
	end else begin
		ethernet_lp_abi_count <= 8'd128;
	end
	if (ethernet_seen_valid_ci_i) begin
		ethernet_seen_valid_ci_toggle_i <= (~ethernet_seen_valid_ci_toggle_i);
	end
	if (ethernet_rx_config_reg_abi_i) begin
		ethernet_rx_config_reg_abi_toggle_i <= (~ethernet_rx_config_reg_abi_toggle_i);
	end
	if (ethernet_rx_config_reg_ack_i) begin
		ethernet_rx_config_reg_ack_toggle_i <= (~ethernet_rx_config_reg_ack_toggle_i);
	end
	if ((ethernet_pma_a7_gtp_basex_phase_half == ethernet_pma_a7_gtp_basex_phase_half_rereg)) begin
		ethernet_pma_a7_gtp_basex_rx_data1 <= ethernet_pma_a7_gtp_basex_rx_data_half[19:10];
	end else begin
		ethernet_pma_a7_gtp_basex_rx_data1 <= ethernet_pma_a7_gtp_basex_rx_data_half[9:0];
	end
	ethernet_pma_a7_gtp_basex_phase_half <= (~ethernet_pma_a7_gtp_basex_phase_half);
	if (ethernet_rx_packet_fifo_sink_sink_valid) begin
		ethernet_rx_packet_fifo_invalid <= (ethernet_rx_packet_fifo_invalid | ethernet_rx_packet_fifo_discard);
		if (((~ethernet_rx_packet_fifo_overflow) & (~ethernet_rx_packet_fifo_full))) begin
			ethernet_rx_packet_fifo_wr_ptr <= (ethernet_rx_packet_fifo_wr_ptr + 1'd1);
		end else begin
			ethernet_rx_packet_fifo_overflow <= 1'd1;
		end
		if (ethernet_rx_packet_fifo_sink_sink_last) begin
			ethernet_rx_packet_fifo_overflow <= 1'd0;
			ethernet_rx_packet_fifo_invalid <= 1'd0;
			if (ethernet_rx_packet_fifo_commit) begin
				ethernet_rx_packet_fifo_commit_ptr <= (ethernet_rx_packet_fifo_wr_ptr + 1'd1);
			end else begin
				ethernet_rx_packet_fifo_wr_ptr <= ethernet_rx_packet_fifo_commit_ptr;
			end
		end
	end
	if (ethernet_rx_packet_fifo_fetch) begin
		ethernet_rx_packet_fifo_rd_ptr <= (ethernet_rx_packet_fifo_rd_ptr + 1'd1);
		ethernet_rx_packet_fifo_out_valid <= 1'd1;
	end else begin
		if ((ethernet_rx_packet_fifo_source_source_valid & ethernet_rx_packet_fifo_source_source_ready)) begin
			ethernet_rx_packet_fifo_out_valid <= 1'd0;
		end
	end
	if (((ethernet_rx_packet_fifo_param_fifo_syncfifo_we & ethernet_rx_packet_fifo_param_fifo_syncfifo_writable) & (~ethernet_rx_packet_fifo_param_fifo_replace))) begin
		ethernet_rx_packet_fifo_param_fifo_produce <= (ethernet_rx_packet_fifo_param_fifo_produce + 1'd1);
	end
	if (ethernet_rx_packet_fifo_param_fifo_do_read) begin
		ethernet_rx_packet_fifo_param_fifo_consume <= (ethernet_rx_packet_fifo_param_fifo_consume + 1'd1);
	end
	if (((ethernet_rx_packet_fifo_param_fifo_syncfifo_we & ethernet_rx_packet_fifo_param_fifo_syncfifo_writable) & (~ethernet_rx_packet_fifo_param_fifo_replace))) begin
		if ((~ethernet_rx_packet_fifo_param_fifo_do_read)) begin
			ethernet_rx_packet_fifo_param_fifo_level <= (ethernet_rx_packet_fifo_param_fifo_level + 1'd1);
		end
	end else begin
		if (ethernet_rx_packet_fifo_param_fifo_do_read) begin
			ethernet_rx_packet_fifo_param_fifo_level <= (ethernet_rx_packet_fifo_param_fifo_level - 1'd1);
		end
	end
	if (ethernet_i) begin
		ethernet_toggle_i <= (~ethernet_toggle_i);
	end
	ethernet_rx_cdc_cdc_graycounter0_q_binary <= ethernet_rx_cdc_cdc_graycounter0_q_next_binary;
	ethernet_rx_cdc_cdc_graycounter0_q <= ethernet_rx_cdc_cdc_graycounter0_q_next;
	if (eth_rx_rst) begin
		ethernet_pcsrx_config_reg <= 16'd0;
		ethernet_pcsrx_decoder_k <= 1'd0;
		ethernet_pcsrx_count0 <= 1'd0;
		ethernet_pcsrx_count1 <= 7'd0;
		ethernet_pcsrx_pipe_valid_source_valid <= 1'd0;
		ethernet_lp_abi_i <= 16'd0;
		ethernet_lp_abi_starter <= 1'd1;
		ethernet_lp_abi_count <= 8'd128;
		ethernet_rx_config_reg_abi_i <= 1'd0;
		ethernet_rx_config_reg_ack_i <= 1'd0;
		ethernet_rx_config_reg_count <= 4'd0;
		ethernet_rx_config_reg_last <= 16'd0;
		ethernet_pma_a7_gtp_basex_rx_data1 <= 10'd0;
		ethernet_pma_a7_gtp_basex_phase_half <= 1'd0;
		ethernet_rx_packet_fifo_param_fifo_level <= 3'd0;
		ethernet_rx_packet_fifo_param_fifo_produce <= 2'd0;
		ethernet_rx_packet_fifo_param_fifo_consume <= 2'd0;
		ethernet_rx_packet_fifo_wr_ptr <= 12'd0;
		ethernet_rx_packet_fifo_commit_ptr <= 12'd0;
		ethernet_rx_packet_fifo_rd_ptr <= 12'd0;
		ethernet_rx_packet_fifo_out_valid <= 1'd0;
		ethernet_rx_packet_fifo_overflow <= 1'd0;
		ethernet_rx_packet_fifo_invalid <= 1'd0;
		ethernet_rx_cdc_cdc_graycounter0_q <= 6'd0;
		ethernet_rx_cdc_cdc_graycounter0_q_binary <= 6'd0;
		clockdomainsrenamer1_state <= 3'd0;
	end
	xilinxmultiregimpl1310 <= ethernet_lp_abi_pong_toggle_i;
	xilinxmultiregimpl1311 <= xilinxmultiregimpl1310;
	xilinxmultiregimpl1430 <= ethernet_rx_cdc_cdc_graycounter1_q;
	xilinxmultiregimpl1431 <= xilinxmultiregimpl1430;
end

always @(posedge eth_rx_half_clk) begin
	ethernet_pma_a7_gtp_basex_phase_half_rereg <= ethernet_pma_a7_gtp_basex_phase_half;
end

always @(posedge eth_tx_clk) begin
	if ((ethernet_sink_valid & ethernet_sink_ready)) begin
		ethernet_first <= ethernet_sink_last;
	end
	ethernet_checker_tick <= 1'd0;
	if ((ethernet_checker_count == 1'd0)) begin
		ethernet_checker_tick <= 1'd1;
		ethernet_checker_count <= 20'd750000;
	end else begin
		ethernet_checker_count <= (ethernet_checker_count - 1'd1);
	end
	if (ethernet_seen_valid_ci_o) begin
		ethernet_checker_error <= 1'd0;
	end
	if (ethernet_checker_tick) begin
		ethernet_checker_error <= 1'd1;
	end
	ethernet_pcstx_parity <= (~ethernet_pcstx_parity);
	if (ethernet_pcstx_encoder_ce0) begin
		ethernet_pcstx_encoder_disp_in <= ethernet_pcstx_encoder_disp_out;
	end
	if (ethernet_pcstx_encoder_ce0) begin
		ethernet_pcstx_encoder2 <= ethernet_pcstx_encoder_output;
		ethernet_pcstx_encoder3 <= ethernet_pcstx_encoder_disp_out;
	end
	if (ethernet_pcstx_encoder_ce1) begin
		if ((ethernet_pcstx_encoder_k & (ethernet_pcstx_encoder_d[4:0] == 5'd28))) begin
			ethernet_pcstx_encoder_code6b <= 6'd48;
			ethernet_pcstx_encoder_code6b_unbalanced <= 1'd1;
			ethernet_pcstx_encoder_code6b_flip <= 1'd1;
		end else begin
			ethernet_pcstx_encoder_code6b <= rhs_self0;
			ethernet_pcstx_encoder_code6b_unbalanced <= rhs_self1;
			ethernet_pcstx_encoder_code6b_flip <= rhs_self2;
		end
		ethernet_pcstx_encoder_code4b <= rhs_self3;
		ethernet_pcstx_encoder_code4b_unbalanced <= rhs_self4;
		if (ethernet_pcstx_encoder_k) begin
			ethernet_pcstx_encoder_code4b_flip <= 1'd1;
		end else begin
			ethernet_pcstx_encoder_code4b_flip <= rhs_self5;
		end
		ethernet_pcstx_encoder_alt7_rd0 <= 1'd0;
		ethernet_pcstx_encoder_alt7_rd1 <= 1'd0;
		if ((ethernet_pcstx_encoder_d[7:5] == 3'd7)) begin
			if ((((ethernet_pcstx_encoder_d[4:0] == 5'd17) | (ethernet_pcstx_encoder_d[4:0] == 5'd18)) | (ethernet_pcstx_encoder_d[4:0] == 5'd20))) begin
				ethernet_pcstx_encoder_alt7_rd0 <= 1'd1;
			end
			if ((((ethernet_pcstx_encoder_d[4:0] == 4'd11) | (ethernet_pcstx_encoder_d[4:0] == 4'd13)) | (ethernet_pcstx_encoder_d[4:0] == 4'd14))) begin
				ethernet_pcstx_encoder_alt7_rd1 <= 1'd1;
			end
			if (ethernet_pcstx_encoder_k) begin
				ethernet_pcstx_encoder_alt7_rd0 <= 1'd1;
				ethernet_pcstx_encoder_alt7_rd1 <= 1'd1;
			end
		end
	end
	ethernet_pcstx_count1 <= (ethernet_pcstx_count1 - 1'd1);
	if (((~ethernet_pcstx_enable) | ethernet_pcstx_done)) begin
		case (ethernet_pcstx_sgmii_speed)
			1'd0: begin
				ethernet_pcstx_count1 <= 7'd99;
			end
			1'd1: begin
				ethernet_pcstx_count1 <= 4'd9;
			end
			2'd2: begin
				ethernet_pcstx_count1 <= 1'd0;
			end
		endcase
	end
	clockdomainsrenamer0_state <= clockdomainsrenamer0_next_state;
	if (ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value_ce0) begin
		ethernet_pcstx_count0 <= ethernet_pcstx_count0_a7_1000basex_clockdomainsrenamer0_next_value0;
	end
	if (ethernet_pcstx_ctype_a7_1000basex_clockdomainsrenamer0_next_value_ce1) begin
		ethernet_pcstx_ctype <= ethernet_pcstx_ctype_a7_1000basex_clockdomainsrenamer0_next_value1;
	end
	ethernet_lp_abi_ping_o1 <= ethernet_lp_abi_ping_o0;
	if (ethernet_lp_abi_ping_o1) begin
		ethernet_lp_abi_o <= ethernet_lp_abi_obuffer;
	end
	ethernet_lp_abi_ping_toggle_o_r <= ethernet_lp_abi_ping_toggle_o;
	if (ethernet_lp_abi_pong_i) begin
		ethernet_lp_abi_pong_toggle_i <= (~ethernet_lp_abi_pong_toggle_i);
	end
	ethernet_seen_valid_ci_toggle_o_r <= ethernet_seen_valid_ci_toggle_o;
	ethernet_rx_config_reg_abi_toggle_o_r <= ethernet_rx_config_reg_abi_toggle_o;
	ethernet_rx_config_reg_ack_toggle_o_r <= ethernet_rx_config_reg_ack_toggle_o;
	if (ethernet_waittimer0_wait) begin
		if ((~ethernet_waittimer0_done)) begin
			ethernet_waittimer0_count <= (ethernet_waittimer0_count - 1'd1);
		end
	end else begin
		ethernet_waittimer0_count <= 21'd1250000;
	end
	if (ethernet_waittimer1_wait) begin
		if ((~ethernet_waittimer1_done)) begin
			ethernet_waittimer1_count <= (ethernet_waittimer1_count - 1'd1);
		end
	end else begin
		ethernet_waittimer1_count <= 21'd1250000;
	end
	if (ethernet_waittimer2_wait) begin
		if ((~ethernet_waittimer2_done)) begin
			ethernet_waittimer2_count <= (ethernet_waittimer2_count - 1'd1);
		end
	end else begin
		ethernet_waittimer2_count <= 18'd200000;
	end
	clockdomainsrenamer2_state <= clockdomainsrenamer2_next_state;
	if (ethernet_pma_a7_gtp_basex_i) begin
		ethernet_pma_a7_gtp_basex_toggle_i <= (~ethernet_pma_a7_gtp_basex_toggle_i);
	end
	ethernet_pma_a7_gtp_basex_buf <= {ethernet_pma_a7_gtp_basex_tx_data1, ethernet_pma_a7_gtp_basex_buf[19:10]};
	ethernet_txdatapath_cdc_graycounter1_q_binary <= ethernet_txdatapath_cdc_graycounter1_q_next_binary;
	ethernet_txdatapath_cdc_graycounter1_q <= ethernet_txdatapath_cdc_graycounter1_q_next;
	if (ethernet_tx_packet_fifo_payload_fifo_syncfifo_re) begin
		ethernet_tx_packet_fifo_payload_fifo_readable <= 1'd1;
	end else begin
		if (ethernet_tx_packet_fifo_payload_fifo_re) begin
			ethernet_tx_packet_fifo_payload_fifo_readable <= 1'd0;
		end
	end
	if (((ethernet_tx_packet_fifo_payload_fifo_syncfifo_we & ethernet_tx_packet_fifo_payload_fifo_syncfifo_writable) & (~ethernet_tx_packet_fifo_payload_fifo_replace))) begin
		ethernet_tx_packet_fifo_payload_fifo_produce <= (ethernet_tx_packet_fifo_payload_fifo_produce + 1'd1);
	end
	if (ethernet_tx_packet_fifo_payload_fifo_do_read) begin
		ethernet_tx_packet_fifo_payload_fifo_consume <= (ethernet_tx_packet_fifo_payload_fifo_consume + 1'd1);
	end
	if (((ethernet_tx_packet_fifo_payload_fifo_syncfifo_we & ethernet_tx_packet_fifo_payload_fifo_syncfifo_writable) & (~ethernet_tx_packet_fifo_payload_fifo_replace))) begin
		if ((~ethernet_tx_packet_fifo_payload_fifo_do_read)) begin
			ethernet_tx_packet_fifo_payload_fifo_level0 <= (ethernet_tx_packet_fifo_payload_fifo_level0 + 1'd1);
		end
	end else begin
		if (ethernet_tx_packet_fifo_payload_fifo_do_read) begin
			ethernet_tx_packet_fifo_payload_fifo_level0 <= (ethernet_tx_packet_fifo_payload_fifo_level0 - 1'd1);
		end
	end
	if (ethernet_tx_packet_fifo_param_fifo_syncfifo_re) begin
		ethernet_tx_packet_fifo_param_fifo_readable <= 1'd1;
	end else begin
		if (ethernet_tx_packet_fifo_param_fifo_re) begin
			ethernet_tx_packet_fifo_param_fifo_readable <= 1'd0;
		end
	end
	if (((ethernet_tx_packet_fifo_param_fifo_syncfifo_we & ethernet_tx_packet_fifo_param_fifo_syncfifo_writable) & (~ethernet_tx_packet_fifo_param_fifo_replace))) begin
		if ((ethernet_tx_packet_fifo_param_fifo_produce == 3'd4)) begin
			ethernet_tx_packet_fifo_param_fifo_produce <= 1'd0;
		end else begin
			ethernet_tx_packet_fifo_param_fifo_produce <= (ethernet_tx_packet_fifo_param_fifo_produce + 1'd1);
		end
	end
	if (ethernet_tx_packet_fifo_param_fifo_do_read) begin
		if ((ethernet_tx_packet_fifo_param_fifo_consume == 3'd4)) begin
			ethernet_tx_packet_fifo_param_fifo_consume <= 1'd0;
		end else begin
			ethernet_tx_packet_fifo_param_fifo_consume <= (ethernet_tx_packet_fifo_param_fifo_consume + 1'd1);
		end
	end
	if (((ethernet_tx_packet_fifo_param_fifo_syncfifo_we & ethernet_tx_packet_fifo_param_fifo_syncfifo_writable) & (~ethernet_tx_packet_fifo_param_fifo_replace))) begin
		if ((~ethernet_tx_packet_fifo_param_fifo_do_read)) begin
			ethernet_tx_packet_fifo_param_fifo_level0 <= (ethernet_tx_packet_fifo_param_fifo_level0 + 1'd1);
		end
	end else begin
		if (ethernet_tx_packet_fifo_param_fifo_do_read) begin
			ethernet_tx_packet_fifo_param_fifo_level0 <= (ethernet_tx_packet_fifo_param_fifo_level0 - 1'd1);
		end
	end
	txdatapath_liteethmacgap_state <= txdatapath_liteethmacgap_next_state;
	if (ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value_ce) begin
		ethernet_tx_gap_counter <= ethernet_tx_gap_counter_clockdomainsrenamer_clockdomainsrenamer3_next_value;
	end
	txdatapath_liteethmacpaddinginserter_state <= txdatapath_liteethmacpaddinginserter_next_state;
	if (ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value_ce) begin
		ethernet_tx_padding_counter <= ethernet_tx_padding_counter_clockdomainsrenamer_clockdomainsrenamer0_next_value;
	end
	if (ethernet_tx_crc_is_ongoing0) begin
		ethernet_tx_crc_cnt <= 2'd3;
	end else begin
		if ((ethernet_tx_crc_is_ongoing1 & (~ethernet_tx_crc_cnt_done))) begin
			ethernet_tx_crc_cnt <= (ethernet_tx_crc_cnt - ethernet_tx_crc_source_ready);
		end
	end
	if (ethernet_tx_crc_ce) begin
		ethernet_tx_crc_reg <= ethernet_tx_crc_crc_next;
	end
	if (ethernet_tx_crc_reset) begin
		ethernet_tx_crc_reg <= 32'd4294967295;
	end
	txdatapath_bufferizeendpoints_state <= txdatapath_bufferizeendpoints_next_state;
	if (ethernet_tx_crc_crc_packet_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce0) begin
		ethernet_tx_crc_crc_packet <= ethernet_tx_crc_crc_packet_clockdomainsrenamer_clockdomainsrenamer1_next_value0;
	end
	if (ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value_ce1) begin
		ethernet_tx_crc_be0 <= ethernet_tx_crc_be0_clockdomainsrenamer_clockdomainsrenamer1_next_value1;
	end
	if (((~ethernet_tx_crc_pipe_valid_source_valid) | ethernet_tx_crc_pipe_valid_source_ready)) begin
		ethernet_tx_crc_pipe_valid_source_valid <= ethernet_tx_crc_pipe_valid_sink_valid;
		ethernet_tx_crc_pipe_valid_source_first <= ethernet_tx_crc_pipe_valid_sink_first;
		ethernet_tx_crc_pipe_valid_source_last <= ethernet_tx_crc_pipe_valid_sink_last;
		ethernet_tx_crc_pipe_valid_source_payload_data <= ethernet_tx_crc_pipe_valid_sink_payload_data;
		ethernet_tx_crc_pipe_valid_source_payload_be <= ethernet_tx_crc_pipe_valid_sink_payload_be;
		ethernet_tx_crc_pipe_valid_source_payload_error <= ethernet_tx_crc_pipe_valid_sink_payload_error;
	end
	txdatapath_liteethmacpreambleinserter_state <= txdatapath_liteethmacpreambleinserter_next_state;
	if (ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value_ce) begin
		ethernet_tx_preamble_count <= ethernet_tx_preamble_count_clockdomainsrenamer_clockdomainsrenamer2_next_value;
	end
	ethernet_txdatapath_cdc_graycounter0_q_binary <= ethernet_txdatapath_cdc_graycounter0_q_next_binary;
	ethernet_txdatapath_cdc_graycounter0_q <= ethernet_txdatapath_cdc_graycounter0_q_next;
	if (ethernet_o) begin
		ethernet_drops_status <= (ethernet_drops_status + 1'd1);
	end
	if (ethernet_pulsesynchronizer0_o) begin
		ethernet_preamble_errors_status <= (ethernet_preamble_errors_status + 1'd1);
	end
	if (ethernet_pulsesynchronizer1_o) begin
		ethernet_crc_errors_status <= (ethernet_crc_errors_status + 1'd1);
	end
	ethernet_toggle_o_r <= ethernet_toggle_o;
	ethernet_rx_cdc_cdc_graycounter1_q_binary <= ethernet_rx_cdc_cdc_graycounter1_q_next_binary;
	ethernet_rx_cdc_cdc_graycounter1_q <= ethernet_rx_cdc_cdc_graycounter1_q_next;
	rxdatapath_liteethmacpreamblechecker_state <= rxdatapath_liteethmacpreamblechecker_next_state;
	if (ethernet_pulsesynchronizer0_i) begin
		ethernet_pulsesynchronizer0_toggle_i <= (~ethernet_pulsesynchronizer0_toggle_i);
	end
	ethernet_pulsesynchronizer0_toggle_o_r <= ethernet_pulsesynchronizer0_toggle_o;
	if (ethernet_liteethmaccrc32checker_is_ongoing2) begin
		ethernet_liteethmaccrc32checker_packet_error <= 1'd0;
	end else begin
		if ((ethernet_liteethmaccrc32checker_sink_sink_valid & ethernet_liteethmaccrc32checker_sink_sink_ready)) begin
			ethernet_liteethmaccrc32checker_packet_error <= (ethernet_liteethmaccrc32checker_packet_error | ((ethernet_liteethmaccrc32checker_sink_sink_payload_error & ethernet_liteethmaccrc32checker_sink_sink_payload_be) != 1'd0));
		end
	end
	if (ethernet_liteethmaccrc32checker_crc_ce) begin
		ethernet_liteethmaccrc32checker_crc_reg <= ethernet_liteethmaccrc32checker_crc_crc_next;
	end
	if (ethernet_liteethmaccrc32checker_crc_reset) begin
		ethernet_liteethmaccrc32checker_crc_reg <= 32'd4294967295;
	end
	if (((ethernet_liteethmaccrc32checker_syncfifo_syncfifo_we & ethernet_liteethmaccrc32checker_syncfifo_syncfifo_writable) & (~ethernet_liteethmaccrc32checker_syncfifo_replace))) begin
		if ((ethernet_liteethmaccrc32checker_syncfifo_produce == 3'd4)) begin
			ethernet_liteethmaccrc32checker_syncfifo_produce <= 1'd0;
		end else begin
			ethernet_liteethmaccrc32checker_syncfifo_produce <= (ethernet_liteethmaccrc32checker_syncfifo_produce + 1'd1);
		end
	end
	if (ethernet_liteethmaccrc32checker_syncfifo_do_read) begin
		if ((ethernet_liteethmaccrc32checker_syncfifo_consume == 3'd4)) begin
			ethernet_liteethmaccrc32checker_syncfifo_consume <= 1'd0;
		end else begin
			ethernet_liteethmaccrc32checker_syncfifo_consume <= (ethernet_liteethmaccrc32checker_syncfifo_consume + 1'd1);
		end
	end
	if (((ethernet_liteethmaccrc32checker_syncfifo_syncfifo_we & ethernet_liteethmaccrc32checker_syncfifo_syncfifo_writable) & (~ethernet_liteethmaccrc32checker_syncfifo_replace))) begin
		if ((~ethernet_liteethmaccrc32checker_syncfifo_do_read)) begin
			ethernet_liteethmaccrc32checker_syncfifo_level <= (ethernet_liteethmaccrc32checker_syncfifo_level + 1'd1);
		end
	end else begin
		if (ethernet_liteethmaccrc32checker_syncfifo_do_read) begin
			ethernet_liteethmaccrc32checker_syncfifo_level <= (ethernet_liteethmaccrc32checker_syncfifo_level - 1'd1);
		end
	end
	if (ethernet_liteethmaccrc32checker_fifo_reset) begin
		ethernet_liteethmaccrc32checker_syncfifo_level <= 3'd0;
		ethernet_liteethmaccrc32checker_syncfifo_produce <= 3'd0;
		ethernet_liteethmaccrc32checker_syncfifo_consume <= 3'd0;
	end
	rxdatapath_bufferizeendpoints_state <= rxdatapath_bufferizeendpoints_next_state;
	if (ethernet_liteethmaccrc32checker_be_clockdomainsrenamer_next_value_ce0) begin
		ethernet_liteethmaccrc32checker_be <= ethernet_liteethmaccrc32checker_be_clockdomainsrenamer_next_value0;
	end
	if (ethernet_liteethmaccrc32checker_last_error_clockdomainsrenamer_next_value_ce1) begin
		ethernet_liteethmaccrc32checker_last_error <= ethernet_liteethmaccrc32checker_last_error_clockdomainsrenamer_next_value1;
	end
	if (((~ethernet_bufferizeendpoints_pipe_valid_source_valid) | ethernet_bufferizeendpoints_pipe_valid_source_ready)) begin
		ethernet_bufferizeendpoints_pipe_valid_source_valid <= ethernet_bufferizeendpoints_pipe_valid_sink_valid;
		ethernet_bufferizeendpoints_pipe_valid_source_first <= ethernet_bufferizeendpoints_pipe_valid_sink_first;
		ethernet_bufferizeendpoints_pipe_valid_source_last <= ethernet_bufferizeendpoints_pipe_valid_sink_last;
		ethernet_bufferizeendpoints_pipe_valid_source_payload_data <= ethernet_bufferizeendpoints_pipe_valid_sink_payload_data;
		ethernet_bufferizeendpoints_pipe_valid_source_payload_be <= ethernet_bufferizeendpoints_pipe_valid_sink_payload_be;
		ethernet_bufferizeendpoints_pipe_valid_source_payload_error <= ethernet_bufferizeendpoints_pipe_valid_sink_payload_error;
	end
	if (ethernet_pulsesynchronizer1_i) begin
		ethernet_pulsesynchronizer1_toggle_i <= (~ethernet_pulsesynchronizer1_toggle_i);
	end
	ethernet_pulsesynchronizer1_toggle_o_r <= ethernet_pulsesynchronizer1_toggle_o;
	if ((ethernet_rx_padding_sink_valid & ethernet_rx_padding_sink_ready)) begin
		if (ethernet_rx_padding_sink_last) begin
			ethernet_rx_padding_length <= 1'd0;
		end else begin
			ethernet_rx_padding_length <= (ethernet_rx_padding_length + ethernet_rx_padding_length_inc);
		end
	end
	if (eth_tx_rst) begin
		ethernet_pcstx_encoder3 <= 1'd0;
		ethernet_pcstx_encoder_disp_in <= 1'd0;
		ethernet_pcstx_encoder_code6b_flip <= 1'd0;
		ethernet_pcstx_encoder_code4b_flip <= 1'd0;
		ethernet_pcstx_count0 <= 1'd0;
		ethernet_pcstx_parity <= 1'd0;
		ethernet_pcstx_ctype <= 1'd0;
		ethernet_pcstx_count1 <= 7'd0;
		ethernet_lp_abi_ping_o1 <= 1'd0;
		ethernet_waittimer0_count <= 21'd1250000;
		ethernet_waittimer1_count <= 21'd1250000;
		ethernet_waittimer2_count <= 18'd200000;
		ethernet_checker_count <= 20'd0;
		ethernet_checker_tick <= 1'd0;
		ethernet_checker_error <= 1'd0;
		ethernet_pma_a7_gtp_basex_buf <= 20'd0;
		ethernet_tx_padding_counter <= 16'd0;
		ethernet_tx_crc_reg <= 32'd4294967295;
		ethernet_tx_crc_cnt <= 2'd3;
		ethernet_tx_crc_pipe_valid_source_valid <= 1'd0;
		ethernet_txdatapath_cdc_graycounter0_q <= 6'd0;
		ethernet_txdatapath_cdc_graycounter0_q_binary <= 6'd0;
		ethernet_txdatapath_cdc_graycounter1_q <= 6'd0;
		ethernet_txdatapath_cdc_graycounter1_q_binary <= 6'd0;
		ethernet_tx_packet_fifo_payload_fifo_readable <= 1'd0;
		ethernet_tx_packet_fifo_payload_fifo_level0 <= 12'd0;
		ethernet_tx_packet_fifo_payload_fifo_produce <= 11'd0;
		ethernet_tx_packet_fifo_payload_fifo_consume <= 11'd0;
		ethernet_tx_packet_fifo_param_fifo_readable <= 1'd0;
		ethernet_tx_packet_fifo_param_fifo_level0 <= 3'd0;
		ethernet_tx_packet_fifo_param_fifo_produce <= 3'd0;
		ethernet_tx_packet_fifo_param_fifo_consume <= 3'd0;
		ethernet_preamble_errors_status <= 32'd0;
		ethernet_crc_errors_status <= 32'd0;
		ethernet_drops_status <= 32'd0;
		ethernet_rx_cdc_cdc_graycounter1_q <= 6'd0;
		ethernet_rx_cdc_cdc_graycounter1_q_binary <= 6'd0;
		ethernet_liteethmaccrc32checker_crc_reg <= 32'd4294967295;
		ethernet_liteethmaccrc32checker_syncfifo_level <= 3'd0;
		ethernet_liteethmaccrc32checker_syncfifo_produce <= 3'd0;
		ethernet_liteethmaccrc32checker_syncfifo_consume <= 3'd0;
		ethernet_liteethmaccrc32checker_last_error <= 1'd0;
		ethernet_liteethmaccrc32checker_packet_error <= 1'd0;
		ethernet_bufferizeendpoints_pipe_valid_source_valid <= 1'd0;
		ethernet_rx_padding_length <= 11'd0;
		ethernet_first <= 1'd1;
		clockdomainsrenamer0_state <= 3'd0;
		clockdomainsrenamer2_state <= 3'd0;
		txdatapath_liteethmacpaddinginserter_state <= 1'd0;
		txdatapath_bufferizeendpoints_state <= 2'd0;
		txdatapath_liteethmacpreambleinserter_state <= 2'd0;
		txdatapath_liteethmacgap_state <= 1'd0;
		rxdatapath_liteethmacpreamblechecker_state <= 1'd0;
		rxdatapath_bufferizeendpoints_state <= 2'd0;
	end
	xilinxmultiregimpl1300 <= ethernet_lp_abi_ping_toggle_i;
	xilinxmultiregimpl1301 <= xilinxmultiregimpl1300;
	xilinxmultiregimpl1320 <= ethernet_lp_abi_ibuffer;
	xilinxmultiregimpl1321 <= xilinxmultiregimpl1320;
	xilinxmultiregimpl1330 <= ethernet_seen_valid_ci_toggle_i;
	xilinxmultiregimpl1331 <= xilinxmultiregimpl1330;
	xilinxmultiregimpl1340 <= ethernet_rx_config_reg_abi_toggle_i;
	xilinxmultiregimpl1341 <= xilinxmultiregimpl1340;
	xilinxmultiregimpl1350 <= ethernet_rx_config_reg_ack_toggle_i;
	xilinxmultiregimpl1351 <= xilinxmultiregimpl1350;
	xilinxmultiregimpl1390 <= ethernet_txdatapath_cdc_graycounter0_q;
	xilinxmultiregimpl1391 <= xilinxmultiregimpl1390;
	xilinxmultiregimpl1400 <= ethernet_txdatapath_cdc_graycounter1_q;
	xilinxmultiregimpl1401 <= xilinxmultiregimpl1400;
	xilinxmultiregimpl1410 <= ethernet_toggle_i;
	xilinxmultiregimpl1411 <= xilinxmultiregimpl1410;
	xilinxmultiregimpl1420 <= ethernet_rx_cdc_cdc_graycounter0_q;
	xilinxmultiregimpl1421 <= xilinxmultiregimpl1420;
	xilinxmultiregimpl1440 <= ethernet_pulsesynchronizer0_toggle_i;
	xilinxmultiregimpl1441 <= xilinxmultiregimpl1440;
	xilinxmultiregimpl1450 <= ethernet_pulsesynchronizer1_toggle_i;
	xilinxmultiregimpl1451 <= xilinxmultiregimpl1450;
end

always @(posedge eth_tx_half_clk) begin
	ethernet_pma_a7_gtp_basex_tx_data_half <= ethernet_pma_a7_gtp_basex_buf;
end

always @(posedge ipbus_clk) begin
	if ((ipbus_bridge_state == 1'd0)) begin
		if (ipbus_bridge_strobe) begin
			ipbus_bridge_address1 <= ipbus_bridge_address0;
			ipbus_bridge_data <= ipbus_bridge_wdata;
			ipbus_bridge_writing <= ipbus_bridge_write;
			ipbus_bridge_state <= 4'd9;
		end
	end
	if ((ipbus_bridge_state == 4'd9)) begin
		if ((((ipbus_bridge_address1 < 7'd64) | (((ipbus_bridge_address1 >>> 5'd16) == 1'd1) & (~ipbus_bridge_writing))) | ((((ipbus_bridge_address1 >>> 5'd16) == 2'd2) & (~ipbus_bridge_writing)) & (ipbus_bridge_address1[11:0] < 11'd1365)))) begin
			ipbus_bridge_state <= (((ipbus_bridge_address1 >>> 5'd16) == 1'd0) ? 2'd3 : 1'd1);
		end else begin
			ipbus_bridge_state <= 4'd8;
		end
	end
	if (((ipbus_bridge_state >= 1'd1) & (ipbus_bridge_state <= 3'd6))) begin
		if (ipbus_bridge_available) begin
			if ((ipbus_bridge_state == 1'd1)) begin
				ipbus_bridge_state <= 2'd2;
			end else begin
				if ((ipbus_bridge_state == 2'd2)) begin
					ipbus_bridge_state <= 3'd4;
				end else begin
					if ((ipbus_bridge_state == 2'd3)) begin
						ipbus_bridge_state <= 3'd4;
					end else begin
						if ((ipbus_bridge_state == 3'd4)) begin
							ipbus_bridge_state <= 3'd5;
						end else begin
							if ((ipbus_bridge_state == 3'd5)) begin
								ipbus_bridge_state <= 3'd6;
							end else begin
								ipbus_bridge_rdata <= ipbus_bridge_control_read_data;
								ipbus_bridge_state <= 3'd7;
							end
						end
					end
				end
			end
		end else begin
			if (ipbus_bridge_memory) begin
				ipbus_bridge_state <= 1'd1;
			end
		end
	end
	if (((ipbus_bridge_state == 3'd7) | (ipbus_bridge_state == 4'd8))) begin
		ipbus_bridge_state <= 1'd0;
	end
	if (ipbus_rst) begin
		ipbus_bridge_rdata <= 32'd0;
		ipbus_bridge_address1 <= 32'd0;
		ipbus_bridge_data <= 32'd0;
		ipbus_bridge_writing <= 1'd0;
		ipbus_bridge_state <= 4'd0;
	end
end

always @(posedge sample_clk) begin
	bank_windowcapture0_sample <= (bank_windowcapture0_sample + 4'd8);
	bank_windowcapture0_prev <= bank_windowcapture0_data[7];
	if (((~bank_windowcapture0_active) & (bank_windowcapture0_request_rx != bank_windowcapture0_ack))) begin
		if (bank_windowcapture0_rx_ready) begin
			bank_windowcapture0_active <= 1'd1;
			bank_windowcapture0_address <= 1'd0;
			bank_windowcapture0_limit <= bank_windowcapture0_length_rx;
			bank_windowcapture0_start_rx <= (bank_windowcapture0_sample + 4'd8);
			bank_windowcapture0_previous_rx <= bank_windowcapture0_data[7];
			bank_windowcapture0_count_rx <= 1'd0;
			bank_windowcapture0_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture0_ack <= bank_windowcapture0_request_rx;
			bank_windowcapture0_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture0_active) begin
			if ((~bank_windowcapture0_rx_ready)) begin
				bank_windowcapture0_active <= 1'd0;
				bank_windowcapture0_ack <= bank_windowcapture0_request_rx;
				bank_windowcapture0_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture0_count_rx <= (bank_windowcapture0_count_rx + 1'd1);
				if ((bank_windowcapture0_address == (bank_windowcapture0_limit - 1'd1))) begin
					bank_windowcapture0_active <= 1'd0;
					bank_windowcapture0_ack <= bank_windowcapture0_request_rx;
				end else begin
					bank_windowcapture0_address <= (bank_windowcapture0_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture1_sample <= (bank_windowcapture1_sample + 4'd8);
	bank_windowcapture1_prev <= bank_windowcapture1_data[7];
	if (((~bank_windowcapture1_active) & (bank_windowcapture1_request_rx != bank_windowcapture1_ack))) begin
		if (bank_windowcapture1_rx_ready) begin
			bank_windowcapture1_active <= 1'd1;
			bank_windowcapture1_address <= 1'd0;
			bank_windowcapture1_limit <= bank_windowcapture1_length_rx;
			bank_windowcapture1_start_rx <= (bank_windowcapture1_sample + 4'd8);
			bank_windowcapture1_previous_rx <= bank_windowcapture1_data[7];
			bank_windowcapture1_count_rx <= 1'd0;
			bank_windowcapture1_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture1_ack <= bank_windowcapture1_request_rx;
			bank_windowcapture1_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture1_active) begin
			if ((~bank_windowcapture1_rx_ready)) begin
				bank_windowcapture1_active <= 1'd0;
				bank_windowcapture1_ack <= bank_windowcapture1_request_rx;
				bank_windowcapture1_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture1_count_rx <= (bank_windowcapture1_count_rx + 1'd1);
				if ((bank_windowcapture1_address == (bank_windowcapture1_limit - 1'd1))) begin
					bank_windowcapture1_active <= 1'd0;
					bank_windowcapture1_ack <= bank_windowcapture1_request_rx;
				end else begin
					bank_windowcapture1_address <= (bank_windowcapture1_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture2_sample <= (bank_windowcapture2_sample + 4'd8);
	bank_windowcapture2_prev <= bank_windowcapture2_data[7];
	if (((~bank_windowcapture2_active) & (bank_windowcapture2_request_rx != bank_windowcapture2_ack))) begin
		if (bank_windowcapture2_rx_ready) begin
			bank_windowcapture2_active <= 1'd1;
			bank_windowcapture2_address <= 1'd0;
			bank_windowcapture2_limit <= bank_windowcapture2_length_rx;
			bank_windowcapture2_start_rx <= (bank_windowcapture2_sample + 4'd8);
			bank_windowcapture2_previous_rx <= bank_windowcapture2_data[7];
			bank_windowcapture2_count_rx <= 1'd0;
			bank_windowcapture2_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture2_ack <= bank_windowcapture2_request_rx;
			bank_windowcapture2_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture2_active) begin
			if ((~bank_windowcapture2_rx_ready)) begin
				bank_windowcapture2_active <= 1'd0;
				bank_windowcapture2_ack <= bank_windowcapture2_request_rx;
				bank_windowcapture2_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture2_count_rx <= (bank_windowcapture2_count_rx + 1'd1);
				if ((bank_windowcapture2_address == (bank_windowcapture2_limit - 1'd1))) begin
					bank_windowcapture2_active <= 1'd0;
					bank_windowcapture2_ack <= bank_windowcapture2_request_rx;
				end else begin
					bank_windowcapture2_address <= (bank_windowcapture2_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture3_sample <= (bank_windowcapture3_sample + 4'd8);
	bank_windowcapture3_prev <= bank_windowcapture3_data[7];
	if (((~bank_windowcapture3_active) & (bank_windowcapture3_request_rx != bank_windowcapture3_ack))) begin
		if (bank_windowcapture3_rx_ready) begin
			bank_windowcapture3_active <= 1'd1;
			bank_windowcapture3_address <= 1'd0;
			bank_windowcapture3_limit <= bank_windowcapture3_length_rx;
			bank_windowcapture3_start_rx <= (bank_windowcapture3_sample + 4'd8);
			bank_windowcapture3_previous_rx <= bank_windowcapture3_data[7];
			bank_windowcapture3_count_rx <= 1'd0;
			bank_windowcapture3_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture3_ack <= bank_windowcapture3_request_rx;
			bank_windowcapture3_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture3_active) begin
			if ((~bank_windowcapture3_rx_ready)) begin
				bank_windowcapture3_active <= 1'd0;
				bank_windowcapture3_ack <= bank_windowcapture3_request_rx;
				bank_windowcapture3_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture3_count_rx <= (bank_windowcapture3_count_rx + 1'd1);
				if ((bank_windowcapture3_address == (bank_windowcapture3_limit - 1'd1))) begin
					bank_windowcapture3_active <= 1'd0;
					bank_windowcapture3_ack <= bank_windowcapture3_request_rx;
				end else begin
					bank_windowcapture3_address <= (bank_windowcapture3_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture4_sample <= (bank_windowcapture4_sample + 4'd8);
	bank_windowcapture4_prev <= bank_windowcapture4_data[7];
	if (((~bank_windowcapture4_active) & (bank_windowcapture4_request_rx != bank_windowcapture4_ack))) begin
		if (bank_windowcapture4_rx_ready) begin
			bank_windowcapture4_active <= 1'd1;
			bank_windowcapture4_address <= 1'd0;
			bank_windowcapture4_limit <= bank_windowcapture4_length_rx;
			bank_windowcapture4_start_rx <= (bank_windowcapture4_sample + 4'd8);
			bank_windowcapture4_previous_rx <= bank_windowcapture4_data[7];
			bank_windowcapture4_count_rx <= 1'd0;
			bank_windowcapture4_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture4_ack <= bank_windowcapture4_request_rx;
			bank_windowcapture4_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture4_active) begin
			if ((~bank_windowcapture4_rx_ready)) begin
				bank_windowcapture4_active <= 1'd0;
				bank_windowcapture4_ack <= bank_windowcapture4_request_rx;
				bank_windowcapture4_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture4_count_rx <= (bank_windowcapture4_count_rx + 1'd1);
				if ((bank_windowcapture4_address == (bank_windowcapture4_limit - 1'd1))) begin
					bank_windowcapture4_active <= 1'd0;
					bank_windowcapture4_ack <= bank_windowcapture4_request_rx;
				end else begin
					bank_windowcapture4_address <= (bank_windowcapture4_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture5_sample <= (bank_windowcapture5_sample + 4'd8);
	bank_windowcapture5_prev <= bank_windowcapture5_data[7];
	if (((~bank_windowcapture5_active) & (bank_windowcapture5_request_rx != bank_windowcapture5_ack))) begin
		if (bank_windowcapture5_rx_ready) begin
			bank_windowcapture5_active <= 1'd1;
			bank_windowcapture5_address <= 1'd0;
			bank_windowcapture5_limit <= bank_windowcapture5_length_rx;
			bank_windowcapture5_start_rx <= (bank_windowcapture5_sample + 4'd8);
			bank_windowcapture5_previous_rx <= bank_windowcapture5_data[7];
			bank_windowcapture5_count_rx <= 1'd0;
			bank_windowcapture5_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture5_ack <= bank_windowcapture5_request_rx;
			bank_windowcapture5_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture5_active) begin
			if ((~bank_windowcapture5_rx_ready)) begin
				bank_windowcapture5_active <= 1'd0;
				bank_windowcapture5_ack <= bank_windowcapture5_request_rx;
				bank_windowcapture5_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture5_count_rx <= (bank_windowcapture5_count_rx + 1'd1);
				if ((bank_windowcapture5_address == (bank_windowcapture5_limit - 1'd1))) begin
					bank_windowcapture5_active <= 1'd0;
					bank_windowcapture5_ack <= bank_windowcapture5_request_rx;
				end else begin
					bank_windowcapture5_address <= (bank_windowcapture5_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture6_sample <= (bank_windowcapture6_sample + 4'd8);
	bank_windowcapture6_prev <= bank_windowcapture6_data[7];
	if (((~bank_windowcapture6_active) & (bank_windowcapture6_request_rx != bank_windowcapture6_ack))) begin
		if (bank_windowcapture6_rx_ready) begin
			bank_windowcapture6_active <= 1'd1;
			bank_windowcapture6_address <= 1'd0;
			bank_windowcapture6_limit <= bank_windowcapture6_length_rx;
			bank_windowcapture6_start_rx <= (bank_windowcapture6_sample + 4'd8);
			bank_windowcapture6_previous_rx <= bank_windowcapture6_data[7];
			bank_windowcapture6_count_rx <= 1'd0;
			bank_windowcapture6_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture6_ack <= bank_windowcapture6_request_rx;
			bank_windowcapture6_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture6_active) begin
			if ((~bank_windowcapture6_rx_ready)) begin
				bank_windowcapture6_active <= 1'd0;
				bank_windowcapture6_ack <= bank_windowcapture6_request_rx;
				bank_windowcapture6_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture6_count_rx <= (bank_windowcapture6_count_rx + 1'd1);
				if ((bank_windowcapture6_address == (bank_windowcapture6_limit - 1'd1))) begin
					bank_windowcapture6_active <= 1'd0;
					bank_windowcapture6_ack <= bank_windowcapture6_request_rx;
				end else begin
					bank_windowcapture6_address <= (bank_windowcapture6_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture7_sample <= (bank_windowcapture7_sample + 4'd8);
	bank_windowcapture7_prev <= bank_windowcapture7_data[7];
	if (((~bank_windowcapture7_active) & (bank_windowcapture7_request_rx != bank_windowcapture7_ack))) begin
		if (bank_windowcapture7_rx_ready) begin
			bank_windowcapture7_active <= 1'd1;
			bank_windowcapture7_address <= 1'd0;
			bank_windowcapture7_limit <= bank_windowcapture7_length_rx;
			bank_windowcapture7_start_rx <= (bank_windowcapture7_sample + 4'd8);
			bank_windowcapture7_previous_rx <= bank_windowcapture7_data[7];
			bank_windowcapture7_count_rx <= 1'd0;
			bank_windowcapture7_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture7_ack <= bank_windowcapture7_request_rx;
			bank_windowcapture7_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture7_active) begin
			if ((~bank_windowcapture7_rx_ready)) begin
				bank_windowcapture7_active <= 1'd0;
				bank_windowcapture7_ack <= bank_windowcapture7_request_rx;
				bank_windowcapture7_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture7_count_rx <= (bank_windowcapture7_count_rx + 1'd1);
				if ((bank_windowcapture7_address == (bank_windowcapture7_limit - 1'd1))) begin
					bank_windowcapture7_active <= 1'd0;
					bank_windowcapture7_ack <= bank_windowcapture7_request_rx;
				end else begin
					bank_windowcapture7_address <= (bank_windowcapture7_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture8_sample <= (bank_windowcapture8_sample + 4'd8);
	bank_windowcapture8_prev <= bank_windowcapture8_data[7];
	if (((~bank_windowcapture8_active) & (bank_windowcapture8_request_rx != bank_windowcapture8_ack))) begin
		if (bank_windowcapture8_rx_ready) begin
			bank_windowcapture8_active <= 1'd1;
			bank_windowcapture8_address <= 1'd0;
			bank_windowcapture8_limit <= bank_windowcapture8_length_rx;
			bank_windowcapture8_start_rx <= (bank_windowcapture8_sample + 4'd8);
			bank_windowcapture8_previous_rx <= bank_windowcapture8_data[7];
			bank_windowcapture8_count_rx <= 1'd0;
			bank_windowcapture8_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture8_ack <= bank_windowcapture8_request_rx;
			bank_windowcapture8_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture8_active) begin
			if ((~bank_windowcapture8_rx_ready)) begin
				bank_windowcapture8_active <= 1'd0;
				bank_windowcapture8_ack <= bank_windowcapture8_request_rx;
				bank_windowcapture8_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture8_count_rx <= (bank_windowcapture8_count_rx + 1'd1);
				if ((bank_windowcapture8_address == (bank_windowcapture8_limit - 1'd1))) begin
					bank_windowcapture8_active <= 1'd0;
					bank_windowcapture8_ack <= bank_windowcapture8_request_rx;
				end else begin
					bank_windowcapture8_address <= (bank_windowcapture8_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture9_sample <= (bank_windowcapture9_sample + 4'd8);
	bank_windowcapture9_prev <= bank_windowcapture9_data[7];
	if (((~bank_windowcapture9_active) & (bank_windowcapture9_request_rx != bank_windowcapture9_ack))) begin
		if (bank_windowcapture9_rx_ready) begin
			bank_windowcapture9_active <= 1'd1;
			bank_windowcapture9_address <= 1'd0;
			bank_windowcapture9_limit <= bank_windowcapture9_length_rx;
			bank_windowcapture9_start_rx <= (bank_windowcapture9_sample + 4'd8);
			bank_windowcapture9_previous_rx <= bank_windowcapture9_data[7];
			bank_windowcapture9_count_rx <= 1'd0;
			bank_windowcapture9_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture9_ack <= bank_windowcapture9_request_rx;
			bank_windowcapture9_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture9_active) begin
			if ((~bank_windowcapture9_rx_ready)) begin
				bank_windowcapture9_active <= 1'd0;
				bank_windowcapture9_ack <= bank_windowcapture9_request_rx;
				bank_windowcapture9_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture9_count_rx <= (bank_windowcapture9_count_rx + 1'd1);
				if ((bank_windowcapture9_address == (bank_windowcapture9_limit - 1'd1))) begin
					bank_windowcapture9_active <= 1'd0;
					bank_windowcapture9_ack <= bank_windowcapture9_request_rx;
				end else begin
					bank_windowcapture9_address <= (bank_windowcapture9_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture10_sample <= (bank_windowcapture10_sample + 4'd8);
	bank_windowcapture10_prev <= bank_windowcapture10_data[7];
	if (((~bank_windowcapture10_active) & (bank_windowcapture10_request_rx != bank_windowcapture10_ack))) begin
		if (bank_windowcapture10_rx_ready) begin
			bank_windowcapture10_active <= 1'd1;
			bank_windowcapture10_address <= 1'd0;
			bank_windowcapture10_limit <= bank_windowcapture10_length_rx;
			bank_windowcapture10_start_rx <= (bank_windowcapture10_sample + 4'd8);
			bank_windowcapture10_previous_rx <= bank_windowcapture10_data[7];
			bank_windowcapture10_count_rx <= 1'd0;
			bank_windowcapture10_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture10_ack <= bank_windowcapture10_request_rx;
			bank_windowcapture10_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture10_active) begin
			if ((~bank_windowcapture10_rx_ready)) begin
				bank_windowcapture10_active <= 1'd0;
				bank_windowcapture10_ack <= bank_windowcapture10_request_rx;
				bank_windowcapture10_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture10_count_rx <= (bank_windowcapture10_count_rx + 1'd1);
				if ((bank_windowcapture10_address == (bank_windowcapture10_limit - 1'd1))) begin
					bank_windowcapture10_active <= 1'd0;
					bank_windowcapture10_ack <= bank_windowcapture10_request_rx;
				end else begin
					bank_windowcapture10_address <= (bank_windowcapture10_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture11_sample <= (bank_windowcapture11_sample + 4'd8);
	bank_windowcapture11_prev <= bank_windowcapture11_data[7];
	if (((~bank_windowcapture11_active) & (bank_windowcapture11_request_rx != bank_windowcapture11_ack))) begin
		if (bank_windowcapture11_rx_ready) begin
			bank_windowcapture11_active <= 1'd1;
			bank_windowcapture11_address <= 1'd0;
			bank_windowcapture11_limit <= bank_windowcapture11_length_rx;
			bank_windowcapture11_start_rx <= (bank_windowcapture11_sample + 4'd8);
			bank_windowcapture11_previous_rx <= bank_windowcapture11_data[7];
			bank_windowcapture11_count_rx <= 1'd0;
			bank_windowcapture11_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture11_ack <= bank_windowcapture11_request_rx;
			bank_windowcapture11_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture11_active) begin
			if ((~bank_windowcapture11_rx_ready)) begin
				bank_windowcapture11_active <= 1'd0;
				bank_windowcapture11_ack <= bank_windowcapture11_request_rx;
				bank_windowcapture11_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture11_count_rx <= (bank_windowcapture11_count_rx + 1'd1);
				if ((bank_windowcapture11_address == (bank_windowcapture11_limit - 1'd1))) begin
					bank_windowcapture11_active <= 1'd0;
					bank_windowcapture11_ack <= bank_windowcapture11_request_rx;
				end else begin
					bank_windowcapture11_address <= (bank_windowcapture11_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture12_sample <= (bank_windowcapture12_sample + 4'd8);
	bank_windowcapture12_prev <= bank_windowcapture12_data[7];
	if (((~bank_windowcapture12_active) & (bank_windowcapture12_request_rx != bank_windowcapture12_ack))) begin
		if (bank_windowcapture12_rx_ready) begin
			bank_windowcapture12_active <= 1'd1;
			bank_windowcapture12_address <= 1'd0;
			bank_windowcapture12_limit <= bank_windowcapture12_length_rx;
			bank_windowcapture12_start_rx <= (bank_windowcapture12_sample + 4'd8);
			bank_windowcapture12_previous_rx <= bank_windowcapture12_data[7];
			bank_windowcapture12_count_rx <= 1'd0;
			bank_windowcapture12_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture12_ack <= bank_windowcapture12_request_rx;
			bank_windowcapture12_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture12_active) begin
			if ((~bank_windowcapture12_rx_ready)) begin
				bank_windowcapture12_active <= 1'd0;
				bank_windowcapture12_ack <= bank_windowcapture12_request_rx;
				bank_windowcapture12_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture12_count_rx <= (bank_windowcapture12_count_rx + 1'd1);
				if ((bank_windowcapture12_address == (bank_windowcapture12_limit - 1'd1))) begin
					bank_windowcapture12_active <= 1'd0;
					bank_windowcapture12_ack <= bank_windowcapture12_request_rx;
				end else begin
					bank_windowcapture12_address <= (bank_windowcapture12_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture13_sample <= (bank_windowcapture13_sample + 4'd8);
	bank_windowcapture13_prev <= bank_windowcapture13_data[7];
	if (((~bank_windowcapture13_active) & (bank_windowcapture13_request_rx != bank_windowcapture13_ack))) begin
		if (bank_windowcapture13_rx_ready) begin
			bank_windowcapture13_active <= 1'd1;
			bank_windowcapture13_address <= 1'd0;
			bank_windowcapture13_limit <= bank_windowcapture13_length_rx;
			bank_windowcapture13_start_rx <= (bank_windowcapture13_sample + 4'd8);
			bank_windowcapture13_previous_rx <= bank_windowcapture13_data[7];
			bank_windowcapture13_count_rx <= 1'd0;
			bank_windowcapture13_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture13_ack <= bank_windowcapture13_request_rx;
			bank_windowcapture13_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture13_active) begin
			if ((~bank_windowcapture13_rx_ready)) begin
				bank_windowcapture13_active <= 1'd0;
				bank_windowcapture13_ack <= bank_windowcapture13_request_rx;
				bank_windowcapture13_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture13_count_rx <= (bank_windowcapture13_count_rx + 1'd1);
				if ((bank_windowcapture13_address == (bank_windowcapture13_limit - 1'd1))) begin
					bank_windowcapture13_active <= 1'd0;
					bank_windowcapture13_ack <= bank_windowcapture13_request_rx;
				end else begin
					bank_windowcapture13_address <= (bank_windowcapture13_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture14_sample <= (bank_windowcapture14_sample + 4'd8);
	bank_windowcapture14_prev <= bank_windowcapture14_data[7];
	if (((~bank_windowcapture14_active) & (bank_windowcapture14_request_rx != bank_windowcapture14_ack))) begin
		if (bank_windowcapture14_rx_ready) begin
			bank_windowcapture14_active <= 1'd1;
			bank_windowcapture14_address <= 1'd0;
			bank_windowcapture14_limit <= bank_windowcapture14_length_rx;
			bank_windowcapture14_start_rx <= (bank_windowcapture14_sample + 4'd8);
			bank_windowcapture14_previous_rx <= bank_windowcapture14_data[7];
			bank_windowcapture14_count_rx <= 1'd0;
			bank_windowcapture14_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture14_ack <= bank_windowcapture14_request_rx;
			bank_windowcapture14_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture14_active) begin
			if ((~bank_windowcapture14_rx_ready)) begin
				bank_windowcapture14_active <= 1'd0;
				bank_windowcapture14_ack <= bank_windowcapture14_request_rx;
				bank_windowcapture14_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture14_count_rx <= (bank_windowcapture14_count_rx + 1'd1);
				if ((bank_windowcapture14_address == (bank_windowcapture14_limit - 1'd1))) begin
					bank_windowcapture14_active <= 1'd0;
					bank_windowcapture14_ack <= bank_windowcapture14_request_rx;
				end else begin
					bank_windowcapture14_address <= (bank_windowcapture14_address + 1'd1);
				end
			end
		end
	end
	bank_windowcapture15_sample <= (bank_windowcapture15_sample + 4'd8);
	bank_windowcapture15_prev <= bank_windowcapture15_data[7];
	if (((~bank_windowcapture15_active) & (bank_windowcapture15_request_rx != bank_windowcapture15_ack))) begin
		if (bank_windowcapture15_rx_ready) begin
			bank_windowcapture15_active <= 1'd1;
			bank_windowcapture15_address <= 1'd0;
			bank_windowcapture15_limit <= bank_windowcapture15_length_rx;
			bank_windowcapture15_start_rx <= (bank_windowcapture15_sample + 4'd8);
			bank_windowcapture15_previous_rx <= bank_windowcapture15_data[7];
			bank_windowcapture15_count_rx <= 1'd0;
			bank_windowcapture15_aborted_rx <= 1'd0;
		end else begin
			bank_windowcapture15_ack <= bank_windowcapture15_request_rx;
			bank_windowcapture15_aborted_rx <= 1'd1;
		end
	end else begin
		if (bank_windowcapture15_active) begin
			if ((~bank_windowcapture15_rx_ready)) begin
				bank_windowcapture15_active <= 1'd0;
				bank_windowcapture15_ack <= bank_windowcapture15_request_rx;
				bank_windowcapture15_aborted_rx <= 1'd1;
			end else begin
				bank_windowcapture15_count_rx <= (bank_windowcapture15_count_rx + 1'd1);
				if ((bank_windowcapture15_address == (bank_windowcapture15_limit - 1'd1))) begin
					bank_windowcapture15_active <= 1'd0;
					bank_windowcapture15_ack <= bank_windowcapture15_request_rx;
				end else begin
					bank_windowcapture15_address <= (bank_windowcapture15_address + 1'd1);
				end
			end
		end
	end
	if (sample_rst) begin
		bank_windowcapture0_ack <= 1'd0;
		bank_windowcapture0_active <= 1'd0;
		bank_windowcapture0_address <= 12'd0;
		bank_windowcapture0_limit <= 13'd0;
		bank_windowcapture0_start_rx <= 64'd0;
		bank_windowcapture0_previous_rx <= 1'd0;
		bank_windowcapture0_count_rx <= 13'd0;
		bank_windowcapture0_aborted_rx <= 1'd0;
		bank_windowcapture0_sample <= 64'd0;
		bank_windowcapture0_prev <= 1'd0;
		bank_windowcapture1_ack <= 1'd0;
		bank_windowcapture1_active <= 1'd0;
		bank_windowcapture1_address <= 12'd0;
		bank_windowcapture1_limit <= 13'd0;
		bank_windowcapture1_start_rx <= 64'd0;
		bank_windowcapture1_previous_rx <= 1'd0;
		bank_windowcapture1_count_rx <= 13'd0;
		bank_windowcapture1_aborted_rx <= 1'd0;
		bank_windowcapture1_sample <= 64'd0;
		bank_windowcapture1_prev <= 1'd0;
		bank_windowcapture2_ack <= 1'd0;
		bank_windowcapture2_active <= 1'd0;
		bank_windowcapture2_address <= 12'd0;
		bank_windowcapture2_limit <= 13'd0;
		bank_windowcapture2_start_rx <= 64'd0;
		bank_windowcapture2_previous_rx <= 1'd0;
		bank_windowcapture2_count_rx <= 13'd0;
		bank_windowcapture2_aborted_rx <= 1'd0;
		bank_windowcapture2_sample <= 64'd0;
		bank_windowcapture2_prev <= 1'd0;
		bank_windowcapture3_ack <= 1'd0;
		bank_windowcapture3_active <= 1'd0;
		bank_windowcapture3_address <= 12'd0;
		bank_windowcapture3_limit <= 13'd0;
		bank_windowcapture3_start_rx <= 64'd0;
		bank_windowcapture3_previous_rx <= 1'd0;
		bank_windowcapture3_count_rx <= 13'd0;
		bank_windowcapture3_aborted_rx <= 1'd0;
		bank_windowcapture3_sample <= 64'd0;
		bank_windowcapture3_prev <= 1'd0;
		bank_windowcapture4_ack <= 1'd0;
		bank_windowcapture4_active <= 1'd0;
		bank_windowcapture4_address <= 12'd0;
		bank_windowcapture4_limit <= 13'd0;
		bank_windowcapture4_start_rx <= 64'd0;
		bank_windowcapture4_previous_rx <= 1'd0;
		bank_windowcapture4_count_rx <= 13'd0;
		bank_windowcapture4_aborted_rx <= 1'd0;
		bank_windowcapture4_sample <= 64'd0;
		bank_windowcapture4_prev <= 1'd0;
		bank_windowcapture5_ack <= 1'd0;
		bank_windowcapture5_active <= 1'd0;
		bank_windowcapture5_address <= 12'd0;
		bank_windowcapture5_limit <= 13'd0;
		bank_windowcapture5_start_rx <= 64'd0;
		bank_windowcapture5_previous_rx <= 1'd0;
		bank_windowcapture5_count_rx <= 13'd0;
		bank_windowcapture5_aborted_rx <= 1'd0;
		bank_windowcapture5_sample <= 64'd0;
		bank_windowcapture5_prev <= 1'd0;
		bank_windowcapture6_ack <= 1'd0;
		bank_windowcapture6_active <= 1'd0;
		bank_windowcapture6_address <= 12'd0;
		bank_windowcapture6_limit <= 13'd0;
		bank_windowcapture6_start_rx <= 64'd0;
		bank_windowcapture6_previous_rx <= 1'd0;
		bank_windowcapture6_count_rx <= 13'd0;
		bank_windowcapture6_aborted_rx <= 1'd0;
		bank_windowcapture6_sample <= 64'd0;
		bank_windowcapture6_prev <= 1'd0;
		bank_windowcapture7_ack <= 1'd0;
		bank_windowcapture7_active <= 1'd0;
		bank_windowcapture7_address <= 12'd0;
		bank_windowcapture7_limit <= 13'd0;
		bank_windowcapture7_start_rx <= 64'd0;
		bank_windowcapture7_previous_rx <= 1'd0;
		bank_windowcapture7_count_rx <= 13'd0;
		bank_windowcapture7_aborted_rx <= 1'd0;
		bank_windowcapture7_sample <= 64'd0;
		bank_windowcapture7_prev <= 1'd0;
		bank_windowcapture8_ack <= 1'd0;
		bank_windowcapture8_active <= 1'd0;
		bank_windowcapture8_address <= 12'd0;
		bank_windowcapture8_limit <= 13'd0;
		bank_windowcapture8_start_rx <= 64'd0;
		bank_windowcapture8_previous_rx <= 1'd0;
		bank_windowcapture8_count_rx <= 13'd0;
		bank_windowcapture8_aborted_rx <= 1'd0;
		bank_windowcapture8_sample <= 64'd0;
		bank_windowcapture8_prev <= 1'd0;
		bank_windowcapture9_ack <= 1'd0;
		bank_windowcapture9_active <= 1'd0;
		bank_windowcapture9_address <= 12'd0;
		bank_windowcapture9_limit <= 13'd0;
		bank_windowcapture9_start_rx <= 64'd0;
		bank_windowcapture9_previous_rx <= 1'd0;
		bank_windowcapture9_count_rx <= 13'd0;
		bank_windowcapture9_aborted_rx <= 1'd0;
		bank_windowcapture9_sample <= 64'd0;
		bank_windowcapture9_prev <= 1'd0;
		bank_windowcapture10_ack <= 1'd0;
		bank_windowcapture10_active <= 1'd0;
		bank_windowcapture10_address <= 12'd0;
		bank_windowcapture10_limit <= 13'd0;
		bank_windowcapture10_start_rx <= 64'd0;
		bank_windowcapture10_previous_rx <= 1'd0;
		bank_windowcapture10_count_rx <= 13'd0;
		bank_windowcapture10_aborted_rx <= 1'd0;
		bank_windowcapture10_sample <= 64'd0;
		bank_windowcapture10_prev <= 1'd0;
		bank_windowcapture11_ack <= 1'd0;
		bank_windowcapture11_active <= 1'd0;
		bank_windowcapture11_address <= 12'd0;
		bank_windowcapture11_limit <= 13'd0;
		bank_windowcapture11_start_rx <= 64'd0;
		bank_windowcapture11_previous_rx <= 1'd0;
		bank_windowcapture11_count_rx <= 13'd0;
		bank_windowcapture11_aborted_rx <= 1'd0;
		bank_windowcapture11_sample <= 64'd0;
		bank_windowcapture11_prev <= 1'd0;
		bank_windowcapture12_ack <= 1'd0;
		bank_windowcapture12_active <= 1'd0;
		bank_windowcapture12_address <= 12'd0;
		bank_windowcapture12_limit <= 13'd0;
		bank_windowcapture12_start_rx <= 64'd0;
		bank_windowcapture12_previous_rx <= 1'd0;
		bank_windowcapture12_count_rx <= 13'd0;
		bank_windowcapture12_aborted_rx <= 1'd0;
		bank_windowcapture12_sample <= 64'd0;
		bank_windowcapture12_prev <= 1'd0;
		bank_windowcapture13_ack <= 1'd0;
		bank_windowcapture13_active <= 1'd0;
		bank_windowcapture13_address <= 12'd0;
		bank_windowcapture13_limit <= 13'd0;
		bank_windowcapture13_start_rx <= 64'd0;
		bank_windowcapture13_previous_rx <= 1'd0;
		bank_windowcapture13_count_rx <= 13'd0;
		bank_windowcapture13_aborted_rx <= 1'd0;
		bank_windowcapture13_sample <= 64'd0;
		bank_windowcapture13_prev <= 1'd0;
		bank_windowcapture14_ack <= 1'd0;
		bank_windowcapture14_active <= 1'd0;
		bank_windowcapture14_address <= 12'd0;
		bank_windowcapture14_limit <= 13'd0;
		bank_windowcapture14_start_rx <= 64'd0;
		bank_windowcapture14_previous_rx <= 1'd0;
		bank_windowcapture14_count_rx <= 13'd0;
		bank_windowcapture14_aborted_rx <= 1'd0;
		bank_windowcapture14_sample <= 64'd0;
		bank_windowcapture14_prev <= 1'd0;
		bank_windowcapture15_ack <= 1'd0;
		bank_windowcapture15_active <= 1'd0;
		bank_windowcapture15_address <= 12'd0;
		bank_windowcapture15_limit <= 13'd0;
		bank_windowcapture15_start_rx <= 64'd0;
		bank_windowcapture15_previous_rx <= 1'd0;
		bank_windowcapture15_count_rx <= 13'd0;
		bank_windowcapture15_aborted_rx <= 1'd0;
		bank_windowcapture15_sample <= 64'd0;
		bank_windowcapture15_prev <= 1'd0;
	end
	xilinxmultiregimpl10 <= bank_windowcapture0_request;
	xilinxmultiregimpl11 <= xilinxmultiregimpl10;
	xilinxmultiregimpl40 <= bank_windowcapture0_length_mailbox;
	xilinxmultiregimpl41 <= xilinxmultiregimpl40;
	xilinxmultiregimpl90 <= bank_windowcapture1_request;
	xilinxmultiregimpl91 <= xilinxmultiregimpl90;
	xilinxmultiregimpl120 <= bank_windowcapture1_length_mailbox;
	xilinxmultiregimpl121 <= xilinxmultiregimpl120;
	xilinxmultiregimpl170 <= bank_windowcapture2_request;
	xilinxmultiregimpl171 <= xilinxmultiregimpl170;
	xilinxmultiregimpl200 <= bank_windowcapture2_length_mailbox;
	xilinxmultiregimpl201 <= xilinxmultiregimpl200;
	xilinxmultiregimpl250 <= bank_windowcapture3_request;
	xilinxmultiregimpl251 <= xilinxmultiregimpl250;
	xilinxmultiregimpl280 <= bank_windowcapture3_length_mailbox;
	xilinxmultiregimpl281 <= xilinxmultiregimpl280;
	xilinxmultiregimpl330 <= bank_windowcapture4_request;
	xilinxmultiregimpl331 <= xilinxmultiregimpl330;
	xilinxmultiregimpl360 <= bank_windowcapture4_length_mailbox;
	xilinxmultiregimpl361 <= xilinxmultiregimpl360;
	xilinxmultiregimpl410 <= bank_windowcapture5_request;
	xilinxmultiregimpl411 <= xilinxmultiregimpl410;
	xilinxmultiregimpl440 <= bank_windowcapture5_length_mailbox;
	xilinxmultiregimpl441 <= xilinxmultiregimpl440;
	xilinxmultiregimpl490 <= bank_windowcapture6_request;
	xilinxmultiregimpl491 <= xilinxmultiregimpl490;
	xilinxmultiregimpl520 <= bank_windowcapture6_length_mailbox;
	xilinxmultiregimpl521 <= xilinxmultiregimpl520;
	xilinxmultiregimpl570 <= bank_windowcapture7_request;
	xilinxmultiregimpl571 <= xilinxmultiregimpl570;
	xilinxmultiregimpl600 <= bank_windowcapture7_length_mailbox;
	xilinxmultiregimpl601 <= xilinxmultiregimpl600;
	xilinxmultiregimpl650 <= bank_windowcapture8_request;
	xilinxmultiregimpl651 <= xilinxmultiregimpl650;
	xilinxmultiregimpl680 <= bank_windowcapture8_length_mailbox;
	xilinxmultiregimpl681 <= xilinxmultiregimpl680;
	xilinxmultiregimpl730 <= bank_windowcapture9_request;
	xilinxmultiregimpl731 <= xilinxmultiregimpl730;
	xilinxmultiregimpl760 <= bank_windowcapture9_length_mailbox;
	xilinxmultiregimpl761 <= xilinxmultiregimpl760;
	xilinxmultiregimpl810 <= bank_windowcapture10_request;
	xilinxmultiregimpl811 <= xilinxmultiregimpl810;
	xilinxmultiregimpl840 <= bank_windowcapture10_length_mailbox;
	xilinxmultiregimpl841 <= xilinxmultiregimpl840;
	xilinxmultiregimpl890 <= bank_windowcapture11_request;
	xilinxmultiregimpl891 <= xilinxmultiregimpl890;
	xilinxmultiregimpl920 <= bank_windowcapture11_length_mailbox;
	xilinxmultiregimpl921 <= xilinxmultiregimpl920;
	xilinxmultiregimpl970 <= bank_windowcapture12_request;
	xilinxmultiregimpl971 <= xilinxmultiregimpl970;
	xilinxmultiregimpl1000 <= bank_windowcapture12_length_mailbox;
	xilinxmultiregimpl1001 <= xilinxmultiregimpl1000;
	xilinxmultiregimpl1050 <= bank_windowcapture13_request;
	xilinxmultiregimpl1051 <= xilinxmultiregimpl1050;
	xilinxmultiregimpl1080 <= bank_windowcapture13_length_mailbox;
	xilinxmultiregimpl1081 <= xilinxmultiregimpl1080;
	xilinxmultiregimpl1130 <= bank_windowcapture14_request;
	xilinxmultiregimpl1131 <= xilinxmultiregimpl1130;
	xilinxmultiregimpl1160 <= bank_windowcapture14_length_mailbox;
	xilinxmultiregimpl1161 <= xilinxmultiregimpl1160;
	xilinxmultiregimpl1210 <= bank_windowcapture15_request;
	xilinxmultiregimpl1211 <= xilinxmultiregimpl1210;
	xilinxmultiregimpl1240 <= bank_windowcapture15_length_mailbox;
	xilinxmultiregimpl1241 <= xilinxmultiregimpl1240;
end

always @(posedge sys_clk) begin
	if ((ipbus_bridge_control_write & (~permitted))) begin
		unsupported <= 1'd1;
	end
	if ((ipbus_bridge_control_write & (ipbus_bridge_control_address == 7'd112))) begin
		unsupported <= 1'd0;
	end
	if (((ipbus_bridge_control_write & (ipbus_bridge_control_address == 5'd28)) & (ipbus_bridge_control_write_data < 5'd16))) begin
		selected <= ipbus_bridge_control_write_data;
	end
	if ((bank_player_write & ((bank_player_write_bank == bank_player_active_bank) | bank_player_pending))) begin
		bank_player_error <= 1'd1;
	end
	if (bank_player_commit) begin
		if ((((bank_player_commit_length == 1'd0) | (bank_player_commit_length > 13'd4096)) | bank_player_pending)) begin
			bank_player_error <= 1'd1;
		end else begin
			bank_player_pending <= 1'd1;
			bank_player_pending_length <= bank_player_commit_length;
		end
	end
	if ((~(bank_player_enable & bank_player_ready))) begin
		bank_player_position <= 1'd0;
	end else begin
		if ((bank_player_position == (bank_player_length - 1'd1))) begin
			bank_player_position <= 1'd0;
			bank_player_loops <= (bank_player_loops + 1'd1);
		end else begin
			bank_player_position <= (bank_player_position + 1'd1);
		end
	end
	if ((bank_player_pending & ((~(bank_player_enable & bank_player_ready)) | (bank_player_position == (bank_player_length - 1'd1))))) begin
		bank_player_active_bank <= (~bank_player_active_bank);
		bank_player_length <= bank_player_pending_length;
		bank_player_pending <= 1'd0;
	end
	bank_windowcapture0_read_valid <= (bank_windowcapture0_done & (~bank_windowcapture0_busy));
	if (bank_windowcapture0_arm) begin
		if ((((bank_windowcapture0_busy | (~bank_windowcapture0_ready_sys)) | (bank_windowcapture0_request_length == 1'd0)) | (bank_windowcapture0_request_length > 13'd4096))) begin
			bank_windowcapture0_error <= 1'd1;
		end else begin
			bank_windowcapture0_length_mailbox <= bank_windowcapture0_request_length;
			bank_windowcapture0_request <= (~bank_windowcapture0_request);
			bank_windowcapture0_busy <= 1'd1;
			bank_windowcapture0_done <= 1'd0;
			bank_windowcapture0_settle <= 1'd0;
			bank_windowcapture0_error <= 1'd0;
			bank_windowcapture0_invalid <= 1'd0;
			bank_windowcapture0_capture_id <= (bank_windowcapture0_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture0_busy & (~bank_windowcapture0_ready_sys))) begin
		bank_windowcapture0_invalid <= 1'd1;
	end
	if ((bank_windowcapture0_busy & (bank_windowcapture0_ack_sys == bank_windowcapture0_request))) begin
		if ((bank_windowcapture0_settle == 3'd5)) begin
			bank_windowcapture0_busy <= 1'd0;
			bank_windowcapture0_done <= (~((bank_windowcapture0_aborted_sys | bank_windowcapture0_invalid) | (~bank_windowcapture0_ready_sys)));
			bank_windowcapture0_error <= ((bank_windowcapture0_aborted_sys | bank_windowcapture0_invalid) | (~bank_windowcapture0_ready_sys));
		end else begin
			bank_windowcapture0_settle <= (bank_windowcapture0_settle + 1'd1);
		end
	end
	bank_windowcapture1_read_valid <= (bank_windowcapture1_done & (~bank_windowcapture1_busy));
	if (bank_windowcapture1_arm) begin
		if ((((bank_windowcapture1_busy | (~bank_windowcapture1_ready_sys)) | (bank_windowcapture1_request_length == 1'd0)) | (bank_windowcapture1_request_length > 13'd4096))) begin
			bank_windowcapture1_error <= 1'd1;
		end else begin
			bank_windowcapture1_length_mailbox <= bank_windowcapture1_request_length;
			bank_windowcapture1_request <= (~bank_windowcapture1_request);
			bank_windowcapture1_busy <= 1'd1;
			bank_windowcapture1_done <= 1'd0;
			bank_windowcapture1_settle <= 1'd0;
			bank_windowcapture1_error <= 1'd0;
			bank_windowcapture1_invalid <= 1'd0;
			bank_windowcapture1_capture_id <= (bank_windowcapture1_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture1_busy & (~bank_windowcapture1_ready_sys))) begin
		bank_windowcapture1_invalid <= 1'd1;
	end
	if ((bank_windowcapture1_busy & (bank_windowcapture1_ack_sys == bank_windowcapture1_request))) begin
		if ((bank_windowcapture1_settle == 3'd5)) begin
			bank_windowcapture1_busy <= 1'd0;
			bank_windowcapture1_done <= (~((bank_windowcapture1_aborted_sys | bank_windowcapture1_invalid) | (~bank_windowcapture1_ready_sys)));
			bank_windowcapture1_error <= ((bank_windowcapture1_aborted_sys | bank_windowcapture1_invalid) | (~bank_windowcapture1_ready_sys));
		end else begin
			bank_windowcapture1_settle <= (bank_windowcapture1_settle + 1'd1);
		end
	end
	bank_windowcapture2_read_valid <= (bank_windowcapture2_done & (~bank_windowcapture2_busy));
	if (bank_windowcapture2_arm) begin
		if ((((bank_windowcapture2_busy | (~bank_windowcapture2_ready_sys)) | (bank_windowcapture2_request_length == 1'd0)) | (bank_windowcapture2_request_length > 13'd4096))) begin
			bank_windowcapture2_error <= 1'd1;
		end else begin
			bank_windowcapture2_length_mailbox <= bank_windowcapture2_request_length;
			bank_windowcapture2_request <= (~bank_windowcapture2_request);
			bank_windowcapture2_busy <= 1'd1;
			bank_windowcapture2_done <= 1'd0;
			bank_windowcapture2_settle <= 1'd0;
			bank_windowcapture2_error <= 1'd0;
			bank_windowcapture2_invalid <= 1'd0;
			bank_windowcapture2_capture_id <= (bank_windowcapture2_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture2_busy & (~bank_windowcapture2_ready_sys))) begin
		bank_windowcapture2_invalid <= 1'd1;
	end
	if ((bank_windowcapture2_busy & (bank_windowcapture2_ack_sys == bank_windowcapture2_request))) begin
		if ((bank_windowcapture2_settle == 3'd5)) begin
			bank_windowcapture2_busy <= 1'd0;
			bank_windowcapture2_done <= (~((bank_windowcapture2_aborted_sys | bank_windowcapture2_invalid) | (~bank_windowcapture2_ready_sys)));
			bank_windowcapture2_error <= ((bank_windowcapture2_aborted_sys | bank_windowcapture2_invalid) | (~bank_windowcapture2_ready_sys));
		end else begin
			bank_windowcapture2_settle <= (bank_windowcapture2_settle + 1'd1);
		end
	end
	bank_windowcapture3_read_valid <= (bank_windowcapture3_done & (~bank_windowcapture3_busy));
	if (bank_windowcapture3_arm) begin
		if ((((bank_windowcapture3_busy | (~bank_windowcapture3_ready_sys)) | (bank_windowcapture3_request_length == 1'd0)) | (bank_windowcapture3_request_length > 13'd4096))) begin
			bank_windowcapture3_error <= 1'd1;
		end else begin
			bank_windowcapture3_length_mailbox <= bank_windowcapture3_request_length;
			bank_windowcapture3_request <= (~bank_windowcapture3_request);
			bank_windowcapture3_busy <= 1'd1;
			bank_windowcapture3_done <= 1'd0;
			bank_windowcapture3_settle <= 1'd0;
			bank_windowcapture3_error <= 1'd0;
			bank_windowcapture3_invalid <= 1'd0;
			bank_windowcapture3_capture_id <= (bank_windowcapture3_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture3_busy & (~bank_windowcapture3_ready_sys))) begin
		bank_windowcapture3_invalid <= 1'd1;
	end
	if ((bank_windowcapture3_busy & (bank_windowcapture3_ack_sys == bank_windowcapture3_request))) begin
		if ((bank_windowcapture3_settle == 3'd5)) begin
			bank_windowcapture3_busy <= 1'd0;
			bank_windowcapture3_done <= (~((bank_windowcapture3_aborted_sys | bank_windowcapture3_invalid) | (~bank_windowcapture3_ready_sys)));
			bank_windowcapture3_error <= ((bank_windowcapture3_aborted_sys | bank_windowcapture3_invalid) | (~bank_windowcapture3_ready_sys));
		end else begin
			bank_windowcapture3_settle <= (bank_windowcapture3_settle + 1'd1);
		end
	end
	bank_windowcapture4_read_valid <= (bank_windowcapture4_done & (~bank_windowcapture4_busy));
	if (bank_windowcapture4_arm) begin
		if ((((bank_windowcapture4_busy | (~bank_windowcapture4_ready_sys)) | (bank_windowcapture4_request_length == 1'd0)) | (bank_windowcapture4_request_length > 13'd4096))) begin
			bank_windowcapture4_error <= 1'd1;
		end else begin
			bank_windowcapture4_length_mailbox <= bank_windowcapture4_request_length;
			bank_windowcapture4_request <= (~bank_windowcapture4_request);
			bank_windowcapture4_busy <= 1'd1;
			bank_windowcapture4_done <= 1'd0;
			bank_windowcapture4_settle <= 1'd0;
			bank_windowcapture4_error <= 1'd0;
			bank_windowcapture4_invalid <= 1'd0;
			bank_windowcapture4_capture_id <= (bank_windowcapture4_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture4_busy & (~bank_windowcapture4_ready_sys))) begin
		bank_windowcapture4_invalid <= 1'd1;
	end
	if ((bank_windowcapture4_busy & (bank_windowcapture4_ack_sys == bank_windowcapture4_request))) begin
		if ((bank_windowcapture4_settle == 3'd5)) begin
			bank_windowcapture4_busy <= 1'd0;
			bank_windowcapture4_done <= (~((bank_windowcapture4_aborted_sys | bank_windowcapture4_invalid) | (~bank_windowcapture4_ready_sys)));
			bank_windowcapture4_error <= ((bank_windowcapture4_aborted_sys | bank_windowcapture4_invalid) | (~bank_windowcapture4_ready_sys));
		end else begin
			bank_windowcapture4_settle <= (bank_windowcapture4_settle + 1'd1);
		end
	end
	bank_windowcapture5_read_valid <= (bank_windowcapture5_done & (~bank_windowcapture5_busy));
	if (bank_windowcapture5_arm) begin
		if ((((bank_windowcapture5_busy | (~bank_windowcapture5_ready_sys)) | (bank_windowcapture5_request_length == 1'd0)) | (bank_windowcapture5_request_length > 13'd4096))) begin
			bank_windowcapture5_error <= 1'd1;
		end else begin
			bank_windowcapture5_length_mailbox <= bank_windowcapture5_request_length;
			bank_windowcapture5_request <= (~bank_windowcapture5_request);
			bank_windowcapture5_busy <= 1'd1;
			bank_windowcapture5_done <= 1'd0;
			bank_windowcapture5_settle <= 1'd0;
			bank_windowcapture5_error <= 1'd0;
			bank_windowcapture5_invalid <= 1'd0;
			bank_windowcapture5_capture_id <= (bank_windowcapture5_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture5_busy & (~bank_windowcapture5_ready_sys))) begin
		bank_windowcapture5_invalid <= 1'd1;
	end
	if ((bank_windowcapture5_busy & (bank_windowcapture5_ack_sys == bank_windowcapture5_request))) begin
		if ((bank_windowcapture5_settle == 3'd5)) begin
			bank_windowcapture5_busy <= 1'd0;
			bank_windowcapture5_done <= (~((bank_windowcapture5_aborted_sys | bank_windowcapture5_invalid) | (~bank_windowcapture5_ready_sys)));
			bank_windowcapture5_error <= ((bank_windowcapture5_aborted_sys | bank_windowcapture5_invalid) | (~bank_windowcapture5_ready_sys));
		end else begin
			bank_windowcapture5_settle <= (bank_windowcapture5_settle + 1'd1);
		end
	end
	bank_windowcapture6_read_valid <= (bank_windowcapture6_done & (~bank_windowcapture6_busy));
	if (bank_windowcapture6_arm) begin
		if ((((bank_windowcapture6_busy | (~bank_windowcapture6_ready_sys)) | (bank_windowcapture6_request_length == 1'd0)) | (bank_windowcapture6_request_length > 13'd4096))) begin
			bank_windowcapture6_error <= 1'd1;
		end else begin
			bank_windowcapture6_length_mailbox <= bank_windowcapture6_request_length;
			bank_windowcapture6_request <= (~bank_windowcapture6_request);
			bank_windowcapture6_busy <= 1'd1;
			bank_windowcapture6_done <= 1'd0;
			bank_windowcapture6_settle <= 1'd0;
			bank_windowcapture6_error <= 1'd0;
			bank_windowcapture6_invalid <= 1'd0;
			bank_windowcapture6_capture_id <= (bank_windowcapture6_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture6_busy & (~bank_windowcapture6_ready_sys))) begin
		bank_windowcapture6_invalid <= 1'd1;
	end
	if ((bank_windowcapture6_busy & (bank_windowcapture6_ack_sys == bank_windowcapture6_request))) begin
		if ((bank_windowcapture6_settle == 3'd5)) begin
			bank_windowcapture6_busy <= 1'd0;
			bank_windowcapture6_done <= (~((bank_windowcapture6_aborted_sys | bank_windowcapture6_invalid) | (~bank_windowcapture6_ready_sys)));
			bank_windowcapture6_error <= ((bank_windowcapture6_aborted_sys | bank_windowcapture6_invalid) | (~bank_windowcapture6_ready_sys));
		end else begin
			bank_windowcapture6_settle <= (bank_windowcapture6_settle + 1'd1);
		end
	end
	bank_windowcapture7_read_valid <= (bank_windowcapture7_done & (~bank_windowcapture7_busy));
	if (bank_windowcapture7_arm) begin
		if ((((bank_windowcapture7_busy | (~bank_windowcapture7_ready_sys)) | (bank_windowcapture7_request_length == 1'd0)) | (bank_windowcapture7_request_length > 13'd4096))) begin
			bank_windowcapture7_error <= 1'd1;
		end else begin
			bank_windowcapture7_length_mailbox <= bank_windowcapture7_request_length;
			bank_windowcapture7_request <= (~bank_windowcapture7_request);
			bank_windowcapture7_busy <= 1'd1;
			bank_windowcapture7_done <= 1'd0;
			bank_windowcapture7_settle <= 1'd0;
			bank_windowcapture7_error <= 1'd0;
			bank_windowcapture7_invalid <= 1'd0;
			bank_windowcapture7_capture_id <= (bank_windowcapture7_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture7_busy & (~bank_windowcapture7_ready_sys))) begin
		bank_windowcapture7_invalid <= 1'd1;
	end
	if ((bank_windowcapture7_busy & (bank_windowcapture7_ack_sys == bank_windowcapture7_request))) begin
		if ((bank_windowcapture7_settle == 3'd5)) begin
			bank_windowcapture7_busy <= 1'd0;
			bank_windowcapture7_done <= (~((bank_windowcapture7_aborted_sys | bank_windowcapture7_invalid) | (~bank_windowcapture7_ready_sys)));
			bank_windowcapture7_error <= ((bank_windowcapture7_aborted_sys | bank_windowcapture7_invalid) | (~bank_windowcapture7_ready_sys));
		end else begin
			bank_windowcapture7_settle <= (bank_windowcapture7_settle + 1'd1);
		end
	end
	bank_windowcapture8_read_valid <= (bank_windowcapture8_done & (~bank_windowcapture8_busy));
	if (bank_windowcapture8_arm) begin
		if ((((bank_windowcapture8_busy | (~bank_windowcapture8_ready_sys)) | (bank_windowcapture8_request_length == 1'd0)) | (bank_windowcapture8_request_length > 13'd4096))) begin
			bank_windowcapture8_error <= 1'd1;
		end else begin
			bank_windowcapture8_length_mailbox <= bank_windowcapture8_request_length;
			bank_windowcapture8_request <= (~bank_windowcapture8_request);
			bank_windowcapture8_busy <= 1'd1;
			bank_windowcapture8_done <= 1'd0;
			bank_windowcapture8_settle <= 1'd0;
			bank_windowcapture8_error <= 1'd0;
			bank_windowcapture8_invalid <= 1'd0;
			bank_windowcapture8_capture_id <= (bank_windowcapture8_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture8_busy & (~bank_windowcapture8_ready_sys))) begin
		bank_windowcapture8_invalid <= 1'd1;
	end
	if ((bank_windowcapture8_busy & (bank_windowcapture8_ack_sys == bank_windowcapture8_request))) begin
		if ((bank_windowcapture8_settle == 3'd5)) begin
			bank_windowcapture8_busy <= 1'd0;
			bank_windowcapture8_done <= (~((bank_windowcapture8_aborted_sys | bank_windowcapture8_invalid) | (~bank_windowcapture8_ready_sys)));
			bank_windowcapture8_error <= ((bank_windowcapture8_aborted_sys | bank_windowcapture8_invalid) | (~bank_windowcapture8_ready_sys));
		end else begin
			bank_windowcapture8_settle <= (bank_windowcapture8_settle + 1'd1);
		end
	end
	bank_windowcapture9_read_valid <= (bank_windowcapture9_done & (~bank_windowcapture9_busy));
	if (bank_windowcapture9_arm) begin
		if ((((bank_windowcapture9_busy | (~bank_windowcapture9_ready_sys)) | (bank_windowcapture9_request_length == 1'd0)) | (bank_windowcapture9_request_length > 13'd4096))) begin
			bank_windowcapture9_error <= 1'd1;
		end else begin
			bank_windowcapture9_length_mailbox <= bank_windowcapture9_request_length;
			bank_windowcapture9_request <= (~bank_windowcapture9_request);
			bank_windowcapture9_busy <= 1'd1;
			bank_windowcapture9_done <= 1'd0;
			bank_windowcapture9_settle <= 1'd0;
			bank_windowcapture9_error <= 1'd0;
			bank_windowcapture9_invalid <= 1'd0;
			bank_windowcapture9_capture_id <= (bank_windowcapture9_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture9_busy & (~bank_windowcapture9_ready_sys))) begin
		bank_windowcapture9_invalid <= 1'd1;
	end
	if ((bank_windowcapture9_busy & (bank_windowcapture9_ack_sys == bank_windowcapture9_request))) begin
		if ((bank_windowcapture9_settle == 3'd5)) begin
			bank_windowcapture9_busy <= 1'd0;
			bank_windowcapture9_done <= (~((bank_windowcapture9_aborted_sys | bank_windowcapture9_invalid) | (~bank_windowcapture9_ready_sys)));
			bank_windowcapture9_error <= ((bank_windowcapture9_aborted_sys | bank_windowcapture9_invalid) | (~bank_windowcapture9_ready_sys));
		end else begin
			bank_windowcapture9_settle <= (bank_windowcapture9_settle + 1'd1);
		end
	end
	bank_windowcapture10_read_valid <= (bank_windowcapture10_done & (~bank_windowcapture10_busy));
	if (bank_windowcapture10_arm) begin
		if ((((bank_windowcapture10_busy | (~bank_windowcapture10_ready_sys)) | (bank_windowcapture10_request_length == 1'd0)) | (bank_windowcapture10_request_length > 13'd4096))) begin
			bank_windowcapture10_error <= 1'd1;
		end else begin
			bank_windowcapture10_length_mailbox <= bank_windowcapture10_request_length;
			bank_windowcapture10_request <= (~bank_windowcapture10_request);
			bank_windowcapture10_busy <= 1'd1;
			bank_windowcapture10_done <= 1'd0;
			bank_windowcapture10_settle <= 1'd0;
			bank_windowcapture10_error <= 1'd0;
			bank_windowcapture10_invalid <= 1'd0;
			bank_windowcapture10_capture_id <= (bank_windowcapture10_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture10_busy & (~bank_windowcapture10_ready_sys))) begin
		bank_windowcapture10_invalid <= 1'd1;
	end
	if ((bank_windowcapture10_busy & (bank_windowcapture10_ack_sys == bank_windowcapture10_request))) begin
		if ((bank_windowcapture10_settle == 3'd5)) begin
			bank_windowcapture10_busy <= 1'd0;
			bank_windowcapture10_done <= (~((bank_windowcapture10_aborted_sys | bank_windowcapture10_invalid) | (~bank_windowcapture10_ready_sys)));
			bank_windowcapture10_error <= ((bank_windowcapture10_aborted_sys | bank_windowcapture10_invalid) | (~bank_windowcapture10_ready_sys));
		end else begin
			bank_windowcapture10_settle <= (bank_windowcapture10_settle + 1'd1);
		end
	end
	bank_windowcapture11_read_valid <= (bank_windowcapture11_done & (~bank_windowcapture11_busy));
	if (bank_windowcapture11_arm) begin
		if ((((bank_windowcapture11_busy | (~bank_windowcapture11_ready_sys)) | (bank_windowcapture11_request_length == 1'd0)) | (bank_windowcapture11_request_length > 13'd4096))) begin
			bank_windowcapture11_error <= 1'd1;
		end else begin
			bank_windowcapture11_length_mailbox <= bank_windowcapture11_request_length;
			bank_windowcapture11_request <= (~bank_windowcapture11_request);
			bank_windowcapture11_busy <= 1'd1;
			bank_windowcapture11_done <= 1'd0;
			bank_windowcapture11_settle <= 1'd0;
			bank_windowcapture11_error <= 1'd0;
			bank_windowcapture11_invalid <= 1'd0;
			bank_windowcapture11_capture_id <= (bank_windowcapture11_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture11_busy & (~bank_windowcapture11_ready_sys))) begin
		bank_windowcapture11_invalid <= 1'd1;
	end
	if ((bank_windowcapture11_busy & (bank_windowcapture11_ack_sys == bank_windowcapture11_request))) begin
		if ((bank_windowcapture11_settle == 3'd5)) begin
			bank_windowcapture11_busy <= 1'd0;
			bank_windowcapture11_done <= (~((bank_windowcapture11_aborted_sys | bank_windowcapture11_invalid) | (~bank_windowcapture11_ready_sys)));
			bank_windowcapture11_error <= ((bank_windowcapture11_aborted_sys | bank_windowcapture11_invalid) | (~bank_windowcapture11_ready_sys));
		end else begin
			bank_windowcapture11_settle <= (bank_windowcapture11_settle + 1'd1);
		end
	end
	bank_windowcapture12_read_valid <= (bank_windowcapture12_done & (~bank_windowcapture12_busy));
	if (bank_windowcapture12_arm) begin
		if ((((bank_windowcapture12_busy | (~bank_windowcapture12_ready_sys)) | (bank_windowcapture12_request_length == 1'd0)) | (bank_windowcapture12_request_length > 13'd4096))) begin
			bank_windowcapture12_error <= 1'd1;
		end else begin
			bank_windowcapture12_length_mailbox <= bank_windowcapture12_request_length;
			bank_windowcapture12_request <= (~bank_windowcapture12_request);
			bank_windowcapture12_busy <= 1'd1;
			bank_windowcapture12_done <= 1'd0;
			bank_windowcapture12_settle <= 1'd0;
			bank_windowcapture12_error <= 1'd0;
			bank_windowcapture12_invalid <= 1'd0;
			bank_windowcapture12_capture_id <= (bank_windowcapture12_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture12_busy & (~bank_windowcapture12_ready_sys))) begin
		bank_windowcapture12_invalid <= 1'd1;
	end
	if ((bank_windowcapture12_busy & (bank_windowcapture12_ack_sys == bank_windowcapture12_request))) begin
		if ((bank_windowcapture12_settle == 3'd5)) begin
			bank_windowcapture12_busy <= 1'd0;
			bank_windowcapture12_done <= (~((bank_windowcapture12_aborted_sys | bank_windowcapture12_invalid) | (~bank_windowcapture12_ready_sys)));
			bank_windowcapture12_error <= ((bank_windowcapture12_aborted_sys | bank_windowcapture12_invalid) | (~bank_windowcapture12_ready_sys));
		end else begin
			bank_windowcapture12_settle <= (bank_windowcapture12_settle + 1'd1);
		end
	end
	bank_windowcapture13_read_valid <= (bank_windowcapture13_done & (~bank_windowcapture13_busy));
	if (bank_windowcapture13_arm) begin
		if ((((bank_windowcapture13_busy | (~bank_windowcapture13_ready_sys)) | (bank_windowcapture13_request_length == 1'd0)) | (bank_windowcapture13_request_length > 13'd4096))) begin
			bank_windowcapture13_error <= 1'd1;
		end else begin
			bank_windowcapture13_length_mailbox <= bank_windowcapture13_request_length;
			bank_windowcapture13_request <= (~bank_windowcapture13_request);
			bank_windowcapture13_busy <= 1'd1;
			bank_windowcapture13_done <= 1'd0;
			bank_windowcapture13_settle <= 1'd0;
			bank_windowcapture13_error <= 1'd0;
			bank_windowcapture13_invalid <= 1'd0;
			bank_windowcapture13_capture_id <= (bank_windowcapture13_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture13_busy & (~bank_windowcapture13_ready_sys))) begin
		bank_windowcapture13_invalid <= 1'd1;
	end
	if ((bank_windowcapture13_busy & (bank_windowcapture13_ack_sys == bank_windowcapture13_request))) begin
		if ((bank_windowcapture13_settle == 3'd5)) begin
			bank_windowcapture13_busy <= 1'd0;
			bank_windowcapture13_done <= (~((bank_windowcapture13_aborted_sys | bank_windowcapture13_invalid) | (~bank_windowcapture13_ready_sys)));
			bank_windowcapture13_error <= ((bank_windowcapture13_aborted_sys | bank_windowcapture13_invalid) | (~bank_windowcapture13_ready_sys));
		end else begin
			bank_windowcapture13_settle <= (bank_windowcapture13_settle + 1'd1);
		end
	end
	bank_windowcapture14_read_valid <= (bank_windowcapture14_done & (~bank_windowcapture14_busy));
	if (bank_windowcapture14_arm) begin
		if ((((bank_windowcapture14_busy | (~bank_windowcapture14_ready_sys)) | (bank_windowcapture14_request_length == 1'd0)) | (bank_windowcapture14_request_length > 13'd4096))) begin
			bank_windowcapture14_error <= 1'd1;
		end else begin
			bank_windowcapture14_length_mailbox <= bank_windowcapture14_request_length;
			bank_windowcapture14_request <= (~bank_windowcapture14_request);
			bank_windowcapture14_busy <= 1'd1;
			bank_windowcapture14_done <= 1'd0;
			bank_windowcapture14_settle <= 1'd0;
			bank_windowcapture14_error <= 1'd0;
			bank_windowcapture14_invalid <= 1'd0;
			bank_windowcapture14_capture_id <= (bank_windowcapture14_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture14_busy & (~bank_windowcapture14_ready_sys))) begin
		bank_windowcapture14_invalid <= 1'd1;
	end
	if ((bank_windowcapture14_busy & (bank_windowcapture14_ack_sys == bank_windowcapture14_request))) begin
		if ((bank_windowcapture14_settle == 3'd5)) begin
			bank_windowcapture14_busy <= 1'd0;
			bank_windowcapture14_done <= (~((bank_windowcapture14_aborted_sys | bank_windowcapture14_invalid) | (~bank_windowcapture14_ready_sys)));
			bank_windowcapture14_error <= ((bank_windowcapture14_aborted_sys | bank_windowcapture14_invalid) | (~bank_windowcapture14_ready_sys));
		end else begin
			bank_windowcapture14_settle <= (bank_windowcapture14_settle + 1'd1);
		end
	end
	bank_windowcapture15_read_valid <= (bank_windowcapture15_done & (~bank_windowcapture15_busy));
	if (bank_windowcapture15_arm) begin
		if ((((bank_windowcapture15_busy | (~bank_windowcapture15_ready_sys)) | (bank_windowcapture15_request_length == 1'd0)) | (bank_windowcapture15_request_length > 13'd4096))) begin
			bank_windowcapture15_error <= 1'd1;
		end else begin
			bank_windowcapture15_length_mailbox <= bank_windowcapture15_request_length;
			bank_windowcapture15_request <= (~bank_windowcapture15_request);
			bank_windowcapture15_busy <= 1'd1;
			bank_windowcapture15_done <= 1'd0;
			bank_windowcapture15_settle <= 1'd0;
			bank_windowcapture15_error <= 1'd0;
			bank_windowcapture15_invalid <= 1'd0;
			bank_windowcapture15_capture_id <= (bank_windowcapture15_capture_id + 1'd1);
		end
	end
	if ((bank_windowcapture15_busy & (~bank_windowcapture15_ready_sys))) begin
		bank_windowcapture15_invalid <= 1'd1;
	end
	if ((bank_windowcapture15_busy & (bank_windowcapture15_ack_sys == bank_windowcapture15_request))) begin
		if ((bank_windowcapture15_settle == 3'd5)) begin
			bank_windowcapture15_busy <= 1'd0;
			bank_windowcapture15_done <= (~((bank_windowcapture15_aborted_sys | bank_windowcapture15_invalid) | (~bank_windowcapture15_ready_sys)));
			bank_windowcapture15_error <= ((bank_windowcapture15_aborted_sys | bank_windowcapture15_invalid) | (~bank_windowcapture15_ready_sys));
		end else begin
			bank_windowcapture15_settle <= (bank_windowcapture15_settle + 1'd1);
		end
	end
	uart_sink_ack <= 1'd0;
	if (((uart_sink_stb & (~uart_tx_busy)) & (~uart_sink_ack))) begin
		uart_tx_reg <= uart_sink_payload_data;
		uart_tx_bitcount <= 1'd0;
		uart_tx_busy <= 1'd1;
		serial_tx <= 1'd0;
	end else begin
		if ((uart_uart_clk_txen & uart_tx_busy)) begin
			uart_tx_bitcount <= (uart_tx_bitcount + 1'd1);
			if ((uart_tx_bitcount == 4'd8)) begin
				serial_tx <= 1'd1;
			end else begin
				if ((uart_tx_bitcount == 4'd9)) begin
					serial_tx <= 1'd1;
					uart_tx_busy <= 1'd0;
					uart_sink_ack <= 1'd1;
				end else begin
					serial_tx <= uart_tx_reg[0];
					uart_tx_reg <= {1'd0, uart_tx_reg[7:1]};
				end
			end
		end
	end
	if (uart_tx_busy) begin
		{uart_uart_clk_txen, uart_phase_accumulator_tx} <= (uart_phase_accumulator_tx + uart_storage);
	end else begin
		{uart_uart_clk_txen, uart_phase_accumulator_tx} <= 1'd0;
	end
	uart_source_stb <= 1'd0;
	uart_rx_r <= uart_rx;
	if ((~uart_rx_busy)) begin
		if (((~uart_rx) & uart_rx_r)) begin
			uart_rx_busy <= 1'd1;
			uart_rx_bitcount <= 1'd0;
		end
	end else begin
		if (uart_uart_clk_rxen) begin
			uart_rx_bitcount <= (uart_rx_bitcount + 1'd1);
			if ((uart_rx_bitcount == 1'd0)) begin
				if (uart_rx) begin
					uart_rx_busy <= 1'd0;
				end
			end else begin
				if ((uart_rx_bitcount == 4'd9)) begin
					uart_rx_busy <= 1'd0;
					if (uart_rx) begin
						uart_source_payload_data <= uart_rx_reg;
						uart_source_stb <= 1'd1;
					end
				end else begin
					uart_rx_reg <= {uart_rx, uart_rx_reg[7:1]};
				end
			end
		end
	end
	if (uart_rx_busy) begin
		{uart_uart_clk_rxen, uart_phase_accumulator_rx} <= (uart_phase_accumulator_rx + uart_storage);
	end else begin
		{uart_uart_clk_rxen, uart_phase_accumulator_rx} <= 32'd2147483648;
	end
	state <= next_state;
	if (bus_timeout_next_value_ce0) begin
		bus_timeout <= bus_timeout_next_value0;
	end
	if (bus_command_next_value_ce1) begin
		bus_command <= bus_command_next_value1;
	end
	if (bus_rx_index_next_value_ce2) begin
		bus_rx_index <= bus_rx_index_next_value2;
	end
	if (bus_reply_next_value_ce3) begin
		bus_reply <= bus_reply_next_value3;
	end
	if (bus_tx_index_next_value_ce4) begin
		bus_tx_index <= bus_tx_index_next_value4;
	end
	if ((bus_read | bus_write)) begin
		ipbus_bridge_hold <= 4'd8;
	end else begin
		if ((ipbus_bridge_hold != 1'd0)) begin
			ipbus_bridge_hold <= (ipbus_bridge_hold - 1'd1);
		end
	end
	ipbus_bridge_previous_state <= ipbus_bridge_state;
	ipbus_bridge_previous_write <= ipbus_bridge_level;
	ethernet_pma_a7_gtp_basex_tx_cm_reset0 <= (~ethernet_lock);
	if (ethernet_pma_a7_gtp_basex_rx_reset) begin
		ethernet_pma_a7_gtp_basex_cdr_locked <= 1'd0;
		ethernet_pma_a7_gtp_basex_cdr_lock_counter <= 1'd0;
	end else begin
		if ((ethernet_pma_a7_gtp_basex_cdr_lock_counter != 13'd4800)) begin
			ethernet_pma_a7_gtp_basex_cdr_lock_counter <= (ethernet_pma_a7_gtp_basex_cdr_lock_counter + 1'd1);
		end else begin
			ethernet_pma_a7_gtp_basex_cdr_locked <= 1'd1;
		end
	end
	ethernet_pma_a7_gtp_basex_rx_cm_reset0 <= (~ethernet_pma_a7_gtp_basex_cdr_locked);
	ethernet_pma_a7_gtp_basex_tx_init_qpll_reset0 <= ethernet_pma_a7_gtp_basex_tx_init_qpll_reset1;
	ethernet_pma_a7_gtp_basex_tx_init_tx_reset0 <= ethernet_pma_a7_gtp_basex_tx_init_tx_reset1;
	ethernet_pma_a7_gtp_basex_tx_init_tick <= 1'd0;
	if ((ethernet_pma_a7_gtp_basex_tx_init_timer == 11'd1200)) begin
		ethernet_pma_a7_gtp_basex_tx_init_tick <= 1'd1;
		ethernet_pma_a7_gtp_basex_tx_init_timer <= 1'd0;
	end else begin
		ethernet_pma_a7_gtp_basex_tx_init_timer <= (ethernet_pma_a7_gtp_basex_tx_init_timer + 1'd1);
	end
	gtptxinit_state <= gtptxinit_next_state;
	ethernet_pma_a7_gtp_basex_rx_init_rx_reset0 <= ethernet_pma_a7_gtp_basex_rx_init_rx_reset1;
	ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done_r <= ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done1;
	gtprxinit_state <= gtprxinit_next_state;
	if (ethernet_pma_a7_gtp_basex_rx_init_drpvalue_a7_1000basex_next_value_ce) begin
		ethernet_pma_a7_gtp_basex_rx_init_drpvalue <= ethernet_pma_a7_gtp_basex_rx_init_drpvalue_a7_1000basex_next_value;
	end
	ethernet_pma_a7_gtp_basex_toggle_o_r <= ethernet_pma_a7_gtp_basex_toggle_o;
	control_arm <= 1'd0;
	control_cycle <= (control_cycle + 1'd1);
	if ((control_reserved & (~ready))) begin
		control_capture_armed <= 1'd0;
		control_generator_armed <= 1'd0;
		control_trigger_pending <= 1'd0;
		control_command_error <= 1'd1;
	end
	if (control_launch) begin
		control_trigger_pending <= 1'd0;
		control_trigger_id <= (control_trigger_id + 1'd1);
		if (control_generator_armed) begin
			control_enabled <= 1'd1;
		end
		control_generator_armed <= 1'd0;
		if (control_capture_armed) begin
			control_trigger_cycle <= control_cycle;
			control_trigger_position <= (control_enabled ? bank_player_position : 1'd0);
			control_trigger_loop <= bank_player_loops;
			control_arm <= 1'd1;
			control_watching <= 1'd1;
			control_seen_busy <= 1'd0;
			control_timer <= 1'd0;
			control_capture_outputs <= ((control_enabled | control_generator_armed) ? control_output_mask : 1'd0);
			control_capture_sequence <= (control_capture_sequence + 1'd1);
			control_capture_trigger_id <= (control_trigger_id + 1'd1);
		end
		control_capture_armed <= 1'd0;
	end
	if (control_watching) begin
		if (control_busy0) begin
			control_seen_busy <= 1'd1;
		end
		if ((((~ready) | (control_timer == 20'd1048575)) | control_error)) begin
			control_capture_fault <= 1'd1;
			control_watching <= 1'd0;
			control_enabled <= 1'd0;
		end else begin
			if (((control_seen_busy & control_done0) & (~control_busy0))) begin
				control_watching <= 1'd0;
			end else begin
				control_timer <= (control_timer + 1'd1);
			end
		end
	end
	if (local_write) begin
		case (local_address)
			4'd8: begin
				if ((local_write_data == 1'd0)) begin
					control_enabled <= 1'd0;
					control_capture_armed <= 1'd0;
					control_generator_armed <= 1'd0;
					control_trigger_pending <= 1'd0;
				end else begin
					if (((((local_write_data == 1'd1) & (~control_busy0)) & ready) & (~control_reserved))) begin
						control_enabled <= 1'd1;
					end else begin
						control_command_error <= 1'd1;
					end
				end
			end
			5'd16: begin
				if (((((~control_enabled) & (~control_busy0)) & (~control_reserved)) & (local_write_data < 17'd65536))) begin
					control_output_mask <= local_write_data;
				end else begin
					control_command_error <= 1'd1;
				end
			end
			5'd20: begin
				if (((((~control_busy0) & (~control_reserved)) & (local_write_data > 1'd0)) & (local_write_data <= 13'd4096))) begin
					control_capture_length <= local_write_data;
				end else begin
					control_command_error <= 1'd1;
				end
			end
			5'd24: begin
				if ((((((((~control_busy0) & (~control_watching)) & (~control_reserved)) & ready) & (~control_capture_fault)) & (control_capture_length > 1'd0)) & (control_capture_length <= 13'd4096))) begin
					control_arm <= 1'd1;
					control_watching <= 1'd1;
					control_seen_busy <= 1'd0;
					control_timer <= 1'd0;
					control_capture_outputs <= (control_enabled ? control_output_mask : 1'd0);
					control_capture_sequence <= (control_capture_sequence + 1'd1);
				end else begin
					control_command_error <= 1'd1;
				end
			end
			5'd28: begin
				if ((local_write_data < 5'd16)) begin
					control_bank <= local_write_data;
				end else begin
					control_command_error <= 1'd1;
				end
			end
			6'd32: begin
				if ((local_write_data < 13'd4096)) begin
					control_rx_address <= local_write_data;
				end else begin
					control_command_error <= 1'd1;
				end
			end
			6'd36: begin
				if ((local_write_data < 13'd4096)) begin
					control_tx_address <= local_write_data;
				end else begin
					control_command_error <= 1'd1;
				end
			end
			6'd48: begin
				if (control_reserved) begin
					control_command_error <= 1'd1;
				end
			end
			6'd52: begin
				if ((((~control_reserved) & (local_write_data > 1'd0)) & (local_write_data <= 13'd4096))) begin
					control_tx_length <= local_write_data;
				end else begin
					control_command_error <= 1'd1;
				end
			end
			6'd56: begin
				if (((control_busy0 | control_watching) | control_reserved)) begin
					control_command_error <= 1'd1;
				end
			end
			7'd64: begin
				control0 <= local_write_data;
			end
			7'd68: begin
				control1 <= local_write_data;
			end
			7'd72: begin
				control2 <= local_write_data;
			end
			7'd76: begin
				control3 <= local_write_data;
			end
			7'd112: begin
				if ((~control_busy0)) begin
					control_command_error <= 1'd0;
				end
			end
			8'd132: begin
				if ((((((((((~control_reserved) & (~control_busy0)) & (~control_watching)) & ready) & (~control_capture_fault)) & (~bank_player_pending)) & (local_write_data > 1'd0)) & (local_write_data < 3'd4)) & ((~local_write_data[1]) | (~control_enabled)))) begin
					control_capture_armed <= local_write_data[0];
					control_generator_armed <= local_write_data[1];
				end else begin
					control_command_error <= 1'd1;
				end
			end
			8'd136: begin
				if (((((local_write_data == 1'd1) & (control_capture_armed | control_generator_armed)) & (~control_trigger_pending)) & ready)) begin
					control_trigger_pending <= 1'd1;
				end else begin
					control_command_error <= 1'd1;
				end
			end
		endcase
	end
	if (control_start) begin
		control_previous0 <= bank_windowcapture0_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous0 <= bank_windowcapture0_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial0[7:0] <= control_rising0;
		end
		if ((control_stage == 1'd1)) begin
			control_partial0[15:8] <= control_rising0;
		end
	end
	if (control_start) begin
		control_previous1 <= bank_windowcapture1_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous1 <= bank_windowcapture1_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial1[7:0] <= control_rising1;
		end
		if ((control_stage == 1'd1)) begin
			control_partial1[15:8] <= control_rising1;
		end
	end
	if (control_start) begin
		control_previous2 <= bank_windowcapture2_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous2 <= bank_windowcapture2_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial2[7:0] <= control_rising2;
		end
		if ((control_stage == 1'd1)) begin
			control_partial2[15:8] <= control_rising2;
		end
	end
	if (control_start) begin
		control_previous3 <= bank_windowcapture3_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous3 <= bank_windowcapture3_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial3[7:0] <= control_rising3;
		end
		if ((control_stage == 1'd1)) begin
			control_partial3[15:8] <= control_rising3;
		end
	end
	if (control_start) begin
		control_previous4 <= bank_windowcapture4_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous4 <= bank_windowcapture4_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial4[7:0] <= control_rising4;
		end
		if ((control_stage == 1'd1)) begin
			control_partial4[15:8] <= control_rising4;
		end
	end
	if (control_start) begin
		control_previous5 <= bank_windowcapture5_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous5 <= bank_windowcapture5_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial5[7:0] <= control_rising5;
		end
		if ((control_stage == 1'd1)) begin
			control_partial5[15:8] <= control_rising5;
		end
	end
	if (control_start) begin
		control_previous6 <= bank_windowcapture6_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous6 <= bank_windowcapture6_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial6[7:0] <= control_rising6;
		end
		if ((control_stage == 1'd1)) begin
			control_partial6[15:8] <= control_rising6;
		end
	end
	if (control_start) begin
		control_previous7 <= bank_windowcapture7_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous7 <= bank_windowcapture7_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial7[7:0] <= control_rising7;
		end
		if ((control_stage == 1'd1)) begin
			control_partial7[15:8] <= control_rising7;
		end
	end
	if (control_start) begin
		control_previous8 <= bank_windowcapture8_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous8 <= bank_windowcapture8_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial8[7:0] <= control_rising8;
		end
		if ((control_stage == 1'd1)) begin
			control_partial8[15:8] <= control_rising8;
		end
	end
	if (control_start) begin
		control_previous9 <= bank_windowcapture9_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous9 <= bank_windowcapture9_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial9[7:0] <= control_rising9;
		end
		if ((control_stage == 1'd1)) begin
			control_partial9[15:8] <= control_rising9;
		end
	end
	if (control_start) begin
		control_previous10 <= bank_windowcapture10_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous10 <= bank_windowcapture10_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial10[7:0] <= control_rising10;
		end
		if ((control_stage == 1'd1)) begin
			control_partial10[15:8] <= control_rising10;
		end
	end
	if (control_start) begin
		control_previous11 <= bank_windowcapture11_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous11 <= bank_windowcapture11_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial11[7:0] <= control_rising11;
		end
		if ((control_stage == 1'd1)) begin
			control_partial11[15:8] <= control_rising11;
		end
	end
	if (control_start) begin
		control_previous12 <= bank_windowcapture12_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous12 <= bank_windowcapture12_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial12[7:0] <= control_rising12;
		end
		if ((control_stage == 1'd1)) begin
			control_partial12[15:8] <= control_rising12;
		end
	end
	if (control_start) begin
		control_previous13 <= bank_windowcapture13_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous13 <= bank_windowcapture13_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial13[7:0] <= control_rising13;
		end
		if ((control_stage == 1'd1)) begin
			control_partial13[15:8] <= control_rising13;
		end
	end
	if (control_start) begin
		control_previous14 <= bank_windowcapture14_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous14 <= bank_windowcapture14_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial14[7:0] <= control_rising14;
		end
		if ((control_stage == 1'd1)) begin
			control_partial14[15:8] <= control_rising14;
		end
	end
	if (control_start) begin
		control_previous15 <= bank_windowcapture15_previous;
	end
	if ((control_busy1 & (control_state == 2'd3))) begin
		control_previous15 <= bank_windowcapture15_read_data[7];
		if ((control_stage == 1'd0)) begin
			control_partial15[7:0] <= control_rising15;
		end
		if ((control_stage == 1'd1)) begin
			control_partial15[15:8] <= control_rising15;
		end
	end
	if ((control_start & (~control_busy1))) begin
		control_busy1 <= 1'd1;
		control_done1 <= 1'd0;
		control_count0 <= 1'd0;
		control_index <= 1'd0;
		control_stage <= 1'd0;
		control_frame <= 1'd0;
		control_state <= 1'd1;
	end
	if (control_busy1) begin
		if ((control_state == 1'd1)) begin
			control_state <= 2'd2;
		end else begin
			if ((control_state == 2'd2)) begin
				control_state <= 2'd3;
			end else begin
				if ((control_stage == 2'd2)) begin
					control_stage <= 1'd0;
					control_frame <= (control_frame + 1'd1);
					control_count0 <= (control_count0 + 1'd1);
				end else begin
					control_stage <= (control_stage + 1'd1);
				end
				if ((control_index == (control_length - 1'd1))) begin
					control_busy1 <= 1'd0;
					control_done1 <= 1'd1;
					control_state <= 1'd0;
				end else begin
					control_index <= (control_index + 1'd1);
					control_state <= 1'd1;
				end
			end
		end
	end
	if (sys_rst) begin
		bank_player_active_bank <= 1'd0;
		bank_player_length <= 13'd15;
		bank_player_pending <= 1'd0;
		bank_player_error <= 1'd0;
		bank_player_position <= 12'd0;
		bank_player_loops <= 32'd0;
		bank_player_pending_length <= 13'd0;
		bank_windowcapture0_busy <= 1'd0;
		bank_windowcapture0_done <= 1'd0;
		bank_windowcapture0_error <= 1'd0;
		bank_windowcapture0_capture_id <= 32'd0;
		bank_windowcapture0_read_valid <= 1'd0;
		bank_windowcapture0_request <= 1'd0;
		bank_windowcapture0_length_mailbox <= 13'd0;
		bank_windowcapture0_invalid <= 1'd0;
		bank_windowcapture0_settle <= 3'd0;
		bank_windowcapture1_busy <= 1'd0;
		bank_windowcapture1_done <= 1'd0;
		bank_windowcapture1_error <= 1'd0;
		bank_windowcapture1_capture_id <= 32'd0;
		bank_windowcapture1_read_valid <= 1'd0;
		bank_windowcapture1_request <= 1'd0;
		bank_windowcapture1_length_mailbox <= 13'd0;
		bank_windowcapture1_invalid <= 1'd0;
		bank_windowcapture1_settle <= 3'd0;
		bank_windowcapture2_busy <= 1'd0;
		bank_windowcapture2_done <= 1'd0;
		bank_windowcapture2_error <= 1'd0;
		bank_windowcapture2_capture_id <= 32'd0;
		bank_windowcapture2_read_valid <= 1'd0;
		bank_windowcapture2_request <= 1'd0;
		bank_windowcapture2_length_mailbox <= 13'd0;
		bank_windowcapture2_invalid <= 1'd0;
		bank_windowcapture2_settle <= 3'd0;
		bank_windowcapture3_busy <= 1'd0;
		bank_windowcapture3_done <= 1'd0;
		bank_windowcapture3_error <= 1'd0;
		bank_windowcapture3_capture_id <= 32'd0;
		bank_windowcapture3_read_valid <= 1'd0;
		bank_windowcapture3_request <= 1'd0;
		bank_windowcapture3_length_mailbox <= 13'd0;
		bank_windowcapture3_invalid <= 1'd0;
		bank_windowcapture3_settle <= 3'd0;
		bank_windowcapture4_busy <= 1'd0;
		bank_windowcapture4_done <= 1'd0;
		bank_windowcapture4_error <= 1'd0;
		bank_windowcapture4_capture_id <= 32'd0;
		bank_windowcapture4_read_valid <= 1'd0;
		bank_windowcapture4_request <= 1'd0;
		bank_windowcapture4_length_mailbox <= 13'd0;
		bank_windowcapture4_invalid <= 1'd0;
		bank_windowcapture4_settle <= 3'd0;
		bank_windowcapture5_busy <= 1'd0;
		bank_windowcapture5_done <= 1'd0;
		bank_windowcapture5_error <= 1'd0;
		bank_windowcapture5_capture_id <= 32'd0;
		bank_windowcapture5_read_valid <= 1'd0;
		bank_windowcapture5_request <= 1'd0;
		bank_windowcapture5_length_mailbox <= 13'd0;
		bank_windowcapture5_invalid <= 1'd0;
		bank_windowcapture5_settle <= 3'd0;
		bank_windowcapture6_busy <= 1'd0;
		bank_windowcapture6_done <= 1'd0;
		bank_windowcapture6_error <= 1'd0;
		bank_windowcapture6_capture_id <= 32'd0;
		bank_windowcapture6_read_valid <= 1'd0;
		bank_windowcapture6_request <= 1'd0;
		bank_windowcapture6_length_mailbox <= 13'd0;
		bank_windowcapture6_invalid <= 1'd0;
		bank_windowcapture6_settle <= 3'd0;
		bank_windowcapture7_busy <= 1'd0;
		bank_windowcapture7_done <= 1'd0;
		bank_windowcapture7_error <= 1'd0;
		bank_windowcapture7_capture_id <= 32'd0;
		bank_windowcapture7_read_valid <= 1'd0;
		bank_windowcapture7_request <= 1'd0;
		bank_windowcapture7_length_mailbox <= 13'd0;
		bank_windowcapture7_invalid <= 1'd0;
		bank_windowcapture7_settle <= 3'd0;
		bank_windowcapture8_busy <= 1'd0;
		bank_windowcapture8_done <= 1'd0;
		bank_windowcapture8_error <= 1'd0;
		bank_windowcapture8_capture_id <= 32'd0;
		bank_windowcapture8_read_valid <= 1'd0;
		bank_windowcapture8_request <= 1'd0;
		bank_windowcapture8_length_mailbox <= 13'd0;
		bank_windowcapture8_invalid <= 1'd0;
		bank_windowcapture8_settle <= 3'd0;
		bank_windowcapture9_busy <= 1'd0;
		bank_windowcapture9_done <= 1'd0;
		bank_windowcapture9_error <= 1'd0;
		bank_windowcapture9_capture_id <= 32'd0;
		bank_windowcapture9_read_valid <= 1'd0;
		bank_windowcapture9_request <= 1'd0;
		bank_windowcapture9_length_mailbox <= 13'd0;
		bank_windowcapture9_invalid <= 1'd0;
		bank_windowcapture9_settle <= 3'd0;
		bank_windowcapture10_busy <= 1'd0;
		bank_windowcapture10_done <= 1'd0;
		bank_windowcapture10_error <= 1'd0;
		bank_windowcapture10_capture_id <= 32'd0;
		bank_windowcapture10_read_valid <= 1'd0;
		bank_windowcapture10_request <= 1'd0;
		bank_windowcapture10_length_mailbox <= 13'd0;
		bank_windowcapture10_invalid <= 1'd0;
		bank_windowcapture10_settle <= 3'd0;
		bank_windowcapture11_busy <= 1'd0;
		bank_windowcapture11_done <= 1'd0;
		bank_windowcapture11_error <= 1'd0;
		bank_windowcapture11_capture_id <= 32'd0;
		bank_windowcapture11_read_valid <= 1'd0;
		bank_windowcapture11_request <= 1'd0;
		bank_windowcapture11_length_mailbox <= 13'd0;
		bank_windowcapture11_invalid <= 1'd0;
		bank_windowcapture11_settle <= 3'd0;
		bank_windowcapture12_busy <= 1'd0;
		bank_windowcapture12_done <= 1'd0;
		bank_windowcapture12_error <= 1'd0;
		bank_windowcapture12_capture_id <= 32'd0;
		bank_windowcapture12_read_valid <= 1'd0;
		bank_windowcapture12_request <= 1'd0;
		bank_windowcapture12_length_mailbox <= 13'd0;
		bank_windowcapture12_invalid <= 1'd0;
		bank_windowcapture12_settle <= 3'd0;
		bank_windowcapture13_busy <= 1'd0;
		bank_windowcapture13_done <= 1'd0;
		bank_windowcapture13_error <= 1'd0;
		bank_windowcapture13_capture_id <= 32'd0;
		bank_windowcapture13_read_valid <= 1'd0;
		bank_windowcapture13_request <= 1'd0;
		bank_windowcapture13_length_mailbox <= 13'd0;
		bank_windowcapture13_invalid <= 1'd0;
		bank_windowcapture13_settle <= 3'd0;
		bank_windowcapture14_busy <= 1'd0;
		bank_windowcapture14_done <= 1'd0;
		bank_windowcapture14_error <= 1'd0;
		bank_windowcapture14_capture_id <= 32'd0;
		bank_windowcapture14_read_valid <= 1'd0;
		bank_windowcapture14_request <= 1'd0;
		bank_windowcapture14_length_mailbox <= 13'd0;
		bank_windowcapture14_invalid <= 1'd0;
		bank_windowcapture14_settle <= 3'd0;
		bank_windowcapture15_busy <= 1'd0;
		bank_windowcapture15_done <= 1'd0;
		bank_windowcapture15_error <= 1'd0;
		bank_windowcapture15_capture_id <= 32'd0;
		bank_windowcapture15_read_valid <= 1'd0;
		bank_windowcapture15_request <= 1'd0;
		bank_windowcapture15_length_mailbox <= 13'd0;
		bank_windowcapture15_invalid <= 1'd0;
		bank_windowcapture15_settle <= 3'd0;
		serial_tx <= 1'd1;
		uart_sink_ack <= 1'd0;
		uart_uart_clk_txen <= 1'd0;
		uart_phase_accumulator_tx <= 32'd0;
		uart_tx_reg <= 8'd0;
		uart_tx_bitcount <= 4'd0;
		uart_tx_busy <= 1'd0;
		uart_source_stb <= 1'd0;
		uart_source_payload_data <= 8'd0;
		uart_uart_clk_rxen <= 1'd0;
		uart_phase_accumulator_rx <= 32'd0;
		uart_rx_r <= 1'd0;
		uart_rx_reg <= 8'd0;
		uart_rx_bitcount <= 4'd0;
		uart_rx_busy <= 1'd0;
		bus_command <= 56'd0;
		bus_reply <= 48'd0;
		bus_rx_index <= 3'd0;
		bus_tx_index <= 3'd0;
		bus_timeout <= 24'd0;
		ipbus_bridge_hold <= 4'd0;
		ipbus_bridge_previous_state <= 4'd0;
		ipbus_bridge_previous_write <= 1'd0;
		ethernet_pma_a7_gtp_basex_tx_cm_reset0 <= 1'd1;
		ethernet_pma_a7_gtp_basex_rx_cm_reset0 <= 1'd1;
		ethernet_pma_a7_gtp_basex_tx_init_qpll_reset0 <= 1'd0;
		ethernet_pma_a7_gtp_basex_tx_init_tx_reset0 <= 1'd0;
		ethernet_pma_a7_gtp_basex_tx_init_timer <= 11'd0;
		ethernet_pma_a7_gtp_basex_tx_init_tick <= 1'd0;
		ethernet_pma_a7_gtp_basex_rx_init_rx_reset0 <= 1'd0;
		ethernet_pma_a7_gtp_basex_rx_init_drpvalue <= 16'd0;
		ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done_r <= 1'd0;
		ethernet_pma_a7_gtp_basex_cdr_lock_counter <= 13'd0;
		ethernet_pma_a7_gtp_basex_cdr_locked <= 1'd0;
		control_output_mask <= 16'd0;
		control_command_error <= 1'd0;
		control_capture_fault <= 1'd0;
		control_enabled <= 1'd0;
		control_tx_address <= 12'd0;
		control_tx_length <= 13'd25;
		control0 <= 32'd0;
		control1 <= 32'd0;
		control2 <= 32'd0;
		control3 <= 32'd0;
		control_bank <= 4'd0;
		control_rx_address <= 12'd0;
		control_capture_length <= 13'd4096;
		control_arm <= 1'd0;
		control_watching <= 1'd0;
		control_seen_busy <= 1'd0;
		control_timer <= 20'd0;
		control_capture_outputs <= 16'd0;
		control_capture_sequence <= 32'd0;
		control_capture_armed <= 1'd0;
		control_generator_armed <= 1'd0;
		control_trigger_pending <= 1'd0;
		control_trigger_id <= 32'd0;
		control_capture_trigger_id <= 32'd0;
		control_cycle <= 64'd0;
		control_trigger_cycle <= 64'd0;
		control_trigger_position <= 12'd0;
		control_trigger_loop <= 32'd0;
		control_busy1 <= 1'd0;
		control_done1 <= 1'd0;
		control_count0 <= 11'd0;
		control_index <= 12'd0;
		control_stage <= 2'd0;
		control_state <= 2'd0;
		control_frame <= 11'd0;
		control_previous0 <= 1'd0;
		control_partial0 <= 16'd0;
		control_previous1 <= 1'd0;
		control_partial1 <= 16'd0;
		control_previous2 <= 1'd0;
		control_partial2 <= 16'd0;
		control_previous3 <= 1'd0;
		control_partial3 <= 16'd0;
		control_previous4 <= 1'd0;
		control_partial4 <= 16'd0;
		control_previous5 <= 1'd0;
		control_partial5 <= 16'd0;
		control_previous6 <= 1'd0;
		control_partial6 <= 16'd0;
		control_previous7 <= 1'd0;
		control_partial7 <= 16'd0;
		control_previous8 <= 1'd0;
		control_partial8 <= 16'd0;
		control_previous9 <= 1'd0;
		control_partial9 <= 16'd0;
		control_previous10 <= 1'd0;
		control_partial10 <= 16'd0;
		control_previous11 <= 1'd0;
		control_partial11 <= 16'd0;
		control_previous12 <= 1'd0;
		control_partial12 <= 16'd0;
		control_previous13 <= 1'd0;
		control_partial13 <= 16'd0;
		control_previous14 <= 1'd0;
		control_partial14 <= 16'd0;
		control_previous15 <= 1'd0;
		control_partial15 <= 16'd0;
		unsupported <= 1'd0;
		selected <= 4'd0;
		state <= 3'd0;
		gtptxinit_state <= 2'd0;
		gtprxinit_state <= 4'd0;
	end
	xilinxmultiregimpl00 <= locked1;
	xilinxmultiregimpl01 <= xilinxmultiregimpl00;
	xilinxmultiregimpl20 <= bank_windowcapture0_ack;
	xilinxmultiregimpl21 <= xilinxmultiregimpl20;
	xilinxmultiregimpl30 <= bank_windowcapture0_rx_ready;
	xilinxmultiregimpl31 <= xilinxmultiregimpl30;
	xilinxmultiregimpl50 <= bank_windowcapture0_start_rx;
	xilinxmultiregimpl51 <= xilinxmultiregimpl50;
	xilinxmultiregimpl60 <= bank_windowcapture0_previous_rx;
	xilinxmultiregimpl61 <= xilinxmultiregimpl60;
	xilinxmultiregimpl70 <= bank_windowcapture0_count_rx;
	xilinxmultiregimpl71 <= xilinxmultiregimpl70;
	xilinxmultiregimpl80 <= bank_windowcapture0_aborted_rx;
	xilinxmultiregimpl81 <= xilinxmultiregimpl80;
	xilinxmultiregimpl100 <= bank_windowcapture1_ack;
	xilinxmultiregimpl101 <= xilinxmultiregimpl100;
	xilinxmultiregimpl110 <= bank_windowcapture1_rx_ready;
	xilinxmultiregimpl111 <= xilinxmultiregimpl110;
	xilinxmultiregimpl130 <= bank_windowcapture1_start_rx;
	xilinxmultiregimpl131 <= xilinxmultiregimpl130;
	xilinxmultiregimpl140 <= bank_windowcapture1_previous_rx;
	xilinxmultiregimpl141 <= xilinxmultiregimpl140;
	xilinxmultiregimpl150 <= bank_windowcapture1_count_rx;
	xilinxmultiregimpl151 <= xilinxmultiregimpl150;
	xilinxmultiregimpl160 <= bank_windowcapture1_aborted_rx;
	xilinxmultiregimpl161 <= xilinxmultiregimpl160;
	xilinxmultiregimpl180 <= bank_windowcapture2_ack;
	xilinxmultiregimpl181 <= xilinxmultiregimpl180;
	xilinxmultiregimpl190 <= bank_windowcapture2_rx_ready;
	xilinxmultiregimpl191 <= xilinxmultiregimpl190;
	xilinxmultiregimpl210 <= bank_windowcapture2_start_rx;
	xilinxmultiregimpl211 <= xilinxmultiregimpl210;
	xilinxmultiregimpl220 <= bank_windowcapture2_previous_rx;
	xilinxmultiregimpl221 <= xilinxmultiregimpl220;
	xilinxmultiregimpl230 <= bank_windowcapture2_count_rx;
	xilinxmultiregimpl231 <= xilinxmultiregimpl230;
	xilinxmultiregimpl240 <= bank_windowcapture2_aborted_rx;
	xilinxmultiregimpl241 <= xilinxmultiregimpl240;
	xilinxmultiregimpl260 <= bank_windowcapture3_ack;
	xilinxmultiregimpl261 <= xilinxmultiregimpl260;
	xilinxmultiregimpl270 <= bank_windowcapture3_rx_ready;
	xilinxmultiregimpl271 <= xilinxmultiregimpl270;
	xilinxmultiregimpl290 <= bank_windowcapture3_start_rx;
	xilinxmultiregimpl291 <= xilinxmultiregimpl290;
	xilinxmultiregimpl300 <= bank_windowcapture3_previous_rx;
	xilinxmultiregimpl301 <= xilinxmultiregimpl300;
	xilinxmultiregimpl310 <= bank_windowcapture3_count_rx;
	xilinxmultiregimpl311 <= xilinxmultiregimpl310;
	xilinxmultiregimpl320 <= bank_windowcapture3_aborted_rx;
	xilinxmultiregimpl321 <= xilinxmultiregimpl320;
	xilinxmultiregimpl340 <= bank_windowcapture4_ack;
	xilinxmultiregimpl341 <= xilinxmultiregimpl340;
	xilinxmultiregimpl350 <= bank_windowcapture4_rx_ready;
	xilinxmultiregimpl351 <= xilinxmultiregimpl350;
	xilinxmultiregimpl370 <= bank_windowcapture4_start_rx;
	xilinxmultiregimpl371 <= xilinxmultiregimpl370;
	xilinxmultiregimpl380 <= bank_windowcapture4_previous_rx;
	xilinxmultiregimpl381 <= xilinxmultiregimpl380;
	xilinxmultiregimpl390 <= bank_windowcapture4_count_rx;
	xilinxmultiregimpl391 <= xilinxmultiregimpl390;
	xilinxmultiregimpl400 <= bank_windowcapture4_aborted_rx;
	xilinxmultiregimpl401 <= xilinxmultiregimpl400;
	xilinxmultiregimpl420 <= bank_windowcapture5_ack;
	xilinxmultiregimpl421 <= xilinxmultiregimpl420;
	xilinxmultiregimpl430 <= bank_windowcapture5_rx_ready;
	xilinxmultiregimpl431 <= xilinxmultiregimpl430;
	xilinxmultiregimpl450 <= bank_windowcapture5_start_rx;
	xilinxmultiregimpl451 <= xilinxmultiregimpl450;
	xilinxmultiregimpl460 <= bank_windowcapture5_previous_rx;
	xilinxmultiregimpl461 <= xilinxmultiregimpl460;
	xilinxmultiregimpl470 <= bank_windowcapture5_count_rx;
	xilinxmultiregimpl471 <= xilinxmultiregimpl470;
	xilinxmultiregimpl480 <= bank_windowcapture5_aborted_rx;
	xilinxmultiregimpl481 <= xilinxmultiregimpl480;
	xilinxmultiregimpl500 <= bank_windowcapture6_ack;
	xilinxmultiregimpl501 <= xilinxmultiregimpl500;
	xilinxmultiregimpl510 <= bank_windowcapture6_rx_ready;
	xilinxmultiregimpl511 <= xilinxmultiregimpl510;
	xilinxmultiregimpl530 <= bank_windowcapture6_start_rx;
	xilinxmultiregimpl531 <= xilinxmultiregimpl530;
	xilinxmultiregimpl540 <= bank_windowcapture6_previous_rx;
	xilinxmultiregimpl541 <= xilinxmultiregimpl540;
	xilinxmultiregimpl550 <= bank_windowcapture6_count_rx;
	xilinxmultiregimpl551 <= xilinxmultiregimpl550;
	xilinxmultiregimpl560 <= bank_windowcapture6_aborted_rx;
	xilinxmultiregimpl561 <= xilinxmultiregimpl560;
	xilinxmultiregimpl580 <= bank_windowcapture7_ack;
	xilinxmultiregimpl581 <= xilinxmultiregimpl580;
	xilinxmultiregimpl590 <= bank_windowcapture7_rx_ready;
	xilinxmultiregimpl591 <= xilinxmultiregimpl590;
	xilinxmultiregimpl610 <= bank_windowcapture7_start_rx;
	xilinxmultiregimpl611 <= xilinxmultiregimpl610;
	xilinxmultiregimpl620 <= bank_windowcapture7_previous_rx;
	xilinxmultiregimpl621 <= xilinxmultiregimpl620;
	xilinxmultiregimpl630 <= bank_windowcapture7_count_rx;
	xilinxmultiregimpl631 <= xilinxmultiregimpl630;
	xilinxmultiregimpl640 <= bank_windowcapture7_aborted_rx;
	xilinxmultiregimpl641 <= xilinxmultiregimpl640;
	xilinxmultiregimpl660 <= bank_windowcapture8_ack;
	xilinxmultiregimpl661 <= xilinxmultiregimpl660;
	xilinxmultiregimpl670 <= bank_windowcapture8_rx_ready;
	xilinxmultiregimpl671 <= xilinxmultiregimpl670;
	xilinxmultiregimpl690 <= bank_windowcapture8_start_rx;
	xilinxmultiregimpl691 <= xilinxmultiregimpl690;
	xilinxmultiregimpl700 <= bank_windowcapture8_previous_rx;
	xilinxmultiregimpl701 <= xilinxmultiregimpl700;
	xilinxmultiregimpl710 <= bank_windowcapture8_count_rx;
	xilinxmultiregimpl711 <= xilinxmultiregimpl710;
	xilinxmultiregimpl720 <= bank_windowcapture8_aborted_rx;
	xilinxmultiregimpl721 <= xilinxmultiregimpl720;
	xilinxmultiregimpl740 <= bank_windowcapture9_ack;
	xilinxmultiregimpl741 <= xilinxmultiregimpl740;
	xilinxmultiregimpl750 <= bank_windowcapture9_rx_ready;
	xilinxmultiregimpl751 <= xilinxmultiregimpl750;
	xilinxmultiregimpl770 <= bank_windowcapture9_start_rx;
	xilinxmultiregimpl771 <= xilinxmultiregimpl770;
	xilinxmultiregimpl780 <= bank_windowcapture9_previous_rx;
	xilinxmultiregimpl781 <= xilinxmultiregimpl780;
	xilinxmultiregimpl790 <= bank_windowcapture9_count_rx;
	xilinxmultiregimpl791 <= xilinxmultiregimpl790;
	xilinxmultiregimpl800 <= bank_windowcapture9_aborted_rx;
	xilinxmultiregimpl801 <= xilinxmultiregimpl800;
	xilinxmultiregimpl820 <= bank_windowcapture10_ack;
	xilinxmultiregimpl821 <= xilinxmultiregimpl820;
	xilinxmultiregimpl830 <= bank_windowcapture10_rx_ready;
	xilinxmultiregimpl831 <= xilinxmultiregimpl830;
	xilinxmultiregimpl850 <= bank_windowcapture10_start_rx;
	xilinxmultiregimpl851 <= xilinxmultiregimpl850;
	xilinxmultiregimpl860 <= bank_windowcapture10_previous_rx;
	xilinxmultiregimpl861 <= xilinxmultiregimpl860;
	xilinxmultiregimpl870 <= bank_windowcapture10_count_rx;
	xilinxmultiregimpl871 <= xilinxmultiregimpl870;
	xilinxmultiregimpl880 <= bank_windowcapture10_aborted_rx;
	xilinxmultiregimpl881 <= xilinxmultiregimpl880;
	xilinxmultiregimpl900 <= bank_windowcapture11_ack;
	xilinxmultiregimpl901 <= xilinxmultiregimpl900;
	xilinxmultiregimpl910 <= bank_windowcapture11_rx_ready;
	xilinxmultiregimpl911 <= xilinxmultiregimpl910;
	xilinxmultiregimpl930 <= bank_windowcapture11_start_rx;
	xilinxmultiregimpl931 <= xilinxmultiregimpl930;
	xilinxmultiregimpl940 <= bank_windowcapture11_previous_rx;
	xilinxmultiregimpl941 <= xilinxmultiregimpl940;
	xilinxmultiregimpl950 <= bank_windowcapture11_count_rx;
	xilinxmultiregimpl951 <= xilinxmultiregimpl950;
	xilinxmultiregimpl960 <= bank_windowcapture11_aborted_rx;
	xilinxmultiregimpl961 <= xilinxmultiregimpl960;
	xilinxmultiregimpl980 <= bank_windowcapture12_ack;
	xilinxmultiregimpl981 <= xilinxmultiregimpl980;
	xilinxmultiregimpl990 <= bank_windowcapture12_rx_ready;
	xilinxmultiregimpl991 <= xilinxmultiregimpl990;
	xilinxmultiregimpl1010 <= bank_windowcapture12_start_rx;
	xilinxmultiregimpl1011 <= xilinxmultiregimpl1010;
	xilinxmultiregimpl1020 <= bank_windowcapture12_previous_rx;
	xilinxmultiregimpl1021 <= xilinxmultiregimpl1020;
	xilinxmultiregimpl1030 <= bank_windowcapture12_count_rx;
	xilinxmultiregimpl1031 <= xilinxmultiregimpl1030;
	xilinxmultiregimpl1040 <= bank_windowcapture12_aborted_rx;
	xilinxmultiregimpl1041 <= xilinxmultiregimpl1040;
	xilinxmultiregimpl1060 <= bank_windowcapture13_ack;
	xilinxmultiregimpl1061 <= xilinxmultiregimpl1060;
	xilinxmultiregimpl1070 <= bank_windowcapture13_rx_ready;
	xilinxmultiregimpl1071 <= xilinxmultiregimpl1070;
	xilinxmultiregimpl1090 <= bank_windowcapture13_start_rx;
	xilinxmultiregimpl1091 <= xilinxmultiregimpl1090;
	xilinxmultiregimpl1100 <= bank_windowcapture13_previous_rx;
	xilinxmultiregimpl1101 <= xilinxmultiregimpl1100;
	xilinxmultiregimpl1110 <= bank_windowcapture13_count_rx;
	xilinxmultiregimpl1111 <= xilinxmultiregimpl1110;
	xilinxmultiregimpl1120 <= bank_windowcapture13_aborted_rx;
	xilinxmultiregimpl1121 <= xilinxmultiregimpl1120;
	xilinxmultiregimpl1140 <= bank_windowcapture14_ack;
	xilinxmultiregimpl1141 <= xilinxmultiregimpl1140;
	xilinxmultiregimpl1150 <= bank_windowcapture14_rx_ready;
	xilinxmultiregimpl1151 <= xilinxmultiregimpl1150;
	xilinxmultiregimpl1170 <= bank_windowcapture14_start_rx;
	xilinxmultiregimpl1171 <= xilinxmultiregimpl1170;
	xilinxmultiregimpl1180 <= bank_windowcapture14_previous_rx;
	xilinxmultiregimpl1181 <= xilinxmultiregimpl1180;
	xilinxmultiregimpl1190 <= bank_windowcapture14_count_rx;
	xilinxmultiregimpl1191 <= xilinxmultiregimpl1190;
	xilinxmultiregimpl1200 <= bank_windowcapture14_aborted_rx;
	xilinxmultiregimpl1201 <= xilinxmultiregimpl1200;
	xilinxmultiregimpl1220 <= bank_windowcapture15_ack;
	xilinxmultiregimpl1221 <= xilinxmultiregimpl1220;
	xilinxmultiregimpl1230 <= bank_windowcapture15_rx_ready;
	xilinxmultiregimpl1231 <= xilinxmultiregimpl1230;
	xilinxmultiregimpl1250 <= bank_windowcapture15_start_rx;
	xilinxmultiregimpl1251 <= xilinxmultiregimpl1250;
	xilinxmultiregimpl1260 <= bank_windowcapture15_previous_rx;
	xilinxmultiregimpl1261 <= xilinxmultiregimpl1260;
	xilinxmultiregimpl1270 <= bank_windowcapture15_count_rx;
	xilinxmultiregimpl1271 <= xilinxmultiregimpl1270;
	xilinxmultiregimpl1280 <= bank_windowcapture15_aborted_rx;
	xilinxmultiregimpl1281 <= xilinxmultiregimpl1280;
	xilinxmultiregimpl1290 <= serial_rx;
	xilinxmultiregimpl1291 <= xilinxmultiregimpl1290;
	xilinxmultiregimpl1360 <= ethernet_pma_a7_gtp_basex_tx_init_qpll_lock0;
	xilinxmultiregimpl1361 <= xilinxmultiregimpl1360;
	xilinxmultiregimpl1370 <= ethernet_pma_a7_gtp_basex_rx_init_rx_pma_reset_done0;
	xilinxmultiregimpl1371 <= xilinxmultiregimpl1370;
	xilinxmultiregimpl1380 <= ethernet_pma_a7_gtp_basex_toggle_i;
	xilinxmultiregimpl1381 <= xilinxmultiregimpl1380;
	xilinxmultiregimpl1460 <= ethernet_link_up;
	xilinxmultiregimpl1461 <= xilinxmultiregimpl1460;
	xilinxmultiregimpl1470 <= ethernet_got;
	xilinxmultiregimpl1471 <= xilinxmultiregimpl1470;
end

IBUFDS IBUFDS(
	.I(mcx_clkin_p),
	.IB(mcx_clkin_n),
	.O(reference)
);

BUFG BUFG(
	.I(reference),
	.O(buffered)
);

BUFG BUFG_1(
	.I(ipword),
	.O(ipbus_clk)
);

MMCME2_BASE #(
	.CLKFBOUT_MULT_F(8.0),
	.CLKIN1_PERIOD(8.333333333333334),
	.CLKOUT0_DIVIDE_F(2.0),
	.CLKOUT1_DIVIDE(4'd8),
	.CLKOUT2_DIVIDE(5'd24),
	.DIVCLK_DIVIDE(1'd1)
) gate_mmcm_sys (
	.CLKFBIN(fb0),
	.CLKIN1(buffered),
	.PWRDWN(1'd0),
	.RST(1'd0),
	.CLKFBOUT(feedback0),
	.CLKOUT0(fast0),
	.CLKOUT1(word0),
	.CLKOUT2(ipword),
	.LOCKED(locked0)
);

BUFG BUFG_2(
	.I(feedback0),
	.O(fb0)
);

BUFG BUFG_3(
	.I(word0),
	.O(sys_clk)
);

MMCME2_BASE #(
	.CLKFBOUT_MULT_F(8.0),
	.CLKIN1_PERIOD(8.333333333333334),
	.CLKOUT0_DIVIDE_F(2.0),
	.CLKOUT1_DIVIDE(4'd8),
	.DIVCLK_DIVIDE(1'd1)
) gate_mmcm_rx (
	.CLKFBIN(fb1),
	.CLKIN1(buffered),
	.PWRDWN(1'd0),
	.RST(1'd0),
	.CLKFBOUT(feedback1),
	.CLKOUT0(fast1),
	.CLKOUT1(word1),
	.LOCKED(locked1)
);

BUFG BUFG_4(
	.I(feedback1),
	.O(fb1)
);

BUFG BUFG_5(
	.I(word1),
	.O(sample_clk)
);

BUFG BUFG_6(
	.I(fast1),
	.O(ser_rx_clk)
);

reg [127:0] memory[0:8191];
reg [127:0] memdat;
reg [127:0] memdat_1;
always @(posedge sys_clk) begin : mem_write_block
	if (bank_player_write_port_we)
		memory[bank_player_write_port_adr] <= bank_player_write_port_dat_w;
	memdat <= memory[bank_player_write_port_adr];
end

always @(posedge sys_clk) begin : mem_write_block_1
	memdat_1 <= memory[bank_player_read_port_adr];
end

assign bank_player_write_port_dat_r = memdat;
assign bank_player_read_port_dat_r = memdat_1;

reg [7:0] memory_1[0:4095];
reg [7:0] memdat_2;
reg [7:0] memdat_3;
always @(posedge sample_clk) begin : mem_write_block_2
	if (bank_windowcapture0_wp_we)
		memory_1[bank_windowcapture0_wp_adr] <= bank_windowcapture0_wp_dat_w;
	memdat_2 <= memory_1[bank_windowcapture0_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_3
	memdat_3 <= memory_1[bank_windowcapture0_rp_adr];
end

assign bank_windowcapture0_wp_dat_r = memdat_2;
assign bank_windowcapture0_rp_dat_r = memdat_3;

reg [7:0] memory_2[0:4095];
reg [7:0] memdat_4;
reg [7:0] memdat_5;
always @(posedge sample_clk) begin : mem_write_block_4
	if (bank_windowcapture1_wp_we)
		memory_2[bank_windowcapture1_wp_adr] <= bank_windowcapture1_wp_dat_w;
	memdat_4 <= memory_2[bank_windowcapture1_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_5
	memdat_5 <= memory_2[bank_windowcapture1_rp_adr];
end

assign bank_windowcapture1_wp_dat_r = memdat_4;
assign bank_windowcapture1_rp_dat_r = memdat_5;

reg [7:0] memory_3[0:4095];
reg [7:0] memdat_6;
reg [7:0] memdat_7;
always @(posedge sample_clk) begin : mem_write_block_6
	if (bank_windowcapture2_wp_we)
		memory_3[bank_windowcapture2_wp_adr] <= bank_windowcapture2_wp_dat_w;
	memdat_6 <= memory_3[bank_windowcapture2_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_7
	memdat_7 <= memory_3[bank_windowcapture2_rp_adr];
end

assign bank_windowcapture2_wp_dat_r = memdat_6;
assign bank_windowcapture2_rp_dat_r = memdat_7;

reg [7:0] memory_4[0:4095];
reg [7:0] memdat_8;
reg [7:0] memdat_9;
always @(posedge sample_clk) begin : mem_write_block_8
	if (bank_windowcapture3_wp_we)
		memory_4[bank_windowcapture3_wp_adr] <= bank_windowcapture3_wp_dat_w;
	memdat_8 <= memory_4[bank_windowcapture3_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_9
	memdat_9 <= memory_4[bank_windowcapture3_rp_adr];
end

assign bank_windowcapture3_wp_dat_r = memdat_8;
assign bank_windowcapture3_rp_dat_r = memdat_9;

reg [7:0] memory_5[0:4095];
reg [7:0] memdat_10;
reg [7:0] memdat_11;
always @(posedge sample_clk) begin : mem_write_block_10
	if (bank_windowcapture4_wp_we)
		memory_5[bank_windowcapture4_wp_adr] <= bank_windowcapture4_wp_dat_w;
	memdat_10 <= memory_5[bank_windowcapture4_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_11
	memdat_11 <= memory_5[bank_windowcapture4_rp_adr];
end

assign bank_windowcapture4_wp_dat_r = memdat_10;
assign bank_windowcapture4_rp_dat_r = memdat_11;

reg [7:0] memory_6[0:4095];
reg [7:0] memdat_12;
reg [7:0] memdat_13;
always @(posedge sample_clk) begin : mem_write_block_12
	if (bank_windowcapture5_wp_we)
		memory_6[bank_windowcapture5_wp_adr] <= bank_windowcapture5_wp_dat_w;
	memdat_12 <= memory_6[bank_windowcapture5_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_13
	memdat_13 <= memory_6[bank_windowcapture5_rp_adr];
end

assign bank_windowcapture5_wp_dat_r = memdat_12;
assign bank_windowcapture5_rp_dat_r = memdat_13;

reg [7:0] memory_7[0:4095];
reg [7:0] memdat_14;
reg [7:0] memdat_15;
always @(posedge sample_clk) begin : mem_write_block_14
	if (bank_windowcapture6_wp_we)
		memory_7[bank_windowcapture6_wp_adr] <= bank_windowcapture6_wp_dat_w;
	memdat_14 <= memory_7[bank_windowcapture6_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_15
	memdat_15 <= memory_7[bank_windowcapture6_rp_adr];
end

assign bank_windowcapture6_wp_dat_r = memdat_14;
assign bank_windowcapture6_rp_dat_r = memdat_15;

reg [7:0] memory_8[0:4095];
reg [7:0] memdat_16;
reg [7:0] memdat_17;
always @(posedge sample_clk) begin : mem_write_block_16
	if (bank_windowcapture7_wp_we)
		memory_8[bank_windowcapture7_wp_adr] <= bank_windowcapture7_wp_dat_w;
	memdat_16 <= memory_8[bank_windowcapture7_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_17
	memdat_17 <= memory_8[bank_windowcapture7_rp_adr];
end

assign bank_windowcapture7_wp_dat_r = memdat_16;
assign bank_windowcapture7_rp_dat_r = memdat_17;

reg [7:0] memory_9[0:4095];
reg [7:0] memdat_18;
reg [7:0] memdat_19;
always @(posedge sample_clk) begin : mem_write_block_18
	if (bank_windowcapture8_wp_we)
		memory_9[bank_windowcapture8_wp_adr] <= bank_windowcapture8_wp_dat_w;
	memdat_18 <= memory_9[bank_windowcapture8_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_19
	memdat_19 <= memory_9[bank_windowcapture8_rp_adr];
end

assign bank_windowcapture8_wp_dat_r = memdat_18;
assign bank_windowcapture8_rp_dat_r = memdat_19;

reg [7:0] memory_10[0:4095];
reg [7:0] memdat_20;
reg [7:0] memdat_21;
always @(posedge sample_clk) begin : mem_write_block_20
	if (bank_windowcapture9_wp_we)
		memory_10[bank_windowcapture9_wp_adr] <= bank_windowcapture9_wp_dat_w;
	memdat_20 <= memory_10[bank_windowcapture9_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_21
	memdat_21 <= memory_10[bank_windowcapture9_rp_adr];
end

assign bank_windowcapture9_wp_dat_r = memdat_20;
assign bank_windowcapture9_rp_dat_r = memdat_21;

reg [7:0] memory_11[0:4095];
reg [7:0] memdat_22;
reg [7:0] memdat_23;
always @(posedge sample_clk) begin : mem_write_block_22
	if (bank_windowcapture10_wp_we)
		memory_11[bank_windowcapture10_wp_adr] <= bank_windowcapture10_wp_dat_w;
	memdat_22 <= memory_11[bank_windowcapture10_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_23
	memdat_23 <= memory_11[bank_windowcapture10_rp_adr];
end

assign bank_windowcapture10_wp_dat_r = memdat_22;
assign bank_windowcapture10_rp_dat_r = memdat_23;

reg [7:0] memory_12[0:4095];
reg [7:0] memdat_24;
reg [7:0] memdat_25;
always @(posedge sample_clk) begin : mem_write_block_24
	if (bank_windowcapture11_wp_we)
		memory_12[bank_windowcapture11_wp_adr] <= bank_windowcapture11_wp_dat_w;
	memdat_24 <= memory_12[bank_windowcapture11_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_25
	memdat_25 <= memory_12[bank_windowcapture11_rp_adr];
end

assign bank_windowcapture11_wp_dat_r = memdat_24;
assign bank_windowcapture11_rp_dat_r = memdat_25;

reg [7:0] memory_13[0:4095];
reg [7:0] memdat_26;
reg [7:0] memdat_27;
always @(posedge sample_clk) begin : mem_write_block_26
	if (bank_windowcapture12_wp_we)
		memory_13[bank_windowcapture12_wp_adr] <= bank_windowcapture12_wp_dat_w;
	memdat_26 <= memory_13[bank_windowcapture12_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_27
	memdat_27 <= memory_13[bank_windowcapture12_rp_adr];
end

assign bank_windowcapture12_wp_dat_r = memdat_26;
assign bank_windowcapture12_rp_dat_r = memdat_27;

reg [7:0] memory_14[0:4095];
reg [7:0] memdat_28;
reg [7:0] memdat_29;
always @(posedge sample_clk) begin : mem_write_block_28
	if (bank_windowcapture13_wp_we)
		memory_14[bank_windowcapture13_wp_adr] <= bank_windowcapture13_wp_dat_w;
	memdat_28 <= memory_14[bank_windowcapture13_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_29
	memdat_29 <= memory_14[bank_windowcapture13_rp_adr];
end

assign bank_windowcapture13_wp_dat_r = memdat_28;
assign bank_windowcapture13_rp_dat_r = memdat_29;

reg [7:0] memory_15[0:4095];
reg [7:0] memdat_30;
reg [7:0] memdat_31;
always @(posedge sample_clk) begin : mem_write_block_30
	if (bank_windowcapture14_wp_we)
		memory_15[bank_windowcapture14_wp_adr] <= bank_windowcapture14_wp_dat_w;
	memdat_30 <= memory_15[bank_windowcapture14_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_31
	memdat_31 <= memory_15[bank_windowcapture14_rp_adr];
end

assign bank_windowcapture14_wp_dat_r = memdat_30;
assign bank_windowcapture14_rp_dat_r = memdat_31;

reg [7:0] memory_16[0:4095];
reg [7:0] memdat_32;
reg [7:0] memdat_33;
always @(posedge sample_clk) begin : mem_write_block_32
	if (bank_windowcapture15_wp_we)
		memory_16[bank_windowcapture15_wp_adr] <= bank_windowcapture15_wp_dat_w;
	memdat_32 <= memory_16[bank_windowcapture15_wp_adr];
end

always @(posedge sys_clk) begin : mem_write_block_33
	memdat_33 <= memory_16[bank_windowcapture15_rp_adr];
end

assign bank_windowcapture15_wp_dat_r = memdat_32;
assign bank_windowcapture15_rp_dat_r = memdat_33;

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_1 (
	.I(gate_lvds_p),
	.IB(gate_lvds_n),
	.O(inp0)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp0),
	.RST(sample_rst),
	.Q1(word2[7]),
	.Q2(word2[6]),
	.Q3(word2[5]),
	.Q4(word2[4]),
	.Q5(word2[3]),
	.Q6(word2[2]),
	.Q7(word2[1]),
	.Q8(word2[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_2 (
	.I(gate_lvds_p_1),
	.IB(gate_lvds_n_1),
	.O(inp1)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_1 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp1),
	.RST(sample_rst),
	.Q1(word3[7]),
	.Q2(word3[6]),
	.Q3(word3[5]),
	.Q4(word3[4]),
	.Q5(word3[3]),
	.Q6(word3[2]),
	.Q7(word3[1]),
	.Q8(word3[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_3 (
	.I(gate_lvds_p_2),
	.IB(gate_lvds_n_2),
	.O(inp2)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_2 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp2),
	.RST(sample_rst),
	.Q1(word4[7]),
	.Q2(word4[6]),
	.Q3(word4[5]),
	.Q4(word4[4]),
	.Q5(word4[3]),
	.Q6(word4[2]),
	.Q7(word4[1]),
	.Q8(word4[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_4 (
	.I(gate_lvds_p_3),
	.IB(gate_lvds_n_3),
	.O(inp3)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_3 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp3),
	.RST(sample_rst),
	.Q1(word5[7]),
	.Q2(word5[6]),
	.Q3(word5[5]),
	.Q4(word5[4]),
	.Q5(word5[3]),
	.Q6(word5[2]),
	.Q7(word5[1]),
	.Q8(word5[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_5 (
	.I(gate_lvds_p_4),
	.IB(gate_lvds_n_4),
	.O(inp4)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_4 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp4),
	.RST(sample_rst),
	.Q1(word6[7]),
	.Q2(word6[6]),
	.Q3(word6[5]),
	.Q4(word6[4]),
	.Q5(word6[3]),
	.Q6(word6[2]),
	.Q7(word6[1]),
	.Q8(word6[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_6 (
	.I(gate_lvds_p_5),
	.IB(gate_lvds_n_5),
	.O(inp5)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_5 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp5),
	.RST(sample_rst),
	.Q1(word7[7]),
	.Q2(word7[6]),
	.Q3(word7[5]),
	.Q4(word7[4]),
	.Q5(word7[3]),
	.Q6(word7[2]),
	.Q7(word7[1]),
	.Q8(word7[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_7 (
	.I(gate_lvds_p_6),
	.IB(gate_lvds_n_6),
	.O(inp6)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_6 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp6),
	.RST(sample_rst),
	.Q1(word8[7]),
	.Q2(word8[6]),
	.Q3(word8[5]),
	.Q4(word8[4]),
	.Q5(word8[3]),
	.Q6(word8[2]),
	.Q7(word8[1]),
	.Q8(word8[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_8 (
	.I(gate_lvds_p_7),
	.IB(gate_lvds_n_7),
	.O(inp7)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_7 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp7),
	.RST(sample_rst),
	.Q1(word9[7]),
	.Q2(word9[6]),
	.Q3(word9[5]),
	.Q4(word9[4]),
	.Q5(word9[3]),
	.Q6(word9[2]),
	.Q7(word9[1]),
	.Q8(word9[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_9 (
	.I(gate_lvds_p_8),
	.IB(gate_lvds_n_8),
	.O(inp8)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_8 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp8),
	.RST(sample_rst),
	.Q1(word10[7]),
	.Q2(word10[6]),
	.Q3(word10[5]),
	.Q4(word10[4]),
	.Q5(word10[3]),
	.Q6(word10[2]),
	.Q7(word10[1]),
	.Q8(word10[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_10 (
	.I(gate_lvds_p_9),
	.IB(gate_lvds_n_9),
	.O(inp9)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_9 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp9),
	.RST(sample_rst),
	.Q1(word11[7]),
	.Q2(word11[6]),
	.Q3(word11[5]),
	.Q4(word11[4]),
	.Q5(word11[3]),
	.Q6(word11[2]),
	.Q7(word11[1]),
	.Q8(word11[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_11 (
	.I(gate_lvds_p_10),
	.IB(gate_lvds_n_10),
	.O(inp10)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_10 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp10),
	.RST(sample_rst),
	.Q1(word12[7]),
	.Q2(word12[6]),
	.Q3(word12[5]),
	.Q4(word12[4]),
	.Q5(word12[3]),
	.Q6(word12[2]),
	.Q7(word12[1]),
	.Q8(word12[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_12 (
	.I(gate_lvds_p_11),
	.IB(gate_lvds_n_11),
	.O(inp11)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_11 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp11),
	.RST(sample_rst),
	.Q1(word13[7]),
	.Q2(word13[6]),
	.Q3(word13[5]),
	.Q4(word13[4]),
	.Q5(word13[3]),
	.Q6(word13[2]),
	.Q7(word13[1]),
	.Q8(word13[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_13 (
	.I(gate_lvds_p_12),
	.IB(gate_lvds_n_12),
	.O(inp12)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_12 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp12),
	.RST(sample_rst),
	.Q1(word14[7]),
	.Q2(word14[6]),
	.Q3(word14[5]),
	.Q4(word14[4]),
	.Q5(word14[3]),
	.Q6(word14[2]),
	.Q7(word14[1]),
	.Q8(word14[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_14 (
	.I(gate_lvds_p_13),
	.IB(gate_lvds_n_13),
	.O(inp13)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_13 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp13),
	.RST(sample_rst),
	.Q1(word15[7]),
	.Q2(word15[6]),
	.Q3(word15[5]),
	.Q4(word15[4]),
	.Q5(word15[3]),
	.Q6(word15[2]),
	.Q7(word15[1]),
	.Q8(word15[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_15 (
	.I(gate_lvds_p_14),
	.IB(gate_lvds_n_14),
	.O(inp14)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_14 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp14),
	.RST(sample_rst),
	.Q1(word16[7]),
	.Q2(word16[6]),
	.Q3(word16[5]),
	.Q4(word16[4]),
	.Q5(word16[3]),
	.Q6(word16[2]),
	.Q7(word16[1]),
	.Q8(word16[0])
);

IBUFDS #(
	.DIFF_TERM("TRUE"),
	.IBUF_LOW_PWR("FALSE")
) IBUFDS_16 (
	.I(gate_lvds_p_15),
	.IB(gate_lvds_n_15),
	.O(inp15)
);

ISERDESE2 #(
	.DATA_RATE("DDR"),
	.DATA_WIDTH(4'd8),
	.INTERFACE_TYPE("NETWORKING"),
	.NUM_CE(1'd1)
) ISERDESE2_15 (
	.BITSLIP(1'd0),
	.CE1(1'd1),
	.CE2(1'd1),
	.CLK(ser_rx_clk),
	.CLKB((~ser_rx_clk)),
	.CLKDIV(sample_clk),
	.D(inp15),
	.RST(sample_rst),
	.Q1(word17[7]),
	.Q2(word17[6]),
	.Q3(word17[5]),
	.Q4(word17[4]),
	.Q5(word17[3]),
	.Q6(word17[2]),
	.Q7(word17[1]),
	.Q8(word17[0])
);

IBUFDS_GTE2 IBUFDS_GTE2(
	.CEB(1'd0),
	.I(clk125_gtp_p),
	.IB(clk125_gtp_n),
	.O(ethernet_ref)
);

GTPE2_COMMON #(
	.PLL0_FBDIV(3'd4),
	.PLL0_FBDIV_45(3'd5),
	.PLL0_REFCLK_DIV(1'd1)
) GTPE2_COMMON (
	.BGBYPASSB(1'd1),
	.BGMONITORENB(1'd1),
	.BGPDB(1'd1),
	.BGRCALOVRD(5'd31),
	.GTREFCLK0(ethernet_ref),
	.GTREFCLK1(1'd0),
	.PLL0LOCKEN(1'd1),
	.PLL0PD(1'd0),
	.PLL0REFCLKSEL(1'd1),
	.PLL0RESET(ethernet_reset),
	.PLL1PD(1'd1),
	.RCALENB(1'd1),
	.PLL0LOCK(ethernet_lock),
	.PLL0OUTCLK(ethernet_clk),
	.PLL0OUTREFCLK(ethernet_refclk)
);

reg [4:0] mem_6b5b[0:63];
reg [5:0] memadr;
always @(posedge eth_rx_clk) begin : mem_write_block_34
	if (ethernet_pcsrx_decoder_re)
		memadr <= ethernet_pcsrx_decoder_adr;
end

assign ethernet_pcsrx_decoder_dat_r = mem_6b5b[memadr];

initial begin
	$readmemh("mem_6b5b.init", mem_6b5b);
end

BUFG BUFG_7(
	.I(ethernet_pma_a7_gtp_basex_txoutclk),
	.O(ethernet_pma_a7_gtp_basex_txoutclk_rebuffer)
);

BUFG BUFG_8(
	.I(ethernet_pma_a7_gtp_basex_rxoutclk),
	.O(ethernet_pma_a7_gtp_basex_rxoutclk_rebuffer)
);

BUFH BUFH(
	.I(ethernet_pma_a7_gtp_basex_s7pll0_clkout0),
	.O(ethernet_pma_a7_gtp_basex_s7pll0_clkout_buf0)
);

BUFH BUFH_1(
	.I(ethernet_pma_a7_gtp_basex_s7pll0_clkout1),
	.O(ethernet_pma_a7_gtp_basex_s7pll0_clkout_buf1)
);

BUFG BUFG_9(
	.I(ethernet_pma_a7_gtp_basex_s7pll1_clkout0),
	.O(ethernet_pma_a7_gtp_basex_s7pll1_clkout_buf0)
);

BUFG BUFG_10(
	.I(ethernet_pma_a7_gtp_basex_s7pll1_clkout1),
	.O(ethernet_pma_a7_gtp_basex_s7pll1_clkout_buf1)
);

reg [11:0] storage[0:31];
reg [4:0] memadr_1;
reg [4:0] memadr_2;
always @(posedge eth_tx_clk) begin : mem_write_block_35
	if (ethernet_txdatapath_cdc_wrport_we)
		storage[ethernet_txdatapath_cdc_wrport_adr] <= ethernet_txdatapath_cdc_wrport_dat_w;
	memadr_1 <= ethernet_txdatapath_cdc_wrport_adr;
end

always @(posedge eth_tx_clk) begin : mem_write_block_36
	memadr_2 <= ethernet_txdatapath_cdc_rdport_adr;
end

assign ethernet_txdatapath_cdc_wrport_dat_r = storage[memadr_1];
assign ethernet_txdatapath_cdc_rdport_dat_r = storage[memadr_2];

reg [11:0] storage_1[0:2047];
reg [11:0] memdat_34;
reg [11:0] memdat_35;
always @(posedge eth_tx_clk) begin : mem_write_block_37
	if (ethernet_tx_packet_fifo_payload_fifo_wrport_we)
		storage_1[ethernet_tx_packet_fifo_payload_fifo_wrport_adr] <= ethernet_tx_packet_fifo_payload_fifo_wrport_dat_w;
	memdat_34 <= storage_1[ethernet_tx_packet_fifo_payload_fifo_wrport_adr];
end

always @(posedge eth_tx_clk) begin : mem_write_block_38
	if (ethernet_tx_packet_fifo_payload_fifo_rdport_re)
		memdat_35 <= storage_1[ethernet_tx_packet_fifo_payload_fifo_rdport_adr];
end

assign ethernet_tx_packet_fifo_payload_fifo_wrport_dat_r = memdat_34;
assign ethernet_tx_packet_fifo_payload_fifo_rdport_dat_r = memdat_35;

reg [2:0] storage_2[0:4];
reg [2:0] memdat_36;
reg [2:0] memdat_37;
always @(posedge eth_tx_clk) begin : mem_write_block_39
	if (ethernet_tx_packet_fifo_param_fifo_wrport_we)
		storage_2[ethernet_tx_packet_fifo_param_fifo_wrport_adr] <= ethernet_tx_packet_fifo_param_fifo_wrport_dat_w;
	memdat_36 <= storage_2[ethernet_tx_packet_fifo_param_fifo_wrport_adr];
end

always @(posedge eth_tx_clk) begin : mem_write_block_40
	if (ethernet_tx_packet_fifo_param_fifo_rdport_re)
		memdat_37 <= storage_2[ethernet_tx_packet_fifo_param_fifo_rdport_adr];
end

assign ethernet_tx_packet_fifo_param_fifo_wrport_dat_r = memdat_36;
assign ethernet_tx_packet_fifo_param_fifo_rdport_dat_r = memdat_37;

reg [2:0] storage_3[0:3];
reg [2:0] memdat_38;
always @(posedge eth_rx_clk) begin : mem_write_block_41
	if (ethernet_rx_packet_fifo_param_fifo_wrport_we)
		storage_3[ethernet_rx_packet_fifo_param_fifo_wrport_adr] <= ethernet_rx_packet_fifo_param_fifo_wrport_dat_w;
	memdat_38 <= storage_3[ethernet_rx_packet_fifo_param_fifo_wrport_adr];
end

always @(posedge eth_rx_clk) begin : mem_write_block_42
end

assign ethernet_rx_packet_fifo_param_fifo_wrport_dat_r = memdat_38;
assign ethernet_rx_packet_fifo_param_fifo_rdport_dat_r = storage_3[ethernet_rx_packet_fifo_param_fifo_rdport_adr];

reg [11:0] mem[0:2047];
reg [10:0] memadr_3;
reg [10:0] memadr_4;
always @(posedge eth_rx_clk) begin : mem_write_block_43
	if (ethernet_rx_packet_fifo_wr_port_we)
		mem[ethernet_rx_packet_fifo_wr_port_adr] <= ethernet_rx_packet_fifo_wr_port_dat_w;
	memadr_3 <= ethernet_rx_packet_fifo_wr_port_adr;
end

always @(posedge eth_rx_clk) begin : mem_write_block_44
	if (ethernet_rx_packet_fifo_rd_port_re)
		memadr_4 <= ethernet_rx_packet_fifo_rd_port_adr;
end

assign ethernet_rx_packet_fifo_wr_port_dat_r = mem[memadr_3];
assign ethernet_rx_packet_fifo_rd_port_dat_r = mem[memadr_4];

reg [11:0] storage_4[0:31];
reg [4:0] memadr_5;
reg [4:0] memadr_6;
always @(posedge eth_rx_clk) begin : mem_write_block_45
	if (ethernet_rx_cdc_cdc_wrport_we)
		storage_4[ethernet_rx_cdc_cdc_wrport_adr] <= ethernet_rx_cdc_cdc_wrport_dat_w;
	memadr_5 <= ethernet_rx_cdc_cdc_wrport_adr;
end

always @(posedge eth_tx_clk) begin : mem_write_block_46
	memadr_6 <= ethernet_rx_cdc_cdc_rdport_adr;
end

assign ethernet_rx_cdc_cdc_wrport_dat_r = storage_4[memadr_5];
assign ethernet_rx_cdc_cdc_rdport_dat_r = storage_4[memadr_6];

reg [11:0] storage_5[0:4];
reg [11:0] memdat_39;
always @(posedge eth_tx_clk) begin : mem_write_block_47
	if (ethernet_liteethmaccrc32checker_syncfifo_wrport_we)
		storage_5[ethernet_liteethmaccrc32checker_syncfifo_wrport_adr] <= ethernet_liteethmaccrc32checker_syncfifo_wrport_dat_w;
	memdat_39 <= storage_5[ethernet_liteethmaccrc32checker_syncfifo_wrport_adr];
end

always @(posedge eth_tx_clk) begin : mem_write_block_48
end

assign ethernet_liteethmaccrc32checker_syncfifo_wrport_dat_r = memdat_39;
assign ethernet_liteethmaccrc32checker_syncfifo_rdport_dat_r = storage_5[ethernet_liteethmaccrc32checker_syncfifo_rdport_adr];

rng_ipbus_endpoint rng_ipbus_endpoint(
	.ip_addr(32'd3232236273),
	.ipb_ack(ipbus_bridge_ack),
	.ipb_clk(ipbus_clk),
	.ipb_err(ipbus_bridge_err),
	.ipb_rdata(ipbus_bridge_rdata),
	.mac_addr(42'd2199023260162),
	.mac_clk(eth_tx_clk),
	.mac_rx_data(ethernet_source_payload_data),
	.mac_rx_error((ethernet_source_payload_error & ethernet_source_valid)),
	.mac_rx_last((ethernet_source_last & ethernet_source_valid)),
	.mac_rx_valid(ethernet_source_valid),
	.mac_tx_ready(ethernet_sink_ready),
	.rst_ipb(ipbus_rst),
	.rst_macclk(eth_tx_rst),
	.got_ip(ethernet_got),
	.ipb_addr(ipbus_bridge_address0),
	.ipb_strobe(ipbus_bridge_strobe),
	.ipb_wdata(ipbus_bridge_wdata),
	.ipb_write(ipbus_bridge_write),
	.mac_tx_data(ethernet_sink_payload_data),
	.mac_tx_error(ethernet_sink_payload_error),
	.mac_tx_last(ethernet_sink_last),
	.mac_tx_valid(ethernet_sink_valid)
);

reg [31:0] memory_17[0:1364];
reg [31:0] memdat_40;
reg [31:0] memdat_41;
always @(posedge sys_clk) begin : mem_write_block_49
	if (control_wp_memory0_we)
		memory_17[control_wp_memory0_adr] <= control_wp_memory0_dat_w;
	memdat_40 <= memory_17[control_wp_memory0_adr];
end

always @(posedge sys_clk) begin : mem_write_block_50
	memdat_41 <= memory_17[control_rp_memory0_adr];
end

assign control_wp_memory0_dat_r = memdat_40;
assign control_rp_memory0_dat_r = memdat_41;

reg [31:0] memory_18[0:1364];
reg [31:0] memdat_42;
reg [31:0] memdat_43;
always @(posedge sys_clk) begin : mem_write_block_51
	if (control_wp_memory1_we)
		memory_18[control_wp_memory1_adr] <= control_wp_memory1_dat_w;
	memdat_42 <= memory_18[control_wp_memory1_adr];
end

always @(posedge sys_clk) begin : mem_write_block_52
	memdat_43 <= memory_18[control_rp_memory1_adr];
end

assign control_wp_memory1_dat_r = memdat_42;
assign control_rp_memory1_dat_r = memdat_43;

reg [31:0] memory_19[0:1364];
reg [31:0] memdat_44;
reg [31:0] memdat_45;
always @(posedge sys_clk) begin : mem_write_block_53
	if (control_wp_memory2_we)
		memory_19[control_wp_memory2_adr] <= control_wp_memory2_dat_w;
	memdat_44 <= memory_19[control_wp_memory2_adr];
end

always @(posedge sys_clk) begin : mem_write_block_54
	memdat_45 <= memory_19[control_rp_memory2_adr];
end

assign control_wp_memory2_dat_r = memdat_44;
assign control_rp_memory2_dat_r = memdat_45;

reg [31:0] memory_20[0:1364];
reg [31:0] memdat_46;
reg [31:0] memdat_47;
always @(posedge sys_clk) begin : mem_write_block_55
	if (control_wp_memory3_we)
		memory_20[control_wp_memory3_adr] <= control_wp_memory3_dat_w;
	memdat_46 <= memory_20[control_wp_memory3_adr];
end

always @(posedge sys_clk) begin : mem_write_block_56
	memdat_47 <= memory_20[control_rp_memory3_adr];
end

assign control_wp_memory3_dat_r = memdat_46;
assign control_rp_memory3_dat_r = memdat_47;

reg [31:0] memory_21[0:1364];
reg [31:0] memdat_48;
reg [31:0] memdat_49;
always @(posedge sys_clk) begin : mem_write_block_57
	if (control_wp_memory4_we)
		memory_21[control_wp_memory4_adr] <= control_wp_memory4_dat_w;
	memdat_48 <= memory_21[control_wp_memory4_adr];
end

always @(posedge sys_clk) begin : mem_write_block_58
	memdat_49 <= memory_21[control_rp_memory4_adr];
end

assign control_wp_memory4_dat_r = memdat_48;
assign control_rp_memory4_dat_r = memdat_49;

reg [31:0] memory_22[0:1364];
reg [31:0] memdat_50;
reg [31:0] memdat_51;
always @(posedge sys_clk) begin : mem_write_block_59
	if (control_wp_memory5_we)
		memory_22[control_wp_memory5_adr] <= control_wp_memory5_dat_w;
	memdat_50 <= memory_22[control_wp_memory5_adr];
end

always @(posedge sys_clk) begin : mem_write_block_60
	memdat_51 <= memory_22[control_rp_memory5_adr];
end

assign control_wp_memory5_dat_r = memdat_50;
assign control_rp_memory5_dat_r = memdat_51;

reg [31:0] memory_23[0:1364];
reg [31:0] memdat_52;
reg [31:0] memdat_53;
always @(posedge sys_clk) begin : mem_write_block_61
	if (control_wp_memory6_we)
		memory_23[control_wp_memory6_adr] <= control_wp_memory6_dat_w;
	memdat_52 <= memory_23[control_wp_memory6_adr];
end

always @(posedge sys_clk) begin : mem_write_block_62
	memdat_53 <= memory_23[control_rp_memory6_adr];
end

assign control_wp_memory6_dat_r = memdat_52;
assign control_rp_memory6_dat_r = memdat_53;

reg [31:0] memory_24[0:1364];
reg [31:0] memdat_54;
reg [31:0] memdat_55;
always @(posedge sys_clk) begin : mem_write_block_63
	if (control_wp_memory7_we)
		memory_24[control_wp_memory7_adr] <= control_wp_memory7_dat_w;
	memdat_54 <= memory_24[control_wp_memory7_adr];
end

always @(posedge sys_clk) begin : mem_write_block_64
	memdat_55 <= memory_24[control_rp_memory7_adr];
end

assign control_wp_memory7_dat_r = memdat_54;
assign control_rp_memory7_dat_r = memdat_55;

reg [31:0] memory_25[0:1364];
reg [31:0] memdat_56;
reg [31:0] memdat_57;
always @(posedge sys_clk) begin : mem_write_block_65
	if (control_wp_memory8_we)
		memory_25[control_wp_memory8_adr] <= control_wp_memory8_dat_w;
	memdat_56 <= memory_25[control_wp_memory8_adr];
end

always @(posedge sys_clk) begin : mem_write_block_66
	memdat_57 <= memory_25[control_rp_memory8_adr];
end

assign control_wp_memory8_dat_r = memdat_56;
assign control_rp_memory8_dat_r = memdat_57;

reg [31:0] memory_26[0:1364];
reg [31:0] memdat_58;
reg [31:0] memdat_59;
always @(posedge sys_clk) begin : mem_write_block_67
	if (control_wp_memory9_we)
		memory_26[control_wp_memory9_adr] <= control_wp_memory9_dat_w;
	memdat_58 <= memory_26[control_wp_memory9_adr];
end

always @(posedge sys_clk) begin : mem_write_block_68
	memdat_59 <= memory_26[control_rp_memory9_adr];
end

assign control_wp_memory9_dat_r = memdat_58;
assign control_rp_memory9_dat_r = memdat_59;

reg [31:0] memory_27[0:1364];
reg [31:0] memdat_60;
reg [31:0] memdat_61;
always @(posedge sys_clk) begin : mem_write_block_69
	if (control_wp_memory10_we)
		memory_27[control_wp_memory10_adr] <= control_wp_memory10_dat_w;
	memdat_60 <= memory_27[control_wp_memory10_adr];
end

always @(posedge sys_clk) begin : mem_write_block_70
	memdat_61 <= memory_27[control_rp_memory10_adr];
end

assign control_wp_memory10_dat_r = memdat_60;
assign control_rp_memory10_dat_r = memdat_61;

reg [31:0] memory_28[0:1364];
reg [31:0] memdat_62;
reg [31:0] memdat_63;
always @(posedge sys_clk) begin : mem_write_block_71
	if (control_wp_memory11_we)
		memory_28[control_wp_memory11_adr] <= control_wp_memory11_dat_w;
	memdat_62 <= memory_28[control_wp_memory11_adr];
end

always @(posedge sys_clk) begin : mem_write_block_72
	memdat_63 <= memory_28[control_rp_memory11_adr];
end

assign control_wp_memory11_dat_r = memdat_62;
assign control_rp_memory11_dat_r = memdat_63;

reg [31:0] memory_29[0:1364];
reg [31:0] memdat_64;
reg [31:0] memdat_65;
always @(posedge sys_clk) begin : mem_write_block_73
	if (control_wp_memory12_we)
		memory_29[control_wp_memory12_adr] <= control_wp_memory12_dat_w;
	memdat_64 <= memory_29[control_wp_memory12_adr];
end

always @(posedge sys_clk) begin : mem_write_block_74
	memdat_65 <= memory_29[control_rp_memory12_adr];
end

assign control_wp_memory12_dat_r = memdat_64;
assign control_rp_memory12_dat_r = memdat_65;

reg [31:0] memory_30[0:1364];
reg [31:0] memdat_66;
reg [31:0] memdat_67;
always @(posedge sys_clk) begin : mem_write_block_75
	if (control_wp_memory13_we)
		memory_30[control_wp_memory13_adr] <= control_wp_memory13_dat_w;
	memdat_66 <= memory_30[control_wp_memory13_adr];
end

always @(posedge sys_clk) begin : mem_write_block_76
	memdat_67 <= memory_30[control_rp_memory13_adr];
end

assign control_wp_memory13_dat_r = memdat_66;
assign control_rp_memory13_dat_r = memdat_67;

reg [31:0] memory_31[0:1364];
reg [31:0] memdat_68;
reg [31:0] memdat_69;
always @(posedge sys_clk) begin : mem_write_block_77
	if (control_wp_memory14_we)
		memory_31[control_wp_memory14_adr] <= control_wp_memory14_dat_w;
	memdat_68 <= memory_31[control_wp_memory14_adr];
end

always @(posedge sys_clk) begin : mem_write_block_78
	memdat_69 <= memory_31[control_rp_memory14_adr];
end

assign control_wp_memory14_dat_r = memdat_68;
assign control_rp_memory14_dat_r = memdat_69;

reg [31:0] memory_32[0:1364];
reg [31:0] memdat_70;
reg [31:0] memdat_71;
always @(posedge sys_clk) begin : mem_write_block_79
	if (control_wp_memory15_we)
		memory_32[control_wp_memory15_adr] <= control_wp_memory15_dat_w;
	memdat_70 <= memory_32[control_wp_memory15_adr];
end

always @(posedge sys_clk) begin : mem_write_block_80
	memdat_71 <= memory_32[control_rp_memory15_adr];
end

assign control_wp_memory15_dat_r = memdat_70;
assign control_rp_memory15_dat_r = memdat_71;

FDCE FDCE(
	.C(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(ethernet_pma_a7_gtp_basex_tx_cm_reset1),
	.Q(s7pll0_reset0)
);

FDCE FDCE_1(
	.C(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll0_reset0),
	.Q(s7pll0_reset1)
);

FDCE FDCE_2(
	.C(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll0_reset1),
	.Q(s7pll0_reset2)
);

FDCE FDCE_3(
	.C(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll0_reset2),
	.Q(s7pll0_reset3)
);

FDCE FDCE_4(
	.C(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll0_reset3),
	.Q(s7pll0_reset4)
);

FDCE FDCE_5(
	.C(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll0_reset4),
	.Q(s7pll0_reset5)
);

FDCE FDCE_6(
	.C(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll0_reset5),
	.Q(s7pll0_reset6)
);

FDCE FDCE_7(
	.C(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll0_reset6),
	.Q(s7pll0_reset7)
);

PLLE2_ADV #(
	.CLKFBOUT_MULT(5'd24),
	.CLKIN1_PERIOD(16.0),
	.CLKOUT0_DIVIDE(5'd24),
	.CLKOUT0_PHASE(1'd0),
	.CLKOUT1_DIVIDE(4'd12),
	.CLKOUT1_PHASE(1'd0),
	.DIVCLK_DIVIDE(1'd1),
	.REF_JITTER1(0.01),
	.STARTUP_WAIT("FALSE")
) PLLE2_ADV (
	.CLKFBIN(s7pll0_pll_fb),
	.CLKIN1(ethernet_pma_a7_gtp_basex_s7pll0_clkin_signal),
	.PWRDWN(ethernet_pma_a7_gtp_basex_tx_cm_power_down),
	.RST(s7pll0_reset7),
	.CLKFBOUT(s7pll0_pll_fb),
	.CLKOUT0(ethernet_pma_a7_gtp_basex_s7pll0_clkout0),
	.CLKOUT1(ethernet_pma_a7_gtp_basex_s7pll0_clkout1),
	.LOCKED(ethernet_pma_a7_gtp_basex_tx_cm_locked1)
);

FDCE FDCE_8(
	.C(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(ethernet_pma_a7_gtp_basex_rx_cm_reset1),
	.Q(s7pll1_reset0)
);

FDCE FDCE_9(
	.C(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll1_reset0),
	.Q(s7pll1_reset1)
);

FDCE FDCE_10(
	.C(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll1_reset1),
	.Q(s7pll1_reset2)
);

FDCE FDCE_11(
	.C(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll1_reset2),
	.Q(s7pll1_reset3)
);

FDCE FDCE_12(
	.C(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll1_reset3),
	.Q(s7pll1_reset4)
);

FDCE FDCE_13(
	.C(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll1_reset4),
	.Q(s7pll1_reset5)
);

FDCE FDCE_14(
	.C(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll1_reset5),
	.Q(s7pll1_reset6)
);

FDCE FDCE_15(
	.C(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.CE(1'd1),
	.CLR(1'd0),
	.D(s7pll1_reset6),
	.Q(s7pll1_reset7)
);

PLLE2_ADV #(
	.CLKFBOUT_MULT(5'd24),
	.CLKIN1_PERIOD(16.0),
	.CLKOUT0_DIVIDE(5'd24),
	.CLKOUT0_PHASE(1'd0),
	.CLKOUT1_DIVIDE(4'd12),
	.CLKOUT1_PHASE(1'd0),
	.DIVCLK_DIVIDE(1'd1),
	.REF_JITTER1(0.01),
	.STARTUP_WAIT("FALSE")
) PLLE2_ADV_1 (
	.CLKFBIN(s7pll1_pll_fb),
	.CLKIN1(ethernet_pma_a7_gtp_basex_s7pll1_clkin_signal),
	.PWRDWN(ethernet_pma_a7_gtp_basex_rx_cm_power_down),
	.RST(s7pll1_reset7),
	.CLKFBOUT(s7pll1_pll_fb),
	.CLKOUT0(ethernet_pma_a7_gtp_basex_s7pll1_clkout0),
	.CLKOUT1(ethernet_pma_a7_gtp_basex_s7pll1_clkout1),
	.LOCKED(ethernet_pma_a7_gtp_basex_rx_cm_locked1)
);

GTPE2_CHANNEL #(
	.ACJTAG_DEBUG_MODE(1'd0),
	.ACJTAG_MODE(1'd0),
	.ACJTAG_RESET(1'd0),
	.ADAPT_CFG0(1'd0),
	.ALIGN_COMMA_DOUBLE("FALSE"),
	.ALIGN_COMMA_ENABLE(10'd1023),
	.ALIGN_COMMA_WORD(2'd2),
	.ALIGN_MCOMMA_DET("TRUE"),
	.ALIGN_MCOMMA_VALUE(10'd643),
	.ALIGN_PCOMMA_DET("TRUE"),
	.ALIGN_PCOMMA_VALUE(9'd380),
	.CBCC_DATA_SOURCE_SEL("ENCODED"),
	.CFOK_CFG(43'd5016522067584),
	.CFOK_CFG2(6'd32),
	.CFOK_CFG3(6'd32),
	.CFOK_CFG4(1'd0),
	.CFOK_CFG5(1'd0),
	.CFOK_CFG6(1'd0),
	.CHAN_BOND_KEEP_ALIGN("FALSE"),
	.CHAN_BOND_MAX_SKEW(1'd1),
	.CHAN_BOND_SEQ_1_1(1'd0),
	.CHAN_BOND_SEQ_1_2(1'd0),
	.CHAN_BOND_SEQ_1_3(1'd0),
	.CHAN_BOND_SEQ_1_4(1'd0),
	.CHAN_BOND_SEQ_1_ENABLE(4'd15),
	.CHAN_BOND_SEQ_2_1(1'd0),
	.CHAN_BOND_SEQ_2_2(1'd0),
	.CHAN_BOND_SEQ_2_3(1'd0),
	.CHAN_BOND_SEQ_2_4(1'd0),
	.CHAN_BOND_SEQ_2_ENABLE(4'd15),
	.CHAN_BOND_SEQ_2_USE("FALSE"),
	.CHAN_BOND_SEQ_LEN(1'd1),
	.CLK_COMMON_SWING(1'd0),
	.CLK_CORRECT_USE("FALSE"),
	.CLK_COR_KEEP_IDLE("FALSE"),
	.CLK_COR_MAX_LAT(4'd9),
	.CLK_COR_MIN_LAT(3'd7),
	.CLK_COR_PRECEDENCE("TRUE"),
	.CLK_COR_REPEAT_WAIT(1'd0),
	.CLK_COR_SEQ_1_1(9'd256),
	.CLK_COR_SEQ_1_2(1'd0),
	.CLK_COR_SEQ_1_3(1'd0),
	.CLK_COR_SEQ_1_4(1'd0),
	.CLK_COR_SEQ_1_ENABLE(4'd15),
	.CLK_COR_SEQ_2_1(9'd256),
	.CLK_COR_SEQ_2_2(1'd0),
	.CLK_COR_SEQ_2_3(1'd0),
	.CLK_COR_SEQ_2_4(1'd0),
	.CLK_COR_SEQ_2_ENABLE(4'd15),
	.CLK_COR_SEQ_2_USE("FALSE"),
	.CLK_COR_SEQ_LEN(1'd1),
	.DEC_MCOMMA_DETECT("FALSE"),
	.DEC_PCOMMA_DETECT("FALSE"),
	.DEC_VALID_COMMA_ONLY("FALSE"),
	.DMONITOR_CFG(12'd2560),
	.ES_CLK_PHASE_SEL(1'd0),
	.ES_CONTROL(1'd0),
	.ES_ERRDET_EN("FALSE"),
	.ES_EYE_SCAN_EN("FALSE"),
	.ES_HORZ_OFFSET(5'd16),
	.ES_PMA_CFG(1'd0),
	.ES_PRESCALE(1'd0),
	.ES_QUALIFIER(1'd0),
	.ES_QUAL_MASK(1'd0),
	.ES_SDATA_MASK(1'd0),
	.ES_VERT_OFFSET(1'd0),
	.FTS_DESKEW_SEQ_ENABLE(4'd15),
	.FTS_LANE_DESKEW_CFG(4'd15),
	.FTS_LANE_DESKEW_EN("FALSE"),
	.GEARBOX_MODE(1'd0),
	.LOOPBACK_CFG(1'd0),
	.OUTREFCLK_SEL_INV(2'd3),
	.PCS_PCIE_EN("FALSE"),
	.PCS_RSVD_ATTR(1'd0),
	.PD_TRANS_TIME_FROM_P2(6'd60),
	.PD_TRANS_TIME_NONE_P2(6'd60),
	.PD_TRANS_TIME_TO_P2(7'd100),
	.PMA_LOOPBACK_CFG(1'd0),
	.PMA_RSV(10'd819),
	.PMA_RSV2(14'd8256),
	.PMA_RSV3(1'd0),
	.PMA_RSV4(1'd0),
	.PMA_RSV5(1'd0),
	.PMA_RSV6(1'd0),
	.PMA_RSV7(1'd0),
	.RXBUFRESET_TIME(1'd1),
	.RXBUF_ADDR_MODE("FAST"),
	.RXBUF_EIDLE_HI_CNT(4'd8),
	.RXBUF_EIDLE_LO_CNT(1'd0),
	.RXBUF_EN("TRUE"),
	.RXBUF_RESET_ON_CB_CHANGE("TRUE"),
	.RXBUF_RESET_ON_COMMAALIGN("FALSE"),
	.RXBUF_RESET_ON_EIDLE("FALSE"),
	.RXBUF_RESET_ON_RATE_CHANGE("TRUE"),
	.RXBUF_THRESH_OVFLW(6'd61),
	.RXBUF_THRESH_OVRD("FALSE"),
	.RXBUF_THRESH_UNDFLW(3'd4),
	.RXCDRFREQRESET_TIME(1'd1),
	.RXCDRPHRESET_TIME(1'd1),
	.RXCDR_CFG(65'd19022659880579502096),
	.RXCDR_FR_RESET_ON_EIDLE(1'd0),
	.RXCDR_HOLD_DURING_EIDLE(1'd0),
	.RXCDR_LOCK_CFG(4'd9),
	.RXCDR_PH_RESET_ON_EIDLE(1'd0),
	.RXDLY_CFG(5'd31),
	.RXDLY_LCFG(6'd48),
	.RXDLY_TAP_CFG(1'd0),
	.RXGEARBOX_EN("FALSE"),
	.RXISCANRESET_TIME(1'd1),
	.RXLPMRESET_TIME(4'd15),
	.RXLPM_BIAS_STARTUP_DISABLE(1'd0),
	.RXLPM_CFG(3'd6),
	.RXLPM_CFG1(1'd0),
	.RXLPM_CM_CFG(1'd0),
	.RXLPM_GC_CFG(9'd482),
	.RXLPM_GC_CFG2(1'd1),
	.RXLPM_HF_CFG(10'd1008),
	.RXLPM_HF_CFG2(4'd10),
	.RXLPM_HF_CFG3(1'd0),
	.RXLPM_HOLD_DURING_EIDLE(1'd0),
	.RXLPM_INCM_CFG(1'd0),
	.RXLPM_IPCM_CFG(1'd1),
	.RXLPM_LF_CFG(10'd1008),
	.RXLPM_LF_CFG2(4'd10),
	.RXLPM_OSINT_CFG(3'd4),
	.RXOOB_CFG(3'd6),
	.RXOOB_CLK_CFG("PMA"),
	.RXOSCALRESET_TIME(2'd3),
	.RXOSCALRESET_TIMEOUT(1'd0),
	.RXOUT_DIV(3'd4),
	.RXPCSRESET_TIME(1'd1),
	.RXPHDLY_CFG(20'd540704),
	.RXPH_CFG(24'd12582914),
	.RXPH_MONITOR_SEL(1'd0),
	.RXPI_CFG0(1'd0),
	.RXPI_CFG1(1'd1),
	.RXPI_CFG2(1'd1),
	.RXPMARESET_TIME(2'd3),
	.RXPRBS_ERR_LOOPBACK(1'd0),
	.RXSLIDE_AUTO_WAIT(3'd7),
	.RXSLIDE_MODE("OFF"),
	.RXSYNC_MULTILANE(1'd0),
	.RXSYNC_OVRD(1'd0),
	.RXSYNC_SKIP_DA(1'd0),
	.RX_BIAS_CFG(12'd3891),
	.RX_BUFFER_CFG(1'd0),
	.RX_CLK25_DIV(3'd5),
	.RX_CLKMUX_EN(1'd1),
	.RX_CM_SEL(1'd1),
	.RX_CM_TRIM(1'd0),
	.RX_DATA_WIDTH(5'd20),
	.RX_DDI_SEL(1'd0),
	.RX_DEBUG_CFG(1'd0),
	.RX_DEFER_RESET_BUF_EN("TRUE"),
	.RX_DISPERR_SEQ_MATCH("FALSE"),
	.RX_OS_CFG(8'd128),
	.RX_SIG_VALID_DLY(4'd10),
	.RX_XCLK_SEL("RXREC"),
	.SAS_MAX_COM(7'd64),
	.SAS_MIN_COM(6'd36),
	.SATA_BURST_SEQ_LEN(3'd5),
	.SATA_BURST_VAL(3'd4),
	.SATA_EIDLE_VAL(3'd4),
	.SATA_MAX_BURST(4'd8),
	.SATA_MAX_INIT(5'd21),
	.SATA_MAX_WAKE(3'd7),
	.SATA_MIN_BURST(3'd4),
	.SATA_MIN_INIT(4'd12),
	.SATA_MIN_WAKE(3'd4),
	.SATA_PLL_CFG("VCO_3000MHZ"),
	.SHOW_REALIGN_COMMA("TRUE"),
	.SIM_RECEIVER_DETECT_PASS("TRUE"),
	.SIM_RESET_SPEEDUP("FALSE"),
	.SIM_TX_EIDLE_DRIVE_LEVEL("X"),
	.SIM_VERSION("2.0"),
	.TERM_RCAL_CFG(15'd16912),
	.TERM_RCAL_OVRD(1'd0),
	.TRANS_TIME_RATE(4'd14),
	.TST_RSV(1'd0),
	.TXBUF_EN("TRUE"),
	.TXBUF_RESET_ON_RATE_CHANGE("TRUE"),
	.TXDLY_CFG(5'd31),
	.TXDLY_LCFG(6'd48),
	.TXDLY_TAP_CFG(1'd0),
	.TXGEARBOX_EN("FALSE"),
	.TXOOB_CFG(1'd0),
	.TXOUT_DIV(3'd4),
	.TXPCSRESET_TIME(1'd1),
	.TXPHDLY_CFG(20'd540704),
	.TXPH_CFG(11'd1920),
	.TXPH_MONITOR_SEL(1'd0),
	.TXPI_CFG0(1'd0),
	.TXPI_CFG1(1'd0),
	.TXPI_CFG2(1'd0),
	.TXPI_CFG3(1'd0),
	.TXPI_CFG4(1'd0),
	.TXPI_CFG5(1'd0),
	.TXPI_GREY_SEL(1'd0),
	.TXPI_INVSTROBE_SEL(1'd0),
	.TXPI_PPMCLK_SEL("TXUSRCLK2"),
	.TXPI_PPM_CFG(1'd0),
	.TXPI_SYNFREQ_PPM(1'd1),
	.TXPMARESET_TIME(1'd1),
	.TXSYNC_MULTILANE(1'd0),
	.TXSYNC_OVRD(1'd0),
	.TXSYNC_SKIP_DA(1'd0),
	.TX_CLK25_DIV(3'd5),
	.TX_CLKMUX_EN(1'd1),
	.TX_DATA_WIDTH(5'd20),
	.TX_DEEMPH0(1'd0),
	.TX_DEEMPH1(1'd0),
	.TX_DRIVE_MODE("DIRECT"),
	.TX_EIDLE_ASSERT_DELAY(3'd6),
	.TX_EIDLE_DEASSERT_DELAY(3'd4),
	.TX_LOOPBACK_DRIVE_HIZ("FALSE"),
	.TX_MAINCURSOR_SEL(1'd0),
	.TX_MARGIN_FULL_0(7'd78),
	.TX_MARGIN_FULL_1(7'd73),
	.TX_MARGIN_FULL_2(7'd69),
	.TX_MARGIN_FULL_3(7'd66),
	.TX_MARGIN_FULL_4(7'd64),
	.TX_MARGIN_LOW_0(7'd70),
	.TX_MARGIN_LOW_1(7'd68),
	.TX_MARGIN_LOW_2(7'd66),
	.TX_MARGIN_LOW_3(7'd64),
	.TX_MARGIN_LOW_4(7'd64),
	.TX_PREDRIVER_MODE(1'd0),
	.TX_RXDETECT_CFG(13'd6194),
	.TX_RXDETECT_REF(3'd4),
	.TX_XCLK_SEL("TXOUT"),
	.UCODEER_CLR(1'd0),
	.USE_PCS_CLK_PHASE_SEL(1'd0)
) GTPE2_CHANNEL (
	.CFGRESET(1'd0),
	.CLKRSVD0(1'd0),
	.CLKRSVD1(1'd0),
	.DMONFIFORESET(1'd0),
	.DMONITORCLK(1'd0),
	.DRPADDR(ethernet_pma_a7_gtp_basex_drpaddr),
	.DRPCLK(sys_clk),
	.DRPDI(ethernet_pma_a7_gtp_basex_drpdi),
	.DRPEN(ethernet_pma_a7_gtp_basex_drpen),
	.DRPWE(ethernet_pma_a7_gtp_basex_drpwe),
	.EYESCANMODE(1'd0),
	.EYESCANRESET(1'd0),
	.EYESCANTRIGGER(1'd0),
	.GTPRXN(sfp_rxn),
	.GTPRXP(sfp_rxp),
	.GTRESETSEL(1'd0),
	.GTRSVD(1'd0),
	.GTRXRESET(ethernet_pma_a7_gtp_basex_rx_reset),
	.GTTXRESET(ethernet_pma_a7_gtp_basex_tx_reset),
	.LOOPBACK(1'd0),
	.PCSRSVDIN(1'd0),
	.PLL0CLK(ethernet_clk),
	.PLL0REFCLK(ethernet_refclk),
	.PLL1CLK(1'd0),
	.PLL1REFCLK(1'd0),
	.PMARSVDIN0(1'd0),
	.PMARSVDIN1(1'd0),
	.PMARSVDIN2(1'd0),
	.PMARSVDIN3(1'd0),
	.PMARSVDIN4(1'd0),
	.RESETOVRD(1'd0),
	.RX8B10BEN(1'd0),
	.RXADAPTSELTEST(1'd0),
	.RXBUFRESET(1'd0),
	.RXCDRFREQRESET(1'd0),
	.RXCDRHOLD(1'd0),
	.RXCDROVRDEN(1'd0),
	.RXCDRRESET(1'd0),
	.RXCDRRESETRSV(1'd0),
	.RXCHBONDEN(1'd0),
	.RXCHBONDI(1'd0),
	.RXCHBONDLEVEL(1'd0),
	.RXCHBONDMASTER(1'd0),
	.RXCHBONDSLAVE(1'd0),
	.RXCOMMADETEN(1'd1),
	.RXDDIEN(1'd0),
	.RXDFEXYDEN(1'd0),
	.RXDLYBYPASS(1'd1),
	.RXDLYEN(1'd0),
	.RXDLYOVRDEN(1'd0),
	.RXDLYSRESET(1'd0),
	.RXELECIDLEMODE(2'd3),
	.RXGEARBOXSLIP(1'd0),
	.RXLPMHFHOLD(1'd0),
	.RXLPMHFOVRDEN(1'd0),
	.RXLPMLFHOLD(1'd0),
	.RXLPMLFOVRDEN(1'd0),
	.RXLPMOSINTNTRLEN(1'd0),
	.RXLPMRESET(1'd0),
	.RXMCOMMAALIGNEN(ethernet_pma_a7_gtp_basex_align),
	.RXOOBRESET(1'd0),
	.RXOSCALRESET(1'd0),
	.RXOSHOLD(1'd0),
	.RXOSINTCFG(2'd2),
	.RXOSINTEN(1'd1),
	.RXOSINTHOLD(1'd0),
	.RXOSINTID0(1'd0),
	.RXOSINTNTRLEN(1'd0),
	.RXOSINTOVRDEN(1'd0),
	.RXOSINTPD(1'd0),
	.RXOSINTSTROBE(1'd0),
	.RXOSINTTESTOVRDEN(1'd0),
	.RXOSOVRDEN(1'd0),
	.RXOUTCLKSEL(2'd2),
	.RXPCOMMAALIGNEN(ethernet_pma_a7_gtp_basex_align),
	.RXPCSRESET(1'd0),
	.RXPD(1'd0),
	.RXPHALIGN(1'd0),
	.RXPHALIGNEN(1'd0),
	.RXPHDLYPD(1'd0),
	.RXPHDLYRESET(1'd0),
	.RXPHOVRDEN(1'd0),
	.RXPMARESET(1'd0),
	.RXPOLARITY(1'd0),
	.RXPRBSCNTRESET(1'd0),
	.RXPRBSSEL(1'd0),
	.RXRATE(1'd0),
	.RXRATEMODE(1'd0),
	.RXSLIDE(1'd0),
	.RXSYNCALLIN(1'd0),
	.RXSYNCIN(1'd0),
	.RXSYNCMODE(1'd0),
	.RXSYSCLKSEL(1'd0),
	.RXUSERRDY(ethernet_pma_a7_gtp_basex_rx_cm_locked0),
	.RXUSRCLK(eth_rx_half_clk),
	.RXUSRCLK2(eth_rx_half_clk),
	.SETERRSTATUS(1'd0),
	.SIGVALIDCLK(1'd0),
	.TSTIN(20'd1048575),
	.TX8B10BBYPASS(1'd0),
	.TX8B10BEN(1'd0),
	.TXBUFDIFFCTRL(3'd4),
	.TXCHARDISPMODE({ethernet_pma_a7_gtp_basex_tx_data0[19], ethernet_pma_a7_gtp_basex_tx_data0[9]}),
	.TXCHARDISPVAL({ethernet_pma_a7_gtp_basex_tx_data0[18], ethernet_pma_a7_gtp_basex_tx_data0[8]}),
	.TXCHARISK(1'd0),
	.TXCOMINIT(1'd0),
	.TXCOMSAS(1'd0),
	.TXCOMWAKE(1'd0),
	.TXDATA({ethernet_pma_a7_gtp_basex_tx_data0[17:10], ethernet_pma_a7_gtp_basex_tx_data0[7:0]}),
	.TXDEEMPH(1'd0),
	.TXDETECTRX(1'd0),
	.TXDIFFCTRL(4'd8),
	.TXDIFFPD(1'd0),
	.TXDLYBYPASS(1'd1),
	.TXDLYEN(1'd0),
	.TXDLYHOLD(1'd0),
	.TXDLYOVRDEN(1'd0),
	.TXDLYSRESET(1'd0),
	.TXDLYUPDOWN(1'd0),
	.TXELECIDLE(1'd0),
	.TXHEADER(1'd0),
	.TXINHIBIT(1'd0),
	.TXMAINCURSOR(1'd0),
	.TXMARGIN(1'd0),
	.TXOUTCLKSEL(2'd2),
	.TXPCSRESET(1'd0),
	.TXPD(1'd0),
	.TXPDELECIDLEMODE(1'd0),
	.TXPHALIGN(1'd0),
	.TXPHALIGNEN(1'd0),
	.TXPHDLYPD(1'd0),
	.TXPHDLYRESET(1'd0),
	.TXPHDLYTSTCLK(1'd0),
	.TXPHINIT(1'd0),
	.TXPHOVRDEN(1'd0),
	.TXPIPPMEN(1'd0),
	.TXPIPPMOVRDEN(1'd0),
	.TXPIPPMPD(1'd0),
	.TXPIPPMSEL(1'd1),
	.TXPIPPMSTEPSIZE(1'd0),
	.TXPISOPD(1'd0),
	.TXPMARESET(1'd0),
	.TXPOLARITY(1'd0),
	.TXPOSTCURSOR(1'd0),
	.TXPOSTCURSORINV(1'd0),
	.TXPRBSFORCEERR(1'd0),
	.TXPRBSSEL(1'd0),
	.TXPRECURSOR(1'd0),
	.TXPRECURSORINV(1'd0),
	.TXRATE(1'd0),
	.TXRATEMODE(1'd0),
	.TXSEQUENCE(1'd0),
	.TXSTARTSEQ(1'd0),
	.TXSWING(1'd0),
	.TXSYNCALLIN(1'd0),
	.TXSYNCIN(1'd0),
	.TXSYNCMODE(1'd0),
	.TXSYSCLKSEL(1'd0),
	.TXUSERRDY(ethernet_pma_a7_gtp_basex_tx_cm_locked0),
	.TXUSRCLK(eth_tx_half_clk),
	.TXUSRCLK2(eth_tx_half_clk),
	.DMONITOROUT(ethernet_pma_a7_gtp_basex28),
	.DRPDO(ethernet_pma_a7_gtp_basex_drpdo),
	.DRPRDY(ethernet_pma_a7_gtp_basex_drprdy),
	.EYESCANDATAERROR(ethernet_pma_a7_gtp_basex2),
	.GTPTXN(sfp_txn),
	.GTPTXP(sfp_txp),
	.PCSRSVDOUT(ethernet_pma_a7_gtp_basex41),
	.PHYSTATUS(ethernet_pma_a7_gtp_basex0),
	.PMARSVDOUT0(ethernet_pma_a7_gtp_basex11),
	.PMARSVDOUT1(ethernet_pma_a7_gtp_basex12),
	.RXBUFSTATUS(ethernet_pma_a7_gtp_basex13),
	.RXBYTEISALIGNED(ethernet_pma_a7_gtp_basex21),
	.RXBYTEREALIGN(ethernet_pma_a7_gtp_basex22),
	.RXCDRLOCK(ethernet_pma_a7_gtp_basex3),
	.RXCHANBONDSEQ(ethernet_pma_a7_gtp_basex24),
	.RXCHANISALIGNED(ethernet_pma_a7_gtp_basex26),
	.RXCHANREALIGN(ethernet_pma_a7_gtp_basex27),
	.RXCHARISCOMMA(ethernet_pma_a7_gtp_basex9),
	.RXCHARISK({ethernet_pma_a7_gtp_basex_rx_data0[18], ethernet_pma_a7_gtp_basex_rx_data0[8]}),
	.RXCHBONDO(ethernet_pma_a7_gtp_basex25),
	.RXCLKCORCNT(ethernet_pma_a7_gtp_basex7),
	.RXCOMINITDET(ethernet_pma_a7_gtp_basex39),
	.RXCOMMADET(ethernet_pma_a7_gtp_basex23),
	.RXCOMSASDET(ethernet_pma_a7_gtp_basex37),
	.RXCOMWAKEDET(ethernet_pma_a7_gtp_basex38),
	.RXDATA({ethernet_pma_a7_gtp_basex_rx_data0[17:10], ethernet_pma_a7_gtp_basex_rx_data0[7:0]}),
	.RXDATAVALID(ethernet_pma_a7_gtp_basex33),
	.RXDISPERR({ethernet_pma_a7_gtp_basex_rx_data0[19], ethernet_pma_a7_gtp_basex_rx_data0[9]}),
	.RXDLYSRESETDONE(ethernet_pma_a7_gtp_basex14),
	.RXELECIDLE(ethernet_pma_a7_gtp_basex40),
	.RXHEADER(ethernet_pma_a7_gtp_basex34),
	.RXHEADERVALID(ethernet_pma_a7_gtp_basex35),
	.RXNOTINTABLE(ethernet_pma_a7_gtp_basex10),
	.RXOSINTDONE(ethernet_pma_a7_gtp_basex4),
	.RXOSINTSTARTED(ethernet_pma_a7_gtp_basex5),
	.RXOSINTSTROBEDONE(ethernet_pma_a7_gtp_basex29),
	.RXOSINTSTROBESTARTED(ethernet_pma_a7_gtp_basex6),
	.RXOUTCLK(ethernet_pma_a7_gtp_basex_rxoutclk),
	.RXOUTCLKFABRIC(ethernet_pma_a7_gtp_basex31),
	.RXOUTCLKPCS(ethernet_pma_a7_gtp_basex32),
	.RXPHALIGNDONE(ethernet_pma_a7_gtp_basex15),
	.RXPHMONITOR(ethernet_pma_a7_gtp_basex16),
	.RXPHSLIPMONITOR(ethernet_pma_a7_gtp_basex17),
	.RXPMARESETDONE(ethernet_pma_a7_gtp_basex_rx_pma_reset_done),
	.RXPRBSERR(ethernet_pma_a7_gtp_basex8),
	.RXRATEDONE(ethernet_pma_a7_gtp_basex30),
	.RXRESETDONE(ethernet_pma_a7_gtp_basex_rx_reset_done),
	.RXSTARTOFSEQ(ethernet_pma_a7_gtp_basex36),
	.RXSTATUS(ethernet_pma_a7_gtp_basex18),
	.RXSYNCDONE(ethernet_pma_a7_gtp_basex19),
	.RXSYNCOUT(ethernet_pma_a7_gtp_basex20),
	.RXVALID(ethernet_pma_a7_gtp_basex1),
	.TXBUFSTATUS(ethernet_pma_a7_gtp_basex46),
	.TXCOMFINISH(ethernet_pma_a7_gtp_basex53),
	.TXDLYSRESETDONE(ethernet_pma_a7_gtp_basex43),
	.TXGEARBOXREADY(ethernet_pma_a7_gtp_basex52),
	.TXOUTCLK(ethernet_pma_a7_gtp_basex_txoutclk),
	.TXOUTCLKFABRIC(ethernet_pma_a7_gtp_basex49),
	.TXOUTCLKPCS(ethernet_pma_a7_gtp_basex50),
	.TXPHALIGNDONE(ethernet_pma_a7_gtp_basex44),
	.TXPHINITDONE(ethernet_pma_a7_gtp_basex45),
	.TXPMARESETDONE(ethernet_pma_a7_gtp_basex42),
	.TXRATEDONE(ethernet_pma_a7_gtp_basex51),
	.TXRESETDONE(ethernet_pma_a7_gtp_basex_tx_reset_done),
	.TXSYNCDONE(ethernet_pma_a7_gtp_basex47),
	.TXSYNCOUT(ethernet_pma_a7_gtp_basex48)
);

(* ars_ff1 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE (
	.C(ipbus_clk),
	.CE(1'd1),
	.D(1'd0),
	.PRE(xilinxasyncresetsynchronizerimpl0_async_reset),
	.Q(xilinxasyncresetsynchronizerimpl0_rst_meta)
);

(* ars_ff2 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_1 (
	.C(ipbus_clk),
	.CE(1'd1),
	.D(xilinxasyncresetsynchronizerimpl0_rst_meta),
	.PRE(xilinxasyncresetsynchronizerimpl0_async_reset),
	.Q(ipbus_rst)
);

(* ars_ff1 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_2 (
	.C(sys_clk),
	.CE(1'd1),
	.D(1'd0),
	.PRE(xilinxasyncresetsynchronizerimpl1_async_reset),
	.Q(xilinxasyncresetsynchronizerimpl1_rst_meta)
);

(* ars_ff2 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_3 (
	.C(sys_clk),
	.CE(1'd1),
	.D(xilinxasyncresetsynchronizerimpl1_rst_meta),
	.PRE(xilinxasyncresetsynchronizerimpl1_async_reset),
	.Q(sys_rst)
);

(* ars_ff1 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_4 (
	.C(sample_clk),
	.CE(1'd1),
	.D(1'd0),
	.PRE(xilinxasyncresetsynchronizerimpl2_async_reset),
	.Q(xilinxasyncresetsynchronizerimpl2_rst_meta)
);

(* ars_ff2 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_5 (
	.C(sample_clk),
	.CE(1'd1),
	.D(xilinxasyncresetsynchronizerimpl2_rst_meta),
	.PRE(xilinxasyncresetsynchronizerimpl2_async_reset),
	.Q(sample_rst)
);

(* ars_ff1 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_6 (
	.C(eth_tx_clk),
	.CE(1'd1),
	.D(1'd0),
	.PRE(xilinxasyncresetsynchronizerimpl3_async_reset),
	.Q(xilinxasyncresetsynchronizerimpl3_rst_meta)
);

(* ars_ff2 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_7 (
	.C(eth_tx_clk),
	.CE(1'd1),
	.D(xilinxasyncresetsynchronizerimpl3_rst_meta),
	.PRE(xilinxasyncresetsynchronizerimpl3_async_reset),
	.Q(eth_tx_rst)
);

(* ars_ff1 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_8 (
	.C(eth_rx_clk),
	.CE(1'd1),
	.D(1'd0),
	.PRE(xilinxasyncresetsynchronizerimpl4_async_reset),
	.Q(xilinxasyncresetsynchronizerimpl4_rst_meta)
);

(* ars_ff2 = "true", async_reg = "true" *) FDPE #(
	.INIT(1'd1)
) FDPE_9 (
	.C(eth_rx_clk),
	.CE(1'd1),
	.D(xilinxasyncresetsynchronizerimpl4_rst_meta),
	.PRE(xilinxasyncresetsynchronizerimpl4_async_reset),
	.Q(eth_rx_rst)
);

endmodule
