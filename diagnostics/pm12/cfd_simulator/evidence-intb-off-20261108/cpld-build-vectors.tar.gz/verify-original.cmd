setMode -bs
setCable -port svf -file /srv/nvme-fast-4/simulations/pm12-intb-off-20261108/verify-original.svf
addDevice -p 1 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 2 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 3 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 4 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 5 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 6 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 7 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 8 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 9 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 10 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 11 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 12 -file /srv/nvme-fast-4/simulations/pm12-original-gates-20261106-01/cpld/build/design.jed
addDevice -p 13 -file /srv/nvme-fast-2/toolchains/ise/14.7/ISE_DS/ISE/kintex7/data/xc7k160t_ffg676.bsd
verify -p 1
verify -p 2
verify -p 3
verify -p 4
verify -p 5
verify -p 6
verify -p 7
verify -p 8
verify -p 9
verify -p 10
verify -p 11
verify -p 12
quit
