from pathlib import Path
import sys,contextlib,json
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'ipbus_adc'),'/home/codex-hil/kasli-phase-tester']
from lease import acquire
from client import Client
from host.gate_phase_ipbus import GatePhaseIPbusDevice
from host.gate_phase_dio import input_cards
r=Path(__file__).parent
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 d=GatePhaseIPbusDevice();st.callback(d.close);c=Client();st.callback(c.close)
 report={'cfd_enabled':d.read(0xe0),'port':d.read(0xdc),'hdmi_enabled':d.read(0x144),'bridge':d.read(0x120),'tdc_status':c.read(0x201)[0],'tdc_counts':c.read(0x220,12),'pm_id':c.read(0,3),'directions':input_cards(d)}
 assert report['cfd_enabled']==report['port']==report['hdmi_enabled']==0 and report['tdc_counts']==[0]*12
(r/'post-legacy.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
