import json,struct,collections,hashlib
from pathlib import Path
r=Path(__file__).parent
report={}
t=json.loads((r/'tdc-scan/status.json').read_text());assert t['pass_'] and len(t['statistics'])==100 and len(t['mapping'])==4
records=0;quiet=0;ids=[]
for row in t['captures']:
 ids.append(row['generation'])
 for ch,count in enumerate(row['counts'],1):
  raw=(r/'tdc-scan'/row['label']/f'tdc{ch:02d}.bin').read_bytes();assert len(raw)==2*count
  words=struct.unpack('<%dH'%count,raw);assert all(w<=8191 for w in words)
  hist={str(k):v for k,v in collections.Counter(w&127 for w in words).items()};assert hist==row['fine_histograms'][ch-1]
  records+=count
 if row['tx']:
  expected=[0]*12;expected[row['expected_channel']-1]=row['tx']['repetitions'];assert row['counts']==expected
 else:assert row['counts']==[0]*12;quiet+=1
assert len(ids)==len(set(ids)) and records==12864 and quiet==8
report.update(tdc_phase_points=100,tdc_phase_events=12800,tdc_discovery_events=64,tdc_quiet_windows=quiet,tdc_raw_records_exact=True,no_cross_channel_events=True)
g=json.loads((r/'gate-scan101/status.json').read_text());assert g['pass_'] and len(g['points'])==404 and g['restored_zero']==[12,10,8,6]
for ch in [12,10,8,6]:
 ps=[p for p in g['points'] if p['afe']==ch];assert len(ps)==101 and [p['code'] for p in ps]==[(i*65535+50)//100 for i in range(101)]
 commands=[p for p in g['console'] if p['command'].startswith(f'@DAC {ch} ')]
 assert commands[-1]['reply'].strip()=='DAC SENT A 0000'
report.update(gate_dac_points=404,gate_raw_captures=404,gate_raw_sample_bits=404*8*4095*8,gate_hardware_phase_records_checked_during_acquisition=404*8*1365,all_four_dac_A_restored_zero_acknowledged=True)
f=json.loads((r/'final-state02/status.json').read_text());assert f['pass_'] and f['dna']=='3A17A1B402212223' and f['gates']['9']['high_samples']==0
p=json.loads((r/'post-legacy.json').read_text());assert p['port']==p['cfd_enabled']==p['hdmi_enabled']==0 and p['tdc_counts']==[0]*12
q=json.loads((r/'kasli-qualified/qualification-values.json').read_text());assert q['wns_ns']>=0 and q['whs_ns']>=0 and not q['drc_errors']
report.update(board_uid='PM12-K7-'+f['dna'],kasli_bit_sha256=hashlib.sha256((r/'kasli-qualified/gate_phase_qualified.bit').read_bytes()).hexdigest(),pm_bit_sha256='1dbafd99033f803a086d4153ed3d873adfc9b4208b806785f00d3024bdfbf1ac',qualification=q,tdc_functional_pass=True,gate_measurement_complete=True,gate_return_findings={'10A':'constant HIGH, no edges','8A':'constant HIGH, no edges'},external_dac_and_dmm_used=False,final_cpld12='INTB-off restored; other11 original gates',final_state_verified=True,scope='Functional TDC counts and relative phase response. Missing gate return edges remain unresolved findings, not a board-wide PASS.')
(r/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
