import sys,contextlib,json
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'cfd_simulator'),str(P/'ipbus_adc'),'/home/codex-hil/kasli-phase-tester','/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console
from client import Client
from console import ConsoleI2C,Registers
from mcp23017 import afe_route
from pm12_console_regression import capture
from pm12_power import wait_power_good,require_power_good
from host.gate_phase_ipbus import GatePhaseIPbusDevice
from host.gate_phase_dio import input_cards
r=Path(__file__).parent;report={}
cfg={'uart':'/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port0'}
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console(cfg));report['pg']=wait_power_good(u,capture);report['mcu']=capture(u,'RS');assert 'Board S/N: 1803' in report['mcu']['reply']
 c=Client();st.callback(c.close);
 try:report['pm']=c.read(0,10);report['tdc']=c.read(0x200,6)
 except Exception as e:report['pm_error']=repr(e)
 d=GatePhaseIPbusDevice();st.callback(d.close);d.stop();report['directions']=input_cards(d);report['kasli']=d.status()
 data=d.capture(4095,channels=list(range(8,16)));(r/'all-gates.json').write_text(json.dumps(data)+'\n')
 report['gates']={}
 for row in data['channels']:
  b=[(w>>i)&1 for w in row['words'] for i in range(8)];report['gates'][row['logical']]={'high':sum(b),'rising':sum(not x and y for x,y in zip(b,b[1:]))}
 bus=ConsoleI2C(u,capture);report['mcp']={}
 for ch in [12,10,8,6]:
  require_power_good(u,capture)
  with bus.routed(*afe_route(ch)):
   regs=Registers(bus);report['mcp'][ch]={hex(n):regs.read(n) for n in [0,1,10,11,0x12,0x13,0x14,0x15]}
 report['i2c']=bus.records;d.stop()
(r/'probe.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['i2c']},indent=2))
