import contextlib,sys,json,os,subprocess
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance')]
from lease import acquire,ENV
from station import jtag_command
r=Path(__file__).parent;out=r/'gate12-cpld-window';out.mkdir(exist_ok=False)
vectors=Path('/srv/codex-hil-nvme/pm12-intb-off-20261108')
cfg=json.loads(Path('/srv/codex-hil-nvme/pm12-acceptance-20261107/post-restore-probe-run/station.json').read_text())
def program(prefix,which):
 with (out/(which+'.log')).open('w') as f:subprocess.run(prefix+['-mode','batch','-nolog','-nojournal','-notrace','-source',str(P/'adc/tools/execute_native.tcl'),'-tclargs',cfg['jtag_cable'],cfg['hw_server'],str(vectors/(which+'.tcl')),'0'],stdout=f,stderr=subprocess.STDOUT,timeout=180,check=True)
 assert 'NATIVE_EXECUTE_PASS' in (out/(which+'.log')).read_text()
with contextlib.ExitStack() as st:
 fds={}
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):
  path=Path.home()/'.cache'/(n+'.lock');f=st.enter_context(acquire(path));fds[str(path.resolve())]=f.fileno()
 os.environ[ENV]=json.dumps(fds)
 try:
  with jtag_command(cfg,out) as prefix:program(prefix,'restore')
  s=(r/'scan-gates.py').read_text().replace("root/'gate-scan20'","root/'gate12-original20'").replace("'channels':[12,10,8,6]","'channels':[12]")
  exec(compile(s,str(r/'scan-gates.py'),'exec'),{'__name__':'__main__','__file__':str(r/'scan-gates.py')})
 finally:
  with jtag_command(cfg,out) as prefix:program(prefix,'program')
  os.environ.pop(ENV,None)
print('CPLD12 INTB_OFF RESTORED',flush=True)
