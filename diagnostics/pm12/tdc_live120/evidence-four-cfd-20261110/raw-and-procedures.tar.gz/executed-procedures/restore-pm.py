import sys,json,hashlib,contextlib,subprocess,time
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P),str(P/'acceptance'),str(P/'ipbus_adc'),'/home/codex-hil/kasli-phase-tester','/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console,jtag_command
from test_board import payload
from pm12_power import wait_power_good,require_power_good
from pm12_console_regression import capture
from client import Client
from host.gate_phase_ipbus import GatePhaseIPbusDevice
root=Path(__file__).parent;out=root/'pm-restore';out.mkdir(exist_ok=False)
cfg=json.loads(Path('/srv/codex-hil-nvme/pm12-acceptance-20261107/post-restore-probe-run/station.json').read_text())
bit=Path('/srv/codex-hil-nvme/pm12-hdmi-integrated-20261106/pm-final-candidate/pm12_ipbus_adc.bit');assert hashlib.sha256(bit.read_bytes()).hexdigest()=='1dbafd99033f803a086d4153ed3d873adfc9b4208b806785f00d3024bdfbf1ac'
s=(P/'adc/tools/load_fpga.tcl').read_text().replace('source [file join [file dirname [info script]] common.tcl]',f'source {P}/adc/tools/common.tcl').replace('0x504dad01','0x504d5a04');(out/'load.tcl').write_text(s);bits=payload(bit,out/'payload.hex');report={}
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console(cfg));report['pg']=wait_power_good(u,capture);report['mcu']=capture(u,'RS');assert 'Board S/N: 1803' in report['mcu']['reply']
 with jtag_command(cfg,out) as prefix:
  with (out/'load.log').open('w') as log:subprocess.run(prefix+['-mode','batch','-nolog','-nojournal','-notrace','-source',str(out/'load.tcl'),'-tclargs',cfg['jtag_cable'],cfg['hw_server'],str(out/'payload.hex'),str(bits)],stdout=log,stderr=subprocess.STDOUT,timeout=180,check=True)
  assert 'LOAD_PASS' in (out/'load.log').read_text()
 d=GatePhaseIPbusDevice();st.callback(d.close);d.write(0x100,256);time.sleep(.05);d.write(0x100,0);d.write(0x120,1)
 c=Client();st.callback(c.close);report['pm']=c.read(0,3);assert report['pm']==[0x504d1202,0x10002,0xc7c42d28];report['tdc']=c.read(0x201,5);report['pg_final']=require_power_good(u,capture)
(out/'status.json').write_text(json.dumps(report,indent=2)+'\n');print('PM RESTORED',report['pm'],report['tdc'],flush=True)
