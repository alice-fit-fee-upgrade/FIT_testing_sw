import contextlib,json,sys,time,hashlib
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'ipbus_adc'),'/home/codex-hil/kasli-phase-tester','/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console
from host.hardware_test import identify,jtag
from host.gate_phase_device import GatePhaseDevice
from host.gate_phase_ipbus import GatePhaseIPbusDevice
from host.gate_phase_dio import input_cards
from pm12_power import wait_power_good,require_power_good
from pm12_console_regression import capture
from client import Client
r=Path(__file__).parent;out=r/'kasli-deploy03';out.mkdir(exist_ok=False)
new=r/'kasli-qualified/gate_phase_qualified.bit';q=json.loads((new.parent/'qualification-values.json').read_text());assert q['wns_ns']>=0 and q['whs_ns']>=0 and q['drc_errors']==0 and q['differential_output_buffers']==10
old=Path('/srv/codex-hil-nvme/pm12-hdmi-integrated-20261106/kasli-final-candidate/gate_phase.bit');assert hashlib.sha256(old.read_bytes()).hexdigest()=='4299ddd3c87ccc4ad76796127de1d08d2d50943c7679555fca140b1e64261745'
report={'pass_':False,'bit_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'qualification':q}
def save():(out/'status.json').write_text(json.dumps(report,indent=2)+'\n')
def reconnect():
 # SFP0 has an independent 125MHz clock and does not need the private bridge.
 # Bootstrap and reset/enable the PM bridge through IPbus, no Kasli UART access.
 end=time.monotonic()+20
 while True:
  try:d=GatePhaseIPbusDevice();break
  except TimeoutError:
   if time.monotonic()>end:raise
 d.write(0x100,256);time.sleep(.05);d.write(0x100,0);d.write(0x120,1)
 return d
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console({'uart':'/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port0'}));report['pg']=wait_power_good(u,capture);report['mcu']=capture(u,'RS');assert 'Board S/N: 1803' in report['mcu']['reply']
 boot=reconnect();boot.close()
 c=Client();st.callback(c.close);report['pm_before']=c.read(0,3);assert report['pm_before']==[0x504d1202,0x10002,0xc7c42d28];report['pm_uptime_before']=c.read(5,2)
 d=GatePhaseIPbusDevice();d.write(0xe0,0);d.stop();input_cards(d);d.close();d=None
 usb=identify();report['usb']=usb;cmd='adapter usb location '+Path(usb['sysfs']).name+'; init; '
 try:
  jtag(cmd+'pld load 0 {'+str(new)+'}; shutdown','load-four-ports',out)
  d=reconnect();assert d.read(0xd8)==0x43464434;assert d.read(0xdc)==0 and d.read(0xe0)==0;assert d.read(0x15c)==0x03020100
  for port in range(4):d.write(0xdc,port);assert d.read(0xdc)==port
  d.write(0xdc,0);report['directions']=input_cards(d)
  report['pm_after']=c.read(0,3);assert report['pm_after']==report['pm_before'];report['pm_uptime_after']=c.read(5,2);report['tdc']=c.read(0x201,5)
  report['pg_final']=require_power_good(u,capture);report['pass_']=True
 except BaseException as e:
  report['error']=repr(e)
  if d:d.close();d=None
  try:
   jtag(cmd+'pld load 0 {'+str(old)+'}; shutdown','rollback',out);d=reconnect();input_cards(d);report['rollback']=True
  except BaseException as err:report['rollback_error']=repr(err)
  raise
 finally:
  if d:
   try:d.write(0xe0,0);d.stop()
   finally:d.close()
  save()
print('KASLI_FOUR_PORTS_LOADED',flush=True)
