# Run from build directory after implementation. Never call this a cable test.
open_checkpoint lvds8_route.dcp
report_timing_summary -check_timing_verbose -report_unconstrained -file qualification-timing.rpt
report_drc -file qualification-drc.rpt
report_cdc -details -file qualification-cdc.rpt
report_utilization -file qualification-utilization.rpt
set wns [get_property SLACK [get_timing_paths -delay_type max -max_paths 1]]
set whs [get_property SLACK [get_timing_paths -delay_type min -max_paths 1]]
set errors [get_drc_violations -filter {SEVERITY == Error}]
set f [open qualification-values.json w]
puts $f "{\"wns_ns\": $wns, \"whs_ns\": $whs, \"drc_errors\": [llength $errors]}"
close $f
if {$wns<0 || $whs<0 || [llength $errors]} {error "LVDS8 implementation qualification failed"}
exit
