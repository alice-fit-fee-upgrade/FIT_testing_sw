"""Validated clock arithmetic and UG482 table4-13 PRBS CDR settings."""


def line_settings(line_mbps):
    if line_mbps not in (1250, 6000, 6250):
        raise ValueError('Supported raw line rates:1250,6000,6250Mb/s')
    slow = line_mbps == 1250
    return dict(line_mbps=line_mbps, line_hz=line_mbps*1000000,
                ref_hz=120000000 if line_mbps == 6000 else 125000000,
                pll_fbdiv=4 if slow else 5, pll_fbdiv_45=5,
                out_div=4 if slow else 1,
                sys_mult=16 if slow else 20,
                sys_fast_div=16 if slow else 4, sys_slow_div=32 if slow else 8,
                rx_mult=16 if slow else 2,
                rx_fast_div=16 if slow else 2, rx_slow_div=32 if slow else 4,
                cdr_cfg=0x0001107FE086021101010 if slow else 0x0001107FE206021041010)
