"""Buffered raw serializer and finite capture; bit zero is earliest in time."""
from migen import *
from migen.genlib.cdc import MultiReg


class PatternPlayer(Module):
    def __init__(self, depth=4096, word_width=40):
        self.enable = Signal()
        self.ready = Signal()
        self.write = Signal()
        self.write_bank = Signal()
        self.write_address = Signal(max=depth)
        self.write_data = Signal(word_width)
        self.commit = Signal()
        self.commit_length = Signal(max=depth+1)
        self.active_bank = Signal()
        self.length = Signal(max=depth+1, reset=15)
        self.pending = Signal()
        self.error = Signal()
        self.position = Signal(max=depth)
        self.loops = Signal(32)
        self.data = Signal(word_width)
        pending_length = Signal(max=depth+1)
        memory = Memory(word_width, depth*2)
        write_port = memory.get_port(write_capable=True, mode=READ_FIRST)
        read_port = memory.get_port(mode=READ_FIRST)
        self.specials += memory, write_port, read_port
        # One-cycle synchronous BRAM read; prefetch the word following position.
        next_position = Signal(max=depth)
        next_bank = Signal()
        running = self.enable & self.ready
        boundary = self.position == self.length-1
        self.comb += [
            write_port.adr.eq(Cat(self.write_address, self.write_bank)),
            write_port.dat_w.eq(self.write_data),
            write_port.we.eq(self.write & (self.write_bank != self.active_bank) & ~self.pending),
            next_position.eq(Mux(running & ~boundary, self.position+1, 0)),
            next_bank.eq(Mux(self.pending & (~running | boundary), ~self.active_bank, self.active_bank)),
            read_port.adr.eq(Cat(next_position, next_bank)),
            self.data.eq(Mux(running, read_port.dat_r, 0)),
        ]
        self.sync += [
            If(self.write & ((self.write_bank == self.active_bank) | self.pending), self.error.eq(1)),
            If(self.commit,
                If((self.commit_length == 0) | (self.commit_length > depth) | self.pending,
                    self.error.eq(1)
                ).Else(self.pending.eq(1), pending_length.eq(self.commit_length))
            ),
            If(~running,
                self.position.eq(0)
            ).Elif(boundary,
                self.position.eq(0), self.loops.eq(self.loops+1)
            ).Else(self.position.eq(self.position+1)),
            If(self.pending & (~running | boundary),
                self.active_bank.eq(~self.active_bank), self.length.eq(pending_length),
                self.pending.eq(0)
            ),
        ]


class WindowCapture(Module):
    """Write raw words in rx, read frozen RAM in sys; stable mailbox handshake.

    No per-edge admission limit: every bit of each captured word is preserved.
    The counter runs outside capture; start_sample identifies bit zero of word 0.
    """
    def __init__(self, depth=4096, word_width=40):
        self.data = Signal(word_width)
        self.rx_ready = Signal()
        self.arm = Signal()
        self.request_length = Signal(max=depth+1)
        self.read_address = Signal(max=depth)
        self.read_data = Signal(word_width)
        self.busy = Signal()
        self.done = Signal()
        self.error = Signal()
        self.count = Signal(max=depth+1)
        self.start_sample = Signal(64)
        self.previous = Signal()
        self.capture_id = Signal(32)
        self.read_valid = Signal()
        request = Signal()
        ack = Signal()
        ack_sys = Signal()
        request_rx = Signal()
        length_mailbox = Signal(max=depth+1)
        length_rx = Signal(max=depth+1)
        ready_sys = Signal()
        self.specials += [MultiReg(request, request_rx, 'rx'), MultiReg(ack, ack_sys),
                          MultiReg(self.rx_ready, ready_sys)]
        # Mailbox is held stable from request until acknowledged; receivers
        # sample after the toggle has passed a two-stage synchronizer.
        self.specials += MultiReg(length_mailbox, length_rx, 'rx')
        memory = Memory(word_width, depth)
        wp = memory.get_port(write_capable=True, clock_domain='rx', mode=READ_FIRST)
        rp = memory.get_port(mode=READ_FIRST)
        self.specials += memory, wp, rp
        active = Signal()
        address = Signal(max=depth)
        limit = Signal(max=depth+1)
        start_rx = Signal(64)
        previous_rx = Signal()
        count_rx = Signal(max=depth+1)
        aborted_rx = Signal()
        aborted_sys = Signal()
        invalid = Signal()
        self.specials += MultiReg(start_rx, self.start_sample), MultiReg(previous_rx, self.previous)
        self.specials += MultiReg(count_rx, self.count), MultiReg(aborted_rx, aborted_sys)
        sample = Signal(64)
        prev = Signal()
        self.comb += [wp.adr.eq(address), wp.dat_w.eq(self.data),
                      wp.we.eq(active & self.rx_ready), rp.adr.eq(self.read_address),
                      self.read_data.eq(rp.dat_r)]
        self.sync.rx += [
            sample.eq(sample+word_width), prev.eq(self.data[word_width-1]),
            If(~active & (request_rx != ack),
                If(self.rx_ready,
                    active.eq(1), address.eq(0), limit.eq(length_rx),
                    start_rx.eq(sample+word_width), previous_rx.eq(self.data[word_width-1]),
                    count_rx.eq(0), aborted_rx.eq(0)
                ).Else(ack.eq(request_rx), aborted_rx.eq(1))
            ).Elif(active,
                If(~self.rx_ready,
                    active.eq(0), ack.eq(request_rx), aborted_rx.eq(1)
                ).Else(
                    count_rx.eq(count_rx+1),
                    If(address == limit-1,
                        active.eq(0), ack.eq(request_rx)
                    ).Else(address.eq(address+1))
                )
            ),
        ]
        settle = Signal(3)
        self.sync += [
            self.read_valid.eq(self.done & ~self.busy),
            If(self.arm,
                If(self.busy | ~ready_sys | (self.request_length == 0) | (self.request_length > depth),
                    self.error.eq(1)
                ).Else(
                    length_mailbox.eq(self.request_length), request.eq(~request),
                    self.busy.eq(1), self.done.eq(0), settle.eq(0),
                    self.error.eq(0), invalid.eq(0), self.capture_id.eq(self.capture_id+1)
                )
            ),
            If(self.busy & ~ready_sys, invalid.eq(1)),
            If(self.busy & (ack_sys == request),
                If(settle == 5,
                    self.busy.eq(0), self.done.eq(~(aborted_sys | invalid | ~ready_sys)),
                    self.error.eq(aborted_sys | invalid | ~ready_sys)
                ).Else(settle.eq(settle+1))
            ),
        ]


class RegisterProtocol(Module):
    """UART command: opcode(0=read,1=write), address LE16, data LE32.

    Reply is address LE16 + value LE32. Exactly one outstanding request.
    """
    def __init__(self, uart):
        self.address = Signal(16)
        self.write_data = Signal(32)
        self.read_data = Signal(32)
        self.read = Signal()
        self.write = Signal()
        command = Signal(56)
        reply = Signal(48)
        rx_index = Signal(max=7)
        tx_index = Signal(max=6)
        timeout = Signal(24)
        self.submodules.fsm = fsm = FSM(reset_state='RECEIVE')
        self.comb += [self.address.eq(command[8:24]), self.write_data.eq(command[24:56]),
                      uart.sink.data.eq(reply[:8])]
        fsm.act('RECEIVE',
            uart.source.ack.eq(1),
            If(uart.source.stb,
                NextValue(timeout, 0),
                NextValue(command, Cat(command[8:], uart.source.data)),
                If(rx_index == 6, NextValue(rx_index, 0), NextState('ACCESS'))
                .Else(NextValue(rx_index, rx_index+1))
            ).Elif(rx_index != 0,
                NextValue(timeout, timeout+1),
                If(timeout == 0xffffff, NextValue(rx_index, 0), NextValue(timeout, 0))
            )
        )
        fsm.act('ACCESS', self.read.eq(command[:8] == 0), self.write.eq(command[:8] == 1),
                NextState('WAIT'))
        fsm.act('WAIT', NextState('LATCH'))
        fsm.act('LATCH', NextValue(reply, Cat(self.address, self.read_data)),
                NextValue(tx_index, 0), NextState('REPLY'))
        fsm.act('REPLY', uart.sink.stb.eq(1),
            If(uart.sink.ack,
                NextValue(reply, reply >> 8),
                If(tx_index == 5, NextState('RECEIVE')).Else(NextValue(tx_index, tx_index+1))
            )
        )
