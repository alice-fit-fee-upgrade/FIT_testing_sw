"""UART-register side of the LVDS instrument; all addresses byte addresses."""
from migen import *
from gateware.lvds8_phase import PhaseRecords

class Control(Module):
    def __init__(self,bank,bus,ready,depth,slot,reference_hz,sample_hz=1000000000,period_bins=25,profile_id=0):
        channels=len(bank.captures);player=bank.player
        self.output_mask=Signal(channels)
        self.command_error=Signal()
        self.capture_fault=Signal()
        self.valid=Signal()
        self.enabled=Signal()
        tx_address=Signal(max=depth);tx_length=Signal(max=depth+1,reset=25)
        tx_words=[Signal(32) for _ in range((channels*8+31)//32)]
        rx_channel=Signal(max=channels);rx_address=Signal(max=depth)
        capture_length=Signal(max=depth+1,reset=depth)
        arm=Signal();watching=Signal();seen_busy=Signal();timer=Signal(20)
        capture_outputs=Signal(channels);capture_sequence=Signal(32)
        busy=Signal();done=Signal();error=Signal()
        capture_armed=Signal();generator_armed=Signal();trigger_pending=Signal()
        trigger_id=Signal(32);capture_trigger_id=Signal(32)
        cycle=Signal(64);trigger_cycle=Signal(64)
        trigger_position=Signal(max=depth);trigger_loop=Signal(32)
        reserved=Signal();launch=Signal()
        self.comb += [reserved.eq(capture_armed|generator_armed|trigger_pending),
            launch.eq(trigger_pending&ready&~player.pending&~bus.write&
                      (~self.enabled|(player.position==player.length-1)))]
        raw_busy=Signal();phase_busy=Signal();phase_done=Signal(reset=1)
        capture_address=rx_address
        if period_bins==24:
            self.submodules.phases=phases=PhaseRecords(bank.captures,depth)
            capture_address=Signal(max=depth)
            self.comb += [phase_busy.eq(phases.busy),phase_done.eq(phases.done),
                phases.start.eq(watching&seen_busy&done&~raw_busy&~phase_busy&~self.capture_fault),
                phases.length.eq(capture_length),phases.read_address.eq(rx_address),
                capture_address.eq(Mux(phase_busy,phases.address,rx_address))]
        self.comb += [raw_busy.eq(Cat(*[cap.busy for cap in bank.captures])!=0),
            busy.eq(raw_busy|phase_busy),
            done.eq(Cat(*[cap.done for cap in bank.captures])==(1<<channels)-1),
            error.eq(Cat(*[cap.error for cap in bank.captures])!=0),
            self.valid.eq(done&~busy&~watching&~self.capture_fault&phase_done),bank.arm.eq(arm),
            bank.length.eq(capture_length),bank.ready.eq(ready),bank.address.eq(capture_address),
            player.ready.eq(ready),player.enable.eq(self.enabled),
            player.write_bank.eq(~player.active_bank),player.write_address.eq(tx_address),
            player.write_data.eq(Cat(*tx_words)),player.commit_length.eq(tx_length),
            player.write.eq(bus.write&(bus.address==0x30)&~self.command_error&~reserved),
            player.commit.eq(bus.write&(bus.address==0x38)&~self.command_error&~busy&~watching&~reserved)]
        self.sync += [arm.eq(0),cycle.eq(cycle+1),
            If(reserved&~ready,
                capture_armed.eq(0),generator_armed.eq(0),trigger_pending.eq(0),self.command_error.eq(1)),
            If(launch,
                trigger_pending.eq(0),trigger_id.eq(trigger_id+1),
                If(generator_armed,self.enabled.eq(1)),generator_armed.eq(0),
                If(capture_armed,
                    trigger_cycle.eq(cycle),trigger_position.eq(Mux(self.enabled,player.position,0)),
                    trigger_loop.eq(player.loops),
                    arm.eq(1),watching.eq(1),seen_busy.eq(0),timer.eq(0),
                    capture_outputs.eq(Mux(self.enabled|generator_armed,self.output_mask,0)),
                    capture_sequence.eq(capture_sequence+1),capture_trigger_id.eq(trigger_id+1)),
                capture_armed.eq(0)),
            If(watching,
                If(busy,seen_busy.eq(1)),
                If(~ready|(timer==2**20-1)|error,self.capture_fault.eq(1),watching.eq(0),self.enabled.eq(0))
                .Elif(seen_busy&done&~busy,watching.eq(0)).Else(timer.eq(timer+1))),
            If(bus.write,
                Case(bus.address,{
                    0x08: If(bus.write_data==0,self.enabled.eq(0),capture_armed.eq(0),generator_armed.eq(0),trigger_pending.eq(0))
                          .Elif((bus.write_data==1)&~busy&ready&~reserved,self.enabled.eq(1))
                          .Else(self.command_error.eq(1)),
                    # No output mask change while TX is enabled or RX is busy.
                    0x10: If(~self.enabled&~busy&~reserved&(bus.write_data<(1<<channels)),self.output_mask.eq(bus.write_data))
                          .Else(self.command_error.eq(1)),
                    0x14: If(~busy&~reserved&(bus.write_data>0)&(bus.write_data<=depth),capture_length.eq(bus.write_data)).Else(self.command_error.eq(1)),
                    0x18: If(~busy&~watching&~reserved&ready&~self.capture_fault&
                             (capture_length>0)&(capture_length<=depth),
                              arm.eq(1),watching.eq(1),seen_busy.eq(0),timer.eq(0),
                              capture_outputs.eq(Mux(self.enabled,self.output_mask,0)),capture_sequence.eq(capture_sequence+1))
                          .Else(self.command_error.eq(1)),
                    0x1c: If(bus.write_data<channels,rx_channel.eq(bus.write_data)).Else(self.command_error.eq(1)),
                    0x20: If(bus.write_data<depth,rx_address.eq(bus.write_data)).Else(self.command_error.eq(1)),
                    0x24: If(bus.write_data<depth,tx_address.eq(bus.write_data)).Else(self.command_error.eq(1)),
                    0x34: If(~reserved&(bus.write_data>0)&(bus.write_data<=depth),tx_length.eq(bus.write_data)).Else(self.command_error.eq(1)),
                    0x38: If(busy|watching|reserved,self.command_error.eq(1)),
                    0x30: If(reserved,self.command_error.eq(1)),
                    # ARM bits: capture=1, generator=2. Generator arm never restarts running TX.
                    0x84: If(~reserved&~busy&~watching&ready&~self.capture_fault&~player.pending&
                             (bus.write_data>0)&(bus.write_data<4)&
                             (~bus.write_data[1]|~self.enabled),
                              capture_armed.eq(bus.write_data[0]),generator_armed.eq(bus.write_data[1]))
                          .Else(self.command_error.eq(1)),
                    0x88: If((bus.write_data==1)&(capture_armed|generator_armed)&~trigger_pending&ready,
                              trigger_pending.eq(1)).Else(self.command_error.eq(1)),
                    0x70: If(~busy, self.command_error.eq(0)),
                    **{0x40+4*i:word.eq(bus.write_data) for i,word in enumerate(tx_words)}
                }))]
        def selected(name):return Array([getattr(cap,name) for cap in bank.captures])[rx_channel]
        phase_registers={0xb8:bus.read_data.eq(0),0xbc:bus.read_data.eq(0xffffffff)}
        if period_bins==24:
            phase_registers={0xb8:bus.read_data.eq(Mux(self.valid,phases.count,0)),
                0xbc:bus.read_data.eq(Mux(self.valid&(rx_address<phases.count),
                    Array(phases.read_data)[rx_channel],0xffffffff))}
        self.comb += [bus.read_data.eq(0xffffffff),Case(bus.address,{
            0x00:bus.read_data.eq(0x4c563831), # LV81
            0x04:bus.read_data.eq(0x10002),
            0x08:bus.read_data.eq(self.enabled),
            0x0c:bus.read_data.eq(Cat(ready,busy,self.valid,self.capture_fault,
                                     self.command_error,player.error,player.pending,player.active_bank)),
            0x10:bus.read_data.eq(self.output_mask),0x14:bus.read_data.eq(capture_length),
            0x1c:bus.read_data.eq(rx_channel),0x20:bus.read_data.eq(rx_address),
            0x24:bus.read_data.eq(tx_address),0x34:bus.read_data.eq(player.length),
            0x3c:bus.read_data.eq(player.loops),
            0x50:bus.read_data.eq(Mux(self.valid&(rx_address<selected('count')),selected('read_data'),0xffffffff)),
            0x54:bus.read_data.eq(Mux(self.valid,selected('count'),0)),
            0x58:bus.read_data.eq(selected('start_sample')[:32]),
            0x5c:bus.read_data.eq(selected('start_sample')[32:]),
            0x60:bus.read_data.eq(selected('previous')),
            0x64:bus.read_data.eq(capture_sequence),0x68:bus.read_data.eq(capture_outputs),
            0x74:bus.read_data.eq(int(reference_hz)),0x78:bus.read_data.eq(depth),
            0x7c:bus.read_data.eq(slot),0x80:bus.read_data.eq(channels),
            0x8c:bus.read_data.eq(Cat(capture_armed,generator_armed,trigger_pending)),
            0x90:bus.read_data.eq(trigger_id),0x94:bus.read_data.eq(trigger_cycle[:32]),
            0x98:bus.read_data.eq(trigger_cycle[32:]),0x9c:bus.read_data.eq(trigger_position),
            0xa0:bus.read_data.eq(trigger_loop),0xa4:bus.read_data.eq(capture_trigger_id),
            **phase_registers,
            0xa8:bus.read_data.eq(sample_hz),0xac:bus.read_data.eq(period_bins),
            0xb0:bus.read_data.eq(profile_id),0xb4:bus.read_data.eq(sample_hz//8),
        })]
