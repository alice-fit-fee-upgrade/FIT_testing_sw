"""Known Kasli SFP0 1000BASE-X + unchanged PM12 CERN IPbus endpoint."""
from migen import *
from migen.genlib.cdc import MultiReg
from misoc.cores.a7_gtp import QPLL,QPLLSettings
from liteeth.phy.serial.basex.wrappers.a7_gtp import A7_1000BASEX
from liteeth.mac.core import LiteEthMACCore

class GateEthernet(Module):
    def __init__(self,platform,bridge,sys_clk,ipbus_clk,qpll_channel=None):
        if qpll_channel is None:
            pads=platform.request('clk125_gtp');ref=Signal()
            self.specials += Instance('IBUFDS_GTE2',i_I=pads.p,i_IB=pads.n,i_CEB=0,o_O=ref)
            self.submodules.qpll=qpll=QPLL(ref,QPLLSettings(0b001,4,5,1))
            qpll_channel=qpll.channels[0]
        self.submodules.phy=phy=A7_1000BASEX(qpll_channel,platform.request('sfp',0),120e6,with_csr=False)
        platform.add_period_constraint(phy.txoutclk,16.0);platform.add_period_constraint(phy.rxoutclk,16.0)
        platform.add_false_path_constraints(sys_clk,phy.txoutclk,phy.rxoutclk)
        for clock in (phy.txoutclk,phy.rxoutclk):
            platform.add_false_path_constraint(ipbus_clk,clock);platform.add_false_path_constraint(clock,ipbus_clk)
        # Byte-wide MAC/controller in125MHz eth_tx domain; IPbus40MHz CDC is
        # upstream controller logic already used on PM12. No extra clock PLL.
        self.submodules.mac=mac=ClockDomainsRenamer('eth_tx')(LiteEthMACCore(phy,dw=8,with_sys_datapath=True,with_store_and_forward=True))
        rx,tx=mac.source,mac.sink;first=Signal(reset=1)
        self.sync.eth_tx += If(tx.valid&tx.ready,first.eq(tx.last))
        self.comb += [rx.ready.eq(1),tx.first.eq(first),tx.be.eq(1)]
        got=Signal();self.link=Signal();self.got_ip=Signal()
        self.specials += [MultiReg(phy.link_up,self.link),MultiReg(got,self.got_ip)]
        self.specials += Instance('rng_ipbus_endpoint',
            i_mac_clk=ClockSignal('eth_tx'),i_rst_macclk=ResetSignal('eth_tx'),
            i_ipb_clk=ClockSignal('ipbus'),i_rst_ipb=ResetSignal('ipbus'),
            i_mac_rx_data=rx.data,i_mac_rx_valid=rx.valid,i_mac_rx_last=rx.last&rx.valid,i_mac_rx_error=rx.error&rx.valid,
            o_mac_tx_data=tx.data,o_mac_tx_valid=tx.valid,o_mac_tx_last=tx.last,o_mac_tx_error=tx.error,i_mac_tx_ready=tx.ready,
            i_mac_addr=0x020000001202,i_ip_addr=0xc0a802f1,o_got_ip=got,
            o_ipb_addr=bridge.address,o_ipb_wdata=bridge.wdata,o_ipb_strobe=bridge.strobe,o_ipb_write=bridge.write,
            i_ipb_rdata=bridge.rdata,i_ipb_ack=bridge.ack,i_ipb_err=bridge.err)
