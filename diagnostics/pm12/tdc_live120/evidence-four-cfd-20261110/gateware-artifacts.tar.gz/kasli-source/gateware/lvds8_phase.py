"""Frozen raw capture -> per-period phase records; runs only in sys domain.

Three chronological x8 words form one 24-sample frame. Preserve raw memory;
record earliest rising-edge bin, total edge count, present/multiple flags.
Frame zero is the first captured sample, not a calibrated external phase zero.
"""
from migen import *

class PhaseRecords(Module):
    def __init__(self,captures,depth):
        self.start=Signal();self.busy=Signal();self.done=Signal()
        self.length=Signal(max=depth+1);self.count=Signal(max=depth//3+1)
        self.address=Signal(max=depth);self.read_address=Signal(max=depth)
        self.read_data=[]
        index=Signal(max=depth);stage=Signal(2);state=Signal(2)
        frame=Signal(max=depth//3+1)
        self.comb += self.address.eq(index)
        write=self.busy&(state==3)&(stage==2)
        for cap in captures:
            previous=Signal();partial=Signal(16);rising=Signal(8);mask=Signal(24)
            first=Signal(5);count=Signal(5);record=Signal(32)
            self.comb += [rising.eq(cap.read_data&~Cat(previous,cap.read_data[:7])),
                          mask.eq(Cat(partial,rising)),first.eq(0)]
            for bit in reversed(range(24)):
                self.comb += If(mask[bit],first.eq(bit))
            terms=[mask[i] for i in range(24)]
            while len(terms)>1:
                terms=[terms[i]+terms[i+1] if i+1<len(terms) else terms[i] for i in range(0,len(terms),2)]
            self.comb += [count.eq(terms[0]),record.eq(Cat(first,Constant(0,11),count,Constant(0,9),count!=0,count>1))]
            memory=Memory(32,depth//3)
            wp=memory.get_port(write_capable=True,mode=READ_FIRST)
            rp=memory.get_port(mode=READ_FIRST)
            self.specials += memory,wp,rp
            self.comb += [wp.adr.eq(frame),wp.dat_w.eq(record),wp.we.eq(write),rp.adr.eq(self.read_address)]
            self.read_data.append(rp.dat_r)
            self.sync += [If(self.start,previous.eq(cap.previous)),
                If(self.busy&(state==3),previous.eq(cap.read_data[7]),
                    If(stage==0,partial[:8].eq(rising)),
                    If(stage==1,partial[8:].eq(rising)))]
        self.sync += [
            If(self.start&~self.busy,
                self.busy.eq(1),self.done.eq(0),self.count.eq(0),
                index.eq(0),stage.eq(0),frame.eq(0),state.eq(1)),
            If(self.busy,
                If(state==1,state.eq(2)).Elif(state==2,state.eq(3)).Else(
                    If(stage==2,stage.eq(0),frame.eq(frame+1),self.count.eq(self.count+1))
                    .Else(stage.eq(stage+1)),
                    If(index==self.length-1,self.busy.eq(0),self.done.eq(1),state.eq(0))
                    .Else(index.eq(index+1),state.eq(1))))]
