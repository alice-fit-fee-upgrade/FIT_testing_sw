"""IPbus word-addressed CSR + frozen RAM aperture, sharing RPH1 with UART.

UART accesses have priority. A collided IPbus RAM read reselects lane/address;
side-effect CSR writes are issued once. IPbus strobe is held until ACK/ERR.
"""
from migen import *

class IPbusBridge(Module):
    def __init__(self, uart, clock_domain='sys',csr_words=64):
        self.address=Signal(32);self.wdata=Signal(32);self.strobe=Signal();self.write=Signal()
        self.rdata=Signal(32);self.ack=Signal();self.err=Signal()
        self.control=bus=Record([('address',16),('write_data',32),('read_data',32),('write',1)])
        address=Signal(32);data=Signal(32);writing=Signal();state=Signal(4)
        raw=Signal();phase=Signal();hdmi=Signal();memory=Signal();lane=Signal(4);index=Signal(12)
        hold=Signal(4);uart_active=uart.read|uart.write;available=Signal()
        self.sync += If(uart_active,hold.eq(8)).Elif(hold!=0,hold.eq(hold-1))
        self.comb += [available.eq(~uart_active&(hold==0)),memory.eq(raw|phase|hdmi),hdmi.eq(address[16:]==3),
            raw.eq(address[16:]==1),phase.eq(address[16:]==2),lane.eq(address[12:16]),index.eq(address[:12]),
            bus.address.eq(uart.address),bus.write_data.eq(uart.write_data),bus.write.eq(uart.write),
            uart.read_data.eq(bus.read_data),self.ack.eq((state==7)&self.strobe),self.err.eq((state==8)&self.strobe)]
        self.comb += If(available,
            If((state>=1)&(state<=6),
                bus.write.eq(0),bus.write_data.eq(data),bus.address.eq(address[:14]<<2),
                If(memory,
                    bus.address.eq(Mux(hdmi,0x168,Mux(phase,0xbc,0x50))),
                    If(state==1,bus.address.eq(Mux(hdmi,0x160,0x1c)),bus.write_data.eq(lane),bus.write.eq(1)),
                    If(state==2,bus.address.eq(Mux(hdmi,0x164,0x20)),bus.write_data.eq(index),bus.write.eq(1))
                ).Elif(state==3,bus.write.eq(writing))
            )
        )
        # The IPbus FSM can run at40MHz while the shared registers stay120MHz.
        # Compress every write-state level to ONE120MHz write pulse.
        previous_state=Signal(4);previous_write=Signal()
        level=Signal();self.comb += level.eq(available&(((state==1)|(state==2))&memory|((state==3)&~memory&writing)))
        self.sync += [previous_state.eq(state),previous_write.eq(level)]
        self.comb += If(available&(state>=1)&(state<=6),bus.write.eq(level&((state!=previous_state)|~previous_write)))
        sync_fsm=getattr(self.sync,clock_domain)
        sync_fsm += [
            If(state==0,
                If(self.strobe,address.eq(self.address),data.eq(self.wdata),writing.eq(self.write),state.eq(9))),
            If(state==9,
                If(((address<csr_words)|(Constant(int(csr_words>=96))&((address>>16)==3)&~writing&(address[12:16]<4)))|(((address>>16)==1)&~writing)|(((address>>16)==2)&~writing&(address[:12]<1365)),
                    state.eq(Mux((address>>16)==0,3,1))).Else(state.eq(8))),
            If((state>=1)&(state<=6),
                If(available,
                    If(state==1,state.eq(2)).Elif(state==2,state.eq(4))
                    .Elif(state==3,state.eq(4)).Elif(state==4,state.eq(5))
                    .Elif(state==5,state.eq(6)).Else(self.rdata.eq(bus.read_data),state.eq(7))
                ).Elif(memory,state.eq(1))
            ),
            # Upstream IPbus keeps STROBE high across a burst. ACK one cycle,
            # then idle one cycle while the master advances ADDRESS.
            If((state==7)|(state==8),state.eq(0))
        ]
