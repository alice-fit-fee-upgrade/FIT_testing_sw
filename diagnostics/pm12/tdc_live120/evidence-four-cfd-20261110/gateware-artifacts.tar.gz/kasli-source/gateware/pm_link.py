"""SFP1 PRBS diagnostic, LHC PLL1; existing SFP0 uses independent125MHz PLL0.

Nominal ref120MHz gives1.2Gb/s. Actual120.2361MHz gives1.202361Gb/s.
SFP2/SFP3 are not instantiated in this first link-qualification image.
"""
from types import SimpleNamespace
from migen import *
from migen.genlib.cdc import MultiReg
from misoc.cores.a7_gtp import QPLL,QPLLSettings
from liteeth.phy.serial.basex.wrappers.a7_gtp import A7_1000BASEX

class LHCBaseX(A7_1000BASEX):
    # Reuse the established /4 CDR/output-divider parameter set. Actual
    # serial rate is fixed by the external PLL configuration, not this key.
    linerate=1.25e9
    rx_clk_freq=120e6
    tx_clk_freq=120e6

class PMLink(Module):
    def __init__(self,platform,bus,mcx_clock,sys_clock,ipbus_clock,packet_bridge=False):
        fixed=platform.request('clk125_gtp');lhc=platform.request('cdr_clk_clean')
        f=Signal();l=Signal();ld=Signal()
        self.specials += [Instance('IBUFDS_GTE2',i_I=fixed.p,i_IB=fixed.n,i_CEB=0,o_O=f),
                          Instance('IBUFDS_GTE2',i_I=lhc.p,i_IB=lhc.n,i_CEB=0,o_O=l,o_ODIV2=ld)]
        platform.add_period_constraint(fixed.p,8.0)
        platform.add_period_constraint(lhc.p,1e9/120236100)
        # Physical REFCLK0=AG14 LHC; REFCLK1=AG16 fixed125. Keep PLL0
        # on fixed REFCLK1 and PLL1 on LHC REFCLK0. These are not swappable wires.
        self.submodules.qpll=qpll=QPLL(l,QPLLSettings(2,4,5,1),f,QPLLSettings(1,4,5,1))
        c=qpll.channels[0]
        self.ethernet_channel=SimpleNamespace(index=0,clk=c.clk,refclk=c.refclk,lock=c.lock,reset=Signal())
        self.bridge_channel=SimpleNamespace(index=0,clk=c.clk,refclk=c.refclk,lock=c.lock,reset=Signal())
        self.comb += c.reset.eq(self.ethernet_channel.reset|self.bridge_channel.reset)
        # Reproduce MCX->CKIN1 forwarding used by the existing Kasli target.
        # No synthesizer register writes or output-frequency changes here.
        cp=platform.request('cdr_clk');co=Signal()
        self.specials += [Instance('ODDR',i_C=mcx_clock,i_CE=1,i_D1=0,i_D2=1,o_Q=co),
                          Instance('OBUFDS',i_I=co,o_O=cp.p,o_OB=cp.n)]
        self.submodules.phy=phy=ClockDomainsRenamer({'eth_tx':'pm_tx','eth_rx':'pm_rx','eth_tx_half':'pm_tx_half','eth_rx_half':'pm_rx_half'})(LHCBaseX(qpll.channels[1],platform.request('sfp',1),120e6,with_csr=False,tx_cm_buf_type='BUFG',pcs_kwargs=dict(with_autoneg=False,sgmii=False)))
        # CTRL[2:0] loopback, [4] PRBS7,[5] PRBS15 RX mismatch,[6] inject TX
        # error continuously,[8] restart. Startup emits PRBS7 onto DAC.
        control=Signal(16,reset=0 if packet_bridge else 16)
        self.sync += If(bus.write & (bus.address==0x100),control.eq(bus.write_data))
        txc=Signal(16);rxc=Signal(16)
        self.specials += [MultiReg(control,txc,'pm_tx'),MultiReg(control,rxc,'pm_rx')]
        err=Signal()
        phy.gtp_params.update(i_LOOPBACK=control[:3],i_TXPRBSSEL=Mux(txc[4],1,0),
            i_RXPRBSSEL=Mux(rxc[5],2,Mux(rxc[4],1,0)),o_RXPRBSERR=err,
            i_TXPRBSFORCEERR=txc[6])
        self.comb += phy.reset.eq(control[8])
        if not packet_bridge:self.comb += [phy.sink.valid.eq(0),phy.sink.data.eq(0),phy.sink.last.eq(0)]
        # Counters count sampled RXPRBSERR cycles, not erroneous bits (not BER).
        errsys=Signal();txready=Signal();rxready=Signal()
        self.specials += [MultiReg(err,errsys),MultiReg(phy.tx_init.done,txready),MultiReg(phy.rx_init.done,rxready)]
        errors=Signal(32);tick=Signal(32)
        self.sync += [tick.eq(tick+1),If(control[4]&errsys,errors.eq(errors+1))]
        self.clock_domains.cd_pm_refmon=ClockDomain('pm_refmon',reset_less=True)
        self.specials += Instance('BUFG',i_I=ld,o_O=self.cd_pm_refmon.clk)
        rc=Signal(32);gray=Signal(32);gs=Signal(32);decoded=Signal(32)
        self.sync.pm_refmon += [rc.eq(rc+1),gray.eq((rc+1)^((rc+1)>>1))]
        self.specials += MultiReg(gray,gs)
        for i in range(32):self.comb += decoded[i].eq(gs[i]^decoded[i+1] if i<31 else gs[31])
        locks=Signal(2);self.specials += MultiReg(Cat(qpll.channels[0].lock,qpll.channels[1].lock),locks)
        self.read_data=Signal(32)
        self.comb += Case(bus.address,{0x100:self.read_data.eq(control),
            0x104:self.read_data.eq(Cat(locks,txready,rxready,errsys)),
            0x108:self.read_data.eq(errors),0x10c:self.read_data.eq(tick),
            0x110:self.read_data.eq(decoded),0x114:self.read_data.eq(0x504d4c31),
            0x118:self.read_data.eq(120236100),0x11c:self.read_data.eq(1202361000)})
        for clock in (phy.txoutclk,phy.rxoutclk):
            platform.add_period_constraint(clock,20e9/1202361000)
            platform.add_false_path_constraints(sys_clock,clock)
        platform.add_false_path_constraints(ipbus_clock,phy.txoutclk,phy.rxoutclk)
