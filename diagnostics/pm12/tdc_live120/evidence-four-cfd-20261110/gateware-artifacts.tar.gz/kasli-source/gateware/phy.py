"""Raw 40-bit GTP, TX buffer bypass, RX CDR locked to reference (UG482)."""
from migen import *
from migen.genlib.cdc import MultiReg
from migen.genlib.resetsync import AsyncResetSynchronizer
from vendor.gtp_init import GTPTXInit, GTPRXInit
from vendor.gtp_parameters import channel_parameters
from gateware.rates import line_settings


class RawGTP(Module):
    def __init__(self, qpll, pads, sys_hz, line_hz, rx_common_mode='gnd', startup_guard=False):
        rate = line_settings(int(line_hz/1000000))
        if rx_common_mode not in ('gnd', '800mv'):
            raise ValueError('Unsupported RX termination common mode')
        self.txdata = Signal(40)
        self.rxdata = Signal(40)
        self.txenable = Signal()
        self.loopback = Signal(3)
        self.restart = Signal()
        self.rx_source_ready = Signal(reset=1)
        self.rx_polarity = Signal()
        self.tx_polarity = Signal()
        self.cdr_hold = Signal(reset=1)
        self.afe_hold = Signal()
        self.txoutclk = Signal()
        self.rxoutclk = Signal()
        self.rx_mmcm_locked = Signal()
        rx_locked_sys = Signal()
        self.rx_clock_locked_sys = rx_locked_sys
        self.submodules.tx_init = tx_init = GTPTXInit(sys_hz)
        # 64000x40UI=2.56millionUI exceeds DS181 table55 TDLOCK max2.3millionUI.
        self.submodules.rx_init = rx_init = GTPRXInit(sys_hz, 64000 if startup_guard else 1024, startup_guard)
        self.comb += [tx_init.clk_path_ready.eq(1), qpll.reset.eq(tx_init.pllreset),
                      tx_init.plllock.eq(qpll.lock), tx_init.restart.eq(self.restart),
                      rx_init.tx_init_done.eq(tx_init.done & self.rx_source_ready if startup_guard else tx_init.done),
                      rx_init.clock_stable.eq(rx_locked_sys if startup_guard else 1), rx_init.restart.eq(self.restart)]
        rxphaligndone = Signal()
        rx_polarity = Signal()
        self.specials += MultiReg(self.rx_polarity, rx_polarity, 'rx')
        params = channel_parameters(self, tx_init, rx_init, pads, self.txdata, self.rxdata, rxphaligndone)
        params.update(
            # UG482 table4-3 (ground) / table4-5 (programmable800mV).
            # Both modes require external AC coupling on both RX conductors.
            p_RX_CM_SEL=3 if rx_common_mode == '800mv' else 1,
            p_RX_CM_TRIM=10 if rx_common_mode == '800mv' else 0,
            p_RXLPM_INCM_CFG=1 if rx_common_mode == '800mv' else 0,
            p_RXLPM_IPCM_CFG=0 if rx_common_mode == '800mv' else 1,
            p_RX_DATA_WIDTH=40, p_TX_DATA_WIDTH=40,
            p_RXOUT_DIV=rate['out_div'], p_TXOUT_DIV=rate['out_div'],
            p_RXCDR_CFG=rate['cdr_cfg'],
            p_ALIGN_MCOMMA_DET='FALSE', p_ALIGN_PCOMMA_DET='FALSE',
            i_RXCOMMADETEN=0, i_RXCDRHOLD=self.cdr_hold,
            i_RXOSHOLD=self.afe_hold, i_RXLPMHFHOLD=self.afe_hold, i_RXLPMLFHOLD=self.afe_hold,
            # Preserve the documented DRP/PMA reset handshake. MMCM qualification
            # gates phase alignment below, rather than gating this handshake pin.
            i_RXUSERRDY=rx_init.rxuserrdy,
            i_LOOPBACK=self.loopback,
            i_TXUSRCLK=ClockSignal('tx_fast'), i_TXUSRCLK2=ClockSignal('sys'),
            i_RXUSRCLK=ClockSignal('rx_fast'), i_RXUSRCLK2=ClockSignal('rx'),
            i_RXPOLARITY=rx_polarity, i_TXPOLARITY=self.tx_polarity,
            i_TXDATA=Cat(*[self.txdata[10*i:10*i+8] for i in range(4)]),
            i_TXCHARDISPVAL=Cat(*[self.txdata[10*i+8] for i in range(4)]),
            i_TXCHARDISPMODE=Cat(*[self.txdata[10*i+9] for i in range(4)]),
            o_RXDATA=Cat(*[self.rxdata[10*i:10*i+8] for i in range(4)]),
            o_RXCHARISK=Cat(*[self.rxdata[10*i+8] for i in range(4)]),
            o_RXDISPERR=Cat(*[self.rxdata[10*i+9] for i in range(4)]),
            i_PLL0CLK=qpll.clk, i_PLL0REFCLK=qpll.refclk,
            i_PLL1CLK=0, i_PLL1REFCLK=0, i_RXSYSCLKSEL=0, i_TXSYSCLKSEL=0,
        )
        self.specials += Instance('GTPE2_CHANNEL', **params)
        self.clock_domains.cd_rx_fast = ClockDomain('rx_fast', reset_less=True)
        self.clock_domains.cd_rx = ClockDomain('rx')
        rx_in, fb, fb_buf, fast, slow = [Signal() for _ in range(5)]
        # RXOUTCLKPMA is line rate / 20. An MMCM creates aligned /1 and /2.
        self.specials += [
            Instance('BUFG', i_I=self.rxoutclk, o_O=rx_in),
            Instance('MMCME2_BASE', p_CLKIN1_PERIOD=20e9/line_hz,
                p_CLKFBOUT_MULT_F=float(rate['rx_mult']), p_DIVCLK_DIVIDE=1,
                p_CLKOUT0_DIVIDE_F=float(rate['rx_fast_div']), p_CLKOUT1_DIVIDE=rate['rx_slow_div'],
                i_CLKIN1=rx_in, i_CLKFBIN=fb_buf, o_CLKFBOUT=fb,
                o_CLKOUT0=fast, o_CLKOUT1=slow, o_LOCKED=self.rx_mmcm_locked,
                i_RST=~qpll.lock, i_PWRDWN=0),
            Instance('BUFG', i_I=fb, o_O=fb_buf),
            Instance('BUFG', i_I=fast, o_O=self.cd_rx_fast.clk),
            Instance('BUFG', i_I=slow, o_O=self.cd_rx.clk),
        ]
        self.ready = Signal()
        pll_locked_sys = Signal()
        self.specials += MultiReg(self.rx_mmcm_locked, rx_locked_sys), MultiReg(qpll.lock, pll_locked_sys)
        # Register the decoded FSM-ready level before crossing to RX. A decoded
        # state signal must not feed a synchronizer through combinational logic.
        self.sync += self.ready.eq(rx_init.done & tx_init.done & rx_locked_sys & pll_locked_sys)
        # Preserve the toggle handshake across RX/MMCM component restarts.
        # Resetting only the RX half could otherwise replay an old request or
        # acknowledge stale data. Clock gaps invalidate calibration; ready
        # invalidates an in-flight capture. Full system reset clears both halves.
        self.specials += AsyncResetSynchronizer(self.cd_rx, ResetSignal('sys'))
