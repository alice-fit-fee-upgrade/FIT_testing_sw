"""Export a hash-bound timing/DRC guard from routed Vivado reports."""
import argparse
import hashlib
import json
from pathlib import Path
import re


def main():
    p=argparse.ArgumentParser(); p.add_argument('build_dir'); a=p.parse_args()
    b=Path(a.build_dir)
    values=json.loads((b/'qualification-values.json').read_text())
    timing=(b/'qualification-timing.rpt').read_text()
    # Check timing warnings individually. Async UART/I2C inputs terminate in
    # synchronizers; LEDs/debug outputs have no synchronous external receiver.
    unconstrained=re.search(r'There are (\d+) register/latch pins with no clock',timing)
    values['register_pins_without_clock']=int(unconstrained[1]) if unconstrained else None
    values['bitstream_sha256']=hashlib.sha256((b/'phase_tester.bit').read_bytes()).hexdigest()
    values['manifest_sha256']=hashlib.sha256((b/'manifest.json').read_bytes()).hexdigest()
    cdc=(b/'qualification-cdc.rpt').read_text()
    critical=re.findall(r'^CDC-\d+\s+Critical\s+(\d+)',cdc,re.MULTILINE)
    values['cdc_critical']=sum(map(int,critical))
    values['pass']=values['wns_ns']>=0 and values['whs_ns']>=0 and values['drc_errors']==0 and values['register_pins_without_clock']==0 and values['cdc_critical']==0
    (b/'qualification.json').write_text(json.dumps(values,indent=2)+'\n')
    print(json.dumps(values,indent=2))
    if not values['pass']: raise SystemExit(1)


if __name__=='__main__':main()
