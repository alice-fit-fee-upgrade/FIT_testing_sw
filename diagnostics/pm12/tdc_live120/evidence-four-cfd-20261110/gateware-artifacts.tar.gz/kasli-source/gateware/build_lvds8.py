"""Build complete Kasli-DIOT LVDS x8 UART instrument; outputs boot disabled."""
import argparse,hashlib,json
from pathlib import Path
from migen import *
from migen.genlib.cdc import MultiReg
from migen.genlib.resetsync import AsyncResetSynchronizer
from migen.build.generic_platform import Pins,IOStandard,Subsignal
from migen.build.platforms.sinara.kasli_diot import Platform
from misoc.cores.uart.core import RS232PHY
from gateware.core import RegisterProtocol
from gateware.lvds8 import LVDSInstrument
from gateware.lvds8_control import Control

class Top(Module):
    def __init__(self,platform,slot,profile,depth):
        for name in ['sys','sample','ser_tx','ser_rx']:
            setattr(self.clock_domains,'cd_'+name,ClockDomain(name))
        reference=Signal();buffered=Signal()
        coherent=profile in ('lhc120','external120')
        sys_hz=120e6 if coherent else 125e6
        if profile=='lhc120':
            # Use the already-supported Si5324 MGT output; ODIV2 supplies 60 MHz.
            pads=platform.request('cdr_clk_clean');period=1e9/60e6;mult=16.0
            self.specials += Instance('IBUFDS_GTE2',i_I=pads.p,i_IB=pads.n,i_CEB=0,o_ODIV2=reference)
            # Same external MCX -> CKIN1 forwarding as the GTP instrument.
            ci=platform.request('mcx_clkin');co=platform.request('cdr_clk')
            cin=Signal();cio=Signal();cout=Signal()
            self.specials += [Instance('IBUFDS',i_I=ci.p,i_IB=ci.n,o_O=cin),
                Instance('BUFIO',i_I=cin,o_O=cio),
                Instance('ODDR',i_C=cio,i_CE=1,i_D1=0,i_D2=1,o_Q=cout),
                Instance('OBUFDS',i_I=cout,o_O=co.p,o_OB=co.n)]
            platform.add_period_constraint(ci.p,25.0)
        elif profile=='external120':
            pads=platform.request('mcx_clkin');period=1e9/120e6;mult=8.0
            self.specials += Instance('IBUFDS',i_I=pads.p,i_IB=pads.n,o_O=reference)
        elif profile=='external40':
            pads=platform.request('mcx_clkin');period=25.0;mult=25.0
            self.specials += Instance('IBUFDS',i_I=pads.p,i_IB=pads.n,o_O=reference)
        else:
            pads=platform.request('clk125_gtp');period=16.0;mult=16.0
            self.specials += Instance('IBUFDS_GTE2',i_I=pads.p,i_IB=pads.n,i_CEB=0,o_ODIV2=reference)
        platform.add_period_constraint(pads.p,25.0 if profile=='external40' else 1e9/120e6 if coherent else 8.0)
        self.specials += Instance('BUFG',i_I=reference,o_O=buffered)
        locks=[]
        for suffix,fast,slow in [('tx',self.cd_ser_tx,self.cd_sys),('rx',self.cd_ser_rx,self.cd_sample)]:
            feedback=Signal();fb=Signal();f=Signal();s=Signal();locked=Signal();locks.append(locked)
            self.specials += [Instance('MMCME2_BASE',name='lvds_mmcm_'+suffix,
                p_CLKIN1_PERIOD=period,p_CLKFBOUT_MULT_F=mult,p_DIVCLK_DIVIDE=1,
                p_CLKOUT0_DIVIDE_F=2.0,p_CLKOUT1_DIVIDE=8,
                i_CLKIN1=buffered,i_CLKFBIN=fb,o_CLKFBOUT=feedback,
                i_RST=0,i_PWRDWN=0,o_LOCKED=locked,o_CLKOUT0=f,o_CLKOUT1=s),
                Instance('BUFG',i_I=feedback,o_O=fb),Instance('BUFG',i_I=f,o_O=fast.clk),
                Instance('BUFG',i_I=s,o_O=slow.clk),AsyncResetSynchronizer(slow,~locked)]
        rx_lock=Signal();self.specials += MultiReg(locks[1],rx_lock)
        ready=Signal();self.comb += ready.eq(locks[0]&rx_lock)
        resources=[]
        for lane in range(16):
            name='d%d'%lane+('_cc' if lane in (0,8) else '')
            resources.append(('lvds',lane,Subsignal('p',Pins('diot%d:%s_p'%(slot-1,name))),
                              Subsignal('n',Pins('diot%d:%s_n'%(slot-1,name))),IOStandard('LVDS_25')))
        platform.add_extension(resources)
        pairs=[platform.request('lvds',lane) for lane in range(16)]
        self.submodules.instrument=inst=LVDSInstrument([(p.p,p.n) for p in pairs],depth)
        self.submodules.uart=uart=RS232PHY(platform.request('serial'),sys_hz,baudrate=1000000)
        self.submodules.bus=bus=RegisterProtocol(uart)
        self.submodules.control=ctl=Control(inst.bank,bus,ready,depth,slot,125e6 if profile=='internal125' else 40e6,
            sample_hz=int(sys_hz*8),period_bins=24 if coherent else 25,
            profile_id={'internal125':0,'external40':1,'lhc120':2,'external120':3}[profile])
        self.comb += inst.output_mask.eq(ctl.output_mask&Replicate(ctl.enabled,16))
        platform.add_platform_command('set_false_path -to [get_pins -of_objects [get_cells -hier -filter {{mr_ff == TRUE}}] -filter {{REF_PIN_NAME == D}}]')
        # Incoming strobe timing is deliberately measured asynchronously.
        # Bound only the input datapath, not fictitious synchronous setup/hold.
        platform.add_platform_command('set_max_delay -datapath_only -from [get_ports {{lvds_p*}}] -to [get_cells -hier -filter {{REF_NAME == ISERDESE2}}] 2.0')
        # A pad is either driven or received. The input buffer is disabled while
        # its own OSERDES drives; local OQ/TQ->RX feedback is not a data path.
        # External pad->RX paths remain constrained above. No inter-lane cuts.
        for lane in range(16):
            suffix='' if lane==0 else '_%d'%lane
            platform.add_platform_command(
                'set_false_path -through [get_pins {{OSERDESE2%s/OQ OSERDESE2%s/TQ}}] -to [get_pins ISERDESE2%s/D]' % (suffix,suffix,suffix))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--slot',type=int,choices=range(1,9),default=6)
    p.add_argument('--profile',choices=['internal125','external40','lhc120','external120'],default='internal125')
    p.add_argument('--output',default='build/lvds8-slot6-125');p.add_argument('--build',action='store_true')
    a=p.parse_args();platform=Platform(hw_rev='v1.0')
    platform.toolchain.bitstream_commands=[s.replace('0xffffffff','0x4c563831') for s in platform.toolchain.bitstream_commands]
    top=Top(platform,a.slot,a.profile,4096);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    manifest=dict(part=platform.device,slot=a.slot,profile=a.profile,parallel_hz=120000000 if a.profile in ('lhc120','external120') else 125000000,
                  nominal_sample_ps=1e12/960e6 if a.profile in ('lhc120','external120') else 1000,
                  period_bins=24 if a.profile in ('lhc120','external120') else 25,
                  source_sha256={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path('gateware')/n for n in ['core.py','lvds8.py','lvds8_control.py','lvds8_phase.py','build_lvds8.py']]},hardware_validated=False)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    platform.build(top,build_dir=str(out),build_name='lvds8',run=a.build)
    manifest['generated_sha256']={name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ['lvds8.v','lvds8.xdc']}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
