"""Concurrent x8 LVDS TX/RX backend, bit0 earliest; clocks supplied externally.

Domains: sys=control/player, sample=RX parallel, ser_tx/ser_rx=4x respective
parallel clocks. Independent RX clock phase permits sampler scans with fixed TX.
No pin/direction/mux changes are performed by this component.
"""
from migen import *
from gateware.core import PatternPlayer, WindowCapture


class SelectIO8(Module):
    def __init__(self, pad_p, pad_n):
        self.tx = Signal(8)
        self.rx = Signal(8)
        self.oe = Signal()  # reset/configuration defaults to input
        out = Signal(); inp = Signal(); tristate=Signal()
        self.specials += Instance('OSERDESE2',
            p_DATA_RATE_OQ='DDR', p_DATA_WIDTH=8, p_DATA_RATE_TQ='BUF',
            p_TRISTATE_WIDTH=1,p_INIT_OQ=0,p_INIT_TQ=1,
            i_CLK=ClockSignal('ser_tx'),i_CLKDIV=ClockSignal('sys'),
            i_RST=ResetSignal('sys'),i_OCE=1,i_TCE=1,i_T1=~self.oe,
            **{'i_D%d'%(n+1):self.tx[n] for n in range(8)},o_OQ=out,o_TQ=tristate)
        self.specials += Instance('IOBUFDS_INTERMDISABLE',p_DIFF_TERM='TRUE',
            p_IBUF_LOW_PWR='FALSE',p_USE_IBUFDISABLE='TRUE',
            i_I=out,i_T=tristate,i_IBUFDISABLE=~tristate,i_INTERMDISABLE=~tristate,
            io_IO=pad_p,io_IOB=pad_n,o_O=inp)
        self.specials += Instance('ISERDESE2',p_DATA_RATE='DDR',p_DATA_WIDTH=8,
            p_INTERFACE_TYPE='NETWORKING',p_NUM_CE=1,
            i_D=inp,i_CLK=ClockSignal('ser_rx'),i_CLKB=~ClockSignal('ser_rx'),
            i_CLKDIV=ClockSignal('sample'),i_CE1=1,i_CE2=1,i_BITSLIP=0,
            i_RST=ResetSignal('sample'),
            **{'o_Q%d'%(n+1):self.rx[7-n] for n in range(8)})


class ParallelBank(Module):
    """Logic side of the x8 PHY, directly simulatable without I/O primitives.

    A single ARM/length/ready fanout aligns all capture banks. External software
    must wait all-done and verify equal start_sample/count/generation before
    interpreting cross-channel phase. Sources share sample domain and reset.
    """
    def __init__(self, channels=12, depth=4096):
        if channels<1:raise ValueError('nonempty channel bank required')
        self.arm=Signal();self.length=Signal(max=depth+1,reset=depth)
        self.ready=Signal();self.address=Signal(max=depth)
        self.submodules.player=PatternPlayer(depth,word_width=channels*8)
        self.captures=[];self.rx=[];self.tx=[]
        for channel in range(channels):
            cap=ClockDomainsRenamer({'rx':'sample'})(WindowCapture(depth,word_width=8))
            setattr(self.submodules,'capture%d'%channel,cap)
            self.captures.append(cap);self.rx.append(cap.data)
            self.tx.append(self.player.data[channel*8:(channel+1)*8])
            self.comb += [cap.arm.eq(self.arm),cap.request_length.eq(self.length),
                          cap.rx_ready.eq(self.ready),cap.read_address.eq(self.address)]


class LVDSInstrument(Module):
    def __init__(self,pads,depth=4096):
        pads=list(pads)
        self.submodules.bank=bank=ParallelBank(len(pads),depth)
        self.output_mask=Signal(len(pads))
        for n,(p,n_pad) in enumerate(pads):
            phy=SelectIO8(p,n_pad)
            setattr(self.submodules,'phy%d'%n,phy)
            self.comb += [phy.tx.eq(bank.tx[n]),bank.rx[n].eq(phy.rx),
                          phy.oe.eq(self.output_mask[n]&bank.ready)]
