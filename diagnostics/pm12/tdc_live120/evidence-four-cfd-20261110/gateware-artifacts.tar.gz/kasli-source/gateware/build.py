"""Build standalone Kasli-DIOT pulse player and raw timestamp capture."""
import argparse
import hashlib
import json
from types import SimpleNamespace
from pathlib import Path
from migen import *
from migen.fhdl.specials import Tristate
from migen.genlib.cdc import MultiReg
from migen.genlib.resetsync import AsyncResetSynchronizer
from migen.build.platforms.sinara.kasli_diot import Platform
from misoc.cores.a7_gtp import QPLL, QPLLSettings
from misoc.cores.uart.core import RS232PHY
from gateware.core import PatternPlayer, WindowCapture, RegisterProtocol
from gateware.phy import RawGTP
from gateware.rates import line_settings


class Instrument(Module):
    def __init__(self, platform, ref_hz, ref_source, sfp_index, depth, rx_common_mode='gnd', peer_sfp=None, forward_mcx=True, line_mbps=None, startup_guard=False):
        if peer_sfp is not None and (peer_sfp not in (0,1,2) or peer_sfp == sfp_index):
            raise ValueError('External cable peer must be a different safe SFP0..2')
        rate = line_settings(int(ref_hz*50/1000000) if line_mbps is None else line_mbps)
        if ref_hz != rate['ref_hz']:
            raise ValueError('Reference frequency does not match requested line profile')
        line_hz = rate['line_hz']
        sys_hz = line_hz/40
        self.clock_domains.cd_sys = ClockDomain('sys')
        self.clock_domains.cd_tx_fast = ClockDomain('tx_fast', reset_less=True)
        # Same MCX -> FPGA -> Si5324 CKIN1 path as the existing ARTIQ target.
        # A clock connected to MCX does not reach the synthesizer without this.
        clock_output = platform.request('cdr_clk')
        if forward_mcx:
            clock_input = platform.request('mcx_clkin')
            input_se, input_io, output_se = Signal(), Signal(), Signal()
            platform.add_period_constraint(clock_input.p, 25.0)
            self.specials += [
                Instance('IBUFDS', i_I=clock_input.p, i_IB=clock_input.n, o_O=input_se),
                Instance('BUFIO', i_I=input_se, o_O=input_io),
                Instance('ODDR', i_C=input_io, i_CE=1, i_D1=0, i_D2=1, o_Q=output_se),
                Instance('OBUFDS', i_I=output_se, o_O=clock_output.p, o_OB=clock_output.n),
            ]
        else:
            # Isolate external MCX activity from fabric/Si5324 clock forwarding.
            # No MCX input buffer, clock network or ODDR; CKIN1 gets static levels.
            self.specials += Instance('OBUFDS', i_I=0, o_O=clock_output.p, o_OB=clock_output.n)
        pads = platform.request(ref_source)
        ref, fabric, mmcm_in, fb, fb_buf, fast, slow, locked = [Signal() for _ in range(8)]
        platform.add_period_constraint(pads.p, 1e9/ref_hz)
        self.specials += [
            Instance('IBUFDS_GTE2', i_I=pads.p, i_IB=pads.n, i_CEB=0, o_O=ref, o_ODIV2=fabric),
            Instance('BUFH', i_I=fabric, o_O=mmcm_in),
            Instance('MMCME2_BASE', p_CLKIN1_PERIOD=2e9/ref_hz,
                p_CLKFBOUT_MULT_F=float(rate['sys_mult']), p_DIVCLK_DIVIDE=1,
                p_CLKOUT0_DIVIDE_F=float(rate['sys_fast_div']), p_CLKOUT1_DIVIDE=rate['sys_slow_div'],
                i_CLKIN1=mmcm_in, i_CLKFBIN=fb_buf, o_CLKFBOUT=fb,
                o_CLKOUT0=fast, o_CLKOUT1=slow, o_LOCKED=locked, i_RST=0, i_PWRDWN=0),
            Instance('BUFG', i_I=fb, o_O=fb_buf),
            Instance('BUFG', i_I=fast, o_O=self.cd_tx_fast.clk),
            Instance('BUFG', i_I=slow, o_O=self.cd_sys.clk),
            AsyncResetSynchronizer(self.cd_sys, ~locked),
        ]
        self.submodules.qpll = QPLL(ref, QPLLSettings(0b001, rate['pll_fbdiv'], rate['pll_fbdiv_45'], 1))
        channel = self.qpll.channels[0]
        if peer_sfp is None:
            receiver_pll = channel
        else:
            # Both TX initialization controllers request the SAME quad PLL0.
            # Separate request signals avoid multiple drivers on its reset.
            receiver_pll = SimpleNamespace(clk=channel.clk, refclk=channel.refclk,
                                           lock=channel.lock, reset=Signal())
            sender_pll = SimpleNamespace(clk=channel.clk, refclk=channel.refclk,
                                         lock=channel.lock, reset=Signal())
            self.comb += channel.reset.eq(receiver_pll.reset | sender_pll.reset)
            self.submodules.peer = peer = ClockDomainsRenamer({'rx':'rx_peer','rx_fast':'rx_peer_fast'})(
                RawGTP(sender_pll, platform.request('sfp', peer_sfp), sys_hz, line_hz, rx_common_mode, startup_guard))
            platform.add_period_constraint(peer.rxoutclk, 20e9/line_hz)
        self.submodules.phy = phy = RawGTP(receiver_pll, platform.request('sfp', sfp_index), sys_hz, line_hz, rx_common_mode, startup_guard)
        self.comb += phy.rx_source_ready.eq(peer.tx_init.done if peer_sfp is not None else 1)
        tx_ready = phy.tx_init.done if peer_sfp is None else phy.tx_init.done & peer.tx_init.done
        self.submodules.player = player = PatternPlayer(depth)
        self.submodules.capture = capture = WindowCapture(depth)
        self.submodules.uart = uart = RS232PHY(platform.request('serial'), sys_hz, baudrate=1000000)
        self.submodules.protocol = bus = RegisterProtocol(uart)
        control = Signal(8, reset=0x20)
        tx_address = Signal(max=depth)
        tx_low = Signal(32)
        tx_high = Signal(8)
        cap_address = Signal(max=depth)
        pattern_length = Signal(max=depth+1, reset=15)
        window_length = Signal(max=depth+1, reset=depth)
        rx_ready = Signal()
        rx_ready_sys = Signal()
        pll_lock_sys = Signal()
        rx_lock_sys = Signal()
        self.specials += MultiReg(phy.ready, rx_ready, 'rx'), MultiReg(phy.ready, rx_ready_sys)
        self.specials += MultiReg(self.qpll.channels[0].lock, pll_lock_sys), MultiReg(phy.rx_mmcm_locked, rx_lock_sys)
        if peer_sfp is not None:
            self.comb += [peer.txdata.eq(player.data), peer.txenable.eq(control[0] & tx_ready & ~control[1]),
                          peer.loopback.eq(0), peer.rx_polarity.eq(0), peer.tx_polarity.eq(control[3]),
                          peer.cdr_hold.eq(1), peer.afe_hold.eq(0),
                          peer.restart.eq(bus.write & (bus.address == 0x0008) & bus.write_data[4])]
        self.comb += [player.enable.eq(control[0]), player.ready.eq(tx_ready),
                      phy.txdata.eq(player.data), phy.txenable.eq(control[0] & tx_ready & control[1] if peer_sfp is not None else control[0] & tx_ready),
                      phy.loopback.eq(Mux(control[1], 0b010, 0)),
                      phy.rx_polarity.eq(control[2]), phy.tx_polarity.eq(control[3]),
                      phy.cdr_hold.eq(control[5]),
                      phy.afe_hold.eq(control[6]),
                      phy.restart.eq(bus.write & (bus.address == 0x0008) & bus.write_data[4]),
                      capture.data.eq(phy.rxdata), capture.rx_ready.eq(rx_ready),
                      player.write_address.eq(tx_address), player.write_data.eq(Cat(tx_low, tx_high)),
                      player.write_bank.eq(~player.active_bank),
                      player.write.eq(bus.write & (bus.address == 0x001c)),
                      player.commit.eq(bus.write & (bus.address == 0x0024)),
                      player.commit_length.eq(pattern_length),
                      capture.arm.eq(bus.write & (bus.address == 0x0034)),
                      capture.request_length.eq(window_length), capture.read_address.eq(cap_address)]
        self.sync += [
            If(bus.write,
                Case(bus.address, {
                    0x0008: control.eq(bus.write_data & 0x6f),
                    0x0010: tx_address.eq(bus.write_data),
                    0x0014: tx_low.eq(bus.write_data),
                    0x0018: tx_high.eq(bus.write_data),
                    0x0020: pattern_length.eq(bus.write_data),
                    0x0030: window_length.eq(bus.write_data),
                    0x0050: cap_address.eq(bus.write_data),
                })
            )
        ]
        # Open-drain bit-bang access to the four existing I2C buses. Never drive
        # high; all pins release after configuration. Clock programming is host-side.
        i2c_low = Signal(8)
        i2c_input = Signal(8)
        for i in range(4):
            pins = platform.request('i2c', i)
            for j, pin in enumerate((pins.scl, pins.sda)):
                value = Signal()
                self.specials += Tristate(pin, 0, i2c_low[2*i+j], value)
                self.specials += MultiReg(value, i2c_input[2*i+j])
        self.sync += If(bus.write & (bus.address == 0x0060), i2c_low.eq(bus.write_data))
        rx_debug_sync = Signal(8)
        self.comb += rx_debug_sync.eq(Cat(phy.rx_init.rxresetdone_sys,phy.rx_init.rxpmaresetdone_sys,
            phy.rx_init.rxdlysresetdone_sys,phy.rx_init.rxsyncdone_sys,phy.rx_init.gtrxreset,
            phy.rx_init.rxuserrdy,phy.rx_clock_locked_sys,phy.rx_init.clock_stable))
        status = Cat(pll_lock_sys, tx_ready, rx_ready_sys,
                     rx_lock_sys, player.active_bank, player.pending,
                     capture.busy, capture.done, player.error, capture.error)
        self.comb += [bus.read_data.eq(0xffffffff),
            Case(bus.address, {
                0x0000: bus.read_data.eq(0x4b505431),  # KPT1
                0x0004: bus.read_data.eq(0x00010006 if startup_guard else (0x00010004 if peer_sfp is not None or rate['line_mbps'] == 1250 else 0x00010002)),
                0x0008: bus.read_data.eq(control),
                0x000c: bus.read_data.eq(status),
                0x0010: bus.read_data.eq(tx_address),
                0x0020: bus.read_data.eq(player.length),
                0x0028: bus.read_data.eq(player.loops),
                0x0030: bus.read_data.eq(window_length),
                0x0038: bus.read_data.eq(capture.count),
                0x003c: bus.read_data.eq(capture.capture_id),
                0x0040: bus.read_data.eq(capture.start_sample[:32]),
                0x0044: bus.read_data.eq(capture.start_sample[32:]),
                0x0048: bus.read_data.eq(capture.previous),
                0x0050: bus.read_data.eq(cap_address),
                0x0054: bus.read_data.eq(capture.read_data[:32]),
                0x0058: bus.read_data.eq(capture.read_data[32:]),
                0x0060: bus.read_data.eq(i2c_low),
                0x0064: bus.read_data.eq(i2c_input),
                0x0070: bus.read_data.eq(int(ref_hz)),
                0x0074: bus.read_data.eq(int(line_hz/1000000)),
                0x0078: bus.read_data.eq(depth),
                0x007c: bus.read_data.eq(sfp_index),
                0x0080: bus.read_data.eq(0xffffffff if peer_sfp is None else peer_sfp),
                0x0084: bus.read_data.eq(int(startup_guard)),
                0x0088: bus.read_data.eq(Cat(rx_debug_sync,phy.rx_init.phase,phy.rx_init.cdr_wait_done)),
                0x008c: bus.read_data.eq(phy.rx_init.watchdog_count),
            })]
        self.comb += [platform.request('user_led', 0).eq(phy.tx_init.done),
                      platform.request('user_led', 1).eq(rx_ready_sys),
                      platform.request('user_led', 2).eq(capture.busy),
                      platform.request('error_led', 0).eq(player.error | capture.error)]
        platform.add_period_constraint(phy.rxoutclk, 20e9/line_hz)
        # Only CDC synchronizer inputs and asynchronous resets are false paths.
        # RAM ownership crosses by handshake; capture RAM is read only frozen.
        # Migen's Vivado backend constrains the first MultiReg stage and the
        # AsyncResetSynchronizer pins; no blanket clock-domain exclusions.
        # This pinned Migen version puts mr_ff on the first-stage *register*.
        # Its legacy get_nets query misses vector synchronizers in Vivado 2025.
        platform.add_platform_command(
            'set_false_path -to [get_pins -of_objects [get_cells -hier -filter {{mr_ff == TRUE}}] -filter {{REF_PIN_NAME == D}}]')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--ref-mhz', type=float, choices=[120,125], default=120)
    p.add_argument('--ref-source', choices=['clk125_gtp','cdr_clk_clean'], default='cdr_clk_clean')
    p.add_argument('--sfp', type=int, choices=[0,1,2], default=1,
                   help='Logical RX channel; reported faulty SFP3 is excluded')
    p.add_argument('--depth', type=int, default=4096)
    p.add_argument('--output', default='build/phase120')
    p.add_argument('--build', action='store_true')
    p.add_argument('--rx-common-mode', choices=['gnd','800mv'], default='gnd',
                   help='RX termination voltage;800mv requires confirmed AC coupling before loading')
    p.add_argument('--peer-sfp', type=int, choices=[0,1,2],
                   help='External cable source; selected --sfp is RX, ownTX stays inhibited')
    p.add_argument('--no-mcx-forward', action='store_true',
                   help='Fixed125 diagnostic: omit externalMCX input/forwarding, holdSiCKIN1 static')
    p.add_argument('--line-mbps', type=int, choices=[1250,6000,6250],
                   help='Serialrate;1250Mb/s is1GbE physical rate, withrawPRBS ratherthanEthernet')
    p.add_argument('--rx-startup-guard', action='store_true',
                   help='GateRXUSERRDY/alignment onMMCMlock and wait2.56millionUI forCDR afterRXRESETDONE')
    a = p.parse_args()
    if a.depth < 16 or a.depth & (a.depth-1): p.error('depth must be a power of two >=16')
    if a.peer_sfp == a.sfp: p.error('--peer-sfp must differ from --sfp')
    if a.no_mcx_forward and (a.ref_source != 'clk125_gtp' or a.ref_mhz != 125):
        p.error('--no-mcx-forward requires fixed125MHz oscillator')
    rate = line_settings(int(a.ref_mhz*50) if a.line_mbps is None else a.line_mbps)
    if rate['ref_hz'] != a.ref_mhz*1000000: p.error('Lineprofile/reference mismatch')
    platform = Platform(hw_rev='v1.0')
    platform.toolchain.bitstream_commands = [
        x.replace('0xffffffff','0x4b505431') for x in platform.toolchain.bitstream_commands]
    top = Instrument(platform, a.ref_mhz*1e6, a.ref_source, a.sfp, a.depth, a.rx_common_mode, a.peer_sfp, not a.no_mcx_forward, rate['line_mbps'], a.rx_startup_guard)
    out = Path(a.output)
    out.mkdir(parents=True, exist_ok=True)
    manifest = {'part':platform.device,'ref_mhz':a.ref_mhz,'ref_source':a.ref_source,
                'sfp':a.sfp,'depth':a.depth,'line_mbps':rate['line_mbps'],
                'ui_ps':1e6/rate['line_mbps'],'hardware_validated':False,
                'rx_common_mode':a.rx_common_mode,
                'peer_sfp':a.peer_sfp,
                'mcx_forwarded':not a.no_mcx_forward,
                'peer_internal_loopback':a.peer_sfp is not None,
                'rate_settings':rate,
                'rx_startup_guard':a.rx_startup_guard,
                'rx_userrdy_clock_gated':False,
                'cdr_wait_ui':2560000 if a.rx_startup_guard else 40960,
                'rx_init_watchdog_ms':16 if a.rx_startup_guard else 4,
                'rx_external_ac_coupling_required':True,
                'source_sha256':{str(f):hashlib.sha256(f.read_bytes()).hexdigest()
                                 for d in ['gateware','vendor'] for f in Path(d).glob('*.py')}}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    platform.build(top, build_dir=str(out), build_name='phase_tester', run=a.build)


if __name__ == '__main__': main()
