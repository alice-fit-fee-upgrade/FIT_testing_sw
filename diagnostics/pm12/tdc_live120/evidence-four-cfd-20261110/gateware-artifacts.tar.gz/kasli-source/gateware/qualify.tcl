# Usage: vivado -mode batch -source ../../gateware/qualify.tcl
open_checkpoint phase_tester_route.dcp
report_timing_summary -check_timing_verbose -report_unconstrained -file qualification-timing.rpt
report_drc -file qualification-drc.rpt
report_cdc -details -file qualification-cdc.rpt
report_utilization -file qualification-utilization.rpt
set setup [get_timing_paths -delay_type max -max_paths 1]
set hold [get_timing_paths -delay_type min -max_paths 1]
set wns [get_property SLACK $setup]
set whs [get_property SLACK $hold]
set errors [get_drc_violations -filter {SEVERITY == Error}]
set f [open qualification-values.json w]
puts $f "{\"wns_ns\": $wns, \"whs_ns\": $whs, \"drc_errors\": [llength $errors]}"
close $f
exit
