# Incremental exception refresh on unchanged routed RTL. Cold builds include
# the same exceptions directly in build_lvds8.py.
open_checkpoint lvds8_route.dcp
for {set n 0} {$n < 16} {incr n} {
 set suffix [expr {$n==0 ? "" : "_$n"}]
 set pins [get_pins [list OSERDESE2${suffix}/OQ OSERDESE2${suffix}/TQ]]
 if {[llength $pins]!=2} {error "Missing local serializer output pins $n"}
 set_false_path -through $pins -to [get_pins ISERDESE2${suffix}/D]
}
report_timing_summary -check_timing_verbose -report_unconstrained -file qualification-timing.rpt
report_drc -file qualification-drc.rpt
report_cdc -details -file qualification-cdc.rpt
report_utilization -file qualification-utilization.rpt
set wns [get_property SLACK [get_timing_paths -delay_type max -max_paths 1]]
set whs [get_property SLACK [get_timing_paths -delay_type min -max_paths 1]]
set errors [get_drc_violations -filter {SEVERITY == Error}]
set f [open qualification-values.json w]
puts $f "{\"wns_ns\": $wns, \"whs_ns\": $whs, \"drc_errors\": [llength $errors]}"
close $f
if {$wns<0 || $whs<0 || [llength $errors]} {error "LVDS8 timing/DRC qualification failed"}
write_checkpoint -force lvds8_route.dcp
source lvds8_bitstream.tcl
exit
