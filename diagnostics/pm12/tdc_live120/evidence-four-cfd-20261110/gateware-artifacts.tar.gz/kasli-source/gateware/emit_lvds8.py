"""Emit component RTL for OOC synthesis, not a board-programmable image."""
from pathlib import Path
from migen import *
from migen.fhdl import verilog
from gateware.lvds8 import LVDSInstrument

out=Path('build/lvds8-component');out.mkdir(parents=True,exist_ok=True)
dut=Module()
for name in ['sys','sample','ser_tx','ser_rx']:
    setattr(dut.clock_domains,'cd_'+name,ClockDomain(name))
pads=[(Signal(name_override='lvds%d_p'%i),Signal(name_override='lvds%d_n'%i)) for i in range(16)]
dut.submodules.instrument=inst=LVDSInstrument(pads)
bank=inst.bank;p=bank.player
ports={inst.output_mask,bank.arm,bank.length,bank.ready,bank.address,
       p.enable,p.ready,p.write,p.write_bank,p.write_address,p.write_data,
       p.commit,p.commit_length,p.active_bank,p.pending,p.error,p.position,p.loops}
for cap in bank.captures:
    ports.update([cap.read_data,cap.read_valid,cap.busy,cap.done,cap.error,
                  cap.count,cap.start_sample,cap.previous,cap.capture_id])
for pair in pads:ports.update(pair)
for name in ['sys','sample','ser_tx','ser_rx']:
    domain=getattr(dut,'cd_'+name);ports.update([domain.clk,domain.rst])
verilog.convert(dut,ios=ports,name='lvds8_component').write(str(out/'lvds8_component.v'))
