"""Seal full routed LV81 builds; hardware/cable test remains a separate result."""
import argparse,hashlib,json,re
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('build',type=Path);a=p.parse_args()
build=a.build;manifest=json.loads((build/'manifest.json').read_text())
values=json.loads((build/'qualification-values.json').read_text())
timing=(build/'qualification-timing.rpt').read_text()
for file,sha in manifest['source_sha256'].items():
    if hashlib.sha256(Path(file).read_bytes()).hexdigest()!=sha:raise RuntimeError('changed source '+file)
checks={name:int(re.search(r'checking '+name+r' \((\d+)\)',timing)[1]) for name in ['no_clock','unconstrained_internal_endpoints','loops','multiple_clock']}
cdc=(build/'qualification-cdc.rpt').read_text()
critical=[line for line in cdc.splitlines() if re.match(r'^\s*\d+\s+CDC-\d+\s+Critical\s',line)]
reviewed=[]
for line in critical:
    source,destination=line.split()[-2:]
    same_lane=source.startswith('OSERDESE2') and destination==source.replace('OSERDESE2','ISERDESE2').replace('/CLK','/D')
    mode_control=bool(re.fullmatch(r'(control_(enabled|output_mask.*)_reg.*|xilinxmultiregimpl\d+_reg)/C',source))
    if 'CDC-13' in line and 'False Path' in line and destination.startswith('ISERDESE2') and destination.endswith('/D') and (same_lane or mode_control):
        reviewed.append(line)
cdc_review=dict(critical_total=len(critical),reviewed_mutually_exclusive_io=len(reviewed),unexpected_critical=len(critical)-len(reviewed),
                contract='Input buffer disabled while the same pad drives; direction held during acquisition. Selected RX lanes cannot be driven. Emergency stop invalidates affected TX-lane samples, never treated as RX.')
passed=values['wns_ns']>=0 and values['whs_ns']>=0 and not values['drc_errors'] and not any(checks.values()) and not cdc_review['unexpected_critical']
report=dict(pass_=passed,**values,checks=checks,cdc_review=cdc_review,profile=manifest['profile'],slot=manifest['slot'],hardware_validated=False,
            scope='Routed board implementation with explicit mutually-exclusive local TX/RX mode exceptions; external input delay/phase accuracy NOT_RUN',
            bit_sha256=hashlib.sha256((build/'lvds8.bit').read_bytes()).hexdigest(),
            manifest_sha256=hashlib.sha256((build/'manifest.json').read_bytes()).hexdigest(),
            reports_sha256={f:hashlib.sha256((build/f).read_bytes()).hexdigest() for f in ['qualification-timing.rpt','qualification-drc.rpt','qualification-cdc.rpt','qualification-utilization.rpt']})
report['pass']=report.pop('pass_')
(build/'qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if not passed:raise SystemExit('LV81 build does not qualify')
