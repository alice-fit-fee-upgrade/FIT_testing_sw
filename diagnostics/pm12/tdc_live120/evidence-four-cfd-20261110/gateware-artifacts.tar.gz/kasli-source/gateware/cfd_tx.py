"""Finite x8 CFD pattern player, ONLY slot7 channel0/RJ45 pins1,2.

Gate-return pairs and RJ45 pair3/6 are never driven. STOP releases the pad.
Idle enable drives LVDS logical0 so quiet windows are not floating inputs.
"""
from migen import *
from gateware.core import PatternPlayer

class CFDBurst(Module):
    def __init__(self,bus,ready,depth=4096,ports=1):
        assert ports in (1,4)
        self.port=Signal(2);self.ports=ports
        self.submodules.player=p=PatternPlayer(depth,word_width=8)
        self.enabled=Signal();self.running=Signal();self.error=Signal();self.completed=Signal(32)
        self.generation=Signal(16);self.read_data=Signal(32);self.data=p.data
        address=Signal(max=depth);length=Signal(max=depth+1,reset=1200);repeats=Signal(32,reset=1);remaining=Signal(32);last=Signal(8)
        writable=~self.running&~p.pending
        self.comb += [p.ready.eq(ready),p.enable.eq(self.running),p.write_bank.eq(~p.active_bank),
            p.write_address.eq(address),p.write_data.eq(bus.write_data[:8]),
            p.write.eq(bus.write&(bus.address==0xec)&writable&(bus.write_data<256)),
            p.commit.eq(bus.write&(bus.address==0xf0)&writable&(bus.write_data>0)&(bus.write_data<=depth)),
            p.commit_length.eq(bus.write_data[:len(p.commit_length)]),self.read_data.eq(0xffffffff)]
        self.sync += [
            If(self.running & ready & (p.position==p.length-1),
                self.completed.eq(self.completed+1),remaining.eq(remaining-1),If(remaining==1,self.running.eq(0))),
            If(~ready,self.enabled.eq(0),self.running.eq(0)),
            If(bus.write,
                If((bus.address==8)&(bus.write_data==0),self.enabled.eq(0),self.running.eq(0)),
                Case(bus.address,{
                    0xdc:If(~self.enabled&~self.running&(bus.write_data<ports),self.port.eq(bus.write_data)).Else(self.error.eq(1)),
                    0xe0:If(bus.write_data==0,self.enabled.eq(0),self.running.eq(0))
                         .Elif((bus.write_data==1)&ready&~self.running,self.enabled.eq(1))
                         .Elif((bus.write_data==2)&ready&self.enabled&~self.running&~p.pending&~self.error&~p.error,
                              self.running.eq(1),remaining.eq(repeats),self.completed.eq(0),self.generation.eq(self.generation+1))
                         .Else(self.error.eq(1)),
                    0xe8:If(writable&(bus.write_data<depth),address.eq(bus.write_data)).Else(self.error.eq(1)),
                    0xec:If(writable&(bus.write_data<256),last.eq(bus.write_data[:8])).Else(self.error.eq(1)),
                    0xf0:If(writable&(bus.write_data>0)&(bus.write_data<=depth),length.eq(bus.write_data)).Else(self.error.eq(1)),
                    0xf4:If(writable&(bus.write_data>0)&(bus.write_data<=1000000),repeats.eq(bus.write_data)).Else(self.error.eq(1)),
                })
            )]
        self.comb += Case(bus.address,{
            0xd8:self.read_data.eq(0x43464434 if ports==4 else 0x43464430),
            0xdc:self.read_data.eq(self.port),
            0xe0:self.read_data.eq(self.enabled),
            0xe4:self.read_data.eq(Cat(ready,self.enabled,self.running,p.pending,self.error|p.error,Constant(0,11),self.generation)),
            0xe8:self.read_data.eq(address),0xec:self.read_data.eq(last),0xf0:self.read_data.eq(length),
            0xf4:self.read_data.eq(repeats),0xf8:self.read_data.eq(self.completed),0xfc:self.read_data.eq(0x43464430)})


def add_output(module,platform,burst,ready):
    from migen.build.generic_platform import Pins,IOStandard,Subsignal
    for port in range(burst.ports):
        ch=4*port;conn='diot6:d%d'%ch+('_cc' if ch in (0,8) else '')
        platform.add_extension([('cfd_tx',port,Subsignal('p',Pins(conn+'_p')),Subsignal('n',Pins(conn+'_n')),IOStandard('LVDS_25'))])
        pads=platform.request('cfd_tx',port);out=Signal();tristate=Signal()
        # One serializer per physical IOB: OQ cannot fan out across output IOBs.
        module.specials += [Instance('OSERDESE2',p_DATA_RATE_OQ='DDR',p_DATA_WIDTH=8,p_INIT_OQ=0,p_DATA_RATE_TQ='BUF',p_TRISTATE_WIDTH=1,p_INIT_TQ=1,
            i_CLK=ClockSignal('ser_tx'),i_CLKDIV=ClockSignal('sys'),i_RST=ResetSignal('sys'),i_OCE=1,i_TCE=1,i_T1=~(burst.enabled&ready&(burst.port==port)),
            **{'i_D%d'%(n+1):burst.data[n] for n in range(8)},o_OQ=out,o_TQ=tristate),
            Instance('OBUFTDS',i_I=out,i_T=tristate,o_O=pads.p,o_OB=pads.n)]
