"""Two-port frame bridge SFP1<->SFP2. SFP0 control never enters this bridge."""
from types import SimpleNamespace
from migen import *
from migen.fhdl.structure import _Assign
from migen.genlib.cdc import MultiReg
from liteeth.common import eth_phy_description
from liteeth.fifo import PacketDropFIFO
from liteeth.mac.core import LiteEthMACCore
from liteeth.phy.serial.basex.wrappers.a7_gtp import A7_1000BASEX

class FrameQueue(Module):
    """Receive without backpressure; commit whole good frames or count drops."""
    def __init__(self,depth=4096):
        self.submodules.fifo=q=PacketDropFIFO(eth_phy_description(8),depth,param_depth=8)
        self.sink=q.sink;self.source=q.source;self.enable=Signal()
        self.forwarded=Signal(32);self.dropped=Signal(32)
        self.comb += q.discard.eq(self.sink.error|~self.enable)
        self.sync += [If(q.drop,self.dropped.eq(self.dropped+1)),
            If(self.source.valid & self.source.ready & self.source.last,self.forwarded.eq(self.forwarded+1))]

class PMBridge(Module):
    def __init__(self,platform,pm,channel,bus,sys_clock,ipbus_clock):
        self.submodules.phy=phy=ClockDomainsRenamer({'eth_tx':'br_tx','eth_rx':'br_rx','eth_tx_half':'br_tx_half','eth_rx_half':'br_rx_half'})(A7_1000BASEX(channel,platform.request('sfp',2),120e6,with_csr=False,tx_cm_buf_type='BUFG'))
        self.submodules.pm_mac=left=ClockDomainsRenamer({'eth_tx':'pm_tx','eth_rx':'pm_rx'})(LiteEthMACCore(pm.phy,8,with_sys_datapath=True,with_store_and_forward=True,tx_cdc_depth=64,rx_cdc_depth=64))
        self.submodules.lan_mac=right=ClockDomainsRenamer({'eth_tx':'br_tx','eth_rx':'br_rx'})(LiteEthMACCore(phy,8,with_sys_datapath=True,with_store_and_forward=True,tx_cdc_depth=64,rx_cdc_depth=64))
        self.submodules.to_lan=a=FrameQueue();self.submodules.to_pm=b=FrameQueue()
        enabled=Signal(16);self.sync += If(bus.write&(bus.address==0x120),enabled.eq(bus.write_data))
        self.comb += [left.source.connect(a.sink),a.source.connect(right.sink),
            right.source.connect(b.sink),b.source.connect(left.sink),a.enable.eq(enabled[0]),b.enable.eq(enabled[0]),phy.reset.eq(enabled[8])]
        fixed=Signal();fixed_up=Signal();idle_age=Signal(20)
        self.specials += MultiReg(enabled[1],fixed,'br_tx')
        self.sync.br_tx += If(phy.pcs.seen_valid_ci.o,idle_age.eq(0),fixed_up.eq(1)).Elif(idle_age<750000,idle_age.eq(idle_age+1)).Else(fixed_up.eq(0))
        def gate(actions):
            for a in actions:
                if isinstance(a,_Assign) and (a.l is phy.pcs.tx.config_valid or a.l is phy.pcs.restart):a.r=a.r & ~fixed
                elif isinstance(a,If):gate(a.t);gate(a.f)
        for actions in phy.pcs.fsm.actions.values():gate(actions)
        link=Signal();self.specials += MultiReg(Mux(fixed,fixed_up,phy.link_up),link)
        self.read_data=Signal(32)
        self.comb += Case(bus.address,{0x120:self.read_data.eq(enabled),0x124:self.read_data.eq(link),
            0x128:self.read_data.eq(a.forwarded),0x12c:self.read_data.eq(b.forwarded),
            0x130:self.read_data.eq(a.dropped),0x134:self.read_data.eq(b.dropped),
            0x138:self.read_data.eq(4096),0x13c:self.read_data.eq(0x42524731)})
        for c in (phy.txoutclk,phy.rxoutclk):
            platform.add_period_constraint(c,16.0);platform.add_false_path_constraints(sys_clock,c)
            platform.add_false_path_constraints(ipbus_clock,c)
