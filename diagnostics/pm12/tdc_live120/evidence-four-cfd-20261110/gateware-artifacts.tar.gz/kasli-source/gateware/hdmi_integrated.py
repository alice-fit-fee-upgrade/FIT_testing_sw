"""HDMI adapter SPI master and four simultaneous raw LVDS capture banks.

SPI pins are released at reset/STOP/clock loss. PCF direction selection remains
an explicit host operation: slot6 mask0x000b or0x00b0 according to data_base;
never drive MISO or data pairs.
"""
from migen import *
from migen.genlib.cdc import MultiReg
from gateware.core import WindowCapture

class HDMITester(Module):
    def __init__(self,bus,bank,ready,data_base=4):
        if data_base not in (0,4):raise ValueError("HDMI data base must be0 or4")
        self.enabled=Signal();self.busy=Signal();self.error=Signal();self.read_data=Signal(32)
        self.sel=Signal();self.sck=Signal();self.mosi=Signal();self.miso=Signal()
        self.output_enable=Signal();self.rx=[Signal(8) for _ in range(4)]
        self.comb += self.output_enable.eq(self.enabled&ready)
        mi=Signal();self.specials += MultiReg(self.miso,mi)
        divider=Signal(16,reset=600);timer=Signal(16);bit=Signal(6);finishing=Signal();shift_pending=Signal()
        tx=Signal(32);rx=Signal(32);result=Signal(32);completed=Signal(32)
        self.comb += self.mosi.eq(Mux(self.busy,tx[31],0))
        self.sync += [
            If(self.busy,
                # Slave samples falling SCK: change MOSI midway through LOW,
                # never on the same edge as the receiving clock.
                If(shift_pending&(timer==(divider>>1)),tx.eq(tx<<1),shift_pending.eq(0)),
                If(timer!=0,timer.eq(timer-1)).Else(timer.eq(divider-1),
                    If(finishing,self.busy.eq(0),self.sel.eq(0),result.eq(rx),completed.eq(completed+1))
                    .Elif(~self.sck,self.sck.eq(1),rx.eq(Cat(mi,rx[:31])))
                    .Else(self.sck.eq(0),
                        If(bit==31,finishing.eq(1))
                        .Else(bit.eq(bit+1),shift_pending.eq(1))))),
            If(~ready,self.enabled.eq(0),self.busy.eq(0),self.sel.eq(0),self.sck.eq(0)),
            If(bus.write,
                If((bus.address==8)&(bus.write_data==0),self.enabled.eq(0),self.busy.eq(0),self.sel.eq(0),self.sck.eq(0)),
                Case(bus.address,{
                    0x144:If(bus.write_data==0,self.enabled.eq(0),self.busy.eq(0),self.sel.eq(0),self.sck.eq(0),self.error.eq(0))
                           .Elif((bus.write_data==1)&ready&~self.busy,self.enabled.eq(1)).Else(self.error.eq(1)),
                    0x148:If(self.enabled&ready&~self.busy&~self.error,self.busy.eq(1),self.sel.eq(1),self.sck.eq(0),
                                tx.eq(bus.write_data),rx.eq(0),bit.eq(0),finishing.eq(0),shift_pending.eq(0),timer.eq(divider-1)).Else(self.error.eq(1)),
                    0x154:If(~self.busy&(bus.write_data>=60)&(bus.write_data<=65535),divider.eq(bus.write_data)).Else(self.error.eq(1)),
                }))]
        lane=Signal(2);index=Signal(12);self.captures=[]
        for n in range(4):
            cap=ClockDomainsRenamer({'rx':'sample'})(WindowCapture(4096,word_width=8))
            setattr(self.submodules,'capture%d'%n,cap);self.captures.append(cap)
            self.comb += [cap.data.eq(self.rx[n]),cap.arm.eq(bank.arm),cap.request_length.eq(bank.length),
                          cap.rx_ready.eq(ready),cap.read_address.eq(index)]
        def selected(name):return Array([getattr(c,name) for c in self.captures])[lane]
        valid=Cat(*[c.done&~c.busy&~c.error for c in self.captures])==15
        self.sync += If(bus.write,Case(bus.address,{
            0x160:If(bus.write_data<4,lane.eq(bus.write_data)).Else(self.error.eq(1)),
            0x164:If(bus.write_data<4096,index.eq(bus.write_data)).Else(self.error.eq(1))}))
        self.comb += [self.read_data.eq(0xffffffff),Case(bus.address,{
            0x140:self.read_data.eq(0x48444d31),0x144:self.read_data.eq(self.enabled),
            0x14c:self.read_data.eq(result),0x150:self.read_data.eq(Cat(ready,self.busy,self.error,self.enabled)),
            0x154:self.read_data.eq(divider),0x158:self.read_data.eq(completed),0x15c:self.read_data.eq(0x03020100 if data_base==0 else 0x07060504),
            0x160:self.read_data.eq(lane),0x164:self.read_data.eq(index),
            0x168:self.read_data.eq(Mux(valid&(index<selected('count')),selected('read_data'),0xffffffff)),
            0x16c:self.read_data.eq(Mux(valid,selected('count'),0)),
            0x170:self.read_data.eq(selected('start_sample')[:32]),0x174:self.read_data.eq(selected('start_sample')[32:]),
            0x178:self.read_data.eq(selected('previous')),0x17c:self.read_data.eq(valid)})]

# SPI direction/drive controls are not synchronous data for the oversamplers.
# Only internal feedback through the two bidirectional SPI pad drivers is cut;
# external LVDS input paths and all four HDMI data receivers remain constrained.
HDMI_TIMING = '''set hdmi_feedback_controls [get_pins -hier -filter {NAME =~ IOBUFDS_INTERMDISABLE*/OBUFTDS/I || NAME =~ IOBUFDS_INTERMDISABLE*/OBUFTDS/T || (NAME =~ IOBUFDS_INTERMDISABLE* && (REF_PIN_NAME == IBUFDISABLE || REF_PIN_NAME == INTERMDISABLE))}]
if {[llength $hdmi_feedback_controls] < 4} {error "Missing HDMI bidirectional SPI pad control pins"}
set_false_path -through $hdmi_feedback_controls -to [get_pins -of_objects [get_cells -hier -filter {REF_NAME == ISERDESE2}] -filter {REF_PIN_NAME == D}]
'''
