set here [file normalize [file dirname [info script]]/../build/lvds8-component]
cd $here
create_project -in_memory -part xc7a200tffg1156-3
read_verilog lvds8_component.v
synth_design -mode out_of_context -top lvds8_component -part xc7a200tffg1156-3
report_utilization -file utilization.txt
write_checkpoint -force component.dcp
set rx [get_cells -hier -filter {REF_NAME == ISERDESE2}]
set tx [get_cells -hier -filter {REF_NAME == OSERDESE2}]
if {[llength $rx]!=16 || [llength $tx]!=16} {error "Expected sixteen x8 TX/RX lanes"}
puts "LVDS8_SYNTHESIS_PASS TX [llength $tx] RX [llength $rx]"
exit
