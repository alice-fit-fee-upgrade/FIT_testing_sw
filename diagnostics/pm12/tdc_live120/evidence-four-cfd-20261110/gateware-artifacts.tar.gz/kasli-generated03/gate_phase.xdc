 ## mcx_clkin:0.p
set_property LOC P4 [get_ports {mcx_clkin_p}]
set_property IOSTANDARD LVDS_25 [get_ports {mcx_clkin_p}]
set_property DIFF_TERM TRUE [get_ports {mcx_clkin_p}]
 ## mcx_clkin:0.n
set_property LOC P3 [get_ports {mcx_clkin_n}]
set_property IOSTANDARD LVDS_25 [get_ports {mcx_clkin_n}]
set_property DIFF_TERM TRUE [get_ports {mcx_clkin_n}]
 ## gate_lvds:0.p
set_property LOC L27 [get_ports {gate_lvds_p}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p}]
 ## gate_lvds:0.n
set_property LOC K27 [get_ports {gate_lvds_n}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n}]
 ## gate_lvds:1.p
set_property LOC L29 [get_ports {gate_lvds_p_1}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_1}]
 ## gate_lvds:1.n
set_property LOC L30 [get_ports {gate_lvds_n_1}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_1}]
 ## gate_lvds:2.p
set_property LOC M24 [get_ports {gate_lvds_p_2}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_2}]
 ## gate_lvds:2.n
set_property LOC L24 [get_ports {gate_lvds_n_2}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_2}]
 ## gate_lvds:3.p
set_property LOC G29 [get_ports {gate_lvds_p_3}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_3}]
 ## gate_lvds:3.n
set_property LOC G30 [get_ports {gate_lvds_n_3}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_3}]
 ## gate_lvds:4.p
set_property LOC H27 [get_ports {gate_lvds_p_4}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_4}]
 ## gate_lvds:4.n
set_property LOC G27 [get_ports {gate_lvds_n_4}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_4}]
 ## gate_lvds:5.p
set_property LOC J24 [get_ports {gate_lvds_p_5}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_5}]
 ## gate_lvds:5.n
set_property LOC H24 [get_ports {gate_lvds_n_5}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_5}]
 ## gate_lvds:6.p
set_property LOC H33 [get_ports {gate_lvds_p_6}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_6}]
 ## gate_lvds:6.n
set_property LOC G34 [get_ports {gate_lvds_n_6}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_6}]
 ## gate_lvds:7.p
set_property LOC L33 [get_ports {gate_lvds_p_7}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_7}]
 ## gate_lvds:7.n
set_property LOC L34 [get_ports {gate_lvds_n_7}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_7}]
 ## gate_lvds:8.p
set_property LOC H11 [get_ports {gate_lvds_p_8}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_8}]
 ## gate_lvds:8.n
set_property LOC G11 [get_ports {gate_lvds_n_8}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_8}]
 ## gate_lvds:9.p
set_property LOC G10 [get_ports {gate_lvds_p_9}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_9}]
 ## gate_lvds:9.n
set_property LOC G9 [get_ports {gate_lvds_n_9}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_9}]
 ## gate_lvds:10.p
set_property LOC L12 [get_ports {gate_lvds_p_10}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_10}]
 ## gate_lvds:10.n
set_property LOC K12 [get_ports {gate_lvds_n_10}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_10}]
 ## gate_lvds:11.p
set_property LOC G7 [get_ports {gate_lvds_p_11}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_11}]
 ## gate_lvds:11.n
set_property LOC G6 [get_ports {gate_lvds_n_11}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_11}]
 ## gate_lvds:12.p
set_property LOC K10 [get_ports {gate_lvds_p_12}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_12}]
 ## gate_lvds:12.n
set_property LOC J10 [get_ports {gate_lvds_n_12}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_12}]
 ## gate_lvds:13.p
set_property LOC H2 [get_ports {gate_lvds_p_13}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_13}]
 ## gate_lvds:13.n
set_property LOC G2 [get_ports {gate_lvds_n_13}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_13}]
 ## gate_lvds:14.p
set_property LOC K1 [get_ports {gate_lvds_p_14}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_14}]
 ## gate_lvds:14.n
set_property LOC J1 [get_ports {gate_lvds_n_14}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_14}]
 ## gate_lvds:15.p
set_property LOC L10 [get_ports {gate_lvds_p_15}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_p_15}]
 ## gate_lvds:15.n
set_property LOC L9 [get_ports {gate_lvds_n_15}]
set_property IOSTANDARD LVDS_25 [get_ports {gate_lvds_n_15}]
 ## hdmi_pair:0.p
set_property LOC J28 [get_ports {hdmi_pair_p}]
set_property IOSTANDARD LVDS_25 [get_ports {hdmi_pair_p}]
 ## hdmi_pair:0.n
set_property LOC H28 [get_ports {hdmi_pair_n}]
set_property IOSTANDARD LVDS_25 [get_ports {hdmi_pair_n}]
 ## hdmi_pair:2.p
set_property LOC K33 [get_ports {hdmi_pair_p_1}]
set_property IOSTANDARD LVDS_25 [get_ports {hdmi_pair_p_1}]
 ## hdmi_pair:2.n
set_property LOC J34 [get_ports {hdmi_pair_n_1}]
set_property IOSTANDARD LVDS_25 [get_ports {hdmi_pair_n_1}]
 ## hdmi_pair:4.p
set_property LOC K30 [get_ports {hdmi_pair_p_2}]
set_property IOSTANDARD LVDS_25 [get_ports {hdmi_pair_p_2}]
 ## hdmi_pair:4.n
set_property LOC J30 [get_ports {hdmi_pair_n_2}]
set_property IOSTANDARD LVDS_25 [get_ports {hdmi_pair_n_2}]
 ## hdmi_pair:6.p
set_property LOC J33 [get_ports {hdmi_pair_p_3}]
set_property IOSTANDARD LVDS_25 [get_ports {hdmi_pair_p_3}]
 ## hdmi_pair:6.n
set_property LOC H34 [get_ports {hdmi_pair_n_3}]
set_property IOSTANDARD LVDS_25 [get_ports {hdmi_pair_n_3}]
 ## serial:0.rx
set_property LOC U9 [get_ports {serial_rx}]
set_property IOSTANDARD LVCMOS25 [get_ports {serial_rx}]
 ## serial:0.tx
set_property LOC T10 [get_ports {serial_tx}]
set_property IOSTANDARD LVCMOS25 [get_ports {serial_tx}]
 ## clk125_gtp:0.p
set_property LOC AG16 [get_ports {clk125_gtp_p}]
 ## clk125_gtp:0.n
set_property LOC AH16 [get_ports {clk125_gtp_n}]
 ## cdr_clk_clean:0.p
set_property LOC AG14 [get_ports {cdr_clk_clean_p}]
 ## cdr_clk_clean:0.n
set_property LOC AH14 [get_ports {cdr_clk_clean_n}]
 ## cdr_clk:0.p
set_property LOC R10 [get_ports {cdr_clk_p}]
set_property IOSTANDARD LVDS_25 [get_ports {cdr_clk_p}]
 ## cdr_clk:0.n
set_property LOC P10 [get_ports {cdr_clk_n}]
set_property IOSTANDARD LVDS_25 [get_ports {cdr_clk_n}]
 ## sfp:1.txp
set_property LOC AN15 [get_ports {sfp_txp}]
 ## sfp:1.txn
set_property LOC AP15 [get_ports {sfp_txn}]
 ## sfp:1.rxp
set_property LOC AL16 [get_ports {sfp_rxp}]
 ## sfp:1.rxn
set_property LOC AM16 [get_ports {sfp_rxn}]
 ## sfp:0.txp
set_property LOC AN17 [get_ports {sfp_txp_1}]
 ## sfp:0.txn
set_property LOC AP17 [get_ports {sfp_txn_1}]
 ## sfp:0.rxp
set_property LOC AJ17 [get_ports {sfp_rxp_1}]
 ## sfp:0.rxn
set_property LOC AK17 [get_ports {sfp_rxn_1}]
 ## sfp:2.txp
set_property LOC AL14 [get_ports {sfp_txp_2}]
 ## sfp:2.txn
set_property LOC AM14 [get_ports {sfp_txn_2}]
 ## sfp:2.rxp
set_property LOC AJ15 [get_ports {sfp_rxp_2}]
 ## sfp:2.rxn
set_property LOC AK15 [get_ports {sfp_rxn_2}]
 ## cfd_tx:0.p
set_property LOC K7 [get_ports {cfd_tx_p}]
set_property IOSTANDARD LVDS_25 [get_ports {cfd_tx_p}]
 ## cfd_tx:0.n
set_property LOC K6 [get_ports {cfd_tx_n}]
set_property IOSTANDARD LVDS_25 [get_ports {cfd_tx_n}]
 ## cfd_tx:1.p
set_property LOC K11 [get_ports {cfd_tx_p_1}]
set_property IOSTANDARD LVDS_25 [get_ports {cfd_tx_p_1}]
 ## cfd_tx:1.n
set_property LOC J11 [get_ports {cfd_tx_n_1}]
set_property IOSTANDARD LVDS_25 [get_ports {cfd_tx_n_1}]
 ## cfd_tx:2.p
set_property LOC G5 [get_ports {cfd_tx_p_2}]
set_property IOSTANDARD LVDS_25 [get_ports {cfd_tx_p_2}]
 ## cfd_tx:2.n
set_property LOC G4 [get_ports {cfd_tx_n_2}]
set_property IOSTANDARD LVDS_25 [get_ports {cfd_tx_n_2}]
 ## cfd_tx:3.p
set_property LOC H4 [get_ports {cfd_tx_p_3}]
set_property IOSTANDARD LVDS_25 [get_ports {cfd_tx_p_3}]
 ## cfd_tx:3.n
set_property LOC H3 [get_ports {cfd_tx_n_3}]
set_property IOSTANDARD LVDS_25 [get_ports {cfd_tx_n_3}]

set hdmi_feedback_controls [get_pins -hier -filter {NAME =~ IOBUFDS_INTERMDISABLE*/OBUFTDS/I || NAME =~ IOBUFDS_INTERMDISABLE*/OBUFTDS/T || (NAME =~ IOBUFDS_INTERMDISABLE* && (REF_PIN_NAME == IBUFDISABLE || REF_PIN_NAME == INTERMDISABLE))}]
if {[llength $hdmi_feedback_controls] < 4} {error "Missing HDMI bidirectional SPI pad control pins"}
set_false_path -through $hdmi_feedback_controls -to [get_pins -of_objects [get_cells -hier -filter {REF_NAME == ISERDESE2}] -filter {REF_PIN_NAME == D}]


set_false_path -to [get_pins -of_objects [get_cells -hier -filter {mr_ff == TRUE}] -filter {REF_PIN_NAME == D}]

set_max_delay -datapath_only -from [get_ports {gate_lvds_p*}] -to [get_cells -hier -filter {REF_NAME == ISERDESE2}] 2.0

create_clock -name mcx_clkin_p -period 8.316969695457521 [get_nets mcx_clkin_p]

create_clock -name clk125_gtp_p -period 8.0 [get_nets clk125_gtp_p]

create_clock -name cdr_clk_clean_p -period 8.316969695457521 [get_nets cdr_clk_clean_p]

create_clock -name pmlink_pma_a7_gtp_basex_txoutclk -period 16.633939390915042 [get_pins GTPE2_CHANNEL/TXOUTCLK]

create_clock -name pmlink_pma_a7_gtp_basex_rxoutclk -period 16.633939390915042 [get_pins GTPE2_CHANNEL/RXOUTCLK]

create_clock -name ethernet_pma_a7_gtp_basex_txoutclk -period 16.0 [get_pins GTPE2_CHANNEL_1/TXOUTCLK]

create_clock -name ethernet_pma_a7_gtp_basex_rxoutclk -period 16.0 [get_pins GTPE2_CHANNEL_1/RXOUTCLK]

create_clock -name pm_bridge_a7_1000basex_pma_a7_gtp_basex_txoutclk -period 16.0 [get_pins GTPE2_CHANNEL_2/TXOUTCLK]

create_clock -name pm_bridge_a7_1000basex_pma_a7_gtp_basex_rxoutclk -period 16.0 [get_pins GTPE2_CHANNEL_2/RXOUTCLK]

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets sys_clk]] -group [get_clocks -include_generated_clocks pmlink_pma_a7_gtp_basex_txoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets sys_clk]] -group [get_clocks -include_generated_clocks pmlink_pma_a7_gtp_basex_rxoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets sys_clk]] -group [get_clocks -include_generated_clocks ethernet_pma_a7_gtp_basex_txoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets sys_clk]] -group [get_clocks -include_generated_clocks ethernet_pma_a7_gtp_basex_rxoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets sys_clk]] -group [get_clocks -include_generated_clocks pm_bridge_a7_1000basex_pma_a7_gtp_basex_txoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets sys_clk]] -group [get_clocks -include_generated_clocks pm_bridge_a7_1000basex_pma_a7_gtp_basex_rxoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets ipbus_clk]] -group [get_clocks -include_generated_clocks pmlink_pma_a7_gtp_basex_txoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets ipbus_clk]] -group [get_clocks -include_generated_clocks pmlink_pma_a7_gtp_basex_rxoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets ipbus_clk]] -group [get_clocks -include_generated_clocks ethernet_pma_a7_gtp_basex_txoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets ipbus_clk]] -group [get_clocks -include_generated_clocks ethernet_pma_a7_gtp_basex_rxoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets ipbus_clk]] -group [get_clocks -include_generated_clocks pm_bridge_a7_1000basex_pma_a7_gtp_basex_txoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks -of [get_nets ipbus_clk]] -group [get_clocks -include_generated_clocks pm_bridge_a7_1000basex_pma_a7_gtp_basex_rxoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks pmlink_pma_a7_gtp_basex_txoutclk] -group [get_clocks -include_generated_clocks pmlink_pma_a7_gtp_basex_rxoutclk] -asynchronous

set_clock_groups -group [get_clocks -include_generated_clocks ethernet_pma_a7_gtp_basex_txoutclk] -group [get_clocks -include_generated_clocks ethernet_pma_a7_gtp_basex_rxoutclk] -asynchronous

set_false_path -quiet -to [get_nets -filter {mr_ff == TRUE}]

set_false_path -quiet -to [get_pins -filter {REF_PIN_NAME == PRE} -of [get_cells -filter {ars_ff1 == TRUE || ars_ff2 == TRUE}]]

set_max_delay 2 -quiet -from [get_pins -filter {REF_PIN_NAME == Q} -of [get_cells -filter {ars_ff1 == TRUE}]] -to [get_pins -filter {REF_PIN_NAME == D} -of [get_cells -filter {ars_ff2 == TRUE}]]