set hdmi_feedback_controls [get_pins -hier -filter {NAME =~ IOBUFDS_INTERMDISABLE*/OBUFTDS/I || NAME =~ IOBUFDS_INTERMDISABLE*/OBUFTDS/T || (NAME =~ IOBUFDS_INTERMDISABLE* && (REF_PIN_NAME == IBUFDISABLE || REF_PIN_NAME == INTERMDISABLE))}]
if {[llength $hdmi_feedback_controls] < 4} {error "Missing HDMI bidirectional SPI pad control pins"}
set_false_path -through $hdmi_feedback_controls -to [get_pins -of_objects [get_cells -hier -filter {REF_NAME == ISERDESE2}] -filter {REF_PIN_NAME == D}]
