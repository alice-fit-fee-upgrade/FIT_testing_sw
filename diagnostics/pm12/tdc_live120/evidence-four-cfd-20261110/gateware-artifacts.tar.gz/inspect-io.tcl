open_checkpoint gate_phase_route.dcp
foreach c [get_cells -hier -filter {REF_NAME =~ OBUFDS* || REF_NAME =~ OBUFTDS* || REF_NAME =~ IOBUFDS* || REF_NAME == OSERDESE2}] {puts "IOCELL $c [get_property REF_NAME $c]"}
foreach p [get_ports] {if {[get_property DIRECTION $p] != "IN"} {puts "PORT $p [get_property DIRECTION $p] [get_property PACKAGE_PIN $p]"}}
exit
