import sys,contextlib,json,hashlib,subprocess,time,math,datetime
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P),str(P/'system'),str(P/'tdc_live120/clock40')]
from hold_spi import *
from station import jtag_command,identify,load_dependencies
from test_board import payload
import retest
root=Path(__file__).parent;out=root/'hardware';out.mkdir(exist_ok=False);(out/'executed-deploy.py').write_bytes(Path(__file__).read_bytes());cfg=json.loads(Path('/srv/codex-hil-nvme/pm12-campaigns/PM12-K7-3A17A1B402212223/four-cfd-20261113/staging/board-station.json').read_text());cfg['jtag_workspace']=str(root/'jtag-work');load_dependencies(cfg)
bit=root/'candidate/pm12_ipbus_adc.bit';gold=Path(cfg['boundary']['restore_bit']);q=json.loads((root/'candidate/qualification.json').read_text());newid=int(q['build_id'],16)
assert q['pass'] and hashlib.sha256(bit.read_bytes()).hexdigest()==q['bit_sha256']
assert hashlib.sha256(gold.read_bytes()).hexdigest()=='1dbafd99033f803a086d4153ed3d873adfc9b4208b806785f00d3024bdfbf1ac'
r={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_build':q['build_id'],'candidate_sha256':q['bit_sha256'],'accepted':False}
def save():(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
def pm(expected):
 c=system.Client();end=time.monotonic()+15
 while True:
  try:
   if c.read(0,3)==[0x504d1202,0x10002,expected]:return c
  except TimeoutError:pass
  if time.monotonic()>end:c.close();raise RuntimeError('PM identity did not recover')
  time.sleep(.1)
def fine_screen(data):
 rows=[]
 for ch in [9,10,11,12]:
  points=sorted([x for x in data['statistics'] if x['channel']==ch],key=lambda x:x['phase_bin']);assert len(points)==25
  ys=[]
  for p in points:
   y=p['fine']['mean_circular'];ys.append(y if not ys else ys[-1]+(y-ys[-1]+64)%128-64)
  spread=max(p['fine']['std_circular'] for p in points);span=max(ys)-min(ys);assert span>64 and spread<8,(ch,span,spread)
  rows.append({'channel':ch,'fine_unwrapped_span':span,'max_fine_std':spread,'pass':True})
 return rows
with contextlib.ExitStack() as st:
 for name in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(name+'.lock')))
 d=system.GatePhaseIPbusDevice();st.callback(d.close);a=HeldAdapter(d);a.stop();r['identity_before']=identify(cfg,out);assert r['identity_before']['identity']['uid']=='PM12-K7-3A17A1B402212223';save()
 with jtag_command(cfg,out) as prefix:
  text=(P/'adc/tools/load_fpga.tcl').read_text().replace('source [file join [file dirname [info script]] common.tcl]','source '+str(P/'adc/tools/common.tcl')).replace('0x504dad01','0x504d5a04');(out/'load.tcl').write_text(text)
  def load(file,label):
   bits=payload(file,out/'payload.hex')
   with (out/(label+'.log')).open('w') as log:subprocess.run(prefix+['-mode','batch','-nolog','-nojournal','-notrace','-source',str(out/'load.tcl'),'-tclargs',cfg['jtag_cable'],cfg['hw_server'],str(out/'payload.hex'),str(bits)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
   (out/'payload.hex').unlink();assert 'LOAD_PASS' in (out/(label+'.log')).read_text()
  try:
   load(bit,'candidate-load');c=pm(newid)
   try:
    with console(cfg) as u:data=retest.run(d,c,u,out/'tdc',newid)
    r['tdc_pass']=data['pass'];r['phase_functional_screen']=fine_screen(data);save()
    # Preserve all resident ADC functions; synthetic and physical banksA/B.
    from client import save_capture
    r['adc']=[]
    for pattern,bank in [(True,0),(True,1),(False,0),(False,1)]:
     gen,status=c.acquire(bank,pattern);raw=c.download(gen);r['adc'].append(save_capture(out/f'adc-{int(pattern)}-{bank}',raw,bank,pattern,gen,status));save()
    # Bounded diagnosis, not an acceptance PASS prerequisite for known HDMI issue.
    r['spi']=[]
    for address in [0,1,2]*4:
     a.stop();before=c.read(5,2);value=a.transfer(True,address);time.sleep(.03);after=c.read(5,2)
     r['spi'].append({'address':address,'value':value,'uptime_before':before,'uptime_after':after,'sys_reset':after[0]+(after[1]<<32)<before[0]+(before[1]<<32)});save();assert value==[0x4844,0x4d49,1][address]
    end=time.monotonic()+10
    while c.read(0x205)!=[0xfff]:
     if time.monotonic()>end:raise TimeoutError('TDC frontend recovery')
     time.sleep(.01)
    from host.pm_tdc_test import acquire as quiet
    z=quiet(c,out,'final-tdc-quiet');r['quiet_after_spi']=z;assert z['counts']==[0]*12
    gen,status=c.acquire(0,False);r['final']={'identity':c.read(0,3),'frontend_ready':c.read(0x205)[0],'adc_generation':gen,'adc_status':status,'kasli_hdmi_enable':d.read(0x144),'kasli_hdmi_state':d.read(0x150),'cfd_enable':d.read(0xe0),'cfd_port':d.read(0xdc)};a.stop()
    with console(cfg) as u:r['pgood_after']=wait_power_good(u,capture)
    r['accepted']=True;r['resident']='clock40';save()
   finally:c.close()
  except BaseException as error:r['error']=repr(error);raise
  finally:
   if not r['accepted']:
    load(gold,'golden-restore');c=pm(0xc7c42d28)
    try:c.acquire(0,False);r['resident']='c7c42d28-restored';r['restored_identity']=c.read(0,3)
    finally:c.close()
   r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();a.stop()
print('CLOCK40_ACCEPTED',r['accepted'],flush=True)
