set_param general.maxThreads 4
set here [file dirname [file normalize [info script]]]
cd $here
create_project -in_memory -part xc7k160tffg676-3
read_verilog $here/pm12_ipbus_adc.v
read_verilog $here/eth_jtag.v
read_verilog $here/hdmi_slave.v
read_vhdl $here/PM12_pkg.vhd
read_vhdl $here/trigger.vhd
read_vhdl $here/idle.vhd
read_vhdl $here/pm12_mcu_spi.vhd
set manifest [open $here/ipbus-sources.json r]
set text [read $manifest]
close $manifest
# Ordered list generated from the qualified upstream dependency manifest.
foreach f [split [string trim [read [set fp [open $here/ipbus-order.txt r]]]] "\n"] {
 read_vhdl -vhdl2008 $here/ipbus/$f
}
close $fp
source $here/tdc-ip.tcl
read_vhdl $here/pin_capt.vhd
read_vhdl $here/autophase.vhd
read_vhdl $here/TDCCHAN_instrumented.vhd
read_xdc $here/pins.xdc
read_xdc $here/tdc-pins.xdc
synth_design -top pm12_ipbus_adc -part xc7k160tffg676-3
foreach name {I2C_SDA I2C_SCL I2C_RESET_N} {
 if {[get_property DIRECTION [get_ports $name]] ne "IN"} {error "I2C ownership violation: $name"}
}
file mkdir build
write_checkpoint -force build/pm12_ipbus_adc_synth.dcp
source $here/tdc-timing.tcl
opt_design
place_design
route_design
phys_opt_design -directive AggressiveExplore
route_design -directive AggressiveExplore
file mkdir build
report_drc -file build/drc.txt
report_utilization -file build/utilization.txt
report_timing_summary -file build/timing.txt
write_checkpoint -force build/pm12_ipbus_adc_routed.dcp
foreach corner {max min} {
 if {[llength [get_timing_paths -quiet -delay_type $corner -slack_lesser_than 0 -max_paths 1]]} {error "Timing failed $corner"}
}
write_checkpoint -force build/pm12_ipbus_adc.dcp
write_bitstream -force build/pm12_ipbus_adc.bit
exit
