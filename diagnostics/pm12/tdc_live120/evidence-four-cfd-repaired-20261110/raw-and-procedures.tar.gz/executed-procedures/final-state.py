import contextlib,sys,json,gzip
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'cfd_simulator'),str(P/'ipbus_adc'),'/home/codex-hil/kasli-phase-tester','/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console,read_dna
from client import Client
from console import ConsoleI2C,Registers
from mcp23017 import afe_route
from pm12_console_regression import capture
from pm12_power import wait_power_good,require_power_good
from host.gate_phase_ipbus import GatePhaseIPbusDevice
from host.gate_phase_dio import input_cards
from host.hdmi_check import check_phase_records
r=Path(__file__).parent;out=r/'final-state02';out.mkdir(exist_ok=False);report={'pass_':False}
cfg=json.loads(Path('/srv/codex-hil-nvme/pm12-acceptance-20261107/post-restore-probe-run/station.json').read_text())
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console(cfg));report['pg']=wait_power_good(u,capture);report['mcu']=capture(u,'RS');assert 'Board S/N: 1803' in report['mcu']['reply']
 report['dna']=read_dna(cfg,out);assert report['dna']=='3A17A1B402212223'
 c=Client();st.callback(c.close);report['pm']=c.read(0,3);assert report['pm']==[0x504d1202,0x10002,0xc7c42d28];report['adc']=c.read(0x11,4);report['tdc']=c.read(0x201,5);report['tdc_counts']=c.read(0x220,12);assert report['tdc_counts']==[0]*12 and report['tdc'][0]&0x23==1
 d=GatePhaseIPbusDevice();st.callback(d.close);d.write(0xe0,0);d.stop();report['directions']=input_cards(d);report['kasli']={'cfd4':hex(d.read(0xd8)),'selected_port':d.read(0xdc),'cfd_enabled':d.read(0xe0),'hdmi_enabled':d.read(0x144),'bridge':d.read(0x120)};assert report['kasli']['cfd4']=='0x43464434' and report['kasli']['cfd_enabled']==report['kasli']['hdmi_enabled']==0
 data=d.capture(4095,channels=list(range(8,16)))
 with gzip.open(out/'gate-final.json.gz','wt') as f:json.dump(data,f)
 report['gates']={}
 for row in data['channels']:
  check_phase_records(row);bits=[(w>>b)&1 for w in row['words'] for b in range(8)];report['gates'][row['logical']]={'high_samples':sum(bits),'rising_edges':sum(not a and b for a,b in zip(bits,bits[1:]))}
 assert report['gates'][9]['high_samples']==0
 for lane in [8,10,11,12,13,14,15]:assert report['gates'][lane]['rising_edges']>=680,(lane,report['gates'][lane])
 bus=ConsoleI2C(u,capture);report['mcp']={}
 for ch in [12,10,8,6]:
  require_power_good(u,capture)
  with bus.routed(*afe_route(ch)):
   regs=Registers(bus);report['mcp'][ch]={str(n):regs.read(n) for n in [0,1,0x14,0x15]};assert regs.read(0x14)&8
 report['tca']={str(n):bus.mux(n) for n in [0x70,0x71]};assert list(report['tca'].values())==[0,0]
 d.stop();report['pg_final']=require_power_good(u,capture);report['pass_']=True
(out/'status.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL_STATE_PASS',flush=True)
