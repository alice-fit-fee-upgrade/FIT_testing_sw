"""Post-repair repeat: original CPLD12 gates during scan, INTB-off restored."""
import sys,contextlib,json,subprocess,os
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'ipbus_adc'),'/home/codex-hil/kasli-phase-tester','/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire,ENV
from station import console,jtag_command
from pm12_power import wait_power_good,require_power_good
from pm12_console_regression import capture
from client import Client
from host.gate_phase_ipbus import GatePhaseIPbusDevice
r=Path(__file__).parent;out=r/'cpld-window';out.mkdir(exist_ok=False)
vectors=Path('/srv/codex-hil-nvme/pm12-intb-off-20261108');cfg=json.loads(Path('/srv/codex-hil-nvme/pm12-acceptance-20261107/post-restore-probe-run/station.json').read_text());report={'pass_':False,'owner_reports':'Short circuits on DIO5/9 repaired','external_dac_and_dmm_used':False}
def save():(out/'status.json').write_text(json.dumps(report,indent=2)+'\n')
def program(which):
 with jtag_command(cfg,out) as prefix:
  with (out/(which+'.log')).open('w') as f:subprocess.run(prefix+['-mode','batch','-nolog','-nojournal','-notrace','-source',str(P/'adc/tools/execute_native.tcl'),'-tclargs',cfg['jtag_cable'],cfg['hw_server'],str(vectors/(which+'.tcl')),'0'],stdout=f,stderr=subprocess.STDOUT,timeout=180,check=True)
 assert 'NATIVE_EXECUTE_PASS' in (out/(which+'.log')).read_text()
with contextlib.ExitStack() as st:
 fds={}
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):
  path=Path.home()/'.cache'/(n+'.lock');f=st.enter_context(acquire(path));fds[str(path.resolve())]=f.fileno()
 os.environ[ENV]=json.dumps(fds)
 try:
  with console(cfg) as u:
   report['pg']=wait_power_good(u,capture);report['mcu']=capture(u,'RS');assert 'Board S/N: 1803' in report['mcu']['reply']
  c=Client()
  try:report['pm']=c.read(0,3);assert report['pm']==[0x504d1202,0x10002,0xc7c42d28]
  finally:c.close()
  d=GatePhaseIPbusDevice()
  try:assert d.read(0xd8)==0x43464434;d.write(0xe0,0);d.stop()
  finally:d.close()
  # Vendor vectors target physical CPLD12 only and include verification.
  try:
   program('restore');report['original_gate_mode_set']=True;save()
   subprocess.run(['/home/codex-hil/kasli-phase-tester/run-python',str(P/'cfd_simulator/scan_four_phase.py'),'--channels','12','10','8','6','--intervals','100','--out',str(r/'gate-scan101')],pass_fds=tuple(fds.values()),check=True)
   gate=json.loads((r/'gate-scan101/status.json').read_text());assert gate['pass_'] and len(gate['points'])==404
   missing=[(p['afe'],p['code'],lane) for p in gate['points'] for lane in range(8,16) if 'mean_ns' not in p['lanes'][str(lane)]]
   report['missing_return_points']=missing;save();assert not missing,missing[:10]
  finally:
   program('program');report['intb_off_restored']=True;save()
  subprocess.run(['/home/codex-hil/kasli-phase-tester/run-python',str(P/'tdc_live120/scan_four_cfd.py'),'--channels','12','10','8','6','--out',str(r/'tdc-scan')],pass_fds=tuple(fds.values()),check=True)
  report['tdc_pass']=json.loads((r/'tdc-scan/status.json').read_text())['pass_'];assert report['tdc_pass'];report['pass_']=True
 except BaseException as e:report['error']=repr(e);raise
 finally:os.environ.pop(ENV,None);save()
print('POST_REPAIR_REPEAT_PASS',flush=True)
