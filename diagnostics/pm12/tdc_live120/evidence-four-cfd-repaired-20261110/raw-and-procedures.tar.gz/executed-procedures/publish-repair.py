"""Package immutable post-repair data, overlays and an editable chapter."""
from pathlib import Path
import json,shutil,tarfile,hashlib,subprocess,re
r=Path(__file__).parent;repo=Path('/home/codex-hil/fit-testing-publish');base=repo/'diagnostics/pm12/tdc_live120';old=base/'evidence-four-cfd-20261110';out=base/'evidence-four-cfd-repaired-20261110';out.mkdir(exist_ok=False)
s=json.loads((r/'analysis/summary.json').read_text());v=json.loads((r/'validation.json').read_text());assert v['gate_return_test_pass'] and v['tdc_functional_pass']
for p in (r/'analysis').iterdir():
 if p.suffix=='.svg':(out/p.name).write_text('\n'.join(x.rstrip() for x in p.read_text().splitlines())+'\n')
 else:shutil.copy2(p,out/p.name)
shutil.copy2(r/'validation.json',out/'validation.json')
with tarfile.open(out/'raw-and-procedures.tar.gz','w:gz') as t:
 for name in ['gate-scan101','tdc-scan','cpld-window','final-state02','phase8-check','probe.json','all-gates.json','power-probe.json','kasli-recovery','pm-restore/status.json','pm-restore/load.log']:
  t.add(r/name,arcname=name)
 for p in r.glob('*.py'):t.add(p,arcname='executed-procedures/'+p.name)
 for p in r.glob('*console.txt'):t.add(p,arcname='console/'+p.name)
 for p in [repo/'diagnostics/pm12/cfd_simulator/scan_four_phase.py',base/'scan_four_cfd.py',base/'plot_four_cfd.py']:
  t.add(p,arcname='acquisition-source/'+p.name)
 t.add('/home/codex-hil/kasli-phase-tester/host/cfd_pattern.py',arcname='acquisition-source/cfd_pattern.py')
# Explicit pointers to the unchanged, already archived bitstreams and source.
(out/'provenance.json').write_text(json.dumps({'source_git_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'new_build':False,'reused_gateware_archive':'../evidence-four-cfd-20261110/gateware-artifacts.tar.gz','pm_bit_sha256':v['pm_bit_sha256'],'kasli_bit_sha256':v['kasli_bit_sha256'],'acquisition_source_sha256':{str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [repo/'diagnostics/pm12/cfd_simulator/scan_four_phase.py',base/'scan_four_cfd.py',base/'plot_four_cfd.py']},'before_repair_context':'../evidence-four-cfd-20261110/historical-lvds-context.json'},indent=2)+'\n')
rows=[];gaterows=[]
for i,ch in enumerate([12,10,8,6]):
 t=s['tdc'][str(ch)];g=s['gate'][str(ch)]
 rows.append(f"| {ch} | {t['slope_codes_per_ns']:.3f} | {g['A']['span_ns']:.2f} | {g['B']['span_ns']:.2f} |")
 gaterows.append(f"{ch} & {i} & {t['slope_codes_per_ns']:.3f} & {t['max_fine_std_codes']:.3f} \\\\")
text='''# Post-repair four-CFD repeat — 2026-11-10

The owner repaired short circuits on DIO physical channels5 and9. The repeat
used the same PM12 board **PM12-K7-3A17A1B402212223**, four CFD simulators on
physical channels12/10/8/6 and the same slot7 RJ45 assignments.

**Repair confirmed in the connected CFD fixture:** the two formerly static-HIGH
INTA returns now carry edges and follow their corresponding DAC-A phase setting.
The pre-scan buffers each contained683 rising edges on logical RX10 and RX12,
compared with zero before repair. During the full sweep, **all eight gate-return
lanes had valid edges at all404 DAC points**. This is a functional return-path
repeat; it does not newly qualify every DIO line in both directions at1Gb/s.

## Full repeat results

- Internal DAC-A:101 points per physical channel,0..65535;404 captures total.
- TDC:25 input phases/channel,128 events/phase;12,800 scan events plus64 input
  discovery events. Exactly the expected channel responded; no cross-channel
  records. All eight quiet windows were empty.
- Raw TDC counts/fine histograms independently match all downloaded binary data.
  Hardware phase records were checked against raw ISERDES samples during acquisition.
- External MOD-DAC-28 and the shared DMM were not used or leased.

| Physical PM channel | TDC slope [fine codes/ns] | Gate A span [ns] | Gate B span [ns] |
|---|---:|---:|---:|
'''+ '\n'.join(rows)+'''

The phase axes assume40.0787MHz LHC reference and one serializer bit of about
1.0396ns. These are relative responses; no absolute timestamp or intrinsic
jitter calibration is claimed. Gate phases are sampled in approximately1.04ns
bins. The separate TDC and DAC scans exercise different signal paths.

![All repaired gate returns](evidence-four-cfd-repaired-20261110/gate-phase-four.png)

![Repeated TDC phase responses](evidence-four-cfd-repaired-20261110/tdc-phase-four.png)

## Channel8 phase-step observation

The main sweep contains a simultaneous gate-A/B step between DAC codes655
and1311: approximately−12.48ns and−13.52ns, respectively. This adds roughly
one ADC period to the apparent excursion for channel8. The raw curve is retained;
its32–33ns excursion must not be presented as a continuous tuning range.
Three local up/down repeats (21 additional points) did not reproduce the large
step; adjacent phase changes stayed near one sampling bin. A divider/counter
state change is a plausible interpretation, not an isolated root cause.

## Startup and final state

After the repair/power interruption, diagnostic SRAM images and Kasli startup
clock/SFP enables needed restoration. Existing qualified PMc7c42d28 and Kasli
four-port images were reloaded; no new FPGA build was made. Kasli Si5324 CKIN1
bypass and SFP TX enables were restored using existing station helpers; no
VCO/divider/ICAL or PM CDCE profile change was made.

CPLD12 original complementary gates were temporarily restored for the DAC scan,
then its INTB-off experimental image was restored and vendor-verified. The other
11 CPLD images were unchanged. All four DAC-A codes were acknowledged0000 at
cleanup, monitor multiplexers inhibited, TCA70/71 disconnected. The other
integrator/injection controls were preserved as observed.

Final CFD/HDMI output enables0, CFD selector0, DIO slot6/7 input directions,
private PM bridge1, valid quiet/frozen TDC buffers with all counts0. Fresh MCU
serial/FPGA DNA and physical PGOOD passed. No ADC acquisition was performed.
No MCU firmware, EEPROM or FPGA configuration flash writes. All leases released.

## Reproduction and retained evidence

The existing [gate scanner](../cfd_simulator/scan_four_phase.py),
[TDC scanner](scan_four_cfd.py) and [plot generator](plot_four_cfd.py) were reused.
The exact CPLD-window wrapper and source snapshots are in the raw archive.
[Prior measurements](FOUR_CFD_CHARACTERIZATION.md) remain unchanged as evidence
of the failed fixture condition.

[PDF chapter](evidence-four-cfd-repaired-20261110/report.pdf),
[editable LaTeX](evidence-four-cfd-repaired-20261110/report.tex),
[gate CSV](evidence-four-cfd-repaired-20261110/gate-phase.csv),
[TDC CSV](evidence-four-cfd-repaired-20261110/tdc-phase.csv),
[validation and before/after counts](evidence-four-cfd-repaired-20261110/validation.json),
[raw data and procedures](evidence-four-cfd-repaired-20261110/raw-and-procedures.tar.gz).
The unchanged bitstreams and gateware sources remain in the
[previous gateware archive](evidence-four-cfd-20261110/gateware-artifacts.tar.gz).
'''
(base/'FOUR_CFD_REPAIR_REPEAT.md').write_text(text)
tex=(old/'report.tex').read_text().replace('PM12: four-channel CFD and TDC characterization','PM12: post-repair CFD and TDC repeat').replace('Incremental test chapter --- 10 November 2026','Post-repair test chapter --- 10 November 2026').replace('pm12-cfd-four-20261110','pm12-cfd-repaired-20261110-01')
start=tex.index('12 & 0 &');end=tex.index('\\bottomrule',start);tex=tex[:start]+'\n'.join(gaterows)+'\n'+tex[end:]
slopes=[abs(x['slope_codes_per_ns']) for x in s['tdc'].values()];percent=(max(slopes)-min(slopes))/(sum(slopes)/len(slopes))*100
tex=tex.replace('approximately 0.051\\%',f'approximately {percent:.3f}\\%')
start=tex.index('\\textbf{Unresolved return-path findings:}');end=tex.index('On channel 12,',start)
tex=tex[:start]+'''\\textbf{Repair confirmed:} the owner removed shorts on DIO physical channels
5 and 9. INTA from PM channels 10 and 8 now carries edges and follows DAC-A.
Both pre-scan return buffers contain 683 rising edges, compared with zero before
repair. All eight gate returns were valid at every one of the 404 DAC points.
The main channel-8 sweep includes a common gate-A/B step of about one ADC\nperiod near codes 655--1311; it did not recur in three local up/down checks.\nIts apparent 32--33 ns excursion is not a continuous delay-range claim. The old\nmeasurements remain as before-repair evidence.

'''+tex[end:]
tex=tex.replace('The legacy single-port script also passed\nwith16 events on channel12 after the four-port scan.','')
tex=tex.replace('The legacy single-port test also passed\nwith exactly 16 events on channel 12 after the four-port scan.','')
tex=tex.replace('\\textbf{Observed range:} approximately 20--21 ns,', '\\textbf{Observed range:} approximately 20--21 ns for channels 12/10/6; channel 8\'s apparent 32--33 ns includes a phase step,')
tex=tex.replace('Dell Vivado 2025.2 qualification:','Reused image, prior Dell Vivado 2025.2 qualification:')
tex=tex.replace('No MCU firmware, EEPROM, FPGA flash or PLL profile was written. The intended','Kasli Si5324 bypass and SFP enables were restored after startup; divider/VCO/ICAL\nsettings were unchanged. No MCU firmware, EEPROM, FPGA flash or PM CDCE profile\nwas written. The intended')
tex=tex.replace('\\texttt{gateware-artifacts.tar.gz} retains generated HDL, source snapshots,\nqualified bitstreams, recovery images and qualification reports.','The previous run\'s \\texttt{gateware-artifacts.tar.gz} retains the unchanged HDL,\nsource snapshots, qualified bitstreams, recovery images and reports.')
(out/'report.tex').write_text(tex)
print(out)
