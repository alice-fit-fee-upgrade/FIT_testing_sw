import sys,contextlib,json,gzip,time
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'cfd_simulator'),str(P/'ipbus_adc'),'/home/codex-hil/kasli-phase-tester','/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console
from phase_scan import ConsoleDAC
from phase_estimator import estimate
from pm12_power import wait_power_good,require_power_good
from pm12_console_regression import capture
from host.gate_phase_ipbus import GatePhaseIPbusDevice
from host.hdmi_check import check_phase_records
from host.gate_phase_dio import input_cards
from client import Client
r=Path(__file__).parent;out=r/'phase8-check';out.mkdir(exist_ok=False);report={'pass_':False,'points':[],'console':[],'scope':'Local check of phase step seen between DAC-A655 and1311; no new gateware.'}
def save():(out/'status.json').write_text(json.dumps(report,indent=2)+'\n')
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 u=st.enter_context(console({'uart':'/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port0'}));report['pg']=wait_power_good(u,capture)
 d=GatePhaseIPbusDevice();st.callback(d.close);d.stop();report['directions']=input_cards(d);dac=ConsoleDAC(u,8,capture,lambda row:report['console'].append(row))
 try:
  for rep in range(3):
   for index,code in enumerate([0,655,1311,1966,1311,655,0]):
    require_power_good(u,capture);dac.set_code(code);time.sleep(.1);data=d.capture(4095,channels=[12,13])
    with gzip.open(out/f'r{rep}-i{index}-code{code}.json.gz','wt') as f:json.dump(data,f)
    row={'repeat':rep,'index':index,'code':code,'lanes':{}}
    for lane in data['channels']:check_phase_records(lane);row['lanes'][lane['logical']]=estimate([lane],1e12/(40.0787e6*24),24,edge_period_bins=48)
    report['points'].append(row);save();print(rep,code,{k:round(v['mean_ns'],4) for k,v in row['lanes'].items()},flush=True)
  report['pg_final']=require_power_good(u,capture);report['pass_']=True
 finally:
  require_power_good(u,capture);dac.set_code(0);report['restored_zero']=True;d.stop();report['directions_final']=input_cards(d)
  c=Client()
  try:report['final']={'pm':c.read(0,3),'tdc_counts':c.read(0x220,12),'tdc_status':c.read(0x201)[0],'port':d.read(0xdc),'cfd':d.read(0xe0),'hdmi':d.read(0x144)};assert report['final']['tdc_counts']==[0]*12 and report['final']['port']==report['final']['cfd']==report['final']['hdmi']==0
  finally:c.close()
  save()
print('PHASE8_LOCAL_REPEAT_PASS',flush=True)
