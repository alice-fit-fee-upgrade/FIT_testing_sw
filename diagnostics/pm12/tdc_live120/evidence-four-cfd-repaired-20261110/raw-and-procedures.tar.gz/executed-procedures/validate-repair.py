"""Independently validate downloaded TDC buffers and repaired gate-return coverage."""
import json,struct,collections,hashlib
from pathlib import Path
r=Path(__file__).parent;old=Path('/srv/codex-hil-nvme/pm12-cfd-four-20261110');report={}
t=json.loads((r/'tdc-scan/status.json').read_text());assert t['pass_'] and len(t['statistics'])==100 and len(t['mapping'])==4
records=0;quiet=0;ids=[]
for row in t['captures']:
 ids.append(row['generation'])
 for ch,count in enumerate(row['counts'],1):
  raw=(r/'tdc-scan'/row['label']/f'tdc{ch:02d}.bin').read_bytes();assert len(raw)==2*count
  words=struct.unpack('<%dH'%count,raw);assert all(w<=8191 for w in words)
  assert {str(k):v for k,v in collections.Counter(w&127 for w in words).items()}==row['fine_histograms'][ch-1]
  records+=count
 if row['tx']:
  expected=[0]*12;expected[row['expected_channel']-1]=row['tx']['repetitions'];assert row['counts']==expected
 else:assert row['counts']==[0]*12;quiet+=1
assert len(ids)==len(set(ids)) and records==12864 and quiet==8
report.update(tdc_phase_points=100,tdc_phase_events=12800,tdc_discovery_events=64,tdc_quiet_windows=quiet,tdc_raw_records_exact=True,no_cross_channel_events=True)
g=json.loads((r/'gate-scan101/status.json').read_text());assert g['pass_'] and len(g['points'])==404 and g['restored_zero']==[12,10,8,6]
for ch in [12,10,8,6]:
 ps=[p for p in g['points'] if p['afe']==ch];assert len(ps)==101 and [p['code'] for p in ps]==[(i*65535+50)//100 for i in range(101)]
 commands=[p for p in g['console'] if p['command'].startswith(f'@DAC {ch} ')]
 assert commands[-1]['reply'].strip()=='DAC SENT A 0000'
 # Repaired fixture must carry every gate return during the original-gate scan.
 assert all('mean_ns' in p['lanes'][str(lane)] and p['lanes'][str(lane)]['rising_edges']>=680 for p in ps for lane in range(8,16))
report.update(gate_dac_points=404,gate_raw_sample_bits=404*8*4095*8,gate_hardware_phase_records_checked_during_acquisition=404*8*1365,all_eight_gate_returns_present_at_all_404_points=True,all_four_dac_A_restored_zero_acknowledged=True)
pre=json.loads((old/'probe.json').read_text());post=json.loads((r/'probe.json').read_text())
report['repair_comparison']={}
for lane,ch,dio in [(10,10,5),(12,8,9)]:
 report['repair_comparison'][str(ch)]={'signal':'INTA','physical_dio_channel':dio,'logical_rx':lane,'before_rising_edges':pre['gates'][str(lane)]['rising'],'after_rising_edges':post['gates'][str(lane)]['rising']}
 assert report['repair_comparison'][str(ch)]['before_rising_edges']==0 and report['repair_comparison'][str(ch)]['after_rising_edges']>=680
f=json.loads((r/'final-state02/status.json').read_text());assert f['pass_'] and f['dna']=='3A17A1B402212223' and f['gates']['9']['high_samples']==0
w=json.loads((r/'cpld-window/status.json').read_text());assert w['pass_'] and w['intb_off_restored'] and w['missing_return_points']==[]
report.update(board_uid='PM12-K7-'+f['dna'],owner_reports='Shorts repaired on DIO channels5/9',repair_confirmed_by_restored_return_signals=True,tdc_functional_pass=True,gate_return_test_pass=True,external_dac_and_dmm_used=False,pm_bit_sha256='1dbafd99033f803a086d4153ed3d873adfc9b4208b806785f00d3024bdfbf1ac',kasli_bit_sha256='a71a08a258620b0e5a52c5d03aefd8c69040c9d15e8de6391c484ac182b7173b',new_build=False,final_cpld12='INTB-off restored; other11 original gates',final_state_verified=True,scope='Post-repair fixture returns and relative TDC/gate phase response; not an intrinsic jitter or absolute timestamp calibration.')
(r/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
