import sys,contextlib,json,hashlib,time
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),'/home/codex-hil/kasli-phase-tester']
from lease import acquire
from host.hardware_test import identify,jtag
from host.lhc_reference import lhc_bypass
from host.gate_phase_ipbus import GatePhaseIPbusDevice
from host.gate_phase_dio import input_cards
r=Path(__file__).parent;out=r/'kasli-recovery';out.mkdir(exist_ok=False);report={'pass_':False};bit=Path('/srv/codex-hil-nvme/pm12-cfd-four-20261110/kasli-qualified/gate_phase_qualified.bit');assert hashlib.sha256(bit.read_bytes()).hexdigest()=='a71a08a258620b0e5a52c5d03aefd8c69040c9d15e8de6391c484ac182b7173b'
with contextlib.ExitStack() as st:
 for n in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(n+'.lock')))
 try:
  usb=identify();report['usb']=usb;cmd='adapter usb location '+Path(usb['sysfs']).name+'; init; '
  jtag(cmd+'pld load 0 {'+str(bit)+'}; shutdown','load-qualified',out)
  report['clock']={}
  with lhc_bypass(report['clock'],enable_sfp2=True):report['clock']['keep_configuration']=True
  end=time.monotonic()+20
  while True:
   try:d=GatePhaseIPbusDevice();break
   except TimeoutError:
    if time.monotonic()>end:raise
  try:
   assert d.read(0xd8)==0x43464434;d.write(0x100,256);time.sleep(.05);d.write(0x100,0);d.write(0x120,1);d.write(0xe0,0);d.stop();report['directions']=input_cards(d);report['status']=d.status();report['pass_']=True
  finally:d.close()
 finally:(out/'status.json').write_text(json.dumps(report,indent=2)+'\n')
print('KASLI_RECOVERED',flush=True)
