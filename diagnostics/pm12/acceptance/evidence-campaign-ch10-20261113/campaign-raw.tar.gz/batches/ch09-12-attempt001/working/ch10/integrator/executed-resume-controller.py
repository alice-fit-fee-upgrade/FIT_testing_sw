import json,subprocess,sys,time,struct,statistics,math
from pathlib import Path
repo=Path('/home/codex-hil/fit-testing-publish');P=repo/'diagnostics/pm12';sys.path[:0]=[str(P/'cfd_simulator'),str(P/'ipbus_adc')]
from integrator_analysis import integration_pair
from adc_decode import decode
root=Path(__file__).parent.parent;work=root/'batches/ch09-12-attempt001/working/ch10';target=work/'integrator';hw='/home/codex-hil/kasli-diot-bringup/.venv/bin/python';scientific='/srv/codex-hil-nvme/tool-venvs/fit-measurements/bin/python'
while True:
 try:
  line=json.loads((work/'adc-full/line-test.json').read_text());status=json.loads((work/'adc-full/scan/status.json').read_text())
  if not line['pass_'] or not status['pass']:raise RuntimeError('ADC did not pass')
  break
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(2)
time.sleep(2)
target.mkdir(exist_ok=True);(target/'executed-resume-controller.py').write_text(Path(__file__).read_text())
plan=json.loads((target/'plan.json').read_text())
def save():(target/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def acquire(name,offsets,repeats=4,park=None):
 if (target/name/'status.json').exists():
  assert json.loads((target/name/'status.json').read_text())['pass_'];print(name+' existing acquisition reused',flush=True);return
 command=[hw,str(P/'cfd_simulator/integrator_scan.py'),'--afe','10','--board-serial','1803','--dac-channels','2','3','--base','1.024','2.048','--repeats',str(repeats),'--offsets',*[str(round(x,7)) for x in offsets],'--out',str(target/name)]
 if park:command+=['--park',*[str(v) for v in park]]
 plan[name]=command;save()
 with (target/(name+'-console.txt')).open('w') as log:subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name+' COMPLETE',flush=True)
def roots(name):
 d=target/name;r=json.loads((d/'status.json').read_text());assert r['pass_'];found=[]
 for bank in [0,1]:
  points=[]
  for pt in r['points']:
   values=[]
   for cap in pt['captures']:
    if cap['bank']!=bank:continue
    try:values.append(integration_pair(decode(struct.unpack('<4096H',(d/cap['file']).read_bytes()),bank)[0])['mean_change'])
    except ValueError:pass
   if len(values)>=2:points.append((pt['offset_V'],statistics.mean(values)))
  crossings=[a[0]-a[1]*(b[0]-a[0])/(b[1]-a[1]) for a,b in zip(points,points[1:]) if (a[1]>0>b[1] if name=='sweep01' else a[1]*b[1]<0)]
  if len(crossings)!=1:raise RuntimeError(('Missing/ambiguous zero',name,bank,points))
  found.append(crossings[0])
 return found
acquire('sweep01',[-.1,-.08,-.06,-.04,-.02,-.01,0,.01,.02,.04,.06,.08,.1])
plan['coarse_search_note']='Use the negative-direction zero crossing for this reversed DAC coordinate; the far coarse positive crossing follows an inversion of the high integration/reset pair. Fine and independent sign/return checks remain unchanged.';save()
coarse=roots('sweep01');assert max(coarse)-min(coarse)<.008;start=math.floor((statistics.mean(coarse)-.005)/.0004)*.0004
plan['coarse_roots_V']=coarse;save();acquire('fine01',[start+i*.0004 for i in range(26)])
fine=roots('fine01');a,b=[round(v/.0002)*.0002 for v in fine];common=round(statistics.mean([a,b])/.0002)*.0002;park=[round(1.024+common/2,4),round(2.048-common/2,4)]
plan['fine_roots_V']=fine;plan['candidates_V']=[a,b,common];plan['park_V']=park;save()
acquire('validation01',[a,a,a-.005,a+.005,b,b,b-.005,b+.005,common],8,park)
acquire('validation02',[a,b,common,a,b,common],8,park)
subprocess.run([scientific,str(P/'cfd_simulator/plot_integrator_scan.py'),'--root',str(target),'--out',str(target/'analysis'),'--runs','sweep01','fine01','validation01','validation02'],cwd=repo,check=True)
print('CH10_INTEGRATOR_COMPLETE',flush=True)
