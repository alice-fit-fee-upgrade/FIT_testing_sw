import contextlib,json,datetime,sys
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'cfd_simulator'),str(P/'ipbus_adc'),'/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console
from console import ConsoleI2C,Registers
from mcp23017 import afe_route,MCP23017Monitor
from pm12_console_regression import capture
from pm12_power import wait_power_good
from channel_settings import require_serial_reply
from mod_dac28 import remote_lease,DAC
from client import Client
root=Path(__file__).parent.parent;out=root/'batches/ch09-12-attempt001/working/ch10/preflight';out.mkdir()
r=dict(pass_=False,physical_channel=10,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'executed-preflight.py').write_text(Path(__file__).read_text())
try:
 with contextlib.ExitStack() as st:
  for name in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001','esp32-6825dd4c49e4','lattice-VER00001']):st.enter_context(acquire(Path.home()/'.cache'/(name+'.lock')))
  u=st.enter_context(console(dict(uart='/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port0')))
  r['pgood']=wait_power_good(u,capture);r['mcu']=capture(u,'RS');require_serial_reply(r['mcu']['reply'],'1803')
  c=Client();st.callback(c.close);r['fpga']=c.read(0,3);assert r['fpga']==[0x504d1202,0x10002,0xc7c42d28]
  bus=ConsoleI2C(u,capture);r['safe_gpio']={}
  for ch in [9,10,11,12]:
   with bus.routed(*afe_route(ch)):
    regs=Registers(bus);MCP23017Monitor(regs).initialize_monitor().off()
    regs.write(0x15,regs.read(0x15)|0x20);regs.write(1,regs.read(1)&~0x20)
    regs.write(0x14,regs.read(0x14)|0x88);regs.write(0,regs.read(0)&~0x88)
    assert regs.read(0x12)&0x88==0x88 and regs.read(0x15)&0x20
    r['safe_gpio'][str(ch)]={str(a):regs.read(a) for a in [0,1,0x12,0x13,0x14,0x15]}
  remote=st.enter_context(remote_lease());dac01=DAC(remote,channels=[0,1]);st.callback(dac01.close);dac23=DAC(remote,channels=[2,3]);st.callback(dac23.close)
  r['dac_before']=dac01.snapshot();dac01.park(1,1);dac23.park(2.048,1.024);r['dac_prepared']=dac01.snapshot();r['scpi']=dac01.records+dac23.records
  r['tca_final']={str(a):bus.mux(a) for a in [0x70,0x71]};assert set(r['tca_final'].values())=={0};r['i2c']=bus.records;r['pass_']=True
except BaseException as e:r['error']=repr(e);raise
finally:r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'status.json').write_text(json.dumps(r,indent=2)+'\n')
print('CH10_PREFLIGHT_PASS',flush=True)
