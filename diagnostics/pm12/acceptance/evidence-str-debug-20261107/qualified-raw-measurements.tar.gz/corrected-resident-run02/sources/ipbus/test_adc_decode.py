import unittest
from adc_decode import decode


def clock():return [100|(((i//2)&1)<<13) for i in range(4096)]

class Decode(unittest.TestCase):
    def test_client_can_be_loaded_by_path_without_sys_path_setup(self):
        import subprocess,sys,tempfile
        from pathlib import Path
        path=Path(__file__).with_name('client.py').resolve()
        code="import importlib.util;s=importlib.util.spec_from_file_location('isolated_client',"+repr(str(path))+");m=importlib.util.module_from_spec(s);s.loader.exec_module(m)"
        with tempfile.TemporaryDirectory() as d:
            result=subprocess.run([sys.executable,'-c',code],cwd=d,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_aligned(self):
        x,t=decode(clock(),0);self.assertEqual(t['status'],'ALIGNED');self.assertEqual(x,[100]*1023)
    def test_one_bin_uncertainty_is_bounded_not_cumulative(self):
        w=clock();w[6]&=~8192
        x,t=decode(w,0);self.assertEqual(t['status'],'EDGE_QUANTIZED');self.assertEqual(t['rising_phase_span_samples'],1)
        self.assertEqual(t['interval_counts'][3],1);self.assertEqual(t['interval_counts'][5],1)
        with self.assertRaisesRegex(ValueError,'Strict'):decode(w,0,strict_edges=True)
    def test_missing_pulse_rejected(self):
        w=clock();w[6]&=~8192;w[7]&=~8192
        with self.assertRaises(ValueError):decode(w)
    def test_accumulating_drift_rejected(self):
        w=[100|(((i//2)%3==1)<<13) for i in range(4096)]
        with self.assertRaises(ValueError):decode(w)
    def test_unstable_selected_adc_word_rejected(self):
        w=clock();w[5]=101|(w[5]&8192)
        with self.assertRaisesRegex(ValueError,'two-sample'):decode(w)
    def test_tags_reserved_bits_and_truncation_rejected(self):
        for w in [clock()[:-1],[x|0x4000 for x in clock()],[x|0x1000 for x in clock()]]:
            with self.assertRaises(ValueError):decode(w,0)

if __name__=='__main__':unittest.main()
