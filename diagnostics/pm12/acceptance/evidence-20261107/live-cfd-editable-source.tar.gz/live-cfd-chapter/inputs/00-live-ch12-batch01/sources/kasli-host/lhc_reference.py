"""Temporary Si5324 CKIN1 bypass, preserving clock selector and chip registers.

Caller owns Kasli lease, has loaded MCX->CKIN1 forwarding, and restores this
context BEFORE removing that forwarding. No EEPROM/flash or ICAL operations.
See Si5324 datasheet register0 BYPASS_REG, register3 DHOLD.
"""
from contextlib import contextmanager
from pathlib import Path
import time
import usb.core
from pyftdi.i2c import I2cController
from host.hardware_test import identify

@contextmanager
def lhc_bypass(report,enable_sfp2=False):
    p=Path(identify()['sysfs'])
    dev=usb.core.find(idVendor=0x403,idProduct=0x6011,bus=int((p/'busnum').read_text()),address=int((p/'devnum').read_text()))
    ctl=I2cController();gpio=None;mux=None;old_gpio=None;old_si=None;old_sfp2=None
    def rd(a,r):return ctl.exchange(a,bytes([r]),1)[0]
    def wr(a,r,v):ctl.write(a,bytes([r,v]))
    regs=[0,3,4,6,10,11,21]
    try:
        ctl.configure(dev,interface=2,frequency=50000,direction=0x60,initial=0x40)
        gpio=ctl.get_gpio();gpio.set_direction(0x60,0x60);gpio.write(0x40)
        mux=ctl.read(0x70,1)[0];ctl.write(0x70,b'\x08')
        old_gpio={r:rd(0x74,r) for r in [0,1,2,3,6,7]}
        old_si={r:rd(0x68,r) for r in regs}
        report.update(gpio_before=old_gpio,si_before=old_si,mux_before=mux)
        # IC25 PCA9539 P1.7 CLK_SEL:0 selects Si5324 (CLK0), releases its
        # active-low reset and disables the alternative Main_DCXO source.
        # Also enable SFP1 TX by clearing P1.1 TX_DISABLE; SFP0 bits stay intact.
        wr(0x74,3,old_gpio[3]&0x7d);wr(0x74,7,old_gpio[7]&0x7d);time.sleep(.02)
        assert [rd(0x68,r) for r in (134,135)]==[1,0x82]
        live={r:rd(0x68,r) for r in regs+[128,129,130]};report['si_after_select']=live
        report['sfp1_enabled']={r:rd(0x74,r) for r in [1,3,7]}
        assert not report['sfp1_enabled'][1]&0x82,'SFP1 TX disable or clock selector still high'
        # Program only the output path. Dividers/VCO settings remain untouched.
        wr(0x68,3,live[3]|0x20) # Enter digital hold before toggling bypass.
        wr(0x68,21,live[21]&~1) # Register-controlled input selection.
        wr(0x68,4,live[4]&0x3f) # Manual input selection.
        wr(0x68,11,live[11]&~1) # CKIN1 input powered.
        wr(0x68,3,(live[3]&0x0f)|0x20) # CKIN1, digital hold, no ICAL squelch.
        wr(0x68,6,(live[6]&0xf8)|5) # CKOUT1 LVDS; CKOUT2 format retained.
        wr(0x68,10,live[10]&~4) # CKOUT1 enabled; CKOUT2 enable retained.
        wr(0x68,0,(live[0]&~0x40)|0x22) # Bypass, output always-on, no free run.
        wr(0x68,3,live[3]&0x0f) # Leave digital hold, keep CKIN1.
        time.sleep(.1)
        after={r:rd(0x68,r) for r in regs+[128,129,130]};report['si_bypass']=after
        assert after[0]&0x42==2 and after[3]&0xe0==0
        assert not after[129]&2,'No CKIN1 signal after MCX forwarding'
        if enable_sfp2:
            old_sfp2={r:rd(0x75,r) for r in [0,2,6]}
            report['sfp2_before']=old_sfp2
            assert not old_sfp2[0]&16,'SFP2 module not present'
            # Only SFP2 P0.1 TX_DISABLE; do not access SFP3 port1.
            wr(0x75,2,old_sfp2[2]&~2);wr(0x75,6,old_sfp2[6]&~2)
            report['sfp2_enabled']={r:rd(0x75,r) for r in [0,2,6]}
        yield ctl
    finally:
        try:
            if not report.get('keep_configuration'):
                if old_sfp2 is not None:
                    wr(0x75,2,old_sfp2[2]);wr(0x75,6,old_sfp2[6])
                    report['sfp2_restored']={r:rd(0x75,r) for r in [2,6]}
                    assert all(report['sfp2_restored'][r]==old_sfp2[r] for r in [2,6])
                if old_si is not None:
                    wr(0x68,3,rd(0x68,3)|0x20)
                    for r in [21,4,11,6,10,0]:wr(0x68,r,old_si[r])
                    wr(0x68,3,old_si[3])
                    report['si_restored']={r:rd(0x68,r) for r in regs}
                    assert report['si_restored']==old_si,'Si5324 register restore mismatch'
                if old_gpio is not None:
                    wr(0x74,3,old_gpio[3]);wr(0x74,7,old_gpio[7])
                    report['gpio_restored']={r:rd(0x74,r) for r in [2,3,6,7]}
                    assert all(report['gpio_restored'][r]==old_gpio[r] for r in [2,3,6,7])
            else:report['configuration_retained']=True
            if mux is not None:ctl.write(0x70,bytes([mux]))
        finally:
            if gpio is not None:gpio.write(0)
            ctl.terminate()
