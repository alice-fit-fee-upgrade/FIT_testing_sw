"""Slow open-drain I2C over UART registers; no implicit chip configuration."""
import time


class I2C:
    def __init__(self,device,bus=0):
        if not 0<=bus<4: raise ValueError('bus 0..3')
        self.device=device; self.bus=bus; self.low=device.read(0x60)
        self.scl=1<<(2*bus); self.sda=1<<(2*bus+1)

    def lines(self,scl,sda):
        self.low=(self.low&~(self.scl|self.sda))|(0 if scl else self.scl)|(0 if sda else self.sda)
        self.device.write(0x60,self.low)
        if scl:
            deadline=time.monotonic()+.1
            while not self.device.read(0x64)&self.scl:
                if time.monotonic()>deadline: raise TimeoutError('I2C SCL held low')

    def start(self):
        self.lines(1,1); self.lines(1,0); self.lines(0,0)

    def stop(self):
        self.lines(0,0); self.lines(1,0); self.lines(1,1)

    def write_byte(self,value):
        for bit in range(7,-1,-1):
            b=(value>>bit)&1
            self.lines(0,b); self.lines(1,b); self.lines(0,b)
        self.lines(0,1); self.lines(1,1)
        ack=not self.device.read(0x64)&self.sda
        self.lines(0,1)
        if not ack: raise RuntimeError('I2C NACK')

    def read_byte(self,ack=False):
        value=0
        for _ in range(8):
            self.lines(0,1); self.lines(1,1)
            value=(value<<1)|bool(self.device.read(0x64)&self.sda)
            self.lines(0,1)
        self.lines(0,not ack); self.lines(1,not ack); self.lines(0,1)
        return value

    def read_register(self,address,register):
        try:
            self.start(); self.write_byte(address<<1); self.write_byte(register)
            self.start(); self.write_byte((address<<1)|1)
            return self.read_byte()
        finally:self.stop()

    def write_register(self,address,register,value):
        try:
            self.start(); self.write_byte(address<<1); self.write_byte(register); self.write_byte(value)
        finally:self.stop()
