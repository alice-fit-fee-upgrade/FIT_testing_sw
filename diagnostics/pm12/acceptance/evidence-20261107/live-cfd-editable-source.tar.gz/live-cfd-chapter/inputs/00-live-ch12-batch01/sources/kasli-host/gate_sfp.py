"""SFP0 TX_DISABLE control, preserving other PCA9539 pins and service routing."""
from pathlib import Path
from pyftdi.i2c import I2cController
import usb.core

def sfp0_tx(enable=True,restore=None):
    matches=[]
    for p in Path('/sys/bus/usb/devices').iterdir():
        try:
            if (p/'serial').read_text().strip()=='00001' and (p/'product').read_text().strip()=='Artix-7 DIOT System Board':matches.append((int((p/'busnum').read_text()),int((p/'devnum').read_text())))
        except (OSError,ValueError):pass
    if len(matches)!=1:raise RuntimeError('Kasli USB identity missing/ambiguous')
    dev=usb.core.find(idVendor=0x0403,idProduct=0x6011,bus=matches[0][0],address=matches[0][1])
    ctl=I2cController();gpio=None;oldmux=None
    try:
        ctl.configure(dev,interface=2,frequency=50000,direction=0x60,initial=0x40)
        gpio=ctl.get_gpio();gpio.set_direction(0x60,0x60);gpio.write(0x40)
        oldmux=ctl.read(0x70,1)[0];ctl.write(0x70,b'\x08')
        def rd(reg):return ctl.exchange(0x74,bytes([reg]),1)[0]
        def wr(reg,value):ctl.write(0x74,bytes([reg,value]))
        before={str(reg):rd(reg) for reg in range(8)}
        if restore is not None:
            # Restore only the owned pin, preserving any unrelated modifications.
            wr(2,(rd(2)&~2)|(restore['2']&2));wr(6,(rd(6)&~2)|(restore['6']&2))
        else:
            wr(2,(before['2']&~2)|(0 if enable else 2));wr(6,before['6']&~2)
        after={str(reg):rd(reg) for reg in range(8)}
        if restore is None and ((after['2']&2)!=(0 if enable else 2) or after['6']&2):raise RuntimeError('SFP0 TX_DISABLE readback failed')
        return dict(before=before,after=after)
    finally:
        try:
            if oldmux is not None:ctl.write(0x70,bytes([oldmux]))
        finally:
            if gpio is not None:gpio.write(0)
            ctl.terminate()
