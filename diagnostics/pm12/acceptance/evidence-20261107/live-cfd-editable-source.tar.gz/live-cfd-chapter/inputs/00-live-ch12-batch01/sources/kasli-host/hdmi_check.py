"""Check captured PM diagnostic PRBS without reseeding after training."""
import statistics

def prbs7(seed):
    value=seed;bits=[]
    for _ in range(127):
        bits.append((value>>6)&1)
        value=((value<<1)&127)|(((value>>6)^(value>>5))&1)
    assert value==seed
    return bits

def check_prbs(words,seed,samples_per_bit,sample_hz=1e9):
    bits=[(w>>i)&1 for w in words for i in range(8)]
    observed=[i for i in range(1,len(bits)) if bits[i]!=bits[i-1]]
    if len(observed)<10:raise AssertionError('too few PRBS edges')
    gaps=[round((b-a)/samples_per_bit) for a,b in zip(observed,observed[1:])]
    if any(not 1<=g<=7 for g in gaps):raise AssertionError('illegal PRBS run length')
    ref=prbs7(seed);edges=[i for i in range(127) if ref[i]!=ref[(i-1)%127]]
    runs=[(edges[(i+1)%len(edges)]-edges[i])%127 for i in range(len(edges))]
    training=min(12,len(gaps)//2)
    matches=[i for i in range(len(edges)) if ref[edges[i]]==bits[observed[0]] and all(gaps[j]==runs[(i+j)%len(runs)] for j in range(training))]
    if len(matches)!=1:raise AssertionError('PRBS training not unique')
    phase=matches[0]
    errors=[i for i,g in enumerate(gaps[training:],training) if g!=runs[(phase+i)%len(runs)]]
    if errors:raise AssertionError('PRBS mismatch after fixed training: '+str(errors[:8]))
    x=[0]
    for gap in gaps:x.append(x[-1]+gap)
    fit=statistics.linear_regression(x,observed)
    if abs(fit.slope/samples_per_bit-1)>.02:raise AssertionError('unexpected bit rate')
    return dict(seed=seed,compared_bits=sum(gaps[training:]),training_edges=training,
                edges=len(observed),errors=0,samples_per_bit_fit=fit.slope,
                estimated_bitrate_hz=sample_hz/fit.slope,
                scope='Fixed run-length training then continuous PRBS check; nominal time scale, not calibrated BER/jitter')

def check_idle(words,sample_hz=1e9):
    bits=[(w>>i)&1 for w in words for i in range(8)]
    rising=[i for i in range(1,len(bits)) if bits[i] and not bits[i-1]]
    falling=[i for i in range(1,len(bits)) if not bits[i] and bits[i-1]]
    if len(rising)<32:raise AssertionError('no sustained HDMI idle training')
    periods=[b-a for a,b in zip(rising,rising[1:])]
    expected=sample_hz/40e6
    if any(abs(p-expected)>1.1 for p in periods):raise AssertionError('idle frame-period mismatch')
    widths=[];j=0
    for edge in rising:
        while j<len(falling) and falling[j]<=edge:j+=1
        if j<len(falling):widths.append(falling[j]-edge)
    if not widths or any(abs(w-sample_hz/320e6)>1.1 for w in widths):raise AssertionError('idle high-width mismatch')
    return dict(frames=len(periods),frame_period_samples_median=statistics.median(periods),high_width_samples=sorted(set(widths)),
                scope='Native empty-frame training only; not nonempty trigger payload validation')

def circular_span(histogram):
    bins=len(histogram);occupied=[i for i,n in enumerate(histogram) if n]
    if not occupied:return None
    if len(occupied)==1:return 0
    gaps=[(occupied[(i+1)%len(occupied)]-x)%bins for i,x in enumerate(occupied)]
    return bins-max(gaps)

def check_phase_records(row,period_bins=24):
    """Compare every hardware phase record with its retained raw samples."""
    previous=row['previous'];words=row['words'];records=row['phase_records']
    if len(records)!=len(words)*8//period_bins:raise AssertionError('phase record count')
    for frame,record in enumerate(records):
        raw=sum(words[frame*3+i]<<(8*i) for i in range(3))
        mask=raw&~((raw<<1)|previous)&0xffffff
        edges=[i for i in range(24) if mask>>i&1]
        if (record['first_phase_bin'],record['edge_count'],record['present'],record['multiple'])!=(edges[0] if edges else 0,len(edges),bool(edges),len(edges)>1):
            raise AssertionError('hardware/raw phase mismatch at '+str(frame))
        previous=raw>>23
    return len(records)

def phase_coherence(row,period_bins=24):
    """Test stationary PM idle phase in one uninterrupted RX sample epoch."""
    bits=[(word>>i)&1 for word in row['words'] for i in range(8)]
    edges=[row['start_sample']+i for i in range(1,len(bits)) if bits[i] and not bits[i-1]]
    if len(edges)<32:raise AssertionError('too few reference edges for phase coherence')
    histogram=[0]*period_bins
    for edge in edges:histogram[edge%period_bins]+=1
    fit=statistics.linear_regression(range(len(edges)),[edge-edges[0] for edge in edges])
    ppm=(fit.slope/period_bins-1)*1e6;span=circular_span(histogram)
    return dict(channel=row['channel'],edges=len(edges),phase_histogram=histogram,
                circular_span_bins=span,period_samples_fit=fit.slope,relative_clock_error_ppm=ppm,
                coherent=(span<=1 and abs(ppm)<=100),
                scope='Local sample phase modulo24, one clock epoch; physical phase-zero/reset latency not calibrated')
