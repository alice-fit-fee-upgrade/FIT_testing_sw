"""CFD0 finite OSERDES stimulus, bit0 earliest. Caller holds Kasli lease."""
import time


def pattern_words(period_words=1200,phase_bin=24,width_bins=20):
    if not 1<=period_words<=4096 or not 0<=phase_bin<period_words*8 or not 1<=width_bins<=period_words*8-phase_bin:
        raise ValueError('invalid CFD pattern')
    if phase_bin<8 or phase_bin+width_bins>period_words*8-8:raise ValueError('require idle first/last word')
    return [sum(int(phase_bin<=i*8+b<phase_bin+width_bins)<<b for b in range(8)) for i in range(period_words)]

class CFDBurstDevice:
    slot=7
    def __init__(self,device):
        self.device=device
        if device.read(0xfc)!=0x43464430:raise RuntimeError('CFD0 transmitter missing')
    def stop(self):
        self.device.write(0xe0,0)
        self.device.stop()
        if self.device.read(0xe0):raise RuntimeError('CFD output did not release')
    def directions(self,mask):
        if mask!=1:raise ValueError('Only slot7 channel0 may drive CFD')
        self.idle()
    def idle(self):
        self.device.write(0xe0,1)
        if self.device.read(0xe0)!=1:raise RuntimeError('CFD idle enable failed')
    def upload(self,words):
        status=self.device.read(0xe4)
        if status&0x1c:raise RuntimeError('CFD engine busy/error')
        for i,value in enumerate(words):
            if not 0<=value<=255:raise ValueError('invalid x8 word')
            self.device.write(0xe8,i);self.device.write(0xec,value)
        self.device.write(0xf0,len(words));end=time.monotonic()+.2
        while self.device.read(0xe4)&8:
            if time.monotonic()>end:raise TimeoutError('CFD pattern commit')
        if self.device.read(0xe4)&16:raise RuntimeError('CFD pattern rejected')
    def burst(self,repetitions):
        if not 1<=repetitions<=1000000:raise ValueError('invalid burst count')
        self.device.write(0xf4,repetitions)
        before=self.device.read(0xe4)>>16;self.device.write(0xe0,2)
        end=time.monotonic()+.2+repetitions*self.device.read(0xf0)/120e6
        while True:
            status=self.device.read(0xe4)
            if status&16:raise RuntimeError('CFD transmitter fault')
            if status>>16==(before+1)&0xffff and not status&4:break
            if time.monotonic()>end:raise TimeoutError('CFD finite burst')
        count=self.device.read(0xf8)
        if count!=repetitions:raise RuntimeError('CFD repeat counter mismatch')
        return dict(generation=status>>16,repetitions=count)
