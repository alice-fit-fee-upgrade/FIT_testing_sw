"""PML1 diagnostic on the RPH1 UART or IPbus transport (byte CSR addresses)."""
import time

class PMLink:
    def __init__(self,device):
        self.device=device
        if device.read(0x114)!=0x504d4c31:
            raise RuntimeError('PML1 extension required')

    def configure(self,*,loopback=False,prbs=True,mismatch=False,inject=False,restart=False):
        value=(2 if loopback else 0)|(16 if prbs else 0)|(32 if mismatch else 0)|(64 if inject else 0)|(256 if restart else 0)
        self.device.write(0x100,value)

    def snapshot(self):
        d=self.device
        return dict(control=d.read(0x100),status=d.read(0x104),error_samples=d.read(0x108),
                    sys_cycles=d.read(0x10c),reference_half_cycles=d.read(0x110))

    def window(self,seconds=3):
        if not .1<=seconds<=30:raise ValueError('bounded window .1..30 seconds')
        a=self.snapshot();start=time.monotonic();time.sleep(seconds);b=self.snapshot()
        delta=lambda key:(b[key]-a[key])&0xffffffff
        if a['control']!=b['control']:raise RuntimeError('control changed during measurement')
        return dict(before=a,after=b,elapsed_s=time.monotonic()-start,
                    error_samples=delta('error_samples'),
                    reference_to_sys_ratio=2*delta('reference_half_cycles')/delta('sys_cycles'))
