"""Bounded external RX probe; restore the stopped external120 ramp, not ARTIQ."""
import argparse
import hashlib
import json
from pathlib import Path
import time

from host.device import ROOT, Device, board_lock
from host.hardware_test import identify, jtag, loopback_test, check_capture
from host.lvds8_device import LVDSDevice
from host.lvds8_prepare_ramp import ramp
from host.analysis import capture_report, edges


def qualified_bit(build, filename, key):
    bit = build / filename
    q = json.loads((build / 'qualification.json').read_text())
    if not q['pass'] or hashlib.sha256(bit.read_bytes()).hexdigest() != q[key]:
        raise RuntimeError('Unqualified image: ' + str(bit))
    return bit


def cable_pattern():
    """PRBS7 x^7+x^6+1, bit0 of each word transmitted first."""
    state = 0x5d
    words = []
    for _ in range(127):
        word = 0
        for bit in range(40):
            word |= ((state >> 6) & 1) << bit
            state = ((state << 1) & 0x7f) | (((state >> 6) ^ (state >> 5)) & 1)
        words.append(word)
    return words


def cable_test(d, out, report, words, settle, held=False, internal=False, tx_before_init=False):
    pattern = cable_pattern()
    (out/'expected-words.json').write_text(json.dumps(pattern)+'\n')
    if tx_before_init:
        d.configure(enable=False, loopback=internal, cdr_hold=False, afe_hold=False)
        d.upload(pattern)
        d.configure(enable=True, loopback=internal, cdr_hold=False, afe_hold=False, restart=True)
        report['ready'] = d.wait_ready()
    else:
        d.configure(enable=False, loopback=internal, cdr_hold=False, afe_hold=False, restart=True)
        report['ready'] = d.wait_ready()
        d.upload([0x5555555555]*15 if held else pattern)
        d.configure(enable=True)
    time.sleep(settle)
    if held:
        d.configure(cdr_hold=True, afe_hold=True)
        d.upload(pattern)
        time.sleep(.01)
    report['captures'] = []
    report['restarts'] = []
    for i in range(3):
        capture = d.capture(words)
        if capture['control'] != (1 | (2 if internal else 0) | (0x60 if held else 0)):
            raise RuntimeError('Capture control does not match requested loopback/CDR mode')
        (out/f'capture-{i}.json').write_text(json.dumps(capture)+'\n')
        result = check_capture(d, capture, pattern, out, f'capture-{i}')
        report['captures'].append(result)
    for i in range(3):
        d.configure(enable=tx_before_init, loopback=internal, cdr_hold=False, afe_hold=False, restart=True)
        d.wait_ready()
        if held:
            d.upload([0x5555555555]*15)
        d.configure(enable=True)
        time.sleep(settle)
        if held:
            d.configure(cdr_hold=True, afe_hold=True)
            d.upload(pattern)
            time.sleep(.01)
        capture = d.capture(256)
        if capture['control'] != (1 | (2 if internal else 0) | (0x60 if held else 0)):
            raise RuntimeError('Restart capture control mismatch')
        (out/f'capture-restart-{i}.json').write_text(json.dumps(capture)+'\n')
        report['restarts'].append(check_capture(d, capture, pattern, out, f'capture-restart-{i}'))
    report['final_status'] = d.status()
    report['pass_'] = True


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--build-dir', type=Path, default=ROOT/'build/final125')
    p.add_argument('--afe-tracking', action='store_true', help='Keep analog adaptation active as a controlled comparison')
    p.add_argument('--windows', type=int, choices=range(1,4), default=3)
    p.add_argument('--words', type=int, choices=[1024,4096], default=4096)
    p.add_argument('--confirm-rx-ac-coupled', action='store_true',
                   help='Owner confirmed series AC coupling on BOTH RX conductors; required for800mV image')
    p.add_argument('--settle-seconds', type=float, default=.1,
                   help='Bounded startup adaptation time before freezing AFE and capturing')
    p.add_argument('--pma-loopback', action='store_true',
                   help='InternalPMA exact-pattern test, bank swap and3restarts; TXpins also drive pattern')
    p.add_argument('--cable-loopback', action='store_true',
                   help='Two-GTP externalcable PRBS7 test; peerTX->selectedRX with active CDR/AFE')
    p.add_argument('--cable-held', action='store_true',
                   help='Cable diagnostic comparison: train dense0101 then holdCDR/AFE beforePRBS')
    p.add_argument('--pma-prbs', action='store_true',
                   help='With --pma-loopback, use samePRBS7/activeCDR procedure as cabletest')
    p.add_argument('--internal-recovery', action='store_true',
                   help='Owner-selected switch to internalclock: restore stoppedslot6internal125 instead ofexternal120')
    p.add_argument('--tx-before-init', action='store_true',
                   help='PRBScomparison:preload pattern, keepTXenable asserted during GTPstartup soRXcanlocktoactive data')
    a = p.parse_args()
    if not 0 <= a.settle_seconds <= 10:
        p.error('--settle-seconds must be between0 and10')
    if a.pma_loopback and a.cable_loopback:
        p.error('Choose either internalPMA or externalcable test')
    if a.cable_held and not a.cable_loopback:
        p.error('--cable-held requires --cable-loopback')
    if a.pma_prbs and not a.pma_loopback:
        p.error('--pma-prbs requires --pma-loopback')
    if a.tx_before_init and (not (a.pma_prbs or a.cable_loopback) or a.cable_held):
        p.error('--tx-before-init requires activeCDR PRBScable orPMA test')
    out = a.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    candidate = qualified_bit(a.build_dir, 'phase_tester.bit', 'bitstream_sha256')
    qualification = json.loads((a.build_dir/'qualification.json').read_text())
    if hashlib.sha256((a.build_dir/'manifest.json').read_bytes()).hexdigest() != qualification['manifest_sha256']:
        raise RuntimeError('Candidate manifest mismatch')
    manifest = json.loads((a.build_dir/'manifest.json').read_text())
    if manifest['sfp'] not in (0,1,2) or manifest['ref_mhz'] != 125 or manifest['line_mbps'] not in (1250,6250):
        raise RuntimeError('Only safe channels0..2 and diagnostic125 profile supported')
    peer = manifest.get('peer_sfp')
    if a.cable_loopback:
        if peer not in (0,1,2) or peer == manifest['sfp']:
            raise RuntimeError('Cable test requires qualified two-GTP image with distinctpeer')
    elif peer is not None and not (a.pma_loopback and manifest.get('peer_internal_loopback')):
        raise RuntimeError('Two-GTP image must use --cable-loopback')
    if manifest.get('rx_common_mode','gnd') != 'gnd' and not a.confirm_rx_ac_coupled:
        raise RuntimeError('Do not load raised RX bias before owner confirms both RX conductors AC-coupled')
    if manifest.get('rx_startup_guard') and (a.pma_prbs or a.cable_loopback) and not a.tx_before_init:
        raise RuntimeError('GuardedPRBS startup requires --tx-before-init so data is available while RX initializes')
    recovery_profile = 'internal125' if a.internal_recovery else 'external120'
    recovery_dir = 'lvds8-trigger-slot6-125-v2' if a.internal_recovery else 'hdmi-external120-slot6-20261027'
    recovery = qualified_bit(ROOT/'build'/recovery_dir, 'lvds8.bit', 'bit_sha256')
    report = dict(pass_=False, restored=False, persistent_writes=False,
                  sfp=manifest['sfp'], scope='Single RX presence/spacing, fixed125 nominal scale; no phase calibration', captures=[])
    report['candidate_sha256'] = hashlib.sha256(candidate.read_bytes()).hexdigest()
    report['recovery_sha256'] = hashlib.sha256(recovery.read_bytes()).hexdigest()
    report['afe_tracking'] = a.afe_tracking
    report['rx_common_mode'] = manifest.get('rx_common_mode','gnd')
    report['owner_confirmed_rx_ac_coupled'] = a.confirm_rx_ac_coupled
    report['settle_seconds'] = a.settle_seconds
    report['mcx_forwarded'] = manifest.get('mcx_forwarded',True)
    report['recovery_profile'] = recovery_profile
    report['tx_enabled_during_init'] = a.tx_before_init
    report['line_mbps'] = manifest['line_mbps']
    report['rx_startup_guard'] = manifest.get('rx_startup_guard',False)
    report['mode'] = 'near-end-PMA-loopback' if a.pma_loopback else 'external-RX'
    report['tx_pattern_on_connector'] = a.pma_loopback
    if a.pma_loopback:
        report['scope'] = 'InternalPMA exact raw-bit comparison, bank swap and3restarts; not external RX analog qualification'
        if a.pma_prbs:
            report.update(scope='InternalPMA PRBS7 with activeCDR/AFE; control for externalcable test',
                          afe_tracking=True, cdr_held_after_training=False, training_pattern='PRBS7')
    if a.cable_loopback:
        report.update(mode='external-cable', tx_sfp=peer, rx_sfp=manifest['sfp'],
                      scope='Externalcable PRBS7 raw-bit comparison; not phase calibration',
                      tx_pattern_on_connector=True, afe_tracking=not a.cable_held,
                      cdr_held_after_training=a.cable_held,
                      training_pattern='0101' if a.cable_held else 'PRBS7')
    changed = False
    d = None
    with board_lock():
        try:
            report['usb'] = identify()
            cmd = 'adapter usb location ' + Path(report['usb']['sysfs']).name + '; init; '
            jtag(cmd+'virtex2 read_stat 0; shutdown', 'before-jtag', out)
            resident = LVDSDevice()
            try:
                report['before'] = resident.status()
                allowed_profiles = ('external120','internal125') if a.internal_recovery else ('external120',)
                if resident.clock_profile not in allowed_profiles or resident.slot != 6 or resident.period_bins not in (24,25):
                    raise RuntimeError('Unexpected resident profile; no programming')
                if resident.status()['enabled'] or resident.status()['output_mask'] or resident.status()['busy']:
                    raise RuntimeError('Resident instrument active; no programming')
            finally:
                resident.close()
            changed = True
            jtag(cmd+'pld load 0 {'+str(candidate)+'}; shutdown', 'load', out)
            d = Device()
            if d.read(0x7c) != manifest['sfp'] or d.ref_hz != 125000000 or d.line_mbps != manifest['line_mbps']:
                raise RuntimeError('Unexpected RX image')
            if peer is not None and manifest.get('peer_internal_loopback'):
                if d.version not in (0x10004,0x10005,0x10006) or d.read(0x80) != peer:
                    raise RuntimeError('Unexpected dual-GTP diagnostic ABI/peer')
            if manifest.get('rx_startup_guard') and (d.version not in (0x10005,0x10006) or d.read(0x84) != 1):
                raise RuntimeError('RXstartupguard ABI/readback mismatch')
            if a.cable_loopback:
                if d.version not in (0x10003,0x10004,0x10005,0x10006) or d.read(0x80) != peer:
                    raise RuntimeError('Unexpected cableTX/RX selection')
                cable_test(d, out, report, a.words, a.settle_seconds, a.cable_held, tx_before_init=a.tx_before_init)
            elif a.pma_loopback:
                if a.pma_prbs:
                    cable_test(d, out, report, a.words, a.settle_seconds, internal=True, tx_before_init=a.tx_before_init)
                else:
                    loopback_test(d, out, report, a.words)
                    report['pass_'] = report.get('pass', False)
            else:
                d.configure(enable=False, loopback=False, cdr_hold=True, afe_hold=False, restart=True)
                report['ready'] = d.wait_ready()
                time.sleep(a.settle_seconds)
                d.configure(afe_hold=not a.afe_tracking)
                for i in range(a.windows):
                    cap = d.capture(a.words)
                    (out/f'raw-{i}.json').write_text(json.dumps(cap)+'\n')
                    summary = capture_report(cap)
                    summary.pop('timestamps')
                    summary['phase_statistics_scope'] = 'Modulo150 is diagnostic only at6.25Gb/s, not40MHz phase'
                    hits = [h['sample'] for h in edges(cap['words'],cap['start_sample'],cap['previous'])]
                    intervals = [b-a for a,b in zip(hits,hits[1:])]
                    expected = d.line_mbps / 40
                    fraction = sum(abs(x-expected)<=2 for x in intervals)/len(intervals) if intervals else 0
                    summary['fraction_periods_near_40mhz'] = fraction
                    summary['clock_40mhz_plausible'] = len(intervals)>100 and fraction>=.99
                    report['captures'].append(summary)
                report['signal_observed'] = all(c['count'] > 0 for c in report['captures'])
                report['acquisition_pass'] = report['signal_observed']
                report['pass_'] = all(c['clock_40mhz_plausible'] for c in report['captures'])
        except Exception as exc:
            report['error'] = repr(exc)
            if d is not None and d.version >= 0x10006:
                report['failure_status_samples'] = []
                try:
                    for _ in range(20):
                        report['failure_status_samples'].append(d.status())
                        time.sleep(.005)
                except Exception as diagnostic_error:
                    report['diagnostic_read_error'] = repr(diagnostic_error)
        finally:
            if d is not None:
                try:
                    try:
                        d.configure(enable=False)
                    finally:
                        d.close()
                except Exception as exc:
                    report['cleanup_error'] = repr(exc)
            if changed:
                try:
                    jtag(cmd+'pld load 0 {'+str(recovery)+'}; shutdown', 'restore', out)
                    resident = LVDSDevice()
                    try:
                        resident.stop()
                        resident.directions(0)
                        resident.upload_lanes({ch:ramp() for ch in range(8,12)})
                        report['after'] = resident.status()
                        report['restored'] = (resident.clock_profile == recovery_profile and resident.status()['ready']
                                              and not resident.status()['enabled'] and resident.status()['output_mask'] == 0)
                    finally:
                        resident.close()
                except Exception as exc:
                    report['restore_error'] = repr(exc)
            (out/'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k != 'captures'}, indent=2))
    for i,c in enumerate(report['captures']):
        print(json.dumps(dict(window=i, count=c.get('count'), edge_spacing=c.get('edge_spacing'),
                              compared_bits=c.get('compared_bits'), errors=c.get('errors'))))
    if not report['pass_'] or not report['restored']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
