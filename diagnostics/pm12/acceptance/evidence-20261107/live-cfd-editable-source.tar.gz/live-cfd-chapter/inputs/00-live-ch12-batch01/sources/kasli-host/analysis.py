"""Decode every transition, retain coarse timestamp and phase statistics."""
from collections import Counter
import math
import statistics


def edges(words, start_sample=0, previous=0, polarity='rising', word_width=40):
    if not isinstance(word_width, int) or word_width < 1: raise ValueError('invalid word width')
    if polarity not in ('rising','falling','both'): raise ValueError('invalid polarity')
    result=[]
    for index, word in enumerate(words):
        if not isinstance(word, int) or not 0 <= word < 1 << word_width: raise ValueError('invalid sample word')
        for bit in range(word_width):
            value=(word >> bit)&1
            if value != previous and (polarity == 'both' or (value and polarity=='rising') or (not value and polarity=='falling')):
                result.append({'sample':start_sample+word_width*index+bit,'rising':bool(value)})
            previous=value
    return result


def phase_statistics(timestamps, period=150, zero_sample=0, ui_ps=1000/6, expected_per_period=1):
    """Circular mean then unwrap near mean. Sigma is population sigma.

    Coarse/fine are integer divmod after zero correction. Empty captures are
    invalid; broadly distributed phases have no meaningful circular mean.
    Missing-period count excludes unobserved periods before/after first/last hit.
    """
    if period <= 0 or ui_ps <= 0: raise ValueError('invalid time scale')
    corrected=[int(t)-int(zero_sample) for t in timestamps]
    records=[{'sample':t,'coarse':t//period,'fine':t%period} for t in corrected]
    phases=[r['fine'] for r in records]
    histogram=[0]*period
    for f in phases: histogram[f]+=1
    result={'count':len(phases),'period_bins':period,'ui_ps':ui_ps,
            'histogram':histogram,'timestamps':records,'valid':False,
            'mean_phase_ps':None,'sigma_ps':None,'circular_concentration':None}
    if not phases: return result
    z=sum(complex(math.cos(2*math.pi*f/period),math.sin(2*math.pi*f/period)) for f in phases)/len(phases)
    result['circular_concentration']=abs(z)
    occupancy=Counter(r['coarse'] for r in records)
    lo,hi=min(occupancy),max(occupancy)
    result['missing_periods_between_hits']=(hi-lo+1)-len(occupancy)
    result['extra_edges_between_hits']=sum(max(0,n-expected_per_period) for n in occupancy.values())
    if abs(z) < 1e-6: return result
    center=(math.atan2(z.imag,z.real)*period/(2*math.pi))%period
    unwrapped=[center+((f-center+period/2)%period)-period/2 for f in phases]
    mean=statistics.mean(unwrapped)%period
    result.update(valid=True,mean_phase_ps=mean*ui_ps,
                  sigma_ps=statistics.pstdev(unwrapped)*ui_ps,
                  min_unwrapped_ps=min(unwrapped)*ui_ps,max_unwrapped_ps=max(unwrapped)*ui_ps)
    return result


def capture_report(capture, zero_sample=None, period=150):
    hits=edges(capture['words'],capture['start_sample'],capture['previous'])
    stats=phase_statistics([h['sample'] for h in hits],period,
                           0 if zero_sample is None else zero_sample,capture['ui_ps'])
    held=bool(capture['control']&0x20) if 'control' in capture else None
    if zero_sample is not None and held is False:
        raise ValueError('phase-reference calibration requires held CDR')
    stats['reference_calibrated']=zero_sample is not None and held is True
    stats['cdr_held']=held
    stats['afe_held']=bool(capture['control']&0x40) if 'control' in capture else None
    stats['capture_id']=capture.get('capture_id')
    stats['capture_valid']=capture.get('valid',False)
    if not stats['capture_valid']:
        stats['valid']=False
    stats['clock_profile']=capture.get('clock_profile')
    intervals=[hits[i+1]['sample']-hits[i]['sample'] for i in range(len(hits)-1)]
    if intervals:
        mean=statistics.mean(intervals)
        stats['edge_spacing']={'mean_samples':mean,'mean_ps':mean*capture['ui_ps'],
            'sigma_ps':statistics.pstdev(intervals)*capture['ui_ps'],
            'min_samples':min(intervals),'max_samples':max(intervals),
            'estimated_mhz':1e6/(mean*capture['ui_ps'])}
    return stats
