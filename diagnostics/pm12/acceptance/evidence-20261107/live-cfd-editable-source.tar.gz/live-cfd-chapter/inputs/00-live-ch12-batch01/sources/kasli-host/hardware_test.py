"""Bounded SRAM-only diagnostic, exact USB/TAP checks, baseline restore."""
import argparse
import datetime
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path
import serial
from host.device import Device, board_lock, UART, ROOT
from host.pattern import Pulse, compile_pattern
from host.analysis import edges, capture_report

BASE=Path('/home/codex-hil/kasli-diot-bringup')
BASELINE=BASE/'build/diot_standalone/gateware/top.bit'
BASELINE_SHA='c5662ae4f3a89f1a54317c5eb4ce8df87a884b06151ce27b14936fb5062eaf18'
OPENOCD=BASE/'tools/openocd/bin/openocd'


def identify():
    matches=[]
    for p in Path('/sys/bus/usb/devices').glob('*'):
        try:
            if (p/'serial').read_text().strip()=='00001':
                expected={'manufacturer':'Xilinx','product':'Artix-7 DIOT System Board','idVendor':'0403','idProduct':'6011'}
                actual={k:(p/k).read_text().strip() for k in expected}
                if actual!=expected: raise RuntimeError(f'USB identity mismatch: {actual}')
                matches.append({'sysfs':str(p),'serial':'00001',**actual})
        except (FileNotFoundError,NotADirectoryError): pass
    if len(matches)!=1: raise RuntimeError(f'expected exactly one DIOT 00001: {matches}')
    return matches[0]


def jtag(commands,label,out,timeout=90):
    result=subprocess.run([str(OPENOCD),'-f',str(BASE/'tools/board.cfg'),'-c',commands],capture_output=True,text=True,timeout=timeout)
    log=result.stdout+result.stderr
    (out/(label+'.log')).write_text(log)
    if result.returncode or not re.search(r'tap/device found: 0x13636093',log):
        raise RuntimeError(f'JTAG failed / wrong TAP ({label}); inspect {out}')
    return log


def check_pattern(capture,words):
    expected=''.join(str((w>>i)&1) for w in words for i in range(40))
    actual=''.join(str((w>>i)&1) for w in capture['words'] for i in range(40))
    prefix=actual[:min(len(actual),1024)]
    doubled=expected*((len(prefix)+len(expected)-1)//len(expected)+1)
    offsets=[]
    index=doubled.find(prefix)
    while 0<=index<len(expected):
        offsets.append(index)
        index=doubled.find(prefix,index+1)
    for offset in offsets:
        reference=(expected*((len(actual)+offset)//len(expected)+2))[offset:offset+len(actual)]
        if reference==actual:
            return {'pass':True,'cyclic_offset_bits':offset,'compared_bits':len(actual),'errors':0}
    raise AssertionError(f'raw PMA pattern mismatch; first 80 bits {actual[:80]}, candidates {offsets}')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build-dir',default='build/final125')
    p.add_argument('--output',default='evidence/hil-final125')
    p.add_argument('--preflight-only',action='store_true')
    p.add_argument('--external',action='store_true',help='Capture external SFP RX with TX inhibited; restore baseline afterwards')
    p.add_argument('--capture-words',type=int,default=256,help='Finite window per trial; default 256 words')
    p.add_argument('--phase-sweep',action='store_true',help='Also validate all 150 phase codes against raw captured bits')
    a=p.parse_args()
    out=ROOT/a.output; out.mkdir(parents=True,exist_ok=True)
    report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hardware_test':
            'external-RX-capture' if a.external else 'raw-GTP-near-end-PMA-loopback',
            'external_signal_test':'NOT_RUN','flash_written':False,'restored':False,'pass':False}
    with board_lock():
        report['usb']=identify()
        if hashlib.sha256(BASELINE.read_bytes()).hexdigest()!=BASELINE_SHA: raise RuntimeError('baseline SHA mismatch')
        jtag('init; virtex2 read_stat 0; shutdown','preflight-jtag',out)
        if a.preflight_only:
            (out/'preflight.json').write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report,indent=2)); return
        build=ROOT/a.build_dir
        candidate=build/'phase_tester.bit'
        # Timing/DRC guard must be generated from the same final routed DCP.
        qualification=json.loads((build/'qualification.json').read_text())
        sha=hashlib.sha256(candidate.read_bytes()).hexdigest()
        if not qualification['pass'] or qualification['bitstream_sha256']!=sha: raise RuntimeError('unqualified candidate')
        if qualification['manifest_sha256']!=hashlib.sha256((build/'manifest.json').read_bytes()).hexdigest():
            raise RuntimeError('build manifest does not match qualification')
        report['bitstream_sha256']=sha; report['qualification']=qualification
        port=serial.Serial(UART,115200,timeout=.1)
        changed=False
        d=None
        start=time.monotonic()
        try:
            identify()
            changed=True
            jtag(f'init; pld load 0 {{{candidate}}}; virtex2 read_stat 0; shutdown','load',out)
            port.close()
            d=Device(); report['initial_status']=d.status()
            if a.external:
                d.configure(enable=False,loopback=False,restart=True)
                d.wait_ready()
                summaries=[]
                for i in range(3):
                    capture=d.capture(a.capture_words)
                    (out/f'capture-{i}.json').write_text(json.dumps(capture,indent=2)+'\n')
                    summary=capture_report(capture)
                    # This validates successful capture and nonempty signal,
                    # not external phase accuracy or a particular frequency.
                    if summary['count']==0: raise AssertionError('no rising edge on external RX')
                    summary.pop('timestamps'); summary.pop('histogram')
                    summaries.append(summary)
                report['captures']=summaries
                report['external_signal_test']='CAPTURED; accuracy/calibration NOT_VALIDATED'
                report['pass']=True
                return_after_capture=True
            else:return_after_capture=False
            if return_after_capture:
                report['final_status']=d.status()
            else:
                loopback_test(d,out,report,a.capture_words)
                if a.phase_sweep:
                    sweep=[]
                    for phase in range(150):sweep.extend([Pulse(phase,6),Pulse(0,0,False)])
                    waveform=compile_pattern(sweep,d.depth)
                    train_sampler(d); d.upload(waveform['words'])
                    capture=d.capture(d.depth)
                    (out/'capture-phase-sweep.json').write_text(json.dumps(capture,indent=2)+'\n')
                    report['phase_sweep']=check_capture(d,capture,waveform['words'],out,'capture-phase-sweep')
                    report['phase_sweep'].update(phase_codes=150,pattern_words=len(waveform['words']))
        except Exception as exc:
            report['pass']=False
            report['error']=f'{type(exc).__name__}: {exc}'
        finally:
            if d is not None:
                try:d.configure(enable=False)
                except Exception:pass
                try:d.close()
                except Exception as exc:report['uart_cleanup_error']=str(exc)
            try:port.close()
            except Exception as exc:report['baseline_port_cleanup_error']=str(exc)
            if changed:
                try:
                    with serial.Serial(UART,115200,timeout=.1) as restore_port:
                        restore_port.reset_input_buffer()
                        jtag(f'init; pld load 0 {{{BASELINE}}}; virtex2 read_stat 0; shutdown','restore',out)
                        logs=bytearray(); deadline=time.monotonic()+35
                        while time.monotonic()<deadline:
                            logs.extend(restore_port.read(65536))
                            if b'network sessions' in logs or b'accepting network' in logs:break
                        (out/'restore-uart.log').write_bytes(logs)
                        clock_ready=(b'Si5324' in logs and b'locked' in logs) or b'clocking has already been set up' in logs
                        report['restore_clock_ready']=clock_ready
                        report['restored']=clock_ready and b'ARTIQ runtime starting' in logs and b'accepting network sessions' in logs
                        report['restore_runtime_started']=b'ARTIQ runtime' in logs
                except Exception as exc:report['restore_error']=str(exc)
            report['lock_seconds']=time.monotonic()-start
            (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    if not report['pass'] or not report['restored']: raise SystemExit(1)


def loopback_test(d,out,report,capture_words=256):
    d.configure(enable=False,loopback=True,restart=True)
    d.wait_ready()
    pattern=compile_pattern([Pulse(0,12),Pulse(149,6),Pulse(39,20),Pulse(100,1)])
    train_sampler(d)
    d.upload(pattern['words'])
    tests=[]
    for i in range(3):
        capture=d.capture(capture_words)
        (out/f'capture-{i}.json').write_text(json.dumps(capture,indent=2)+'\n')
        match=check_capture(d,capture,pattern['words'],out,f'capture-{i}')
        hits=edges(capture['words'],capture['start_sample'],capture['previous'])
        match['rising_edges']=len(hits)
        match['capture_start']=capture['start_sample']
        tests.append(match)
    report['captures']=tests
    # Physical live bank replacement and a reset/reinitialization.
    second=compile_pattern([Pulse(20,10)])
    d.upload(second['words'])
    capture=d.capture(max(1,capture_words//2)); (out/'capture-live-swap.json').write_text(json.dumps(capture,indent=2)+'\n')
    report['live_swap']=check_capture(d,capture,second['words'],out,'capture-live-swap')
    restarts=[]
    for i in range(3):
        d.configure(enable=False,loopback=True,restart=True); d.wait_ready(); d.configure(enable=True)
        train_sampler(d)
        d.upload(second['words'])
        capture=d.capture(max(1,capture_words//2)); (out/f'capture-restart-{i}.json').write_text(json.dumps(capture,indent=2)+'\n')
        restarts.append(check_capture(d,capture,second['words'],out,f'capture-restart-{i}'))
    report['restarts']=restarts
    report['final_status']=d.status()
    report['pass']=True


def train_sampler(d):
    # Dense known data puts the sampler away from transitions. Hold CDR and
    # analog offset/equalizer adaptation before replacing it with sparse CFD
    # pulses; otherwise the operating point may change with signal duty cycle.
    d.configure(cdr_hold=False,afe_hold=False)
    d.upload([0x5555555555]*15); d.configure(enable=True)
    time.sleep(.1)
    d.configure(cdr_hold=True,afe_hold=True)
    time.sleep(.01)


def check_capture(d,capture,words,out,label):
    try:return check_pattern(capture,words)
    except AssertionError:
        # Do not turn a failed capture into a pass by retrying. Read the same
        # frozen RAM again solely to distinguish readout corruption from data
        # actually recorded by the receiver.
        reread=d.read_capture_words(len(capture['words']))
        diagnostic={'same_frozen_words':reread==capture['words'],
                    'differences':[{'index':i,'first':a,'second':b}
                                   for i,(a,b) in enumerate(zip(capture['words'],reread)) if a!=b],
                    'reread_words':reread}
        (out/(label+'-reread.json')).write_text(json.dumps(diagnostic,indent=2)+'\n')
        raise

if __name__=='__main__':main()
