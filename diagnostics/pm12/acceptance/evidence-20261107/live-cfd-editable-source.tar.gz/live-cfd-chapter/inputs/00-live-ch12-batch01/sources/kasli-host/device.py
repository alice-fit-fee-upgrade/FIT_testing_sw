"""Guarded UART access; all transport holds the DIOT board lock."""
import contextlib
import fcntl
import struct
import time
from pathlib import Path
import serial
import array
import termios

ROOT=Path(__file__).resolve().parents[1]
LOCK=Path('/home/codex-hil/.cache/kasli-diot-00001.lock')
UART='/dev/serial/by-id/usb-Xilinx_Artix-7_DIOT_System_Board_00001-if02-port0'


@contextlib.contextmanager
def board_lock():
    with LOCK.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield lock


class Device:
    def __init__(self, port=UART):
        self.serial=serial.Serial(port,1000000,timeout=2,write_timeout=2)
        self.old_low_latency=None
        self.low_latency=False
        try:
            state=array.array('i',[0]*32)
            fcntl.ioctl(self.serial.fd,termios.TIOCGSERIAL,state)
            self.old_low_latency=bool(state[4]&0x2000)
            self.serial.set_low_latency_mode(True)
            self.low_latency=True
        except (OSError,ValueError):
            self.old_low_latency=None
        self.serial.reset_input_buffer()
        self.control=0
        try:self.identify()
        except Exception:
            self.close()
            raise

    def identify(self):
        if self.read(0) != 0x4b505431:
            raise RuntimeError('Kasli phase tester KPT1 image required')
        self.depth=self.read(0x78)
        self.version=self.read(4)
        self.ref_hz=self.read(0x70)
        self.line_mbps=self.read(0x74)
        self.ui_ps=1e6/self.line_mbps
        self.control=self.read(8)

    def close(self):
        try:
            if self.old_low_latency is not None and self.serial.is_open:
                self.serial.set_low_latency_mode(self.old_low_latency)
        finally:self.serial.close()

    def exchange(self, opcode, address, value=0):
        self.serial.write(struct.pack('<BHI',opcode,address,value))
        data=self.serial.read(6)
        if len(data)!=6: raise TimeoutError(f'UART timeout at 0x{address:04x}: {data.hex()}')
        addr,result=struct.unpack('<HI',data)
        if addr!=address: raise RuntimeError('UART reply address mismatch')
        return result

    def read(self,address): return self.exchange(0,address)
    def write(self,address,value): return self.exchange(1,address,value)

    def status(self):
        raw=self.read(12)
        names=['pll_lock','tx_ready','rx_ready','rx_mmcm_lock','active_bank','swap_pending',
               'capture_busy','capture_done','pattern_error','capture_error']
        result=dict(zip(names,[(raw>>i)&1 for i in range(len(names))]),raw=raw,
                    ref_hz=self.ref_hz,line_mbps=self.line_mbps,ui_ps=self.ui_ps,
                    sfp=self.read(0x7c),version=self.version,uart_low_latency=self.low_latency)
        if self.version>=0x10006:
            dbg=self.read(0x88)
            result.update(rx_debug=dbg,rx_init_phase=(dbg>>8)&15,
                          rx_cdr_wait_done=bool(dbg&0x1000),rx_watchdog_resets=self.read(0x8c))
        return result

    def configure(self,enable=None,loopback=None,rx_invert=None,tx_invert=None,restart=False,cdr_hold=None,afe_hold=None):
        for bit,value in enumerate((enable,loopback,rx_invert,tx_invert)):
            if value is not None: self.control=(self.control&~(1<<bit))|(bool(value)<<bit)
        if cdr_hold is not None:
            if self.version<0x10001: raise RuntimeError('CDR control requires instrument version 0x10001')
            self.control=(self.control&~0x20)|(bool(cdr_hold)<<5)
        if afe_hold is not None:
            if self.version<0x10002: raise RuntimeError('AFE hold requires instrument version 0x10002')
            self.control=(self.control&~0x40)|(bool(afe_hold)<<6)
        self.write(8,self.control|(int(restart)<<4))

    def wait_ready(self,timeout=3):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            s=self.status()
            if s['tx_ready'] and s['rx_ready'] and s['pll_lock']: return s
            time.sleep(.01)
        raise TimeoutError(f'GTP not ready: {s}')

    def upload(self,words):
        if not 1<=len(words)<=self.depth: raise ValueError('invalid pattern length')
        if self.status()['swap_pending']: raise RuntimeError('previous bank swap pending')
        for i,w in enumerate(words):
            if not 0<=w<1<<40: raise ValueError('invalid pattern word')
            self.write(0x10,i); self.write(0x14,w&0xffffffff); self.write(0x18,w>>32); self.write(0x1c,1)
        self.write(0x20,len(words)); self.write(0x24,1)
        deadline=time.monotonic()+2
        while self.status()['swap_pending']:
            if time.monotonic()>deadline: raise TimeoutError('pattern bank swap')
        if self.status()['pattern_error']: raise RuntimeError('pattern hardware rejected write/commit')

    def capture(self,words=4096):
        if not 1<=words<=self.depth: raise ValueError('invalid capture length')
        if self.status()['capture_busy']: raise RuntimeError('capture already active')
        self.write(0x30,words); self.write(0x34,1)
        deadline=time.monotonic()+3
        while True:
            s=self.status()
            if not s['capture_busy']:
                if s['capture_error'] or not s['capture_done']: raise RuntimeError(f'capture invalid: {s}')
                break
            if time.monotonic()>deadline: raise TimeoutError('capture handshake')
        count=self.read(0x38)
        base=self.read(0x40)|(self.read(0x44)<<32)
        prev=self.read(0x48)&1
        data=self.read_capture_words(count)
        return {'valid':True,'words':data,'start_sample':base,'previous':prev,
                'capture_id':self.read(0x3c),'ui_ps':self.ui_ps,'control':self.read(8),'clock_profile':
                {'ref_hz':self.ref_hz,'line_mbps':self.line_mbps},'status':s}

    def read_capture_words(self,count):
        if not 1<=count<=self.depth: raise ValueError('invalid frozen capture count')
        data=[]
        for i in range(count):
            self.write(0x50,i)
            data.append(self.read(0x54)|(self.read(0x58)<<32))
        return data
