"""Physical lower-RJ45 ramp test: TX8..11 -> RX12..15, preserve upper HDMI."""
import argparse,json,time,hashlib
from contextlib import contextmanager
from pathlib import Path
from host.device import board_lock,ROOT
from host.hardware_test import identify,jtag
from host.lvds8_device import LVDSDevice
from host.lvds8_dio import dio_directions
from host.lvds8_prepare_ramp import ramp
from host.lvds8 import compile_lane
from host.lvds8_loopback import match_bits
from host.hdmi_check import check_phase_records
from host.lvds8_cli import analyze


@contextmanager
def temporary_slot(slot,out,report):
    if slot==6:
        yield
        return
    builds=[ROOT/'build/lvds8-external120-slot7-20261028',ROOT/'build/hdmi-external120-slot6-20261027']
    for build in builds:
        q=json.loads((build/'qualification.json').read_text())
        assert q['pass'] and hashlib.sha256((build/'lvds8.bit').read_bytes()).hexdigest()==q['bit_sha256']
        assert hashlib.sha256((build/'manifest.json').read_bytes()).hexdigest()==q['manifest_sha256']
    probe=LVDSDevice()
    try:
        assert probe.slot==6 and probe.clock_profile=='external120'
        state=probe.status();assert not state['enabled'] and not state['busy'] and state['output_mask']==0,'Resident tester in use'
    finally:probe.close()
    cmd='adapter usb location '+Path(identify()['sysfs']).name+'; init; '
    try:
        jtag(cmd+'pld load 0 {'+str(builds[0]/'lvds8.bit')+'}; shutdown','slot7-load',out)
        yield
    finally:
        try:
            jtag(cmd+'pld load 0 {'+str(builds[1]/'lvds8.bit')+'}; shutdown','slot6-restore',out)
            probe=LVDSDevice()
            try:
                probe.stop();probe.directions(0);probe.upload_lanes({ch:ramp() for ch in range(8,12)})
                report['restored_slot6']=probe.status()
                assert probe.slot==6 and not report['restored_slot6']['enabled'] and report['restored_slot6']['output_mask']==0
            finally:probe.close()
        except BaseException as e:
            report['restore_error']=repr(e);report['pass_']=False;raise
        finally:(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--slot',type=int,choices=[6,7],default=6)
    p.add_argument('--reverse',action='store_true');p.add_argument('--settled-only',action='store_true')
    a=p.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    sources=list(range(12,16) if a.reverse else range(8,12));receivers=list(range(8,12) if a.reverse else range(12,16))
    report=dict(pass_=False,persistent_writes=False,physical_loopback=dict(sources=sources,receivers=receivers,user_confirmed_lower_RJ45_cable=True),captures=[])
    d=None
    with board_lock(),temporary_slot(a.slot,out,report):
        try:
            report['usb']=identify();d=LVDSDevice()
            assert d.slot==a.slot and d.clock_profile=='external120' and d.period_bins==24,'Expected resident slot6 external120 tester'
            report['slot']=a.slot;report['before']=d.status();assert not report['before']['enabled'],'Another generator is running'
            events=ramp();expected=compile_lane(events,period_bins=24,sample_ps=d.sample_ps)['words']
            report['pattern']=events;report['expected_words']=expected
            d.upload_lanes({ch:events for ch in sources})
            with dio_directions(d,sum(1<<ch for ch in sources)):
                if a.settled_only:
                    d.arm_test(1,generator=True,measurement=False);d.trigger();time.sleep(.02)
                for index in range(1 if a.settled_only else 2):
                    ticket=d.arm_test(4095,generator=index==0 and not a.settled_only);d.trigger()
                    capture=d.read_capture(ticket,receivers,metadata=dict(mode='physical-lower-RJ45-ramp',generator_restarted=index==0 and not a.settled_only))
                    (out/f'raw-{index}.json').write_text(json.dumps(capture)+'\n')
                    comparisons=[]
                    for row in capture['channels']:
                        result=dict(channel=row['channel'],hardware_phase_records=check_phase_records(row))
                        try:result.update(match_bits(row['words'],expected),exact=True)
                        except AssertionError:
                            bits=''.join(str((w>>i)&1) for w in row['words'] for i in range(8))
                            pattern=''.join(str((w>>i)&1) for w in expected for i in range(8))
                            repeated=pattern*((len(bits)+len(pattern)-1)//len(pattern)+1)
                            value=int(bits,2)
                            errors=[(value^int(repeated[offset:offset+len(bits)],2)).bit_count() for offset in range(len(pattern))]
                            offset=min(range(len(pattern)),key=errors.__getitem__)
                            result.update(exact=False,best_offset_bits=offset,bit_mismatches=errors[offset],compared_bits=len(bits))
                        comparisons.append(result)
                    (out/f'phase-{index}.json').write_text(json.dumps(analyze(capture))+'\n')
                    assert d.status()['enabled'],'Generator stopped during readout'
                    report['captures'].append(dict(index=index,comparisons=comparisons,capture_id=capture['metadata']['capture_id'],start_sample=capture['channels'][0]['start_sample']))
                    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
                    print(json.dumps(report['captures'][-1]),flush=True)
                if len(report['captures'])>1:assert report['captures'][1]['capture_id']==(report['captures'][0]['capture_id']+1)&0xffffffff
                d.stop()
            d.directions(0);report['pass_']=all(row['exact'] for capture in report['captures'] for row in capture['comparisons'])
        except BaseException as e:
            report['error']=repr(e);raise
        finally:
            try:
                if d is not None:
                    try:d.stop();report['after']=d.status()
                    finally:d.close()
            finally:(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    if not report['pass_']:raise SystemExit(1)

if __name__=='__main__':main()
