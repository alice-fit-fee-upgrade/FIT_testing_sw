"""Reversible direction/mux selection for the verified DIOT V4 DIO card."""
from contextlib import contextmanager
from pathlib import Path
from pyftdi.i2c import I2cController
import usb.core

@contextmanager
def dio_directions(device,mask,*,before_restore=None,controller=None):
    device.stop()  # FPGA releases before any repeater direction change.
    matches=[]
    for path in Path('/sys/bus/usb/devices').iterdir():
        try:
            if (path/'serial').read_text().strip()=='00001' and (path/'product').read_text().strip()=='Artix-7 DIOT System Board':
                matches.append((int((path/'busnum').read_text()),int((path/'devnum').read_text())))
        except (FileNotFoundError,PermissionError):pass
    if len(matches)!=1:raise RuntimeError('Kasli-DIOT USB identity missing/ambiguous')
    bus,address=matches[0];dev=usb.core.find(idVendor=0x0403,idProduct=0x6011,bus=bus,address=address)
    provided=controller is not None
    ctl=controller if provided else I2cController();saved_mux=None;saved=None;pcf={};gpio=None
    try:
        if not provided:
            ctl.configure(dev,interface=2,frequency=50000,direction=0x60,initial=0x40)
            gpio=ctl.get_gpio();gpio.set_direction(0x60,0x60);gpio.write(0x40)
        saved_mux=ctl.read(0x70,1)[0];ctl.write(0x70,b'\x08')
        def rd(reg):return ctl.exchange(0x76,bytes([reg]),1)[0]
        def wr(reg,value):ctl.write(0x76,bytes([reg,value]))
        saved=[rd(i) for i in range(8)];base=(saved[3]&0x1f)|0x20
        # Save the entire register state before the first modifying write.
        wr(3,base|0x80);wr(7,saved[7]&0x1f)
        wr(2,1<<[0,2,3,1,4,7,6,5][device.slot-1]);wr(6,0);wr(3,base|0x40)
        ctl.write(0x70,b'\x48')
        for addr in [0x3e,0x3f]:pcf[addr]=ctl.read(addr,1)[0]
        ctl.write(0x3e,bytes([mask&255]));ctl.write(0x3f,bytes([mask>>8]))
        actual=ctl.read(0x3e,1)[0]|(ctl.read(0x3f,1)[0]<<8)
        if actual!=mask:raise RuntimeError('DIO direction readback mismatch')
        device.directions(mask)
        yield
    finally:
        # If FPGA release fails, do not reverse buffer directions into it.
        try:
            device.stop()
            # Release external transmitters before restoring potentially opposite directions.
            if before_restore is not None:before_restore()
            if pcf:
                ctl.write(0x70,b'\x48')
                for addr,value in pcf.items():ctl.write(addr,bytes([value]))
            if saved is not None:
                ctl.write(0x70,b'\x08');wr(3,base|0x80);wr(6,255)
                wr(2,saved[2]);wr(7,saved[7]);wr(6,saved[6]);wr(3,saved[3])
            if saved_mux is not None:ctl.write(0x70,bytes([saved_mux]))
        finally:
            if gpio is not None:gpio.write(0)
            if not provided:ctl.terminate()
