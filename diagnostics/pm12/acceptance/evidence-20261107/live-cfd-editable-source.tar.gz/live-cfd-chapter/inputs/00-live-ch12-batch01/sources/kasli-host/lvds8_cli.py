"""Build raw-word, per-edge phase tables and circular statistics from LVDS captures."""
import argparse,json
from pathlib import Path
from host.lvds8 import report_capture,relative_phase_table

def analyze(capture,reference=None):
    common=capture.get('metadata',{})
    reports=[report_capture(ch['words'],ch['start_sample'],ch['previous'],
               sample_ps=capture.get('sample_ps',1000),period_bins=capture.get('period_bins',25),valid=ch['valid'],
               metadata={**common,**ch.get('metadata',{})}) for ch in capture['channels']]
    result=dict(channels=reports,metadata=common,sample_ps=capture.get('sample_ps',1000),
                scope='x8 sample-grid statistics; no sub-bin accuracy claim')
    if reference is not None:
        if not 0<=reference<len(reports):raise ValueError('invalid reference channel')
        result['reference_channel']=reference
        result['relative']=[relative_phase_table(ch,reports[reference],period_bins=capture.get('period_bins',25)) for ch in reports]
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('input',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--reference',type=int,help='zero-based simultaneously captured reference channel')
    a=p.parse_args();result=analyze(json.loads(a.input.read_text()),a.reference)
    with a.output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
