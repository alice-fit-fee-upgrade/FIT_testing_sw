"""Receive-only phase ABI, logical0..7=slot6odd pairs,8..15=slot7odd pairs."""
from host.lvds8_device import LVDSDevice
from host.device import Device

class GatePhaseDevice(LVDSDevice):
    def identify(self):
        if self.read(0)!=0x52504831 or self.read(4)!=0x10002:raise RuntimeError('RPH1 receive-only instrument required')
        self.abi=0x10002;self.slot=self.read(0x7c);self.depth=self.read(0x78);self.channels=self.read(0x80)
        self.reference_hz=self.read(0x74);self.sample_hz=self.read(0xa8);self.period_bins=self.read(0xac);self.clock_profile='external120';self.sample_ps=1e12/self.sample_hz
        if (self.slot,self.depth,self.channels,self.sample_hz,self.period_bins,self.read(0xb0),self.read(0xc0),self.read(0xc4))!=(0,4096,16,960000000,24,3,0x60,0xaaaa):raise RuntimeError('Unexpected RX gate map/profile')
        self.mapping=[]
        for logical in range(16):
            self.write(0x1c,logical);value=self.read(0xcc);slot=value>>8;channel=value&255
            if (slot,channel)!=(6+logical//8,1+2*(logical%8)):raise RuntimeError('Unexpected physical lane mapping')
            self.mapping.append(dict(logical=logical,slot=slot,channel=channel,rj45=channel//4))
    def enable(self):raise RuntimeError('RPH1 inputs cannot transmit')
    def upload_lanes(self,*args,**kwargs):raise RuntimeError('RPH1 inputs cannot transmit')
    def directions(self,mask):
        if mask:raise ValueError('RPH1 inputs cannot transmit')
        super().directions(0)
    def arm_test(self,words=4096,generator=False,measurement=True):
        if generator:raise ValueError('RPH1 inputs cannot transmit')
        return super().arm_test(words,generator=False,measurement=measurement)
    def read_capture(self,*args,**kwargs):
        result=super().read_capture(*args,**kwargs);result['mapping']=self.mapping
        for row in result['channels']:row.update(self.mapping[row['channel']])
        return result
