"""One resident image pair: HDMI, ADC and TDC tests through IPbus.

No programming, PLL/analog changes or persistent writes. The caller of run()
must own the PM12, MCU and Kasli leases and have checked physical PGOOD.
"""
import argparse
import contextlib
import fcntl
import json
from pathlib import Path
import sys
import time
from host.gate_phase_ipbus import GatePhaseIPbusDevice
from host.lvds8_dio import dio_directions
from host.hdmi_check import check_prbs,check_idle
from host.gate_phase_dio import input_cards
from host.cfd_pattern import CFDBurstDevice,pattern_words
from host.pm_tdc_test import acquire,Client,PORT,console_capture,wait_power_good,require_power_good
import serial

class HDMIAdapter:
    slot=6
    def __init__(self,d):
        self.d=d
        if d.read(0x140)!=0x48444d31:raise RuntimeError('Integrated HDMI master missing')
        packed=d.read(0x15c)
        if packed not in (0x03020100,0x07060504):raise RuntimeError('Unknown HDMI wiring map')
        self.data_base=packed&255;self.mask=0xb<<(4-self.data_base)
    def stop(self):
        self.d.write(0x144,0)
        if self.d.read(0x144)!=0:raise RuntimeError('HDMI outputs not released')
    def directions(self,mask):
        if mask!=self.mask:raise ValueError('HDMI adapter direction mask mismatch')
        self.d.write(0x144,1)
        if self.d.read(0x150)&0xd!=9:raise RuntimeError('HDMI master enable failed')
    def transfer(self,read,address,value=0):
        if not read or address not in (0,1,2) or value!=0:
            raise ValueError('Shared MCU SPI: only diagnostic signature reads0/1/2 are qualified')
        packet=(int(read)<<31)|(address<<22)|value
        before=self.d.read(0x158);self.d.write(0x148,packet)
        deadline=time.monotonic()+1
        while self.d.read(0x158)==before:
            if self.d.read(0x150)&4:raise RuntimeError('HDMI SPI error')
            if time.monotonic()>deadline:raise TimeoutError('HDMI SPI timeout')
        if self.d.read(0x158)!=(before+1)&0xffffffff:raise RuntimeError('HDMI SPI completion sequence mismatch')
        return self.d.read(0x14c)&65535


def capture_hdmi(d,words=4095):
    ticket=d.arm_test(words);d.trigger();deadline=time.monotonic()+2
    while True:
        state=d.status()
        if state['fault'] or state['command_error']:raise RuntimeError('HDMI acquisition fault')
        if state['valid'] and d.read(0x64)==ticket['generation'] and d.read(0x17c)==1:break
        if time.monotonic()>deadline:raise TimeoutError('HDMI acquisition')
    rows=[];data_base=d.read(0x15c)&255
    for lane in range(4):
        d.write(0x160,lane);count=d.read(0x16c)
        if count!=words:raise RuntimeError('Partial HDMI buffer')
        row=dict(channel=lane+data_base,start_sample=d.read(0x170)|(d.read(0x174)<<32),previous=d.read(0x178),
                 words=d.client.block(0x30000+(lane<<12),count))
        if any(w>255 for w in row['words']):raise RuntimeError('Invalid HDMI capture data')
        rows.append(row)
    if len({r['start_sample'] for r in rows})!=1:raise RuntimeError('HDMI lane captures not aligned')
    for hdmi_lane,phase_lane in [(1,data_base//2),(3,data_base//2+1)]:
        original=d.client.block(0x10000+(phase_lane<<12),words)
        if original!=rows[hdmi_lane]['words']:raise RuntimeError('HDMI and original phase raw buffers differ')
    if d.read(0x64)!=ticket['generation'] or not d.status()['valid']:raise RuntimeError('HDMI capture changed')
    return dict(generation=ticket['generation'],channels=rows,sample_hz_nominal=d.sample_hz,original_phase_buffers_bit_exact=True)


def test_hdmi(d,c,out):
    a=HDMIAdapter(d)
    if c.read(0x300)!=[0x48444d31]:raise RuntimeError('Integrated PM HDMI transmitter missing')
    initial=c.read(0x301)[0];result=dict(walking=[],spi=[])
    for address,value in [(0x300,1),(0x301,0x40)]:
        reply=c.transact(1,address,values=[value],allow_error=True)
        assert reply[1]&15, 'Invalid HDMI register write accepted'
        assert c.read(0x301)==[initial]
    result['invalid_pm_writes_rejected']=True
    def set_mode(v):
        try:c.write(0x301,[v])
        except TimeoutError:
            # Do not replay writes. This idempotent mode setter is recovered
            # only by observing the requested value already installed.
            actual=c.read(0x301)[0]
            result.setdefault('missing_mode_write_acks',[]).append(dict(requested=v,readback=actual))
            if actual!=v:raise
        assert c.read(0x301)==[v]
    try:
        observed={}
        for v in [0,15,1,2,4,8,5,10]:
            set_mode(v);cap=capture_hdmi(d,24)
            (out/f'walking-{v:02d}.json').write_text(json.dumps(cap)+'\n')
            row={r['channel']:r['words'][0]&1 for r in cap['channels']}
            assert all(len(set(r['words']))==1 and r['words'][0] in [0,255] for r in cap['channels'])
            observed[v]=row;result['walking'].append(dict(value=v,lanes=row))
        inversions=observed[0]
        discovered=[]
        for bit in range(4):
            lanes=[lane for lane in inversions if observed[1<<bit][lane]^inversions[lane]]
            assert len(lanes)==1,(bit,lanes)
            discovered+=lanes
        assert discovered==[a.data_base+3,a.data_base+1,a.data_base+2,a.data_base],discovered
        assert all((row[lane]^inversions[lane])==((v>>bit)&1) for v,row in observed.items() for bit,lane in enumerate(discovered))
        result['mapping']=discovered;result['inversions']=inversions
        for mode,label,ratio in [(0x30,'prbs-slow',3*256),(0x20,'prbs-fast',3),(0x10,'native-idle',None)]:
            set_mode(mode);cap=capture_hdmi(d)
            (out/(label+'.json')).write_text(json.dumps(cap)+'\n')
            rows={r['channel']:r for r in cap['channels']};checks=[]
            for lane,seed in zip(discovered,[1,0x13,0x35,0x57]):
                data=[w^(255 if inversions[lane] else 0) for w in rows[lane]['words']]
                check=check_idle(data,sample_hz=d.sample_hz) if ratio is None else check_prbs(data,seed,ratio,sample_hz=d.sample_hz)
                checks.append(dict(lane=lane,**check))
            result[label]=checks
        with dio_directions(a,a.mask):
            d.write(0x154,600)
            result['spi_signature']=[a.transfer(True,i) for i in [0,1,2]]
            assert result['spi_signature']==[0x4844,0x4d49,1],result['spi_signature']
            result['spi']=[dict(address=i,readback=v) for i,v in enumerate(result['spi_signature'])]
            result['spi_access']='allowlisted signature reads0/1/2 only; shared MCU bus, other addresses and writes disabled'
        result['pass']=True
        return result
    finally:
        try:set_mode(initial)
        finally:a.stop()


def run(d,c,out,suites=('hdmi','adc','tdc'),channel=12):
    result=dict(pm_identity=c.read(0,3),kasli_identity=d.read(0),suites={},pass_=False)
    assert result['pm_identity'][:2]==[0x504d1202,0x10002]
    assert d.read(0x13c)==0x42524731 and d.read(0x120)&1 and d.read(0x100)==0
    d.write(0x144,0);d.stop()
    result['dio_initial']=input_cards(d)
    result['bridge_before']={hex(a):d.read(a) for a in [0x128,0x12c,0x130,0x134]}
    try:
        for suite in suites:
            dest=out/suite;dest.mkdir()
            uptime_before=c.read(5,2)
            if suite=='hdmi':r=test_hdmi(d,c,dest)
            elif suite=='adc':
                from client import describe,save_capture
                tests=[]
                try:
                    for bank in [0,1]:
                        gen,status=c.acquire(bank,True);data=c.download(gen)
                        tests.append(save_capture(dest/('synthetic-'+str(bank)),data,bank,True,gen,status))
                    for bank in [0,1]:
                        gen,status=c.acquire(bank,False);data=c.download(gen)
                        tests.append(save_capture(dest/('physical-'+str(bank)),data,bank,False,gen,status))
                    r=dict(pass_=True,tests=tests,scope='All 12 digital ADC banks and strobes; analog input currently connected only to selected CFD mux path')
                finally:
                    # Return EV mux to ADC A and retain a valid physical buffer.
                    c.acquire(0,False)
            elif suite=='tdc':
                assert c.read(0x205)==[0xfff]
                burst=CFDBurstDevice(d);rows=[]
                with dio_directions(burst,1):
                    rows.append(acquire(c,dest,'quiet-before'))
                    burst.upload(pattern_words(1200,24,20))
                    rows.append(acquire(c,dest,'stimulated',burst,64,24))
                    rows.append(acquire(c,dest,'quiet-after'))
                expected=[0]*12;expected[channel-1]=64
                assert rows[0]['counts']==rows[-1]['counts']==[0]*12
                assert rows[1]['counts']==expected,rows[1]['counts']
                r=dict(pass_=True,captures=rows,expected_channel=channel)
            else:raise ValueError(suite)
            r['pm_uptime_before']=uptime_before;r['pm_uptime_after']=c.read(5,2)
            r['pm_sys_reset_observed']=(r['pm_uptime_after'][0]+(r['pm_uptime_after'][1]<<32))<(uptime_before[0]+(uptime_before[1]<<32))
            if 'pass_' in r:r['pass']=r.pop('pass_')
            result['suites'][suite]=r
            (dest/'status.json').write_text(json.dumps(r,indent=2)+'\n')
            print(suite,'PASS',flush=True)
        result['bridge_after']={hex(a):d.read(a) for a in [0x128,0x12c,0x130,0x134]}
        result['read_retries']={'pm':c.read_retry_events,'kasli':d.client.read_retry_events}
        result['functional_pass']=all(r['pass'] for r in result['suites'].values())
        result['unexpected_sys_resets']=[name for name,r in result['suites'].items() if r['pm_sys_reset_observed']]
        result['pass_']=result['functional_pass'] and not result['unexpected_sys_resets']
        return result
    finally:
        result['pass']=result.pop('pass_')
        (out/'status.json').write_text(json.dumps(result,indent=2)+'\n')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--suites',nargs='+',choices=['hdmi','adc','tdc'],default=['hdmi','adc','tdc'])
    p.add_argument('--expected-channel',type=int,choices=range(1,13),default=12)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    with contextlib.ExitStack() as st:
        for n in sorted(['atmel-ice-J41800043065','kasli-diot-00001','pm12-210249A73E43']):
            f=st.enter_context(open('/home/codex-hil/.cache/'+n+'.lock','a+'));fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        u=serial.Serial(port=None,baudrate=115200,timeout=.03,write_timeout=1,rtscts=True,exclusive=True)
        u.dtr=False;u.rts=True;u.port=PORT;u.open();st.callback(u.close);u.read(4096)
        pg=wait_power_good(u,console_capture);identity=console_capture(u,'RS');assert 'Board S/N: 1803' in identity['reply']
        d=GatePhaseIPbusDevice();st.callback(d.close);c=Client();st.callback(c.close)
        result=None
        try:
            result=run(d,c,a.out,a.suites,a.expected_channel)
            result['pgood']=pg;result['pgood_final']=require_power_good(u,console_capture)
            (a.out/'status.json').write_text(json.dumps(result,indent=2)+'\n')
            if not result['pass']:raise SystemExit('Functional test or clock health failed; inspect status.json')
        except BaseException as error:
            if result is not None:
                result['pass']=False;result['error']=repr(error)
                (a.out/'status.json').write_text(json.dumps(result,indent=2)+'\n')
            raise
        finally:
            try:
                try:d.write(0x144,0)
                finally:
                    try:d.write(0xe0,0)
                    finally:d.stop()
            finally:u.rts=False;u.dtr=False

if __name__=='__main__':main()
