import argparse
import json
from pathlib import Path
from host.device import Device, board_lock
from host.pattern import Pulse, compile_pattern, ticks
from host.analysis import capture_report


def main():
    p=argparse.ArgumentParser(description='Kasli-DIOT CFD pattern player and finite TDC capture')
    sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('status')
    q=sub.add_parser('pattern'); q.add_argument('json',help='list of {phase_ns,width_ns,enable}')
    q.add_argument('--enable',action='store_true')
    q=sub.add_parser('mode'); q.add_argument('--loopback',type=int,choices=[0,1]); q.add_argument('--enable',type=int,choices=[0,1])
    q.add_argument('--restart',action='store_true')
    q.add_argument('--rx-invert',type=int,choices=[0,1]); q.add_argument('--tx-invert',type=int,choices=[0,1])
    q.add_argument('--cdr-hold',type=int,choices=[0,1])
    q=sub.add_parser('capture'); q.add_argument('--words',type=int,default=4096); q.add_argument('--output',required=True)
    q.add_argument('--zero-sample',type=int); q.add_argument('--period-bins',type=int,default=150)
    q=sub.add_parser('analyze'); q.add_argument('capture'); q.add_argument('--zero-sample',type=int); q.add_argument('--period-bins',type=int,default=150)
    a=p.parse_args()
    if a.command=='analyze':
        print(json.dumps(capture_report(json.loads(Path(a.capture).read_text()),a.zero_sample,a.period_bins),indent=2)); return
    with board_lock():
        d=Device()
        try:
            if a.command=='status': result=d.status()
            elif a.command=='mode':
                d.configure(a.enable,a.loopback,a.rx_invert,a.tx_invert,a.restart,cdr_hold=a.cdr_hold); result=d.status()
            elif a.command=='pattern':
                if d.line_mbps!=6000: raise RuntimeError('25ns pattern requires 6Gb/s profile; lab125 is diagnostic only')
                data=json.loads(Path(a.json).read_text())
                pattern=compile_pattern([Pulse(ticks(x.get('phase_ns',0)),ticks(x.get('width_ns',0)),x.get('enable',True)) for x in data],d.depth)
                d.upload(pattern.pop('words'))
                if a.enable: d.configure(enable=True)
                result=pattern
            else:
                result=d.capture(a.words)
                Path(a.output).write_text(json.dumps(result,indent=2)+'\n')
                result=capture_report(result,a.zero_sample,a.period_bins)
            print(json.dumps(result,indent=2))
        finally: d.close()


if __name__=='__main__': main()
