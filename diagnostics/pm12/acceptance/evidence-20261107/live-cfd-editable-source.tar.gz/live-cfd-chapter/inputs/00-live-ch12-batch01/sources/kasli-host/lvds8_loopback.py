"""Monday cable test: verified slot6 topology, bounded load/test/restore lease."""
import argparse,hashlib,json,time
from pathlib import Path
from host.device import board_lock,ROOT
from host.hardware_test import identify,jtag
from host.lvds8_device import LVDSDevice
from host.lvds8_dio import dio_directions
from host.lvds8 import compile_lane
from host.lvds8_cli import analyze

def pattern_for(lane,period_bins=25):
    # Dense obligatory edges plus lane identity; phase sweep has a quiet slot
    # after each pulse so24->0ns never merges two pulses.
    code=0xa500|lane
    events=[dict(phase=0,width=5,enable=(i%2==0 or bool((code>>(i//2))&1))) for i in range(32)]
    if period_bins==24:
        # Descending sweep keeps distinct 5-bin pulses in EVERY 25 ns period.
        events.extend(dict(phase_bin=phase,width_bins=5) for phase in reversed(range(24)))
    else:
        for phase in range(period_bins):events.extend([dict(phase=phase,width=5),dict(enable=False)])
    return events

def match_bits(words,expected):
    actual=''.join(str((w>>i)&1) for w in words for i in range(8))
    pattern=''.join(str((w>>i)&1) for w in expected for i in range(8))
    search=pattern*((len(actual)+len(pattern)-1)//len(pattern)+2)
    offset=search.find(actual)
    if not 0<=offset<len(pattern):raise AssertionError('external LVDS bitstream mismatch')
    return dict(offset_bits=offset,compared_bits=len(actual),errors=0)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--build-dir',type=Path,default=ROOT/'build/lvds8-lhc120-slot6-v2')
    p.add_argument('--pairs',choices=['A-C','B-D','A-D','both'],default=None,help='one straight RJ45 cable by default; both requires two cables on slot6')
    p.add_argument('--restore-bit',type=Path,required=True,help='explicit agreed SRAM recovery image')
    p.add_argument('--restore-sha256',required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--preflight-only',action='store_true')
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
    manifest=json.loads((a.build_dir/'manifest.json').read_text())
    qualification=json.loads((a.build_dir/'qualification.json').read_text())
    slot=manifest['slot'];pairs=a.pairs or ('A-C' if slot==6 else 'A-D')
    if manifest['profile'] not in ('internal125','lhc120','external120'):raise ValueError('unsupported loopback clock profile')
    period_bins=manifest.get('period_bins',25);capture_words=4095 if period_bins==24 else 4096
    if slot==6 and pairs in ['A-C','B-D','both']:
        sources=list(range(4,8) if pairs=='A-C' else range(4) if pairs=='B-D' else range(8))
        destinations={n:n+8 for n in sources}
    elif slot==7 and pairs=='A-D':
        sources=list(range(4));destinations={n:n+12 for n in sources}
    else:raise ValueError('unsupported/unverified slot or loopback pair; slot7 B-C has a failed5/9 pair')
    if not qualification['pass']:raise RuntimeError('build not qualified')
    if hashlib.sha256((a.build_dir/'manifest.json').read_bytes()).hexdigest()!=qualification['manifest_sha256']:
        raise RuntimeError('manifest hash mismatch')
    bit=a.build_dir/'lvds8.bit'
    if hashlib.sha256(bit.read_bytes()).hexdigest()!=qualification['bit_sha256']:raise RuntimeError('bit hash mismatch')
    for file,sha in manifest['source_sha256'].items():
        if hashlib.sha256((ROOT/file).read_bytes()).hexdigest()!=sha:raise RuntimeError('changed gateware source '+file)
    if hashlib.sha256(a.restore_bit.read_bytes()).hexdigest()!=a.restore_sha256:raise RuntimeError('restore hash mismatch')
    report=dict(pass_=False,slot=slot,pairs=pairs,hardware_test='external DIO LVDS cable loopback',flash_written=False)
    attempted=False;device=None
    with board_lock():
        usb=identify();location=Path(usb['sysfs']).name;report['usb']=usb
        command='adapter usb location '+location+'; init; '
        try:
            jtag(command+'virtex2 read_stat 0; shutdown','preflight',a.out)
            if a.preflight_only:report['preflight_only']=True;return
            attempted=True;jtag(command+'pld load 0 {'+str(bit.resolve())+'}; shutdown','load',a.out)
            device=LVDSDevice();device.stop()
            if device.slot!=slot:raise RuntimeError('loaded wrong slot target')
            deadline=time.monotonic()+180
            patterns={lane:pattern_for(lane,period_bins) for lane in sources}
            expected={lane:compile_lane(events,period_bins=period_bins,sample_ps=manifest['nominal_sample_ps'])['words'] for lane,events in patterns.items()}
            device.upload_lanes(patterns)
            with dio_directions(device,sum(1<<n for n in sources)):
                if device.abi<0x10001:raise RuntimeError('shared-trigger loopback needs ABI 1.1')
                ticket=device.arm_test(capture_words,generator=True)
                device.trigger()
                capture=device.read_capture(ticket,list(destinations.values()),metadata=dict(mode='physical-loopback',dac_sweep=False))
                if time.monotonic()>deadline:raise TimeoutError('bounded loopback window exceeded')
                (a.out/'raw.json').write_text(json.dumps(capture,indent=2)+'\n')
                report['comparisons']=[dict(source=next(n for n,d in destinations.items() if d==ch['channel']),destination=ch['channel'],
                    **match_bits(ch['words'],expected[next(n for n,d in destinations.items() if d==ch['channel'])])) for ch in capture['channels']]
                (a.out/'phase-tables.json').write_text(json.dumps(analyze(capture),indent=2)+'\n')
                # Rearm only RX; the player must continue across readout.
                ticket=device.arm_test(capture_words)
                device.trigger()
                second=device.read_capture(ticket,list(destinations.values()),metadata=dict(mode='physical-loopback-rearmed'))
                (a.out/'raw-rearmed.json').write_text(json.dumps(second,indent=2)+'\n')
                report['rearmed_comparisons']=[dict(destination=ch['channel'],**match_bits(ch['words'],
                    expected[next(n for n,d in destinations.items() if d==ch['channel'])])) for ch in second['channels']]
                if second['metadata']['capture_id']!=((capture['metadata']['capture_id']+1)&0xffffffff):
                    raise AssertionError('capture generation did not advance once')
                if not device.status()['enabled']:raise AssertionError('generator stopped during measurement rearm')
                (a.out/'phase-tables-rearmed.json').write_text(json.dumps(analyze(second),indent=2)+'\n')
                device.stop()
                # No phase accuracy/jitter claim from aggregate swept statistics.
            report['pass_']=True
        except BaseException as error:report['pass_']=False;report['error']=repr(error);raise
        finally:
            try:
                if device is not None:
                    try:device.stop()
                    finally:device.close();device=None
            finally:
                try:
                    if attempted:
                        jtag(command+'pld load 0 {'+str(a.restore_bit.resolve())+'}; shutdown','restore',a.out)
                        report['restored']=True
                except BaseException as error:
                    report['pass_']=False;report['restored']=False;report['restore_error']=repr(error)
                    raise
                finally:(a.out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
