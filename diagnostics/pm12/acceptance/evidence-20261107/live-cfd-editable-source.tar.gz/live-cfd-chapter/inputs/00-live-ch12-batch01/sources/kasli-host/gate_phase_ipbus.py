"""RPH1 through native PM12 IPbus client; bulk frozen raw/phase apertures.

CSR IPbus word address = UART byte address/4. RAW=0x10000+lane*0x1000,
PHASE=0x20000+lane*0x1000. No automatic write retries or acquisition replays.
"""
import importlib.util
from pathlib import Path
from host.gate_phase_device import GatePhaseDevice

class GatePhaseIPbusDevice(GatePhaseDevice):
    def __init__(self,host='192.168.2.241',port=50001,client=None):
        if client is None:
            path=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12/ipbus_adc/client.py')
            spec=importlib.util.spec_from_file_location('pm12_native_ipbus',path)
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            client=module.Client(host,port)
        self.client=client;self.low_latency=False;self._index=0;self._lane=0;self._cache={};self._counts={};self._phases={}
        try:
            if self.read(0xd0)!=0x49504232:raise RuntimeError('RPH1 IPbus extension missing')
            self.identify()
        except BaseException:self.client.close();raise

    def close(self):self.client.close()

    def read(self,address):
        if address in (0x50,0xbc):
            phase=address==0xbc;key=(self._lane,phase)
            if key not in self._cache:
                count=(self._phases if phase else self._counts)[self._lane]
                base=(0x20000 if phase else 0x10000)+(self._lane<<12)
                self._cache[key]=self.client.block(base,count)
            return self._cache[key][self._index]
        value=self.client.read(address//4)[0]
        if address==0x54:self._counts[self._lane]=value
        if address==0xb8:self._phases[self._lane]=value
        return value

    def write(self,address,value):
        if address==0x20:
            self._index=value
            return
        self.client.write(address//4,[value])
        if address==0x1c:self._lane=value
        if address in (0x18,0x84):self._cache.clear()

    def read_capture(self,*args,**kwargs):
        self._cache.clear();self._counts.clear();self._phases.clear()
        return super().read_capture(*args,**kwargs)
