"""Load the external120 ramp, briefly run free lower ports, leave TX stopped.

No cable measurement is claimed. PM12 and the upper HDMI ports are untouched.
"""
import argparse,json,hashlib,time
from pathlib import Path
from host.device import ROOT,board_lock
from host.hardware_test import identify,jtag
from host.lvds8_device import LVDSDevice
from host.lvds8_dio import dio_directions
from host.lvds8 import compile_lane


def ramp():
    return [dict(phase_bin=i,width_bins=3) for i in range(24)]+[dict(enable=False)]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
    build=ROOT/'build/hdmi-external120-slot6-20261027'
    bit=build/'lvds8.bit';q=json.loads((build/'qualification.json').read_text())
    assert q['pass'] and hashlib.sha256(bit.read_bytes()).hexdigest()==q['bit_sha256']
    recovery=Path('/home/codex-hil/kasli-diot-bringup/build-pmtsim-double/probe.bit')
    assert hashlib.sha256(recovery.read_bytes()).hexdigest()=='890ffa0c084e80c6dfe7c0c6ee6f830068c6bdfa60c5229d85f7304be57e3a5c'
    events=ramp();compiled=compile_lane(events,period_bins=24,sample_ps=1e12/960e6)
    report=dict(pass_=False,physical_loopback='NOT_RUN: cable planned tomorrow',outputs=[8,9,10,11],pattern=events,compiled=compiled,bit_sha256=q['bit_sha256'],persistent_writes=False)
    changed=False;device=None
    with board_lock():
        usb=identify();cmd='adapter usb location '+Path(usb['sysfs']).name+'; init; '
        try:
            # Preserve the resident PMT probe's control word while checking identity.
            snapshot=jtag(cmd+'irscan xc7.tap 3; set snap [drscan xc7.tap 128 0 -endstate DRPAUSE]; set ctrl 0x[string range $snap 8 15]; drscan xc7.tap 128 $ctrl -endstate IDLE; echo SNAPSHOT=$snap; echo CONTROL=$ctrl; irscan xc7.tap 63; shutdown','before',out)
            assert 'SNAPSHOT=4c56445300000000' in snapshot,'Unexpected resident image/control; do not replace'
            changed=True;jtag(cmd+'pld load 0 {'+str(bit)+'}; shutdown','load',out)
            device=LVDSDevice();assert device.slot==6 and device.clock_profile=='external120' and device.period_bins==24
            device.upload_lanes({lane:events for lane in range(8,12)})
            with dio_directions(device,0x0f00):
                ticket=device.arm_test(1,generator=True,measurement=False);device.trigger()
                before=device.read(0x3c);time.sleep(2);after=device.read(0x3c)
                report['loops_before']=before;report['loops_after']=after
                assert (after-before)&0xffffffff,'Pattern player did not advance'
                assert device.status()['enabled'] and not device.status()['pattern_error']
                device.stop()
            device.directions(0)
            report['resident_status']=device.status();report['pass_']=True
            report['resident']='external120 tester; ramp retained in active RAM, outputs stopped/released'
        finally:
            try:
                if device is not None:
                    try:device.stop()
                    finally:device.close()
            finally:
                if changed and not report['pass_']:
                    jtag(cmd+'pld load 0 {'+str(recovery)+'}; shutdown','failure-restore',out)
                    report['failure_restored']=True
                (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
