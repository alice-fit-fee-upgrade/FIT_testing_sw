"""Repeat CFD/TDC reaction tests on the resident Kasli/PM12 IPbus images.
No programming, clock initialization or persistent writes. Requires board leases.
"""
import argparse,collections,contextlib,fcntl,json,struct,sys,time
from pathlib import Path
from host.gate_phase_ipbus import GatePhaseIPbusDevice
from host.cfd_pattern import CFDBurstDevice,pattern_words
from host.lvds8_dio import dio_directions

PMROOT=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12')
sys.path[:0]=[str(PMROOT/'tdc_live120'),str(PMROOT/'ipbus_adc'),'/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from client_tdc import Client,download
from pm12_console_regression import PORT,capture as console_capture
from pm12_power import wait_power_good,require_power_good
import serial

def acquire(c,out,label,burst=None,count=0,phase=None):
    c.write(0x200,[1]);end=time.monotonic()+.2
    while not c.read(0x201)[0]&4:
        if time.monotonic()>end:raise TimeoutError('TDC STARTED handshake')
    tx=burst.burst(count) if burst else None
    time.sleep(.002 if count else .01)
    c.write(0x200,[2]);end=time.monotonic()+.2
    while c.read(0x201)[0]&0x23!=1:
        if time.monotonic()>end:raise TimeoutError('TDC freeze handshake')
    gen,status,counts,data=download(c)
    dest=out/label;dest.mkdir()
    for ch,words in enumerate(data):(dest/f'tdc{ch+1:02d}.bin').write_bytes(struct.pack('<%dH'%len(words),*words))
    row=dict(label=label,generation=gen,status=status,counts=counts,tx=tx,phase_bin=phase,
             fine_histograms=[dict(collections.Counter(w&127 for w in words)) for words in data])
    (dest/'summary.json').write_text(json.dumps(row,indent=2)+'\n')
    print(label,counts,flush=True);return row

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--pm-host',default='192.168.2.240');p.add_argument('--kasli-host',default='192.168.2.241')
    p.add_argument('--expected-channel',type=int,choices=range(1,13),default=12)
    p.add_argument('--counts',type=int,nargs='+',default=[16,64,128])
    p.add_argument('--phase-bins',type=int,nargs='+',default=[24,30,36,42])
    a=p.parse_args()
    if any(not 1<=n<=1024 for n in a.counts):p.error('counts1..1024')
    if any(not 8<=n<=191 for n in a.phase_bins):p.error('phase bins8..191')
    a.out.mkdir(parents=True,exist_ok=False)
    report=dict(expected_channel=a.expected_channel,captures=[],pass_=False,
                scope='functional raw TDC reaction; no timestamp calibration',
                stimulus='slot7 channel0, RJ45 pair1/2; nominal960MS/s,20 samples high,period1200 words')
    with contextlib.ExitStack() as st:
        for n in sorted(['atmel-ice-J41800043065','kasli-diot-00001','pm12-210249A73E43']):
            f=st.enter_context(open('/home/codex-hil/.cache/'+n+'.lock','a+'));fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        u=serial.Serial(port=None,baudrate=115200,timeout=.03,write_timeout=1,rtscts=True,exclusive=True)
        u.dtr=False;u.rts=True;u.port=PORT;u.open();st.callback(u.close);u.read(4096)
        d=c=burst=None
        try:
            report['pgood']=wait_power_good(u,console_capture)
            report['identity']=console_capture(u,'RS');assert 'Board S/N: 1803' in report['identity']['reply']
            d=GatePhaseIPbusDevice(a.kasli_host);c=Client(a.pm_host)
            assert d.read(0x13c)==0x42524731 and d.read(0x120)&1
            assert d.read(0x100)==0,'SFP1 must be in packet mode'
            assert c.read(0,2)==[0x504d1202,0x10002]
            assert c.read(0x205)==[0xfff],'TDC frontend not ready'
            burst=CFDBurstDevice(d)
            with dio_directions(burst,1):
                report['captures'].append(acquire(c,a.out,'quiet-before'))
                points=[(n,a.phase_bins[0]) for n in a.counts]+[(a.counts[-1],phase) for phase in a.phase_bins[1:]]
                for i,(n,phase) in enumerate(points):
                    burst.upload(pattern_words(1200,phase,20))
                    report['captures'].append(acquire(c,a.out,f'{i:02d}-n{n}-phase{phase}',burst,n,phase))
                report['captures'].append(acquire(c,a.out,'quiet-after'))
            ch=a.expected_channel-1;rows=report['captures']
            ratios=[r['counts'][ch]/r['tx']['repetitions'] for r in rows if r['tx']]
            report['records_per_pulse']=ratios
            report['pass_']=rows[0]['counts'][ch]==rows[-1]['counts'][ch]==0 and bool(ratios) and ratios[0] in (1,2) and all(x==ratios[0] for x in ratios)
            report['pgood_final']=require_power_good(u,console_capture)
        except BaseException as e:report['error']=repr(e);raise
        finally:
            if burst is not None:
                try:burst.stop()
                except Exception as e:report['stop_error']=repr(e);report['pass_']=False
            if d is not None:d.close()
            if c is not None:c.close()
            u.rts=False;u.dtr=False
            report['pass']=report.pop('pass_');(a.out/'status.json').write_text(json.dumps(report,indent=2)+'\n')
    if not report['pass']:raise SystemExit('TDC counts did not match the requested channel')

if __name__=='__main__':main()
