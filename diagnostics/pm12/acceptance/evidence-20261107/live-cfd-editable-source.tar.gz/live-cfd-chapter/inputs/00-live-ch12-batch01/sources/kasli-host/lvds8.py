"""Chronological x8 waveforms and retained strobe phase tables/statistics."""
from math import gcd
from host.analysis import edges,phase_statistics


def compile_lane(pattern,max_words=4096,*,period_bins=25,sample_ps=1000):
    """One event per reference period; phase/width are integer sample bins."""
    if not isinstance(period_bins,int) or period_bins<2 or sample_ps<=0:raise ValueError("invalid sampling profile")
    pattern=list(pattern)
    if not pattern:raise ValueError('empty pattern')
    expanded=pattern*(8//gcd(period_bins*len(pattern),8))
    total=len(expanded)*period_bins
    if total//8>max_words:raise ValueError('pattern exceeds memory')
    bits=[0]*total
    for slot,event in enumerate(expanded):
        phase=event.get('phase_bin',event.get('phase',0));width=event.get('width_bins',event.get('width',5))
        if not isinstance(phase,int) or not 0<=phase<period_bins:raise ValueError('phase outside reference period')
        if not isinstance(width,int) or width<1 or width>=total:raise ValueError('invalid pulse width')
        if not event.get('enable',True):continue
        start=slot*period_bins+phase
        for i in range(width):
            pos=(start+i)%total
            if bits[pos]:raise ValueError('overlapping pulses')
            bits[pos]=1
    # Count circular rising edges; touching pulses would silently lose events.
    expected=sum(bool(e.get('enable',True)) for e in expanded)
    if sum(bool(bits[i] and not bits[i-1]) for i in range(total))!=expected:
        raise ValueError('touching pulses; insert an empty slot')
    return dict(words=[sum(bits[j+i]<<i for i in range(8)) for j in range(0,total,8)],
                periods=len(expanded),sample_ps=sample_ps,period_bins=period_bins,word_width=8)


def report_capture(words,start_sample,previous,*,zero_sample=None,
                   sample_ps=1000,period_bins=25,valid=True,metadata=None):
    words=list(words)
    hits=edges(words,start_sample,previous,word_width=8)
    stats=phase_statistics([hit['sample'] for hit in hits],period_bins,
                           0 if zero_sample is None else zero_sample,sample_ps)
    stats.update(raw_words=list(words),start_sample=start_sample,previous=previous,
                 reference_calibrated=zero_sample is not None,capture_valid=valid,
                 metadata=dict(metadata or {}))
    if not valid:stats['valid']=False
    return stats


def relative_phase_table(signal_report,reference_report,period_bins=25,period_tolerance=1):
    """Pair each strobe with the preceding reference edge; retain actual period.

    Reject missing/duplicated reference periods instead of silently
    folding an unrelated clock modulo25. Empty leading/trailing cycles omitted.
    """
    from bisect import bisect_right
    if period_bins<=0 or period_tolerance<0:
        raise ValueError('invalid reference period/tolerance')
    if not signal_report['capture_valid'] or not reference_report['capture_valid']:
        raise ValueError('invalid acquisition')
    if signal_report['ui_ps']!=reference_report['ui_ps']:
        raise ValueError('inconsistent sample clocks')
    for key in ['capture_id','clock_epoch']:
        if signal_report['metadata'].get(key)!=reference_report['metadata'].get(key):
            raise ValueError('inconsistent capture epoch')
    if signal_report['start_sample']!=reference_report['start_sample']:
        raise ValueError('capture windows are not aligned')
    ref=[r['sample'] for r in reference_report['timestamps']]
    sig=[r['sample'] for r in signal_report['timestamps']]
    # timestamps returned by phase_statistics are zero-corrected, so require
    # raw uncalibrated reports for a common reference comparison.
    if signal_report['reference_calibrated'] or reference_report['reference_calibrated']:
        raise ValueError('relative phase requires uncorrected absolute timestamps')
    if len(ref)<2 or any(abs((b-a)-period_bins)>period_tolerance for a,b in zip(ref,ref[1:])):
        raise ValueError('reference must have one edge per declared period')
    table=[]
    for sample in sig:
        idx=bisect_right(ref,sample)-1
        if 0<=idx<len(ref)-1:
            table.append(dict(sample=sample,reference_sample=ref[idx],phase_bin=sample-ref[idx],reference_period_bins=ref[idx+1]-ref[idx]))
    stats=phase_statistics([r['phase_bin'] for r in table],period_bins,ui_ps=signal_report['ui_ps'])
    # Aggregate phase codes are not absolute timestamps: occupancy/gap counts
    # from this helper would be meaningless. Return the retained table separately.
    for key in ['timestamps','missing_periods_between_hits','extra_edges_between_hits']:
        stats.pop(key,None)
    return dict(table=table,statistics=stats)
