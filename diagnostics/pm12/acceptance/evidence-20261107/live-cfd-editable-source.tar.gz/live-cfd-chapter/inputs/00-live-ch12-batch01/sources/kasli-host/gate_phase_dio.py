"""Configure two DIOT DIO cards as inputs using ONE FTDI I2C session.

Leaves PCF direction latches0 on purpose: external gate clocks can remain active.
Restores service-routing IC38/mux registers, not previously driven directions.
Caller holds the Kasli board lease and confirms FPGA outputs are released.
"""
from pathlib import Path
from pyftdi.i2c import I2cController
import usb.core

def input_cards(device,slots=(6,7)):
    device.stop();device.directions(0)
    matches=[]
    for path in Path('/sys/bus/usb/devices').iterdir():
        try:
            if (path/'serial').read_text().strip()=='00001' and (path/'product').read_text().strip()=='Artix-7 DIOT System Board':matches.append((int((path/'busnum').read_text()),int((path/'devnum').read_text())))
        except (OSError,ValueError):pass
    if len(matches)!=1:raise RuntimeError('Kasli USB identity missing/ambiguous')
    usbdev=usb.core.find(idVendor=0x0403,idProduct=0x6011,bus=matches[0][0],address=matches[0][1])
    ctl=I2cController();saved=None;old_mux=None;gpio=None;report={}
    try:
        ctl.configure(usbdev,interface=2,frequency=50000,direction=0x60,initial=0x40)
        gpio=ctl.get_gpio();gpio.set_direction(0x60,0x60);gpio.write(0x40)
        old_mux=ctl.read(0x70,1)[0];ctl.write(0x70,b'\x08')
        def rd(reg):return ctl.exchange(0x76,bytes([reg]),1)[0]
        def wr(reg,value):ctl.write(0x76,bytes([reg,value]))
        saved=[rd(i) for i in range(8)];base=(saved[3]&0x1f)|0x20
        for slot in slots:
            ctl.write(0x70,b'\x08');wr(3,base|0x80);wr(7,saved[7]&0x1f)
            wr(2,1<<[0,2,3,1,4,7,6,5][slot-1]);wr(6,0);wr(3,base|0x40)
            ctl.write(0x70,b'\x48')
            before=[ctl.read(addr,1)[0] for addr in (0x3e,0x3f)]
            for addr in (0x3e,0x3f):ctl.write(addr,b'\x00')
            after=[ctl.read(addr,1)[0] for addr in (0x3e,0x3f)]
            report[slot]=dict(before=before,after=after);assert after==[0,0],'DIO input direction readback mismatch'
        return report
    finally:
        try:
            if saved is not None:
                ctl.write(0x70,b'\x08');wr(3,base|0x80);wr(6,255)
                wr(2,saved[2]);wr(7,saved[7]);wr(6,saved[6]);wr(3,saved[3])
            if old_mux is not None:ctl.write(0x70,bytes([old_mux]))
        finally:
            if gpio is not None:gpio.write(0)
            ctl.terminate()
