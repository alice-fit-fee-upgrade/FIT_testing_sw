"""Finite RX-only capture of CFD gate returns on DIOT slots6/7."""
import argparse
from collections import Counter
import json
from pathlib import Path
from host.device import board_lock
from host.gate_phase_device import GatePhaseDevice
from host.gate_phase_dio import input_cards
from host.hdmi_check import check_phase_records


def analyze(capture):
    lanes=[]
    for row in capture['channels']:
        checked=check_phase_records(row)
        bits=[(word>>i)&1 for word in row['words'] for i in range(8)]
        rising=[i for i in range(1,len(bits)) if bits[i] and not bits[i-1]]
        periods=Counter(b-a for a,b in zip(rising,rising[1:]))
        phases=Counter((row['start_sample']+i)%24 for i in rising)
        lanes.append(dict(logical=row['logical'],slot=row['slot'],channel=row['channel'],
            rj45=row['rj45'],rising_edges=len(rising),period_samples=dict(periods),
            phase_bins=dict(phases),phase_records_checked=checked))
    return dict(lanes=lanes,phase_records_checked=sum(r['phase_records_checked'] for r in lanes),
                sample_ps=capture['sample_ps'],phase_origin='uncalibrated sample epoch')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--words',type=int,default=768)
    parser.add_argument('--trials',type=int,default=3)
    args=parser.parse_args()
    if not 3<=args.words<=4096 or args.words%3:parser.error('words must be a multiple of3, from3 to4095')
    if not 1<=args.trials<=100:parser.error('trials must be1..100')
    args.out.mkdir(parents=True,exist_ok=False)
    with board_lock():
        device=GatePhaseDevice()
        try:
            directions=input_cards(device)
            summaries=[]
            for trial in range(args.trials):
                capture=device.capture(args.words)
                (args.out/f'capture-{trial}.json').write_text(json.dumps(capture)+'\n')
                summaries.append(analyze(capture))
            result=dict(directions=directions,captures=summaries,final_status=device.status(),
                        scope='Raw/phase-buffer consistency; signal identity and phase calibration require review')
            (args.out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
        finally:
            try:device.stop()
            finally:device.close()
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
