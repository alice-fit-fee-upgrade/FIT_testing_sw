"""Compile per-25ns CFD pulses to chronological raw GTP words."""
from dataclasses import dataclass
from math import gcd, isfinite

UI_PS = 1000/6
BITS_PER_PERIOD = 150


@dataclass(frozen=True)
class Pulse:
    phase: int
    width: int
    enable: bool = True


def ticks(ns):
    if not isfinite(ns) or ns < 0:
        raise ValueError('time must be finite and nonnegative')
    return int(ns*6+0.5)


def compile_pattern(pulses, max_words=4096):
    """Repeat list until length aligns to 40 bits; widths wrap across loop.

    Overlaps merge physically and are reported. User list order is preserved.
    Widths may span multiple intervals, up to one complete expanded loop.
    """
    pulses = list(pulses)
    if not pulses: raise ValueError('empty pattern')
    for p in pulses:
        if not isinstance(p.phase, int) or not 0 <= p.phase < 150:
            raise ValueError('phase must be an integer in 0..149')
        if not isinstance(p.width, int) or p.width < 0:
            raise ValueError('width must be a nonnegative integer')
        if p.enable and p.width == 0: raise ValueError('enabled pulse needs width >=1')
    repeats = 40//gcd(len(pulses)*150, 40)
    expanded = pulses*repeats
    bit_count = len(expanded)*150
    if bit_count//40 > max_words: raise ValueError('pattern exceeds RAM capacity')
    if any(p.width > bit_count for p in pulses): raise ValueError('pulse width exceeds complete loop duration')
    bitmap = bytearray(bit_count)
    overlap = 0
    for period, p in enumerate(expanded):
        if not p.enable: continue
        for offset in range(p.width):
            bit = (period*150+p.phase+offset)%bit_count
            overlap += bool(bitmap[bit])
            bitmap[bit] = 1
    words = [sum(bitmap[start+i] << i for i in range(40)) for start in range(0,bit_count,40)]
    return {'words':words,'user_periods':len(pulses),'periods':len(expanded),
            'list_repeats':repeats,'overlap_bits':overlap,'ui_ps':UI_PS,
            'bits_per_period':150}
