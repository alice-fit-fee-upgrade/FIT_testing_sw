"""UART controls for the complete LV81 image; use with board_lock held."""
from math import lcm
import time
from host.device import Device
from host.lvds8 import compile_lane

class LVDSDevice(Device):
    def identify(self):
        self.abi=self.read(4)
        if self.read(0)!=0x4c563831 or self.abi not in (0x10000,0x10001,0x10002):
            raise RuntimeError('LV81 instrument ABI required')
        self.depth=self.read(0x78);self.slot=self.read(0x7c);self.channels=self.read(0x80)
        self.reference_hz=self.read(0x74)
        self.sample_hz=self.read(0xa8) if self.abi>=0x10002 else 1000000000
        self.period_bins=self.read(0xac) if self.abi>=0x10002 else 25
        self.clock_profile={0:'internal125',1:'external40',2:'lhc120',3:'external120'}[self.read(0xb0)] if self.abi>=0x10002 else ('external40' if self.reference_hz==40000000 else 'internal125')
        self.sample_ps=1e12/self.sample_hz
        if self.channels!=16 or self.depth!=4096:raise RuntimeError('unexpected LV81 dimensions')
    def status(self):
        value=self.read(0x0c)
        return dict(raw=value,ready=bool(value&1),busy=bool(value&2),valid=bool(value&4),
                    fault=bool(value&8),command_error=bool(value&16),pattern_error=bool(value&32),
                    pending=bool(value&64),active_bank=(value>>7)&1,
                    output_mask=self.read(0x10),enabled=bool(self.read(8)),slot=self.slot)
    def stop(self):
        self.write(8,0)
        if self.read(8):raise RuntimeError('FPGA outputs did not release')
    def directions(self,mask):
        if not 0<=mask<1<<self.channels:raise ValueError('invalid output mask')
        self.stop();self.write(0x10,mask)
        if self.read(0x10)!=mask or self.status()['command_error']:raise RuntimeError('direction rejected')
    def upload_lanes(self,lanes):
        compiled={ch:compile_lane(pattern,self.depth,period_bins=self.period_bins,sample_ps=self.sample_ps)['words'] for ch,pattern in lanes.items()}
        if not compiled or any(not 0<=ch<self.channels for ch in compiled):raise ValueError('invalid lanes')
        length=lcm(*(len(words) for words in compiled.values()))
        if length>self.depth:raise ValueError('combined pattern exceeds memory')
        status=self.status()
        if status['pending'] or status['busy']:raise RuntimeError('capture/swap busy')
        for i in range(length):
            word=sum(words[i%len(words)]<<(8*ch) for ch,words in compiled.items())
            self.write(0x24,i)
            for j in range(4):self.write(0x40+4*j,(word>>(32*j))&0xffffffff)
            self.write(0x30,1)
        self.write(0x34,length);self.write(0x38,1)
        deadline=time.monotonic()+1
        while self.status()['pending']:
            if time.monotonic()>deadline:raise TimeoutError('pattern swap')
        state=self.status()
        if state['command_error'] or state['pattern_error']:raise RuntimeError('pattern rejected')
    def enable(self):
        self.write(8,1)
        if not self.read(8):raise RuntimeError('TX enable rejected')
    def arm_test(self,words=4096,generator=False,measurement=True):
        """Arm independently; returned ticket identifies the next frozen capture."""
        if self.abi<0x10001:raise RuntimeError('shared trigger requires ABI 1.1')
        if not 1<=words<=self.depth:raise ValueError('invalid capture length')
        if not (generator or measurement):raise ValueError('nothing to arm')
        self.write(0x14,words)
        ticket=dict(words=words,generation=(self.read(0x64)+1)&0xffffffff,
                    output_mask=self.read(0x10) if (generator or self.read(8)) else 0)
        self.write(0x84,int(measurement)|(int(generator)<<1))
        if self.status()['command_error']:raise RuntimeError('test ARM rejected')
        return ticket
    def trigger(self):
        if self.abi<0x10001:raise RuntimeError('shared trigger requires ABI 1.1')
        self.write(0x88,1)
        if self.status()['command_error']:raise RuntimeError('software trigger rejected')
    def capture(self,words=4096,channels=None,metadata=None):
        if self.abi>=0x10001:
            ticket=self.arm_test(words);self.trigger()
        else:
            if not 1<=words<=self.depth:raise ValueError('invalid capture length')
            ticket=dict(words=words,generation=(self.read(0x64)+1)&0xffffffff,
                        output_mask=self.read(0x10) if self.read(8) else 0)
            self.write(0x14,words);self.write(0x18,1)
        return self.read_capture(ticket,channels,metadata)
    def read_capture(self,ticket,channels=None,metadata=None):
        words=ticket['words'];active_outputs=ticket['output_mask']
        channels=[n for n in range(self.channels) if not (active_outputs>>n)&1] if channels is None else list(channels)
        if not channels or any(not 0<=n<self.channels for n in channels):raise ValueError('invalid RX channels')
        if any((active_outputs>>n)&1 for n in channels):raise ValueError('cannot measure a driven/receiver-disabled lane')
        deadline=time.monotonic()+1
        while True:
            state=self.status()
            if state['fault'] or state['command_error']:raise RuntimeError('acquisition fault')
            if state['valid'] and self.read(0x64)==ticket['generation']:break
            if time.monotonic()>deadline:raise TimeoutError('acquisition')
        generation=self.read(0x64);output_mask=self.read(0x68);rows=[]
        for ch in channels:
            self.write(0x1c,ch);count=self.read(0x54)
            if count!=words:raise RuntimeError('partial capture')
            start=self.read(0x58)|(self.read(0x5c)<<32);previous=self.read(0x60)
            data=[]
            for i in range(count):
                self.write(0x20,i);value=self.read(0x50)
                if value>255:raise RuntimeError('invalid/frozen RAM read')
                data.append(value)
            row=dict(channel=ch,words=data,start_sample=start,previous=previous,valid=True)
            if self.abi>=0x10002 and self.period_bins==24:
                records=[];phase_count=self.read(0xb8)
                for i in range(phase_count):
                    self.write(0x20,i);record=self.read(0xbc)
                    if record==0xffffffff:raise RuntimeError('invalid phase record')
                    records.append(dict(frame=i,first_phase_bin=record&0xffff,
                        edge_count=(record>>16)&0x3fff,present=bool(record&(1<<30)),multiple=bool(record&(1<<31)),raw=record))
                row['phase_records']=records
                row['phase_origin']='first_captured_sample_uncalibrated'
                row['trailing_samples']=words*8-phase_count*24
            rows.append(row)
        if not self.status()['valid'] or self.read(0x64)!=generation:raise RuntimeError('capture changed while downloading')
        if len({row['start_sample'] for row in rows})!=1:raise RuntimeError('unaligned banks')
        trigger_metadata={}
        if self.abi>=0x10001:
            trigger_metadata=dict(trigger_id=self.read(0xa4),
                latest_trigger_id=self.read(0x90),trigger_cycle=self.read(0x94)|(self.read(0x98)<<32),
                trigger_player_position=self.read(0x9c),trigger_player_loop=self.read(0xa0),
                trigger_alignment='pattern_boundary_request',trigger_sample_calibrated=False)
        return dict(channels=rows,sample_ps=self.sample_ps,period_bins=self.period_bins,metadata={**(metadata or {}),**trigger_metadata,
                    'capture_id':generation,'output_mask':output_mask,'reference_hz_declared':self.reference_hz,
                    'clock_profile':self.clock_profile,
                    'reference_calibrated':False})
