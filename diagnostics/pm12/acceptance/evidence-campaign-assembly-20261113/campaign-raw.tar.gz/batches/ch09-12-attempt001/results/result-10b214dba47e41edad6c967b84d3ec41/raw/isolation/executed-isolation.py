import contextlib,sys,json,time,datetime
from pathlib import Path
P=Path('/home/codex-hil/fit-testing-publish/diagnostics/pm12');sys.path[:0]=[str(P/'acceptance'),str(P/'ipbus_adc'),'/home/codex-hil/kasli-phase-tester','/home/codex-hil/FIT_PM_FW_uPC/tools/hardware']
from lease import acquire
from station import console
from pm12_console_regression import capture
from pm12_power import wait_power_good,require_power_good
from host.pm_system_test import GatePhaseIPbusDevice,Client,HDMIAdapter,dio_directions,input_cards,run
root=Path(__file__).parent.parent;work=root/'batches/ch09-12-attempt001/working'
while not (work/'monitor-recheck/status.json').exists():time.sleep(1)
time.sleep(1);out=work/'hdmi-reset-isolation';out.mkdir();(out/'executed-isolation.py').write_text(Path(__file__).read_text());r=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),trace=[])
with contextlib.ExitStack() as st:
 for name in sorted(['atmel-ice-J41800043065','pm12-210249A73E43','kasli-diot-00001']):st.enter_context(acquire(Path.home()/'.cache'/(name+'.lock')))
 u=st.enter_context(console(dict(uart='/dev/serial/by-id/usb-Prolific_Technology_Inc._USB-Serial_Controller-if00-port0')));r['pgood']=wait_power_good(u,capture);r['mcu']=capture(u,'RS');assert 'Board S/N: 1803' in r['mcu']['reply']
 d=GatePhaseIPbusDevice();st.callback(d.close);c=Client();st.callback(c.close);r['pm_identity']=c.read(0,3);assert r['pm_identity']==[0x504d1202,0x10002,0xc7c42d28];input_cards(d)
 def snap(label):
  value=c.read(5,2);row=dict(label=label,uptime=value,seconds=time.monotonic());r['trace'].append(row);print(row,flush=True)
 class Traced(HDMIAdapter):
  def stop(self):
   snap('before FPGA pad release');super().stop();time.sleep(.02);snap('after FPGA pad release')
  def directions(self,mask):
   super().directions(mask);snap('outputs enabled')
 a=Traced(d)
 try:
  snap('initial')
  with dio_directions(a,a.mask):snap('idle inside')
  time.sleep(.1);snap('after idle direction restore')
  with dio_directions(a,a.mask):
   for address in [0,1,2]:
    snap('before read '+str(address));value=a.transfer(True,address);r.setdefault('spi',[]).append(dict(address=address,value=value));snap('after read '+str(address))
  time.sleep(.1);snap('after SPI direction restore')
 finally:
  a.stop();input_cards(d);r['pgood_after']=require_power_good(u,capture);r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'status.json').write_text(json.dumps(r,indent=2)+'\n')
 time.sleep(.2);safe=work/'board-safe-final';safe.mkdir();result=run(d,c,safe,('adc','tdc'),12);result['pgood']=require_power_good(u,capture);(safe/'result.json').write_text(json.dumps(result,indent=2)+'\n');assert result['pass']
print('SAFE_FINAL_PASS',flush=True)
